package com.zafarcrickethub.zchnewscardstudio.graphics

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.util.LruCache
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Urdu font: bundled Noto Nastaliq Urdu (assets/fonts) with system fallback. */
object Fonts {
    @Volatile private var urdu: Typeface? = null
    fun urdu(ctx: Context): Typeface = urdu ?: synchronized(this) {
        urdu ?: (try {
            Typeface.createFromAsset(ctx.assets, "fonts/NotoNastaliqUrdu-Regular.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT
        }).also { urdu = it }
    }
}

/** Memory-friendly bitmap loader (down-sampling + EXIF rotation + LRU cache). */
object Bmp {
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 8).toInt().coerceAtLeast(8 * 1024 * 1024)
    ) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    fun load(path: String?, maxDim: Int = 1600): Bitmap? {
        if (path.isNullOrBlank()) return null
        val key = "$path@$maxDim"
        cache.get(key)?.let { return it }
        if (!File(path).exists()) return null
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            var s = 1
            while (max(o.outWidth, o.outHeight) / (s * 2) >= maxDim) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            var b = BitmapFactory.decodeFile(path, o2) ?: return null
            val rot = try {
                when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                }
            } catch (e: Exception) { 0f }
            if (rot != 0f) {
                val m = Matrix().apply { postRotate(rot) }
                b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
            }
            cache.put(key, b)
            b
        } catch (e: Throwable) {
            null
        }
    }
}

/** Urdu-aware text drawing through StaticLayout (HarfBuzz shaping, RTL, bidi, wrapping). */
object TextKit {
    private val fit = ConcurrentHashMap<String, Float>()
    private val ticker = ConcurrentHashMap<String, StaticLayout>()
    private val layouts = ConcurrentHashMap<String, StaticLayout>()

    private fun paint(ctx: Context, size: Float, color: Int, bold: Boolean, latin: Boolean, shadow: Boolean) =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = if (latin) Typeface.DEFAULT_BOLD else Fonts.urdu(ctx)
            textSize = size
            this.color = color
            isFakeBoldText = bold && !latin
            if (shadow) setShadowLayer(5f, 0f, 2f, 0x99000000.toInt())
        }

    private fun layout(text: String, p: TextPaint, width: Int, center: Boolean, latin: Boolean): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width.coerceAtLeast(10))
            .setAlignment(if (center) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
            .setLineSpacing(0f, if (latin) 1.0f else 1.1f)
            .setIncludePad(true)
            .build()

    private fun hasArabic(t: String) = t.any { it.code in 0x0600..0x06FF || it.code in 0x0750..0x077F || it.code in 0xFB50..0xFEFF }

    /** The Nastaliq font has a very tall line box (a lot of it is empty space above / below the letters), so Urdu text is allowed
     *  to use this much more than the box height before it is shrunk. Without it the letters came out tiny in every template. */
    private const val URDU_SLACK = 1.4f

    /** Biggest size (never above `base`) at which the text fits the box; found by shrinking step by step. */
    private fun fitSize(ctx: Context, text: String, box: RectF, base: Float, bold: Boolean, lat: Boolean, center: Boolean): Float {
        val p = paint(ctx, base, 0, bold, lat, false)
        val maxH = box.height() * (if (lat) 1f else URDU_SLACK)
        var built = layout(text, p, box.width().toInt(), center, lat)
        while (built.height > maxH && p.textSize > 12f) {
            p.textSize *= 0.93f
            built = layout(text, p, box.width().toInt(), center, lat)
        }
        return p.textSize
    }

    /** v: 0 = top, 1 = centre, 2 = bottom. The text is first shrunk until it fits the box (never bigger than `base`);
     *  `scale` (the Text size slider) is then applied on top of that fitted size, so it always makes the text bigger or smaller.
     *  Urdu / Arabic script uses Nastaliq; pure English uses a bold sans font (TV look).
     *  Built layouts are cached: text shaping is expensive and every frame draws the same text. */
    fun draw(
        ctx: Context, cv: Canvas, text: String, box: RectF, base: Float, color: Int,
        bold: Boolean = true, center: Boolean = true, v: Int = 1, scale: Float = 1f,
        latin: Boolean = false, shadow: Boolean = true
    ) {
        if (text.isBlank() || box.width() < 8f || box.height() < 8f) return
        val lat = latin || !hasArabic(text)
        val key = "${text.hashCode()}|${text.length}|${box.width().toInt()}|${box.height().toInt()}|$base|$bold|$lat|$center"
        val lkey = "$key|$scale|$color|$shadow|${Thread.currentThread().id}"
        var lay = layouts[lkey]
        if (lay == null) {
            val fitted = fit[key] ?: fitSize(ctx, text, box, base, bold, lat, center).also {
                if (fit.size > 600) fit.clear()
                fit[key] = it
            }
            val p = paint(ctx, (fitted * scale).coerceAtLeast(8f), color, bold, lat, shadow)
            val built = layout(text, p, box.width().toInt(), center, lat)
            if (layouts.size > 500) layouts.clear()
            layouts[lkey] = built
            lay = built
        }
        val y = when (v) {
            0 -> box.top
            1 -> box.top + (box.height() - lay.height) / 2f
            else -> box.bottom - lay.height
        }
        cv.save()
        cv.clipRect(box.left - 30f, minOf(box.top - 40f, y - 12f), box.right + 30f, maxOf(box.bottom + 40f, y + lay.height + 12f))
        cv.translate(box.left, y)
        lay.draw(cv)
        cv.restore()
    }

    /** Single-line layout for the scrolling ticker. */
    fun tickerLayout(ctx: Context, text: String, size: Float, color: Int): StaticLayout {
        val t = text.replace('\n', ' ')
        val lat = !hasArabic(t)
        val key = "$t|$size|$color|${Thread.currentThread().id}"
        ticker[key]?.let { return it }
        val p = paint(ctx, size, color, lat, lat, false)
        val w = Math.ceil(Layout.getDesiredWidth(t, p).toDouble()).toInt() + 8
        val lay = layout(t, p, w, false, lat)
        if (ticker.size > 40) ticker.clear()
        ticker[key] = lay
        return lay
    }
}

object Shapes {
    fun star(cx: Float, cy: Float, r: Float): Path {
        val p = Path()
        for (i in 0 until 10) {
            val rad = if (i % 2 == 0) r else r * 0.4f
            val a = Math.toRadians(-90.0 + i * 36.0)
            val x = (cx + rad * cos(a)).toFloat()
            val y = (cy + rad * sin(a)).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }

    private fun key(raw: String): String {
        val n = raw.trim().lowercase()
        return when {
            listOf("pak", "پاکستان").any { n.contains(it) } -> "pak"
            listOf("ind", "بھارت", "انڈیا").any { n.contains(it) } -> "ind"
            listOf("eng", "انگلینڈ", "انگلستان").any { n.contains(it) } -> "eng"
            listOf("aus", "آسٹریلیا").any { n.contains(it) } -> "aus"
            listOf("south africa", "جنوبی افریقہ", "rsa").any { n.contains(it) } -> "rsa"
            listOf("new zealand", "نیوزی", "nz").any { n.contains(it) } -> "nz"
            listOf("sri", "سری لنکا").any { n.contains(it) } -> "sl"
            listOf("ban", "بنگلہ").any { n.contains(it) } -> "ban"
            listOf("afg", "افغان").any { n.contains(it) } -> "afg"
            listOf("west", "ویسٹ انڈیز", "wi").any { n.contains(it) } -> "wi"
            else -> "other"
        }
    }

    /** Simplified bundled flags (drawn with vector shapes, no downloads). */
    fun flag(cv: Canvas, team: String, r: RectF) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        fun box(l: Float, t: Float, rr: Float, b: Float, c: Int) { p.color = c; cv.drawRect(l, t, rr, b, p) }
        fun circle(cx: Float, cy: Float, rad: Float, c: Int) { p.color = c; cv.drawCircle(cx, cy, rad, p) }
        val clip = Path().apply { addRoundRect(r, 10f, 10f, Path.Direction.CW) }
        cv.save()
        cv.clipPath(clip)
        val w = r.width(); val h = r.height()
        when (key(team)) {
            "pak" -> {
                box(r.left, r.top, r.right, r.bottom, 0xFF01411C.toInt())
                box(r.left, r.top, r.left + w * 0.25f, r.bottom, 0xFFFFFFFF.toInt())
                val cx = r.left + w * 0.62f; val cy = r.centerY()
                circle(cx, cy, h * 0.3f, 0xFFFFFFFF.toInt())
                circle(cx + h * 0.1f, cy - h * 0.02f, h * 0.25f, 0xFF01411C.toInt())
                p.color = 0xFFFFFFFF.toInt()
                cv.drawPath(star(cx + h * 0.2f, cy - h * 0.12f, h * 0.11f), p)
            }
            "ind" -> {
                box(r.left, r.top, r.right, r.top + h / 3, 0xFFFF9933.toInt())
                box(r.left, r.top + h / 3, r.right, r.top + 2 * h / 3, 0xFFFFFFFF.toInt())
                box(r.left, r.top + 2 * h / 3, r.right, r.bottom, 0xFF138808.toInt())
                p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.03f; p.color = 0xFF000080.toInt()
                cv.drawCircle(r.centerX(), r.centerY(), h * 0.14f, p)
            }
            "eng" -> {
                box(r.left, r.top, r.right, r.bottom, 0xFFFFFFFF.toInt())
                box(r.centerX() - w * 0.07f, r.top, r.centerX() + w * 0.07f, r.bottom, 0xFFCE1124.toInt())
                box(r.left, r.centerY() - h * 0.1f, r.right, r.centerY() + h * 0.1f, 0xFFCE1124.toInt())
            }
            "aus" -> {
                box(r.left, r.top, r.right, r.bottom, 0xFF00008B.toInt())
                box(r.left, r.top, r.left + w * 0.5f, r.top + h * 0.5f, 0xFFFFFFFF.toInt())
                box(r.left + w * 0.22f, r.top, r.left + w * 0.28f, r.top + h * 0.5f, 0xFFCC0000.toInt())
                box(r.left, r.top + h * 0.22f, r.left + w * 0.5f, r.top + h * 0.28f, 0xFFCC0000.toInt())
                p.color = 0xFFFFFFFF.toInt()
                cv.drawPath(star(r.left + w * 0.72f, r.top + h * 0.7f, h * 0.14f), p)
                cv.drawPath(star(r.left + w * 0.25f, r.top + h * 0.75f, h * 0.12f), p)
            }
            "rsa" -> {
                box(r.left, r.top, r.right, r.centerY(), 0xFFDE3831.toInt())
                box(r.left, r.centerY(), r.right, r.bottom, 0xFF002395.toInt())
                box(r.left, r.centerY() - h * 0.08f, r.right, r.centerY() + h * 0.08f, 0xFF007A4D.toInt())
                box(r.left, r.top, r.left + w * 0.2f, r.bottom, 0xFF000000.toInt())
            }
            "nz" -> {
                box(r.left, r.top, r.right, r.bottom, 0xFF00247D.toInt())
                listOf(0.7f to 0.3f, 0.82f to 0.5f, 0.7f to 0.72f, 0.58f to 0.5f).forEach { (a, b) ->
                    circle(r.left + w * a, r.top + h * b, h * 0.07f, 0xFFCC142B.toInt())
                }
            }
            "sl" -> {
                box(r.left, r.top, r.right, r.bottom, 0xFFFFBE29.toInt())
                box(r.left + w * 0.04f, r.top + h * 0.06f, r.right - w * 0.04f, r.bottom - h * 0.06f, 0xFF8D153A.toInt())
                box(r.left + w * 0.04f, r.top + h * 0.06f, r.left + w * 0.2f, r.bottom - h * 0.06f, 0xFFEB7400.toInt())
            }
            "ban" -> {
                box(r.left, r.top, r.right, r.bottom, 0xFF006A4E.toInt())
                circle(r.centerX() - w * 0.04f, r.centerY(), h * 0.3f, 0xFFF42A41.toInt())
            }
            "afg" -> {
                box(r.left, r.top, r.left + w / 3, r.bottom, 0xFF000000.toInt())
                box(r.left + w / 3, r.top, r.left + 2 * w / 3, r.bottom, 0xFFD32011.toInt())
                box(r.left + 2 * w / 3, r.top, r.right, r.bottom, 0xFF007A36.toInt())
            }
            "wi" -> {
                box(r.left, r.top, r.right, r.bottom, 0xFF7B0041.toInt())
                box(r.left, r.centerY() - h * 0.12f, r.right, r.centerY() + h * 0.12f, 0xFFFFD100.toInt())
            }
            else -> {
                box(r.left, r.top, r.right, r.bottom, 0xFF37474F.toInt())
                p.color = 0xFFFFFFFF.toInt()
                cv.drawPath(star(r.centerX(), r.centerY(), h * 0.3f), p)
            }
        }
        cv.restore()
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = 0xCCFFFFFF.toInt()
        cv.drawRoundRect(r, 10f, 10f, p)
    }
}
