package com.zafarcrickethub.zchnewscardstudio.renderer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import com.zafarcrickethub.zchnewscardstudio.data.Card
import com.zafarcrickethub.zchnewscardstudio.data.Pal
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.graphics.Bmp
import com.zafarcrickethub.zchnewscardstudio.graphics.Shapes
import com.zafarcrickethub.zchnewscardstudio.graphics.TextKit
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Single drawing pipeline used by the editor preview, thumbnails AND the MP4 exporter,
 * so the preview matches the exported video. Everything is a pure function of time (tMs).
 *
 * Every template is built from LAYERS (background picture/scene, tint, light leaks, panels,
 * brackets, badges, text, flags ...). Each layer has its own entrance animation and delay.
 */
class FrameRenderer(private val ctx: Context, private val project: Project) {
    private val s = project.settings
    private val port = !s.landscape
    val dw = if (port) 720f else 1280f
    val dh = if (port) 1280f else 720f
    private val m = 24f
    private val pt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
    private val mtx = Matrix()
    private var curDur = 1000L
    private var allowExit = true

    private val tickerH get() = dh * (if (port) 0.055f else 0.085f)
    private val contentBottom get() = if (s.tickerOn) dh - tickerH else dh

    // ---------------------------------------------------------------- main entry
    fun render(cv: Canvas, w: Int, h: Int, tMs: Long) {
        val save = cv.save()
        cv.scale(w / dw, h / dh)
        cv.clipRect(0f, 0f, dw, dh)
        cv.drawColor(Pal.Navy)
        val cards = project.cards
        if (cards.isEmpty()) {
            fillGrad(cv, RectF(0f, 0f, dw, dh), Pal.Navy, Pal.DeepNavy)
            TextKit.draw(ctx, cv, "ZAFAR CRICKET HUB", RectF(40f, dh * 0.4f, dw - 40f, dh * 0.6f), 70f, Pal.Gold, latin = true)
            cv.restoreToCount(save)
            return
        }
        val idx = currentIndex(tMs)
        val cur = cards[idx]
        val lt = tMs - cur.startMs
        val prev = if (idx > 0) cards[idx - 1] else null
        var kind = cur.transition
        if (kind == 21) kind = 4 + (idx * 5) % 17          // "Auto (varied)"
        val td = cur.transMs.toLong().coerceIn(150L, 2500L)
        if (prev != null && lt in 0 until td && kind != 3) {
            val p = outCubic(lt / td.toFloat())
            val pl = (tMs - prev.startMs).coerceAtLeast(0L)
            transition(cv, kind, p, { drawCard(cv, prev, pl, false) }, { drawCard(cv, cur, lt, true) })
        } else {
            drawCard(cv, cur, lt.coerceAtLeast(0L), true)
        }
        drawTicker(cv, if (cur.tickerText.isNotBlank()) cur.tickerText else s.tickerText, tMs)
        drawLogo(cv, cur)
        cv.restoreToCount(save)
    }

    private fun currentIndex(t: Long): Int {
        val c = project.cards
        var best = -1
        for (i in c.indices) if (t >= c[i].startMs && t < c[i].endMs) best = i
        if (best >= 0) return best
        for (i in c.indices) if (t >= c[i].startMs) best = i
        return if (best >= 0) best else 0
    }

    private fun layer(cv: Canvas, alpha: Float, block: () -> Unit) {
        val sc = cv.saveLayerAlpha(0f, 0f, dw, dh, (alpha.coerceIn(0f, 1f) * 255).toInt())
        block()
        cv.restoreToCount(sc)
    }

    // ---------------------------------------------------------------- transitions (22)
    private fun transition(cv: Canvas, kind: Int, p: Float, prev: () -> Unit, cur: () -> Unit) {
        val cx = dw / 2f
        val cy = dh / 2f
        when (kind) {
            0 -> if (p < 0.5f) layer(cv, 1f - p * 2f, prev) else layer(cv, (p - 0.5f) * 2f, cur)
            1 -> { cv.save(); cv.translate(-p * dw * 0.3f, 0f); prev(); cv.restore(); cv.save(); cv.translate((1f - p) * dw, 0f); cur(); cv.restore() }
            2 -> { prev(); layer(cv, p, cur) }
            4 -> { cv.save(); cv.translate(p * dw * 0.3f, 0f); prev(); cv.restore(); cv.save(); cv.translate(-(1f - p) * dw, 0f); cur(); cv.restore() }
            5 -> { cv.save(); cv.translate(0f, -p * dh * 0.3f); prev(); cv.restore(); cv.save(); cv.translate(0f, (1f - p) * dh); cur(); cv.restore() }
            6 -> { cv.save(); cv.translate(0f, p * dh * 0.3f); prev(); cv.restore(); cv.save(); cv.translate(0f, -(1f - p) * dh); cur(); cv.restore() }
            7 -> { prev(); cv.save(); cv.clipRect(0f, 0f, dw * p, dh); cur(); cv.restore() }
            8 -> { prev(); cv.save(); cv.clipRect(dw * (1f - p), 0f, dw, dh); cur(); cv.restore() }
            9 -> { prev(); cv.save(); cv.clipRect(0f, 0f, dw, dh * p); cur(); cv.restore() }
            10 -> { prev(); cv.save(); val sc = 0.4f + 0.6f * p; cv.scale(sc, sc, cx, cy); layer(cv, p, cur); cv.restore() }
            11 -> { cur(); cv.save(); val sc = 1f + 0.6f * p; cv.scale(sc, sc, cx, cy); layer(cv, 1f - p, prev); cv.restore() }
            12 -> { cv.save(); cv.translate(-p * dw, 0f); prev(); cv.restore(); cv.save(); cv.translate((1f - p) * dw, 0f); cur(); cv.restore() }
            13 -> {
                prev(); cv.save()
                cv.clipPath(Path().apply { addCircle(cx, cy, hypot(cx, cy) * p, Path.Direction.CW) })
                cur(); cv.restore()
            }
            14 -> {
                prev(); cv.save()
                val path = Path()
                val n = 8
                val sw = dw / n
                for (i in 0 until n) path.addRect(RectF(i * sw, 0f, i * sw + sw * p, dh), Path.Direction.CW)
                cv.clipPath(path); cur(); cv.restore()
            }
            15 -> {
                prev(); cv.save()
                val t = (dw + dh * 0.5f) * p
                cv.clipPath(Path().apply { moveTo(0f, 0f); lineTo(t, 0f); lineTo(t - dh * 0.5f, dh); lineTo(0f, dh); close() })
                cur(); cv.restore()
            }
            16 -> {
                if (p < 0.5f) prev() else cur()
                pt.reset(); pt.color = ((1f - abs(2f * p - 1f)).coerceIn(0f, 1f) * 255).toInt() shl 24 or 0xFFFFFF
                cv.drawRect(0f, 0f, dw, dh, pt)
            }
            17 -> {
                prev(); cv.save()
                cv.rotate(-(1f - p) * 90f, cx, cy); val sc = 0.3f + 0.7f * p; cv.scale(sc, sc, cx, cy)
                layer(cv, p, cur); cv.restore()
            }
            18 -> {
                prev()
                for (k in 0 until 4) {
                    if (p > k * 0.12f) {
                        cv.save()
                        cv.clipRect(0f, dh * k / 4f, dw, dh * (k + 1) / 4f)
                        cv.translate((if (k % 2 == 0) 1f else -1f) * (1f - p) * 90f, 0f)
                        cur(); cv.restore()
                    }
                }
            }
            19 -> {
                cur()
                cv.save(); cv.clipRect(0f, 0f, cx, dh); cv.translate(-p * cx, 0f); prev(); cv.restore()
                cv.save(); cv.clipRect(cx, 0f, dw, dh); cv.translate(p * cx, 0f); prev(); cv.restore()
            }
            20 -> {
                if (p < 0.5f) {
                    val sx = 1f - 2f * p
                    if (sx > 0.02f) { cv.save(); cv.scale(sx, 1f, cx, cy); prev(); cv.restore() }
                } else {
                    val sx = (p - 0.5f) * 2f
                    if (sx > 0.02f) { cv.save(); cv.scale(sx, 1f, cx, cy); cur(); cv.restore() }
                }
            }
            else -> cur()
        }
    }

    // ---------------------------------------------------------------- easing
    private fun clamp01(x: Float) = x.coerceIn(0f, 1f)
    private fun outCubic(x: Float): Float { val y = 1f - clamp01(x); return 1f - y * y * y }
    private fun outBack(x: Float): Float { val t = clamp01(x) - 1f; return 1f + 2.70158f * t * t * t + 1.70158f * t * t }
    private fun outBounce(x0: Float): Float {
        var x = clamp01(x0)
        val n = 7.5625f
        val d = 2.75f
        return when {
            x < 1f / d -> n * x * x
            x < 2f / d -> { x -= 1.5f / d; n * x * x + 0.75f }
            x < 2.5f / d -> { x -= 2.25f / d; n * x * x + 0.9375f }
            else -> { x -= 2.625f / d; n * x * x + 0.984375f }
        }
    }
    private fun outElastic(x: Float): Float {
        val t = clamp01(x)
        if (t == 0f || t == 1f) return t
        return (Math.pow(2.0, -10.0 * t) * sin((t * 10.0 - 0.75) * (2.0 * Math.PI / 3.0)) + 1.0).toFloat()
    }

    // ---------------------------------------------------------------- primitives
    private fun shade(c: Int, f: Float) = Color.rgb(
        (Color.red(c) * f).toInt().coerceIn(0, 255), (Color.green(c) * f).toInt().coerceIn(0, 255), (Color.blue(c) * f).toInt().coerceIn(0, 255)
    )
    private fun fillRect(cv: Canvas, r: RectF, c: Int) { pt.reset(); pt.isAntiAlias = true; pt.color = c; cv.drawRect(r, pt) }
    private fun fillRR(cv: Canvas, r: RectF, rad: Float, c: Int) { pt.reset(); pt.isAntiAlias = true; pt.color = c; cv.drawRoundRect(r, rad, rad, pt) }
    private fun strokeRR(cv: Canvas, r: RectF, rad: Float, c: Int, w: Float) {
        pt.reset(); pt.isAntiAlias = true; pt.style = Paint.Style.STROKE; pt.strokeWidth = w; pt.color = c
        cv.drawRoundRect(r, rad, rad, pt)
    }
    private fun fillGrad(cv: Canvas, r: RectF, c1: Int, c2: Int, rad: Float = 0f) {
        pt.reset(); pt.isAntiAlias = true
        pt.shader = LinearGradient(r.left, r.top, r.left, r.bottom, c1, c2, Shader.TileMode.CLAMP)
        if (rad > 0f) cv.drawRoundRect(r, rad, rad, pt) else cv.drawRect(r, pt)
        pt.shader = null
    }
    private fun bgGrad(cv: Canvas, c: Int) = fillGrad(cv, RectF(0f, 0f, dw, dh), c, shade(c, 0.55f))

    private fun split(a: RectF, frac: Float): Pair<RectF, RectF> =
        if (!port) {
            val x = a.left + a.width() * frac
            RectF(a.left + m, a.top + m, x - m / 2, a.bottom - m) to RectF(x + m / 2, a.top + m, a.right - m, a.bottom - m)
        } else {
            val y = a.top + a.height() * frac
            RectF(a.left + m, a.top + m, a.right - m, y - m / 2) to RectF(a.left + m, y + m / 2, a.right - m, a.bottom - m)
        }

    // ---------------------------------------------------------------- layer entrance animations (24)
    private fun enter(cv: Canvas, kind: Int, lt: Long, durMs: Float, b: RectF, block: () -> Unit) {
        if (lt < 0) return
        val rp = clamp01(lt / durMs.coerceAtLeast(60f))
        val p = outCubic(rp)
        var alpha = 1f
        var clip: RectF? = null
        val cx = b.centerX()
        val cy = b.centerY()
        val sv = cv.save()
        when (kind) {
            0 -> alpha = p
            1 -> cv.translate((1f - p) * (dw - b.left + 20f), 0f)
            2 -> cv.translate(-(1f - p) * (b.right + 20f), 0f)
            3 -> cv.translate(0f, (1f - p) * (dh - b.top + 20f))
            4 -> { val sc = 0.5f + 0.5f * outBack(rp); cv.scale(sc, sc, cx, cy); alpha = min(1f, rp * 4f) }
            5 -> { val sc = 0.3f + 0.7f * p; cv.scale(sc, sc, cx, cy); alpha = p }
            6 -> cv.translate(0f, -(1f - p) * (b.bottom + 20f))
            7 -> { val sc = 2.2f - 1.2f * p; cv.scale(sc, sc, cx, cy); alpha = p }
            8 -> { cv.translate(0f, -(1f - outBounce(rp)) * (b.bottom + 40f)); alpha = min(1f, rp * 8f) }
            9 -> { cv.scale(1f, max(0.01f, outBack(rp)), cx, cy); alpha = min(1f, rp * 3f) }
            10 -> { cv.rotate(-30f * (1f - p), cx, cy); val sc = 0.8f + 0.2f * p; cv.scale(sc, sc, cx, cy); alpha = p }
            11 -> { cv.rotate(360f * (1f - p), cx, cy); val sc = 0.2f + 0.8f * p; cv.scale(sc, sc, cx, cy); alpha = p }
            12 -> clip = RectF(b.left - 40f, b.top - 80f, b.left - 40f + (b.width() + 80f) * p, b.bottom + 80f)
            13 -> clip = RectF(b.right + 40f - (b.width() + 80f) * p, b.top - 80f, b.right + 40f, b.bottom + 80f)
            14 -> clip = RectF(b.left - 40f, b.top - 80f, b.right + 40f, b.top - 80f + (b.height() + 160f) * p)
            15 -> { cv.translate((1f - outElastic(rp)) * dw * 0.4f, 0f); alpha = min(1f, rp * 5f) }
            16 -> { cv.translate(sin(rp * 40f) * (1f - rp) * 34f, 0f); alpha = min(1f, rp * 4f) }
            17 -> { cv.rotate(60f * (1f - rp) * (1f - rp) * cos(rp * 9f), cx, b.top); alpha = min(1f, rp * 5f) }
            18 -> if (rp < 0.8f) { val j = ((lt / 45L) % 3L).toInt(); cv.translate((j - 1) * 14f, 0f); alpha = if (j == 0) 0.35f else 1f }
            19 -> { cv.scale(3f - 2f * p, 1f, cx, cy); alpha = p }
            20 -> { cv.translate(-(1f - p) * (b.right + 20f), 0f); cv.skew(-0.35f * (1f - p), 0f) }
            21 -> alpha = if (rp < 0.7f) (if ((lt / 70L) % 2L == 0L) 1f else 0.15f) else 1f
            22 -> { val st = floor(rp * 22f) / 22f; clip = RectF(b.right + 40f - (b.width() + 80f) * st, b.top - 80f, b.right + 40f, b.bottom + 80f) }
            else -> { cv.translate(0f, (1f - p) * 46f); alpha = p }
        }
        val cr = clip
        if (cr != null) cv.clipRect(cr)
        if (alpha < 0.999f) {
            val sl = cv.saveLayerAlpha(b.left - 130f, b.top - 130f, b.right + 130f, b.bottom + 130f, (alpha.coerceIn(0f, 1f) * 255).toInt())
            block()
            cv.restoreToCount(sl)
        } else block()
        cv.restoreToCount(sv)
    }

    /** Panel / decoration layer with its own delay. */
    private fun fx(cv: Canvas, kind: Int, lt: Long, delay: Long, dur: Float, b: RectF, block: () -> Unit) =
        enter(cv, kind, lt - delay, dur, b, block)

    /** Text layer: the user's entrance animation, optional exit animation, optional looping effect. */
    private fun anim(cv: Canvas, c: Card, lt: Long, b: RectF, delay: Long = 0L, block: () -> Unit) {
        val ad = (c.animMs / c.animSpeed.coerceAtLeast(0.25f)).coerceAtLeast(120f)
        val rem = curDur - lt
        val exitMs = 450f
        val sv = cv.save()
        if (c.idleFx >= 2 && lt > delay + ad) {
            val ph = lt / 1000f
            if (c.idleFx == 2) { val sc = 1f + 0.018f * sin(ph * 3f); cv.scale(sc, sc, b.centerX(), b.centerY()) }
            else cv.translate(0f, sin(ph * 2.4f) * 6f)
        }
        if (allowExit && c.exitAnim > 0 && rem < exitMs) enter(cv, c.exitAnim - 1, rem, exitMs, b, block)
        else enter(cv, c.textAnim, lt - delay, ad, b, block)
        cv.restoreToCount(sv)
    }

    private fun tx(
        cv: Canvas, text: String, box: RectF, base: Float, color: Int, bold: Boolean = true, center: Boolean = true,
        v: Int = 1, scale: Float = 1f, latin: Boolean = false, shadow: Boolean = true
    ) = TextKit.draw(ctx, cv, text, box, base, color, bold, center, v, scale, latin, shadow)

    // ---------------------------------------------------------------- pictures
    private fun img(c: Card, slot: Int): String? = c.extraImages.getOrNull(slot)?.takeIf { it.isNotBlank() }

    private fun drawImage(cv: Canvas, c: Card, dest: RectF, lt: Long, dur: Long, rad: Float = 0f) =
        drawImg(cv, c.imagePath, dest, lt, dur, rad, c.imageAnim, c.imgScale, c.imgX, c.imgY)

    /** Extra match pictures; each slot pans in a different direction so galleries feel alive. */
    private fun drawExtra(cv: Canvas, c: Card, slot: Int, dest: RectF, lt: Long, dur: Long, rad: Float = 0f, optional: Boolean = false) {
        val p = img(c, slot)
        if (p == null && optional) return
        val an = if (c.imageAnim == 4) 4 else (c.imageAnim + slot + 1) % 14
        drawImg(cv, p, dest, lt, dur, rad, if (an == 4) 0 else an, 1f, 0f, 0f)
    }

    private fun drawImg(cv: Canvas, path: String?, dest: RectF, lt: Long, dur: Long, rad: Float, anim: Int, zoom0: Float, px0: Float, py0: Float) {
        val bmp: Bitmap? = Bmp.load(path)
        cv.save()
        if (rad > 0f) cv.clipPath(Path().apply { addRoundRect(dest, rad, rad, Path.Direction.CW) }) else cv.clipRect(dest)
        if (bmp == null) {
            // themed placeholder: night sky, green field, pitch
            fillGrad(cv, dest, 0xFF2B4A8C.toInt(), 0xFF0B1630.toInt())
            val gy = dest.top + dest.height() * 0.66f
            fillGrad(cv, RectF(dest.left, gy, dest.right, dest.bottom), 0xFF1F6B2E.toInt(), 0xFF0A2E12.toInt())
            pt.reset(); pt.isAntiAlias = true; pt.color = 0x33F2E3B0
            cv.drawPath(Path().apply {
                moveTo(dest.left + dest.width() * 0.46f, gy); lineTo(dest.left + dest.width() * 0.54f, gy)
                lineTo(dest.left + dest.width() * 0.66f, dest.bottom); lineTo(dest.left + dest.width() * 0.34f, dest.bottom); close()
            }, pt)
            pt.color = 0x44FFFFFF
            cv.drawCircle(dest.centerX(), dest.top + dest.height() * 0.3f, min(dest.width(), dest.height()) * 0.09f, pt)
        } else {
            val q = clamp01(lt.toFloat() / dur.coerceAtLeast(1))
            var zoom = zoom0.coerceIn(1f, 3f)
            var panX = px0
            var panY = py0
            var rot = 0f
            val sec = lt / 1000f
            when (anim) {
                0 -> zoom *= 1f + 0.15f * q
                1 -> zoom *= 1.15f - 0.15f * q
                2 -> { zoom *= 1.2f; panX += 1f - 2f * q }
                3 -> { zoom *= 1.2f; panX += -1f + 2f * q }
                5 -> { zoom *= 1.2f; panY += 1f - 2f * q }
                6 -> { zoom *= 1.2f; panY += -1f + 2f * q }
                7 -> { zoom *= 1.25f; panX += -1f + 2f * q; panY += 1f - 2f * q }
                8 -> zoom *= 1.08f + 0.06f * sin(sec * 1.6f)
                9 -> { zoom *= 1.18f; rot = -3f + 6f * q }
                10 -> { zoom *= 1.1f; panX += sin(sec * 9f) * 0.04f; panY += cos(sec * 7.3f) * 0.04f }
                11 -> zoom *= 1f + 0.35f * (1f - outCubic(lt / 1200f)) + 0.06f * q
                12 -> { zoom *= 1.3f - 0.3f * q; panX += 0.5f - q }
                13 -> { zoom *= 1.25f; panX += sin(q * 6.2832f) }
            }
            val bw = bmp.width.toFloat()
            val bh = bmp.height.toFloat()
            val dr = dest.width() / dest.height()
            var sw: Float
            var sh: Float
            if (bw / bh > dr) { sh = bh; sw = sh * dr } else { sw = bw; sh = sw / dr }
            sw /= zoom; sh /= zoom
            val left = (bw / 2f + panX.coerceIn(-1f, 1f) * (bw - sw) / 2f - sw / 2f).coerceIn(0f, bw - sw)
            val top = (bh / 2f + panY.coerceIn(-1f, 1f) * (bh - sh) / 2f - sh / 2f).coerceIn(0f, bh - sh)
            val sc = dest.width() / sw
            mtx.reset(); mtx.setScale(sc, sc); mtx.postTranslate(dest.left - left * sc, dest.top - top * sc)
            if (rot != 0f) cv.rotate(rot, dest.centerX(), dest.centerY())
            cv.drawBitmap(bmp, mtx, bmpPaint)
        }
        cv.restore()
    }

    // ---------------------------------------------------------------- decorative layers
    private fun bokeh(cv: Canvas, lt: Long, color: Int, n: Int) {
        pt.reset(); pt.isAntiAlias = true
        for (i in 0 until n) {
            val seed = i * 7919
            val bx = ((seed % 1000) / 1000f) * dw
            val speed = 14f + (i % 5) * 6f
            val r = 14f + (i % 4) * 12f
            val y = dh + r - ((lt / 1000f) * speed + (seed % 700)) % (dh + 2f * r)
            val x = bx + sin(lt / 1500f + i) * 24f
            val a = 0.05f + 0.05f * (i % 3)
            pt.color = (color and 0xFFFFFF) or ((a * 255).toInt() shl 24)
            cv.drawCircle(x, y, r, pt)
        }
    }

    private fun lightLeak(cv: Canvas, lt: Long, color: Int) {
        val cx = dw * (0.2f + 0.6f * (0.5f + 0.5f * sin(lt / 3000f)))
        pt.reset()
        pt.shader = RadialGradient(cx, dh * 0.22f, dh * 0.7f, (color and 0xFFFFFF) or 0x44000000, 0x00000000, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, dw, dh, pt)
        pt.shader = null
    }

    private fun sunburst(cv: Canvas, cx: Float, cy: Float, lt: Long, color: Int, rays: Int) {
        val rad = hypot(dw, dh)
        pt.reset(); pt.isAntiAlias = true; pt.color = color
        cv.save()
        cv.rotate(lt * 0.01f, cx, cy)
        val step = 360f / rays
        for (i in 0 until rays) cv.drawArc(RectF(cx - rad, cy - rad, cx + rad, cy + rad), i * step, step / 2f, true, pt)
        cv.restore()
    }

    /** Looping shine sweep over a panel (card option "Shine sweep"). */
    private fun shine(cv: Canvas, c: Card, lt: Long, r: RectF, rad: Float = 0f) {
        if (c.idleFx != 1 && c.idleFx != 4) return
        val period = 2600L
        val ph = (lt % period) / period.toFloat()
        if (ph > 0.55f) return
        val t = ph / 0.55f
        val bw = max(80f, r.width() * 0.22f)
        val x = r.left - bw + (r.width() + 2f * bw) * t
        val sk = r.height() * 0.3f
        cv.save()
        if (rad > 0f) cv.clipPath(Path().apply { addRoundRect(r, rad, rad, Path.Direction.CW) }) else cv.clipRect(r)
        pt.reset(); pt.isAntiAlias = true
        pt.shader = LinearGradient(x, 0f, x + bw, 0f, intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        cv.drawPath(Path().apply { moveTo(x + sk, r.top); lineTo(x + bw + sk, r.top); lineTo(x + bw, r.bottom); lineTo(x, r.bottom); close() }, pt)
        pt.shader = null
        cv.restore()
    }

    private fun brackets(cv: Canvas, r: RectF, color: Int, p: Float, len: Float = 60f, w: Float = 6f) {
        if (p <= 0.02f) return
        val l = len * p
        pt.reset(); pt.isAntiAlias = true; pt.color = color; pt.style = Paint.Style.STROKE; pt.strokeWidth = w; pt.strokeCap = Paint.Cap.SQUARE
        cv.drawLine(r.left, r.top, r.left + l, r.top, pt); cv.drawLine(r.left, r.top, r.left, r.top + l, pt)
        cv.drawLine(r.right, r.top, r.right - l, r.top, pt); cv.drawLine(r.right, r.top, r.right, r.top + l, pt)
        cv.drawLine(r.left, r.bottom, r.left + l, r.bottom, pt); cv.drawLine(r.left, r.bottom, r.left, r.bottom - l, pt)
        cv.drawLine(r.right, r.bottom, r.right - l, r.bottom, pt); cv.drawLine(r.right, r.bottom, r.right, r.bottom - l, pt)
    }

    private fun slant(cv: Canvas, r: RectF, skew: Float, c1: Int, c2: Int, stroke: Int = 0, sw: Float = 0f) {
        val path = Path().apply { moveTo(r.left + skew, r.top); lineTo(r.right, r.top); lineTo(r.right - skew, r.bottom); lineTo(r.left, r.bottom); close() }
        pt.reset(); pt.isAntiAlias = true
        pt.shader = LinearGradient(r.left, r.top, r.left, r.bottom, c1, c2, Shader.TileMode.CLAMP)
        cv.drawPath(path, pt); pt.shader = null
        if (sw > 0f) { pt.style = Paint.Style.STROKE; pt.strokeWidth = sw; pt.color = stroke; cv.drawPath(path, pt) }
    }

    private fun chip(cv: Canvas, r: RectF, text: String, c1: Int, c2: Int, fg: Int, size: Float = 34f) {
        fillGrad(cv, r, c1, c2, r.height() / 2f)
        tx(cv, text, RectF(r.left + 14f, r.top + 3f, r.right - 14f, r.bottom - 3f), size, fg, latin = true, shadow = false)
    }

    private fun liveBadge(cv: Canvas, x: Float, y: Float, lt: Long) {
        val r = RectF(x, y, x + 150f, y + 46f)
        fillRR(cv, r, 23f, Pal.Red)
        pt.reset(); pt.isAntiAlias = true; pt.color = if ((lt / 450L) % 2L == 0L) Pal.White else 0x66FFFFFF
        cv.drawCircle(r.left + 24f, r.centerY(), 9f, pt)
        tx(cv, "LIVE", RectF(r.left + 40f, r.top + 4f, r.right - 12f, r.bottom - 4f), 30f, Pal.White, latin = true, shadow = false)
    }

    /** Layers 0-2: full-bleed picture (or animated stadium scene), colour tint, vignette, light leak. */
    private fun bgLayer(cv: Canvas, c: Card, lt: Long, dur: Long, tint: Float, leak: Boolean = true, useImage: Boolean = true) {
        val full = RectF(0f, 0f, dw, dh)
        if (useImage && c.imagePath != null) drawImage(cv, c, full, lt, dur) else scene(cv, c, lt)
        pt.reset(); pt.color = (c.bgColor and 0xFFFFFF) or ((tint * 255).toInt() shl 24)
        cv.drawRect(full, pt)
        pt.reset(); pt.shader = RadialGradient(dw / 2f, dh / 2f, max(dw, dh) * 0.75f, 0x00000000, 0xAA000000.toInt(), Shader.TileMode.CLAMP)
        cv.drawRect(full, pt); pt.shader = null
        if (leak) lightLeak(cv, lt, Pal.Gold)
    }

    private fun scene(cv: Canvas, c: Card, lt: Long) {
        val full = RectF(0f, 0f, dw, dh)
        fillGrad(cv, full, shade(c.bgColor, 1.5f), shade(c.bgColor, 0.45f))
        for (k in 0..1) {
            val x = if (k == 0) dw * 0.12f else dw * 0.88f
            pt.reset(); pt.shader = RadialGradient(x, dh * 0.08f, dh * 0.55f, 0x66FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
            cv.drawRect(full, pt)
        }
        pt.shader = null
        val fy = dh * 0.68f
        pt.reset(); pt.isAntiAlias = true
        pt.shader = LinearGradient(0f, fy, 0f, dh, 0xFF1F6B2E.toInt(), 0xFF0A2E12.toInt(), Shader.TileMode.CLAMP)
        cv.drawOval(RectF(-dw * 0.3f, fy, dw * 1.3f, dh * 1.5f), pt); pt.shader = null
        pt.color = 0x33F2E3B0
        cv.drawPath(Path().apply { moveTo(dw * 0.47f, fy + dh * 0.02f); lineTo(dw * 0.53f, fy + dh * 0.02f); lineTo(dw * 0.62f, dh); lineTo(dw * 0.38f, dh); close() }, pt)
        bokeh(cv, lt, Pal.White, 12)
    }

    /** Red BREAKING NEWS banner at the top (slides in, blinking live dot, shine). Returns its bottom edge. */
    private fun topBanner(cv: Canvas, c: Card, lt: Long, a: RectF): Float {
        val h = if (port) 84f else 78f
        val r = RectF(0f, a.top, dw, a.top + h)
        val slide = (1f - clamp01(lt / 400f)).let { it * it }
        cv.save(); cv.translate(0f, -slide * h)
        fillGrad(cv, r, 0xFFE0112B.toInt(), Pal.DarkRed)
        fillRect(cv, RectF(0f, r.bottom - 6f, dw, r.bottom), Pal.Gold)
        shine(cv, c, lt, r)
        pt.reset(); pt.isAntiAlias = true
        pt.color = if ((lt / 500L) % 2L == 0L) Pal.White else 0x55FFFFFF
        cv.drawCircle(m + 20f, r.centerY() - 2f, 12f, pt)
        tx(cv, "BREAKING NEWS  |  بریکنگ نیوز", RectF(m * 2 + 30f, r.top + 6f, dw - m, r.bottom - 12f), 58f, Pal.White, latin = true)
        cv.restore()
        return r.bottom
    }

    /** Slanted red headline panel (headline + description) with its own staggered animations. */
    private fun headBand(cv: Canvas, c: Card, lt: Long, r: RectF, delay: Long) {
        fx(cv, 13, lt, delay, 600f, r) {
            slant(cv, r, 56f, 0xEEE0112B.toInt(), 0xEE7A0016.toInt(), Pal.Gold, 4f)
            shine(cv, c, lt, r)
        }
        val f = if (c.description.isBlank()) 1f else 0.62f
        val hb = RectF(r.left + 80f, r.top + 8f, r.right - 40f, r.top + r.height() * f)
        val db = RectF(r.left + 80f, hb.bottom, r.right - 40f, r.bottom - 8f)
        anim(cv, c, lt, hb, delay + 350) { tx(cv, c.headline, hb, 70f, c.textColor, scale = c.textScale) }
        anim(cv, c, lt, db, delay + 600) { tx(cv, c.description, db, 36f, 0xFFDDE3F0.toInt(), bold = false, scale = c.textScale) }
    }

    private fun versus(cv: Canvas, box: RectF, n1: String, n2: String) {
        val fh = box.height() * 0.6f
        val fw = fh * 1.5f
        val lx = box.centerX() - box.width() * 0.27f
        val rx = box.centerX() + box.width() * 0.27f
        val l = RectF(lx - fw / 2, box.top, lx + fw / 2, box.top + fh)
        val r = RectF(rx - fw / 2, box.top, rx + fw / 2, box.top + fh)
        Shapes.flag(cv, n1, l); Shapes.flag(cv, n2, r)
        tx(cv, "VS", RectF(box.centerX() - 50f, box.top, box.centerX() + 50f, box.top + fh), 44f, Pal.Gold, latin = true)
        tx(cv, n1, RectF(l.left - 30f, l.bottom + 2f, l.right + 30f, box.bottom), 28f, Pal.White, latin = true)
        tx(cv, n2, RectF(r.left - 30f, r.bottom + 2f, r.right + 30f, box.bottom), 28f, Pal.White, latin = true)
    }

    private fun scoreboard(cv: Canvas, r: RectF, items: List<Pair<String, String>>) {
        fillRR(cv, r, 16f, 0xE6050E26.toInt()); strokeRR(cv, r, 16f, Pal.Gold, 4f)
        val w = r.width() / items.size
        items.forEachIndexed { i, (k, v) ->
            val col = RectF(r.left + w * i, r.top, r.left + w * (i + 1), r.bottom)
            tx(cv, k, RectF(col.left, col.top + 8f, col.right, col.top + col.height() * 0.32f), 26f, Pal.Gold, latin = true)
            tx(cv, v.ifBlank { "-" }, RectF(col.left + 6f, col.top + col.height() * 0.32f, col.right - 6f, col.bottom - 8f), 64f, Pal.White, latin = true)
            if (i > 0) fillRect(cv, RectF(col.left - 1.5f, r.top + 14f, col.left + 1.5f, r.bottom - 14f), 0x55FFC107)
        }
    }

    private fun parseStats(s: String): List<Pair<String, String>> =
        s.lines().filter { it.isNotBlank() }.map { ln ->
            val i = ln.indexOfFirst { it == ':' || it == '=' }
            if (i < 0) ln.trim() to "" else ln.substring(0, i).trim() to ln.substring(i + 1).trim()
        }

    private fun drawCard(cv: Canvas, c: Card, lt: Long, exit: Boolean) {
        val a = RectF(0f, 0f, dw, contentBottom)
        val dur = (c.endMs - c.startMs).coerceAtLeast(1L)
        curDur = dur
        allowExit = exit
        when (c.template) {
            0 -> t0(cv, c, lt, a, dur)
            1 -> t1(cv, c, lt, a, dur)
            2 -> t2(cv, c, lt, a, dur)
            3 -> t3(cv, c, lt, a, dur)
            4 -> t4(cv, c, lt, a, dur)
            5 -> t5(cv, c, lt, a, dur)
            6 -> t6(cv, c, lt, a, dur)
            7 -> t7(cv, c, lt, a, dur)
            8 -> t8(cv, c, lt, a, dur)
            9 -> t9(cv, c, lt, a, dur)
            10 -> t10(cv, c, lt, a, dur)
            11 -> t11(cv, c, lt, a, dur)
            else -> t12(cv, c, lt, a, dur)
        }
    }

    // ================================================================= 13 layered templates
    // 0 ─ Classic Breaking News
    private fun t0(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgLayer(cv, c, lt, dur, 0.25f)
        val ah = a.height()
        brackets(cv, RectF(m * 1.5f, a.top + m * 1.5f, dw - m * 1.5f, a.bottom - m * 1.5f), Pal.Gold, outCubic(lt / 700f))
        val lb = RectF(m * 2, a.top + m * 2, m * 2 + 150f, a.top + m * 2 + 46f)
        fx(cv, 4, lt, 100, 500f, lb) { liveBadge(cv, lb.left, lb.top, lt) }
        val ph = ah * (if (port) 0.4f else 0.44f)
        val panel = RectF(-40f, a.bottom - ph - m * 2f, dw * (if (port) 1.04f else 0.9f), a.bottom - m * 2f)
        fx(cv, 13, lt, 150, 600f, panel) {
            slant(cv, panel, 70f, 0xFFE0112B.toInt(), Pal.DarkRed, Pal.Gold, 5f)
            shine(cv, c, lt, panel)
        }
        val tag = RectF(m * 2 + 10f, panel.top - 40f, m * 2 + 10f + 470f, panel.top + 34f)
        fx(cv, 4, lt, 450, 450f, tag) {
            slant(cv, tag, 28f, Pal.Gold, 0xFFC79100.toInt())
            tx(cv, "BREAKING NEWS  •  بریکنگ نیوز", RectF(tag.left + 40f, tag.top + 6f, tag.right - 20f, tag.bottom - 6f), 34f, Pal.DeepNavy, latin = true, shadow = false)
        }
        val x0 = panel.left + 110f
        val x1 = panel.right - 70f
        val hb = RectF(x0, panel.top + 52f, x1, panel.top + panel.height() * 0.66f)
        val db = RectF(x0, hb.bottom, x1, panel.bottom - 16f)
        anim(cv, c, lt, hb, 600) { tx(cv, c.headline, hb, 84f, c.textColor, scale = c.textScale) }
        anim(cv, c, lt, db, 850) { tx(cv, c.description, db, 40f, c.textColor, bold = false, scale = c.textScale) }
    }

    // 1 ─ Professional TV Bulletin
    private fun t1(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgLayer(cv, c, lt, dur, 0.3f)
        val ah = a.height()
        val bar = RectF(0f, a.top, dw, a.top + ah * (if (port) 0.2f else 0.24f))
        fx(cv, 6, lt, 0, 550f, bar) {
            fillGrad(cv, bar, 0xF2050E26.toInt(), 0xF20A1A3F.toInt())
            fillRect(cv, RectF(0f, bar.bottom - 6f, dw, bar.bottom), Pal.Gold)
            shine(cv, c, lt, bar)
        }
        val lineP = outCubic((lt - 500) / 600f)
        fillRect(cv, RectF(0f, bar.bottom, dw * lineP, bar.bottom + 4f), Pal.Red)
        val tabW = if (port) 150f else 210f
        val tab = RectF(0f, a.top, tabW, bar.bottom - 6f)
        fx(cv, 2, lt, 250, 450f, tab) {
            slant(cv, tab, 36f, Pal.Gold, 0xFFC79100.toInt())
            tx(cv, "NEWS", RectF(tab.left + 10f, tab.top + 8f, tab.right - 40f, tab.bottom - 8f), 56f, Pal.DeepNavy, latin = true, shadow = false)
        }
        val hb = RectF(tabW + 30f, bar.top + 10f, dw - m * 1.5f, bar.bottom - 16f)
        anim(cv, c, lt, hb, 500) { tx(cv, c.headline, hb, 76f, c.textColor, scale = c.textScale) }
        val plate = RectF(m * 2, a.bottom - ah * 0.22f - m, dw - m * 2, a.bottom - m)
        fx(cv, 13, lt, 800, 550f, plate) {
            fillRR(cv, plate, 14f, 0xDD000000.toInt())
            fillRect(cv, RectF(plate.right - 12f, plate.top + 8f, plate.right, plate.bottom - 8f), Pal.Red)
            shine(cv, c, lt, plate, 14f)
        }
        val db = RectF(plate.left + 20f, plate.top + 6f, plate.right - 34f, plate.bottom - 6f)
        anim(cv, c, lt, db, 1050) { tx(cv, c.description, db, 42f, c.textColor, bold = false, scale = c.textScale) }
        val tg = RectF(m * 2, plate.top - 40f, m * 2 + 250f, plate.top)
        fx(cv, 3, lt, 1000, 450f, tg) { chip(cv, tg, "BULLETIN", Pal.Red, Pal.DarkRed, Pal.White, 28f) }
    }

    // 2 ─ Cricket Sports News
    private fun t2(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgLayer(cv, c, lt, dur, 0.5f, leak = false)
        pt.reset(); pt.color = 0x0EFFFFFF
        val off = (lt * 0.05f) % 160f
        for (i in -3..((dw / 160f).toInt() + 3)) {
            val x = i * 160f + off
            cv.drawPath(Path().apply { moveTo(x, 0f); lineTo(x + 70f, 0f); lineTo(x + 70f - dh * 0.45f, dh); lineTo(x - dh * 0.45f, dh); close() }, pt)
        }
        val ah = a.height()
        val sbH = ah * (if (port) 0.2f else 0.26f)
        val panel = RectF(-60f, a.top, if (port) dw + 60f else dw * 0.68f, a.bottom - sbH - 16f)
        fx(cv, 2, lt, 0, 600f, panel) {
            slant(cv, panel, 90f, 0xE6081633.toInt(), 0xE6050E26.toInt(), Pal.Gold, 4f)
            shine(cv, c, lt, panel)
        }
        val vb = RectF(m * 2, a.top + m * 0.6f, panel.right - 110f, a.top + ah * 0.24f)
        fx(cv, 5, lt, 400, 500f, vb) { versus(cv, vb, c.team1, c.team2) }
        val hb = RectF(m * 2, a.top + ah * 0.27f, panel.right - 120f, panel.bottom - ah * 0.12f - 10f)
        val sb = RectF(m * 2, hb.bottom, panel.right - 120f, panel.bottom - 14f)
        anim(cv, c, lt, hb, 650) { tx(cv, c.headline, hb, 70f, c.textColor, scale = c.textScale) }
        anim(cv, c, lt, sb, 900) { tx(cv, if (c.status.isNotBlank()) c.status else c.description, sb, 36f, Pal.Gold, bold = false, scale = c.textScale) }
        val board = RectF(m, a.bottom - sbH - 4f, dw - m, a.bottom - 6f)
        fx(cv, 3, lt, 700, 550f, board) { scoreboard(cv, board, listOf("SCORE" to c.score, "OVERS" to c.overs, "WICKETS" to c.wickets)) }
    }

    // 3 ─ Headline News
    private fun t3(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgLayer(cv, c, lt, dur, 0.28f)
        val ah = a.height()
        val chipR = RectF(m * 2, a.top + m * 2, m * 2 + 290f, a.top + m * 2 + 60f)
        fx(cv, 2, lt, 100, 450f, chipR) {
            slant(cv, chipR, 24f, Pal.Red, Pal.DarkRed, Pal.White, 3f)
            tx(cv, "HEADLINE", RectF(chipR.left + 30f, chipR.top + 6f, chipR.right - 20f, chipR.bottom - 6f), 36f, Pal.White, latin = true, shadow = false)
        }
        val strip = RectF(dw - 46f, a.top, dw, a.bottom)
        fx(cv, 6, lt, 200, 500f, strip) { fillGrad(cv, strip, Pal.Gold, 0xFFC79100.toInt()); shine(cv, c, lt, strip) }
        val plate = RectF(m, a.bottom - ah * (if (port) 0.42f else 0.46f), dw - 70f, a.bottom - m)
        fx(cv, 12, lt, 350, 600f, plate) {
            fillRR(cv, plate, 20f, 0xE6050E26.toInt()); strokeRR(cv, plate, 20f, 0x55FFFFFF, 2f)
            shine(cv, c, lt, plate, 20f)
        }
        brackets(cv, plate, Pal.Gold, outCubic((lt - 700) / 600f), 46f, 5f)
        val hb = RectF(plate.left + 36f, plate.top + 22f, plate.right - 36f, plate.top + plate.height() * 0.62f)
        val lineW = hb.width() * outCubic((lt - 900) / 700f)
        fillRect(cv, RectF(hb.right - lineW, hb.bottom + 6f, hb.right, hb.bottom + 11f), Pal.Red)
        val db = RectF(hb.left, hb.bottom + 18f, hb.right, plate.bottom - 16f)
        anim(cv, c, lt, hb, 700) { tx(cv, c.headline, hb, 80f, c.textColor, scale = c.textScale) }
        anim(cv, c, lt, db, 1000) { tx(cv, c.description, db, 40f, 0xFFDDE3F0.toInt(), bold = false, scale = c.textScale) }
    }

    // 4 ─ Special Report (cinematic letter-box)
    private fun t4(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgLayer(cv, c, lt, dur, 0.18f)
        val ah = a.height()
        pt.reset(); pt.shader = LinearGradient(0f, dh * 0.3f, 0f, dh, 0x00000000, 0xEE000000.toInt(), Shader.TileMode.CLAMP)
        cv.drawRect(0f, dh * 0.3f, dw, dh, pt); pt.shader = null
        val bh = ah * 0.085f
        val lim = a.bottom - bh - 12f
        val titleY = lim - ah * 0.42f
        val lp = outCubic((lt - 200) / 700f)
        fillRect(cv, RectF(m * 2, titleY, m * 2 + 360f * lp, titleY + 5f), Pal.Gold)
        val tb = RectF(m * 2, titleY + 10f, dw - m * 2, titleY + 66f)
        fx(cv, 0, lt, 450, 500f, tb) { tx(cv, "SPECIAL REPORT  •  خصوصی رپورٹ", tb, 44f, Pal.Gold, center = false, latin = true) }
        val hb = RectF(m * 2, titleY + 70f, dw - m * 2, lim - ah * 0.12f)
        val db = RectF(m * 2, hb.bottom, dw - m * 2, lim)
        anim(cv, c, lt, hb, 700) { tx(cv, c.headline, hb, 88f, c.textColor, v = 2, scale = c.textScale) }
        anim(cv, c, lt, db, 1000) { tx(cv, c.description, db, 40f, c.textColor, bold = false, v = 0, scale = c.textScale) }
        val bp = outCubic(lt / 700f)
        fillRect(cv, RectF(0f, a.top - bh + bh * bp, dw, a.top + bh * bp), Pal.Black)
        fillRect(cv, RectF(0f, a.bottom - bh * bp, dw, a.bottom + bh - bh * bp), Pal.Black)
    }

    // 5 ─ Match Score Update
    private fun t5(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgLayer(cv, c, lt, dur, 0.55f)
        val ah = a.height()
        val panel = RectF(m * 2, a.top + ah * 0.1f, dw - m * 2, a.bottom - ah * 0.08f)
        fx(cv, 5, lt, 0, 550f, panel) {
            fillRR(cv, panel, 28f, 0xD9081633.toInt()); strokeRR(cv, panel, 28f, Pal.Gold, 4f)
            shine(cv, c, lt, panel, 28f)
        }
        val ch = RectF(panel.centerX() - 230f, panel.top - 30f, panel.centerX() + 230f, panel.top + 30f)
        fx(cv, 4, lt, 300, 450f, ch) { chip(cv, ch, "MATCH UPDATE  •  میچ اپ ڈیٹ", Pal.Red, Pal.DarkRed, Pal.White, 32f) }
        val ph = panel.height()
        val pw = panel.width()
        val hb = RectF(panel.left + 30f, panel.top + 40f, panel.right - 30f, panel.top + ph * 0.2f)
        anim(cv, c, lt, hb, 500) { tx(cv, c.headline, hb, 60f, c.textColor, scale = c.textScale) }
        val fw = if (port) pw * 0.3f else pw * 0.2f
        val fh = fw * 0.66f
        val rowCy = panel.top + ph * (if (port) 0.34f else 0.42f)
        val inset = pw * (if (port) 0.1f else 0.08f)
        val l = RectF(panel.left + inset, rowCy - fh / 2, panel.left + inset + fw, rowCy + fh / 2)
        val r = RectF(panel.right - inset - fw, rowCy - fh / 2, panel.right - inset, rowCy + fh / 2)
        fx(cv, 2, lt, 500, 550f, RectF(l.left - 40f, l.top, l.right + 40f, l.bottom + 60f)) {
            Shapes.flag(cv, c.team1, l)
            tx(cv, c.team1, RectF(l.left - 30f, l.bottom + 4f, l.right + 30f, l.bottom + 54f), 36f, Pal.White, latin = true)
        }
        fx(cv, 1, lt, 500, 550f, RectF(r.left - 40f, r.top, r.right + 40f, r.bottom + 60f)) {
            Shapes.flag(cv, c.team2, r)
            tx(cv, c.team2, RectF(r.left - 30f, r.bottom + 4f, r.right + 30f, r.bottom + 54f), 36f, Pal.White, latin = true)
        }
        val score = if (!port) RectF(l.right + 30f, panel.top + ph * 0.24f, r.left - 30f, panel.top + ph * 0.62f)
        else RectF(panel.left + 30f, panel.top + ph * 0.5f, panel.right - 30f, panel.top + ph * 0.66f)
        fx(cv, 4, lt, 750, 550f, score) { tx(cv, c.score.ifBlank { "-" }, score, 150f, Pal.Gold, latin = true) }
        val info = RectF(panel.left + 30f, panel.top + ph * (if (port) 0.69f else 0.72f), panel.right - 30f, panel.top + ph * (if (port) 0.79f else 0.84f))
        fx(cv, 3, lt, 950, 500f, info) {
            val half = (info.width() - m) / 2
            val b1 = RectF(info.left, info.top, info.left + half, info.bottom)
            val b2 = RectF(info.right - half, info.top, info.right, info.bottom)
            fillRR(cv, b1, 14f, 0x66000000); fillRR(cv, b2, 14f, 0x66000000)
            tx(cv, "OVERS  ${c.overs.ifBlank { "-" }}", b1, 44f, Pal.White, latin = true)
            tx(cv, "WICKETS  ${c.wickets.ifBlank { "-" }}", b2, 44f, Pal.White, latin = true)
        }
        val status = RectF(panel.left + 30f, panel.top + ph * (if (port) 0.82f else 0.87f), panel.right - 30f, panel.bottom - 24f)
        fx(cv, 13, lt, 1150, 550f, status) {
            fillRR(cv, status, 16f, Pal.Red); strokeRR(cv, status, 16f, Pal.Gold, 4f)
            tx(cv, c.status, RectF(status.left + 16f, status.top, status.right - 16f, status.bottom), 54f, Pal.White, scale = c.textScale)
        }
    }

    // 6 ─ Player Performance
    private fun t6(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgLayer(cv, c, lt, dur, 0.2f)
        val ah = a.height()
        val panel = if (!port) RectF(-60f, a.top, dw * 0.56f, a.bottom) else RectF(-60f, a.top + ah * 0.38f, dw + 60f, a.bottom)
        fx(cv, if (port) 3 else 2, lt, 0, 600f, panel) {
            slant(cv, panel, if (port) 0f else 110f, 0xEA081633.toInt(), 0xEA050E26.toInt(), Pal.Gold, 4f)
            shine(cv, c, lt, panel)
        }
        val x0 = panel.left + (if (port) 90f else 100f)
        val x1 = if (port) dw - m * 2 else panel.right - 130f
        val rib = RectF(x0, panel.top + m * 1.5f, min(x0 + 520f, x1), panel.top + m * 1.5f + 60f)
        fx(cv, 4, lt, 300, 450f, rib) { chip(cv, rib, "PLAYER PERFORMANCE", Pal.Red, Pal.DarkRed, Pal.White, 32f) }
        val ph = panel.height()
        val nb = RectF(x0, rib.bottom + 8f, x1, rib.bottom + ph * 0.2f)
        val hb = RectF(x0, nb.bottom, x1, nb.bottom + ph * 0.09f)
        anim(cv, c, lt, nb, 550) { tx(cv, c.playerName, nb, 90f, Pal.Gold, scale = c.textScale) }
        anim(cv, c, lt, hb, 750) { tx(cv, c.headline, hb, 38f, c.textColor, bold = false, scale = c.textScale) }
        val rows = parseStats(c.stats).take(6)
        val area = RectF(x0, hb.bottom + 10f, x1, panel.bottom - m)
        val rh = min(area.height() / 6f, 90f)
        rows.forEachIndexed { i, (k, v) ->
            val y = area.top + rh * i
            val row = RectF(area.left, y + 4f, area.right, y + rh - 4f)
            fx(cv, 2, lt, 800L + 130L * i, 450f, row) {
                fillRR(cv, row, 12f, 0x66000000)
                fillRect(cv, RectF(row.left, row.top + 8f, row.left + 6f, row.bottom - 8f), Pal.Gold)
                tx(cv, k, RectF(row.left + 20f, row.top, row.centerX(), row.bottom), 32f, c.textColor, bold = false, center = false, latin = true)
                tx(cv, v, RectF(row.centerX(), row.top, row.right - 16f, row.bottom), 46f, Pal.Gold, latin = true)
            }
        }
    }

    // 7 ─ Breaking News Alert
    private fun t7(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        val ah = a.height()
        val full = RectF(0f, 0f, dw, dh)
        fillGrad(cv, full, shade(c.bgColor, 1.15f), shade(c.bgColor, 0.4f))
        sunburst(cv, dw / 2f, dh * 0.5f, lt, 0x0EFFFFFF, 16)
        pt.reset(); pt.isAntiAlias = true; pt.color = 0x16FFFFFF
        val off = (lt * 0.08f) % 140f
        for (k in -4..((dw / 140f).toInt() + 4)) {
            val x = k * 140f + off
            cv.drawPath(Path().apply { moveTo(x, 0f); lineTo(x + 60f, 0f); lineTo(x + 60f - dh * 0.3f, dh); lineTo(x - dh * 0.3f, dh); close() }, pt)
        }
        pt.color = 0x1EFFFFFF
        cv.drawCircle(dw * 0.88f, a.top + ah * 0.5f, 70f + 45f * abs(sin(lt / 500.0)).toFloat(), pt)
        cv.drawCircle(dw * 0.1f, a.top + ah * 0.82f, 50f + 35f * abs(cos(lt / 650.0)).toFloat(), pt)
        val banner = RectF(0f, a.top + ah * 0.07f, dw, a.top + ah * 0.07f + ah * 0.16f)
        fx(cv, 2, lt, 0, 450f, banner) {
            fillRect(cv, banner, Pal.White)
            fillRect(cv, RectF(0f, banner.top, dw, banner.top + 7f), Pal.Gold); fillRect(cv, RectF(0f, banner.bottom - 7f, dw, banner.bottom), Pal.Gold)
            val pulse = 1f + 0.03f * sin(lt / 180f)
            cv.save(); cv.scale(pulse, pulse, banner.centerX(), banner.centerY())
            tx(cv, "BREAKING NEWS  |  بریکنگ نیوز", RectF(m, banner.top + 8f, dw - m, banner.bottom - 8f), 76f, Pal.Red, latin = true, shadow = false)
            cv.restore()
            shine(cv, c, lt, banner)
        }
        val body = RectF(0f, banner.bottom + m, dw, a.bottom - m)
        val txt: RectF
        if (c.imagePath != null) {
            val r = if (!port) min(body.height() * 0.5f, dw * 0.2f) else dw * 0.26f
            val ccx = if (!port) dw * 0.8f else dw / 2f
            val ccy = if (!port) body.centerY() else body.top + r + 10f
            fx(cv, 11, lt, 350, 700f, RectF(ccx - r - 30f, ccy - r - 30f, ccx + r + 30f, ccy + r + 30f)) {
                cv.save()
                cv.clipPath(Path().apply { addCircle(ccx, ccy, r, Path.Direction.CW) })
                drawImg(cv, c.imagePath, RectF(ccx - r, ccy - r, ccx + r, ccy + r), lt, dur, 0f, c.imageAnim, c.imgScale, c.imgX, c.imgY)
                cv.restore()
                pt.reset(); pt.isAntiAlias = true; pt.style = Paint.Style.STROKE; pt.strokeWidth = 8f; pt.color = Pal.Gold
                cv.drawCircle(ccx, ccy, r, pt)
                pt.color = Pal.White; pt.strokeWidth = 6f
                for (k in 0 until 3) cv.drawArc(RectF(ccx - r - 20f, ccy - r - 20f, ccx + r + 20f, ccy + r + 20f), lt * 0.2f + k * 120f, 70f, false, pt)
            }
            txt = if (!port) RectF(m * 2, body.top, dw * 0.8f - r - 40f, body.bottom) else RectF(m * 2, ccy + r + 30f, dw - m * 2, body.bottom)
        } else txt = RectF(m * 2, body.top, dw - m * 2, body.bottom)
        fx(cv, 13, lt, 500, 600f, txt) { fillRR(cv, txt, 20f, 0x99000000.toInt()); shine(cv, c, lt, txt, 20f) }
        val hb = RectF(txt.left + 16f, txt.top + 10f, txt.right - 16f, txt.top + txt.height() * 0.62f)
        val db = RectF(txt.left + 16f, hb.bottom, txt.right - 16f, txt.bottom - 10f)
        anim(cv, c, lt, hb, 750) { tx(cv, c.headline, hb, 92f, c.textColor, scale = c.textScale) }
        anim(cv, c, lt, db, 1000) { tx(cv, c.description, db, 42f, c.textColor, bold = false, scale = c.textScale) }
        val flash = 1f - clamp01(lt / 500f)
        if (flash > 0f) { pt.reset(); pt.color = ((flash * 200).toInt() shl 24) or 0xFFFFFF; cv.drawRect(full, pt) }
    }

    // 8 ─ Match Photo Collage (tilted photos, top breaking banner)
    private fun photo(cv: Canvas, c: Card, path: String?, cx: Float, cy: Float, w: Float, h: Float, ang: Float, lt: Long, dur: Long, kind: Int, delay: Long, slot: Int) {
        val b = RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
        fx(cv, kind, lt, delay, 650f, RectF(b.left - 30f, b.top - 30f, b.right + 30f, b.bottom + 30f)) {
            cv.save(); cv.rotate(ang, cx, cy)
            fillRR(cv, RectF(b.left + 8f, b.top + 12f, b.right + 8f, b.bottom + 12f), 10f, 0x66000000)
            fillRR(cv, RectF(b.left - 10f, b.top - 10f, b.right + 10f, b.bottom + 10f), 8f, Pal.White)
            val an = if (c.imageAnim == 4) 0 else (c.imageAnim + slot) % 14
            drawImg(cv, path, b, lt, dur, 4f, an, if (slot == 0) c.imgScale else 1f, if (slot == 0) c.imgX else 0f, if (slot == 0) c.imgY else 0f)
            cv.restore()
        }
    }

    private fun t8(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgLayer(cv, c, lt, dur, 0.5f, useImage = false)
        val ah = a.height()
        val top = topBanner(cv, c, lt, a) + 14f
        val band = ah * (if (port) 0.2f else 0.26f)
        val g = RectF(m, top, dw - m, a.bottom - band - 24f)
        val gw = g.width()
        val gh = g.height()
        if (!port) {
            photo(cv, c, c.imagePath, g.left + gw * 0.33f, g.centerY(), gw * 0.46f, gh * 0.86f, -4f, lt, dur, 10, 200, 0)
            photo(cv, c, img(c, 0), g.left + gw * 0.75f, g.top + gh * 0.3f, gw * 0.3f, gh * 0.48f, 5f, lt, dur, 4, 450, 1)
            photo(cv, c, img(c, 1), g.left + gw * 0.78f, g.top + gh * 0.74f, gw * 0.3f, gh * 0.42f, -3f, lt, dur, 4, 650, 2)
        } else {
            photo(cv, c, c.imagePath, g.centerX(), g.top + gh * 0.3f, gw * 0.8f, gh * 0.48f, -3f, lt, dur, 10, 200, 0)
            photo(cv, c, img(c, 0), g.left + gw * 0.28f, g.top + gh * 0.78f, gw * 0.42f, gh * 0.34f, 4f, lt, dur, 4, 450, 1)
            photo(cv, c, img(c, 1), g.left + gw * 0.74f, g.top + gh * 0.78f, gw * 0.42f, gh * 0.34f, -4f, lt, dur, 4, 650, 2)
        }
        headBand(cv, c, lt, RectF(-30f, g.bottom + 14f, dw + 30f, a.bottom - 8f), 850)
    }

    // 9 ─ Match Day Live (full-bleed picture, picture-in-picture, score strip with flags)
    private fun t9(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgLayer(cv, c, lt, dur, 0.3f)
        pt.reset(); pt.shader = LinearGradient(0f, 0f, 0f, dh, 0x33000000, 0xEE000000.toInt(), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, dw, dh, pt); pt.shader = null
        val ah = a.height()
        val top = topBanner(cv, c, lt, a) + 14f
        brackets(cv, RectF(m * 1.5f, top, dw - m * 1.5f, a.bottom - m), Pal.Gold, outCubic((lt - 300) / 700f), 50f, 5f)
        val lb = RectF(m * 2, top + 10f, m * 2 + 150f, top + 56f)
        fx(cv, 4, lt, 300, 450f, lb) { liveBadge(cv, lb.left, lb.top, lt) }
        val pw = if (port) dw * 0.38f else dw * 0.22f
        val pip = RectF(dw - m * 2 - pw, top + 10f, dw - m * 2, top + 10f + pw * 0.7f)
        if (img(c, 0) != null) fx(cv, 4, lt, 500, 550f, pip) {
            drawExtra(cv, c, 0, pip, lt, dur, 12f, optional = true); strokeRR(cv, pip, 12f, Pal.Gold, 4f)
        }
        val sh = ah * (if (port) 0.22f else 0.3f)
        val strip = RectF(m, a.bottom - sh - 8f, dw - m, a.bottom - 8f)
        fx(cv, 3, lt, 400, 600f, strip) {
            fillRR(cv, strip, 18f, 0xEE050E26.toInt()); strokeRR(cv, strip, 18f, Pal.Gold, 4f)
            shine(cv, c, lt, strip, 18f)
        }
        val topRow = RectF(strip.left + 16f, strip.top + 10f, strip.right - 16f, strip.top + strip.height() * 0.72f)
        val fh = strip.height() * (if (port) 0.26f else 0.42f)
        val fw = fh * 1.5f
        val l = RectF(topRow.left, topRow.centerY() - fh / 2, topRow.left + fw, topRow.centerY() + fh / 2)
        val r = RectF(topRow.right - fw, topRow.centerY() - fh / 2, topRow.right, topRow.centerY() + fh / 2)
        val nw = topRow.width() * (if (port) 0.2f else 0.17f)
        fx(cv, 2, lt, 800, 500f, RectF(l.left, topRow.top, l.right + nw + 12f, topRow.bottom)) {
            Shapes.flag(cv, c.team1, l)
            tx(cv, c.team1, RectF(l.right + 6f, topRow.top, l.right + 6f + nw, topRow.bottom), 40f, Pal.White, latin = true)
        }
        fx(cv, 1, lt, 800, 500f, RectF(r.left - nw - 12f, topRow.top, r.right, topRow.bottom)) {
            Shapes.flag(cv, c.team2, r)
            tx(cv, c.team2, RectF(r.left - 6f - nw, topRow.top, r.left - 6f, topRow.bottom), 40f, Pal.White, latin = true)
        }
        val center = RectF(l.right + nw + 12f, topRow.top, r.left - nw - 12f, topRow.bottom)
        fx(cv, 4, lt, 1000, 550f, center) {
            tx(cv, c.score.ifBlank { "-" }, RectF(center.left, center.top, center.right, center.top + center.height() * 0.68f), 110f, Pal.Gold, latin = true)
            tx(cv, "OVERS ${c.overs.ifBlank { "-" }}  •  WKTS ${c.wickets.ifBlank { "-" }}", RectF(center.left, center.top + center.height() * 0.68f, center.right, center.bottom), 30f, Pal.White, latin = true)
        }
        val bottom = RectF(strip.left + 16f, topRow.bottom, strip.right - 16f, strip.bottom - 8f)
        anim(cv, c, lt, bottom, 1200) { tx(cv, c.status, bottom, 40f, Pal.Gold, bold = false, scale = c.textScale) }
        val hb = RectF(m * 2 + 60f, strip.top - ah * 0.2f - 14f, dw - m * 2, strip.top - 14f)
        fx(cv, 13, lt, 600, 550f, hb) { slant(cv, RectF(hb.left - 70f, hb.top, hb.right + 20f, hb.bottom), 50f, 0xDDE0112B.toInt(), 0xDD7A0016.toInt(), Pal.Gold, 3f) }
        anim(cv, c, lt, hb, 800) { tx(cv, c.headline, hb, 74f, c.textColor, scale = c.textScale) }
    }

    // 10 ─ Triple Photo Gallery (slanted photo panels)
    private fun t10(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgLayer(cv, c, lt, dur, 0.5f, useImage = false)
        val ah = a.height()
        val top = topBanner(cv, c, lt, a) + 14f
        val band = ah * (if (port) 0.2f else 0.24f)
        val g = RectF(m, top, dw - m, a.bottom - band - 24f)
        val gap = 12f
        val paths = listOf(c.imagePath, img(c, 0), img(c, 1))
        val kinds = intArrayOf(6, 3, 6)
        for (i in 0 until 3) {
            val b: RectF
            val shape = Path()
            if (!port) {
                val sk = 70f
                val wi = (g.width() + 2f * sk - 2f * gap) / 3f
                val x = g.left + i * (wi - sk + gap)
                b = RectF(x, g.top, x + wi, g.bottom)
                shape.moveTo(x + sk, g.top); shape.lineTo(x + wi, g.top); shape.lineTo(x + wi - sk, g.bottom); shape.lineTo(x, g.bottom); shape.close()
            } else {
                val hi = (g.height() - 2f * gap) / 3f
                val y = g.top + i * (hi + gap)
                b = RectF(g.left, y, g.right, y + hi)
                shape.addRoundRect(b, 16f, 16f, Path.Direction.CW)
            }
            fx(cv, kinds[i], lt, 100L + 220L * i, 600f, b) {
                cv.save(); cv.clipPath(shape)
                val an = if (c.imageAnim == 4) 0 else (c.imageAnim + i) % 14
                drawImg(cv, paths[i], b, lt, dur, 0f, an, if (i == 0) c.imgScale else 1f, if (i == 0) c.imgX else 0f, if (i == 0) c.imgY else 0f)
                cv.restore()
                pt.reset(); pt.isAntiAlias = true; pt.style = Paint.Style.STROKE; pt.strokeWidth = 4f; pt.color = Pal.Gold
                cv.drawPath(shape, pt)
                pt.style = Paint.Style.FILL; pt.color = Pal.Red
                cv.drawCircle(b.left + 70f, b.top + 40f, 24f, pt)
                tx(cv, "${i + 1}", RectF(b.left + 46f, b.top + 16f, b.left + 94f, b.top + 64f), 34f, Pal.White, latin = true, shadow = false)
            }
        }
        headBand(cv, c, lt, RectF(-30f, g.bottom + 14f, dw + 30f, a.bottom - 8f), 850)
    }

    // 11 ─ Player of the Match (rotating sun-burst, framed hero picture, stat rows)
    private fun t11(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        fillGrad(cv, RectF(0f, 0f, dw, dh), shade(c.bgColor, 1.1f), shade(Pal.DarkRed, 0.55f))
        val top = topBanner(cv, c, lt, a) + 8f
        val pic: RectF
        val r: RectF
        if (!port) {
            val x = dw * 0.42f
            pic = RectF(m * 1.5f, top + 8f, x - m * 0.5f, a.bottom - m)
            r = RectF(x + m * 0.5f, top + 8f, dw - m * 1.5f, a.bottom - m)
        } else {
            val y = top + (a.bottom - top) * 0.42f
            pic = RectF(m * 1.5f, top + 8f, dw - m * 1.5f, y - m * 0.5f)
            r = RectF(m * 1.5f, y + m * 0.5f, dw - m * 1.5f, a.bottom - m)
        }
        sunburst(cv, pic.centerX(), pic.centerY(), lt, 0x14FFC107, 16)
        fx(cv, 5, lt, 100, 650f, pic) {
            drawImage(cv, c, pic, lt, dur, 22f); strokeRR(cv, pic, 22f, Pal.Gold, 6f); shine(cv, c, lt, pic, 22f)
        }
        val sw = min(pic.width(), pic.height()) * 0.38f
        val small = RectF(pic.left + 10f, pic.bottom - 10f - sw * 0.75f, pic.left + 10f + sw, pic.bottom - 10f)
        if (img(c, 0) != null) fx(cv, 4, lt, 650, 500f, small) {
            drawExtra(cv, c, 0, small, lt, dur, 10f, optional = true); strokeRR(cv, small, 10f, Pal.White, 3f)
        }
        val bcx = pic.right - 56f
        val bcy = pic.top + 56f
        fx(cv, 11, lt, 700, 700f, RectF(bcx - 70f, bcy - 70f, bcx + 70f, bcy + 70f)) {
            cv.save(); cv.rotate(lt * 0.03f, bcx, bcy)
            pt.reset(); pt.isAntiAlias = true; pt.color = Pal.Gold
            cv.drawPath(Shapes.star(bcx, bcy, 64f), pt)
            cv.restore()
            tx(cv, "MOTM", RectF(bcx - 40f, bcy - 20f, bcx + 40f, bcy + 20f), 30f, Pal.DeepNavy, latin = true, shadow = false)
        }
        val h = r.height()
        val chipR = RectF(r.left, r.top, r.right, r.top + h * 0.1f)
        fx(cv, 2, lt, 300, 450f, chipR) { chip(cv, chipR, "PLAYER OF THE MATCH  •  مین آف دی میچ", Pal.Gold, 0xFFC79100.toInt(), Pal.DeepNavy, 32f) }
        val nb = RectF(r.left, chipR.bottom + 4f, r.right, r.top + h * 0.28f)
        val hb = RectF(r.left, nb.bottom, r.right, r.top + h * 0.38f)
        anim(cv, c, lt, nb, 550) { tx(cv, c.playerName, nb, 90f, Pal.Gold, scale = c.textScale) }
        anim(cv, c, lt, hb, 750) { tx(cv, c.headline, hb, 38f, c.textColor, bold = false, scale = c.textScale) }
        val rows = parseStats(c.stats).take(4)
        val area = RectF(r.left, r.top + h * 0.4f, r.right, r.top + h * 0.8f)
        val rh = area.height() / 4f
        rows.forEachIndexed { i, (k, v) ->
            val y = area.top + rh * i
            val row = RectF(area.left, y + 4f, area.right, y + rh - 4f)
            fx(cv, 2, lt, 850L + 130L * i, 450f, row) {
                fillRR(cv, row, 12f, 0x55000000)
                fillRect(cv, RectF(row.left, row.top + 8f, row.left + 6f, row.bottom - 8f), Pal.Gold)
                tx(cv, k, RectF(row.left + 20f, row.top, row.centerX(), row.bottom), 32f, c.textColor, bold = false, center = false, latin = true)
                tx(cv, v, RectF(row.centerX(), row.top, row.right - 16f, row.bottom), 46f, Pal.Gold, latin = true)
            }
        }
        val vs = RectF(r.left, r.top + h * 0.82f, r.right, r.bottom)
        fx(cv, 3, lt, 1300, 500f, vs) { versus(cv, vs, c.team1, c.team2) }
    }

    // 12 ─ Stadium Photo Story (full-bleed picture, film strip, layered lower third)
    private fun filmStrip(cv: Canvas, c: Card, lt: Long, dur: Long, r: RectF, vertical: Boolean) {
        fillRR(cv, r, 8f, 0xF0101010.toInt())
        pt.reset(); pt.isAntiAlias = true; pt.color = 0xFF3A3A3A.toInt()
        if (vertical) {
            var y = r.top + 10f
            while (y < r.bottom - 14f) {
                cv.drawRoundRect(RectF(r.left + 4f, y, r.left + 14f, y + 14f), 3f, 3f, pt)
                cv.drawRoundRect(RectF(r.right - 14f, y, r.right - 4f, y + 14f), 3f, 3f, pt)
                y += 26f
            }
        } else {
            var x = r.left + 10f
            while (x < r.right - 14f) {
                cv.drawRoundRect(RectF(x, r.top + 4f, x + 14f, r.top + 14f), 3f, 3f, pt)
                cv.drawRoundRect(RectF(x, r.bottom - 14f, x + 14f, r.bottom - 4f), 3f, 3f, pt)
                x += 26f
            }
        }
        val f1: RectF
        val f2: RectF
        if (vertical) {
            f1 = RectF(r.left + 20f, r.top + 12f, r.right - 20f, r.centerY() - 4f)
            f2 = RectF(r.left + 20f, r.centerY() + 4f, r.right - 20f, r.bottom - 12f)
        } else {
            f1 = RectF(r.left + 12f, r.top + 20f, r.centerX() - 4f, r.bottom - 20f)
            f2 = RectF(r.centerX() + 4f, r.top + 20f, r.right - 12f, r.bottom - 20f)
        }
        drawExtra(cv, c, 0, f1, lt, dur, 4f)
        drawExtra(cv, c, 1, f2, lt, dur, 4f)
    }

    private fun t12(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgLayer(cv, c, lt, dur, 0.15f)
        pt.reset(); pt.shader = LinearGradient(0f, dh * 0.35f, 0f, dh, 0x00000000, 0xDD000000.toInt(), Shader.TileMode.CLAMP)
        cv.drawRect(0f, dh * 0.35f, dw, dh, pt); pt.shader = null
        val ah = a.height()
        val top = topBanner(cv, c, lt, a) + 14f
        val strip: RectF
        if (!port) {
            val sw = dw * 0.2f
            strip = RectF(dw - m - sw - 30f, top, dw - m, top + sw * 0.68f * 2f + 36f)
        } else {
            val sw = (dw - 2f * m - 12f) / 2f
            strip = RectF(m, top, dw - m, top + sw * 0.68f + 40f)
        }
        fx(cv, if (port) 2 else 1, lt, 300, 650f, strip) { filmStrip(cv, c, lt, dur, strip, !port) }
        val panelTop = a.bottom - ah * (if (port) 0.3f else 0.3f)
        val bar = RectF(m, panelTop - 12f, if (port) dw - m else dw * 0.72f, panelTop - 4f)
        fx(cv, 12, lt, 400, 500f, bar) { fillRect(cv, bar, Pal.Gold) }
        val panel = RectF(m, panelTop, if (port) dw - m else dw * 0.72f, a.bottom - m * 0.6f)
        fx(cv, 13, lt, 550, 600f, panel) {
            fillRR(cv, panel, 16f, 0xEE7A0016.toInt()); fillRect(cv, RectF(panel.left, panel.top + 10f, panel.left + 10f, panel.bottom - 10f), Pal.Gold)
            shine(cv, c, lt, panel, 16f)
        }
        val hb = RectF(panel.left + 24f, panel.top + 6f, panel.right - 16f, panel.top + panel.height() * (if (c.description.isBlank()) 0.95f else 0.62f))
        val db = RectF(panel.left + 24f, hb.bottom, panel.right - 16f, panel.bottom - 6f)
        anim(cv, c, lt, hb, 800) { tx(cv, c.headline, hb, 72f, c.textColor, scale = c.textScale) }
        anim(cv, c, lt, db, 1050) { tx(cv, c.description, db, 36f, 0xFFDDE3F0.toInt(), bold = false, scale = c.textScale) }
    }

    // ---------------------------------------------------------------- ticker + logo
    private fun drawTicker(cv: Canvas, text: String, tMs: Long) {
        if (!s.tickerOn) return
        val th = tickerH; val top = dh - th
        fillRect(cv, RectF(0f, top, dw, dh), s.tickerBg)
        fillRect(cv, RectF(0f, top, dw, top + 4f), Pal.Gold)
        val lw = dw * (if (port) 0.34f else 0.2f)
        val vr = dw - lw
        if (text.isNotBlank()) {
            val lay = TextKit.tickerLayout(ctx, text, th * 0.5f * s.tickerSize, s.tickerColor)
            val tw = lay.width.toFloat()
            val period = vr + tw
            val x = vr - ((tMs / 1000f) * s.tickerSpeed) % period   // right-to-left scrolling
            cv.save(); cv.clipRect(0f, top + 4f, vr, dh)
            cv.translate(x, top + (th - lay.height) / 2f); lay.draw(cv); cv.restore()
        }
        val label = RectF(vr, top, dw, dh)
        fillRect(cv, label, Pal.Red)
        TextKit.draw(ctx, cv, s.tickerLabel, RectF(label.left + 8f, label.top + 4f, label.right - 8f, label.bottom - 4f), th * 0.5f, Pal.White, latin = true, shadow = false)
    }

    private fun drawLogo(cv: Canvas, c: Card) {
        if (!s.showLogo) return
        val bmp = Bmp.load(s.logoPath, 800)
        val lw = dw * s.logoSize
        val lh = if (bmp != null) lw * bmp.height / bmp.width else lw * 0.34f
        val nameH = if (bmp != null && s.showChannelName) lw * 0.18f else 0f
        val total = lh + nameH
        val mg = 20f
        val x = if (c.logoPos == 0 || c.logoPos == 2) mg else dw - mg - lw
        val y = if (c.logoPos < 2) mg else contentBottom - mg - total
        val sc = cv.saveLayerAlpha(x - 20f, y - 20f, x + lw + 20f, y + total + 20f, (s.logoOpacity.coerceIn(0f, 1f) * 255).toInt())
        if (bmp != null) {
            cv.drawBitmap(bmp, null, RectF(x, y, x + lw, y + lh), bmpPaint)
            if (s.showChannelName) TextKit.draw(ctx, cv, s.channelName, RectF(x - 10f, y + lh, x + lw + 10f, y + total), lw * 0.12f, Pal.White, latin = true)
        } else {
            val r = RectF(x, y, x + lw, y + lh)
            fillRR(cv, r, lh / 2, 0xE60A1A3F.toInt()); strokeRR(cv, r, lh / 2, Pal.Gold, 3f)
            pt.reset(); pt.isAntiAlias = true; pt.color = Pal.Red
            cv.drawCircle(r.left + lh / 2, r.centerY(), lh * 0.34f, pt)
            pt.color = Pal.White; pt.style = Paint.Style.STROKE; pt.strokeWidth = 2.5f
            cv.drawArc(RectF(r.left + lh * 0.3f, r.centerY() - lh * 0.2f, r.left + lh * 0.9f, r.centerY() + lh * 0.2f), 200f, 140f, false, pt)
            val tb = RectF(r.left + lh * 0.95f, r.top + lh * 0.12f, r.right - lh * 0.3f, r.bottom - lh * 0.12f)
            TextKit.draw(ctx, cv, if (s.showChannelName) s.channelName else "ZCH", tb, lh * 0.5f, Pal.White, latin = true, shadow = false)
        }
        cv.restoreToCount(sc)
    }
}

object Thumbs {
    fun render(ctx: Context, project: Project, card: Card, width: Int, tMs: Long = 3500): Bitmap {
        val dur = maxOf(card.endMs - card.startMs, 6000L)
        val p = project.copy(cards = listOf(card.copy(startMs = 0, endMs = dur)))
        val r = FrameRenderer(ctx, p)
        val h = (width * r.dh / r.dw).toInt()
        val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
        r.render(Canvas(bmp), width, h, tMs)
        return bmp
    }
}
