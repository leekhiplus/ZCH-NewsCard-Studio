package com.zafarcrickethub.zchnewscardstudio.utils

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Optional online voice-over: Google AI Studio (Gemini API) text-to-speech.
 * Only used when the user pastes an API key and presses "Generate voice-over".
 * The script text is sent to Google; nothing else leaves the device.
 */
object GeminiTts {
    val voices = listOf(
        "Kore", "Puck", "Charon", "Fenrir", "Aoede", "Zephyr", "Leda", "Orus", "Achird", "Sadaltager",
        "Schedar", "Gacrux", "Algenib", "Umbriel", "Sulafat", "Vindemiatrix", "Rasalgethi", "Despina"
    )
    val models = listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts", "gemini-2.5-pro-preview-tts")

    class TtsException(message: String) : Exception(message)

    /** Returns 16-bit mono PCM and its sample rate. Blocking: call from a background thread. */
    fun synthesize(apiKey: String, model: String, voice: String, text: String, style: String): Pair<ByteArray, Int> {
        if (apiKey.isBlank()) throw TtsException("Paste your Google AI Studio API key first")
        if (text.isBlank()) throw TtsException("Write the voice-over script first")
        val prompt = if (style.isBlank()) text.trim() else style.trim().trimEnd(':') + ":\n" + text.trim()
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))))
            })
        }
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent")
        val con = url.openConnection() as HttpURLConnection
        try {
            con.requestMethod = "POST"
            con.connectTimeout = 20_000
            con.readTimeout = 180_000
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json")
            con.setRequestProperty("x-goog-api-key", apiKey.trim())
            con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = con.responseCode
            val raw = (if (code in 200..299) con.inputStream else con.errorStream)?.use { it.readBytes() }?.toString(Charsets.UTF_8) ?: ""
            if (code !in 200..299) throw TtsException(friendlyError(code, raw))
            val root = JSONObject(raw)
            val parts = root.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw TtsException("Google returned no audio. Try a different model or shorter text.")
            val out = ByteArrayOutputStream()
            var rate = 24000
            for (i in 0 until parts.length()) {
                val inl = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                val data = inl.optString("data")
                if (data.isEmpty()) continue
                Regex("rate=(\\d+)").find(inl.optString("mimeType"))?.let { rate = it.groupValues[1].toInt() }
                out.write(Base64.decode(data, Base64.DEFAULT))
            }
            if (out.size() == 0) throw TtsException("Google returned no audio data")
            return out.toByteArray() to rate
        } finally {
            con.disconnect()
        }
    }

    internal fun friendlyError(code: Int, raw: String): String {
        val msg = try { JSONObject(raw).optJSONObject("error")?.optString("message") ?: "" } catch (e: Exception) { "" }
        return when (code) {
            400 -> if (msg.contains("API key", true)) "API key is not valid. Copy it again from aistudio.google.com/apikey" else "Request rejected: $msg"
            401, 403 -> "API key rejected or this model is not allowed for your key. $msg"
            404 -> "Model not found. Choose another model in Settings."
            429 -> "Quota or rate limit reached. Wait a minute or use another key/model."
            in 500..599 -> "Google server error ($code). Try again in a moment."
            else -> "Error $code: $msg"
        }
    }

    /** Wraps raw 16-bit mono PCM in a WAV container so the normal audio pipeline can use it. */
    fun pcmToWav(pcm: ByteArray, sampleRate: Int, channels: Int = 1): ByteArray {
        val byteRate = sampleRate * channels * 2
        val bb = java.nio.ByteBuffer.allocate(44 + pcm.size).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(channels.toShort())
        bb.putInt(sampleRate); bb.putInt(byteRate); bb.putShort((channels * 2).toShort()); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return bb.array()
    }
}
