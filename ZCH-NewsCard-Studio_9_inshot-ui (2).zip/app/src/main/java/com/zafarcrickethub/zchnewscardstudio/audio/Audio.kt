package com.zafarcrickethub.zchnewscardstudio.audio

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.nio.ByteOrder
import kotlin.math.abs

object AudioUtils {
    fun duration(path: String): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    fun audioTrack(ex: MediaExtractor): Int {
        for (i in 0 until ex.trackCount) {
            if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) return i
        }
        return -1
    }

    fun canDecode(path: String): Boolean {
        val ex = MediaExtractor()
        return try {
            ex.setDataSource(path)
            val t = audioTrack(ex)
            if (t < 0) false else {
                val mime = ex.getTrackFormat(t).getString(MediaFormat.KEY_MIME)!!
                MediaCodec.createDecoderByType(mime).release()
                true
            }
        } catch (e: Exception) {
            false
        } finally {
            ex.release()
        }
    }

    /** Decodes the file once and returns normalised peak levels (0..1) for the waveform view. */
    fun waveform(path: String, bins: Int = 400): FloatArray {
        val durMs = duration(path).coerceAtLeast(1L)
        val peaks = FloatArray(bins)
        val ex = MediaExtractor()
        var dec: MediaCodec? = null
        try {
            ex.setDataSource(path)
            val t = audioTrack(ex)
            if (t < 0) return peaks
            ex.selectTrack(t)
            val fmt = ex.getTrackFormat(t)
            dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            dec.configure(fmt, null, null, 0)
            dec.start()
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            while (!outDone) {
                if (!inDone) {
                    val i = dec.dequeueInputBuffer(5000)
                    if (i >= 0) {
                        val n = ex.readSampleData(dec.getInputBuffer(i)!!, 0)
                        if (n < 0) {
                            dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true
                        } else {
                            dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance()
                        }
                    }
                }
                val o = dec.dequeueOutputBuffer(info, 5000)
                if (o >= 0) {
                    if (info.size > 0) {
                        val sb = dec.getOutputBuffer(o)!!.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        var mx = 0
                        var k = 0
                        val n = info.size / 2
                        while (k < n) { mx = maxOf(mx, abs(sb.get(k).toInt())); k += 8 }
                        val bin = ((info.presentationTimeUs / 1000L) * bins / durMs).toInt().coerceIn(0, bins - 1)
                        peaks[bin] = maxOf(peaks[bin], mx / 32768f)
                    }
                    dec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
        } catch (e: Exception) {
            // partial waveform is fine
        } finally {
            try { dec?.stop() } catch (_: Exception) {}
            try { dec?.release() } catch (_: Exception) {}
            ex.release()
        }
        val mx = peaks.maxOrNull() ?: 0f
        if (mx > 0f) for (i in peaks.indices) peaks[i] = peaks[i] / mx
        return peaks
    }
}

class Voice {
    private var mp: MediaPlayer? = null
    val ready get() = mp != null
    fun load(path: String?) {
        release()
        if (path == null) return
        mp = try {
            MediaPlayer().apply { setDataSource(path); prepare() }
        } catch (e: Exception) { null }
    }
    fun play() { try { mp?.start() } catch (_: Exception) {} }
    fun pause() { try { if (mp?.isPlaying == true) mp?.pause() } catch (_: Exception) {} }
    fun seek(ms: Long) { try { mp?.seekTo(ms.toInt()) } catch (_: Exception) {} }
    val pos: Long get() = try { mp?.currentPosition?.toLong() ?: 0L } catch (_: Exception) { 0L }
    val isPlaying: Boolean get() = try { mp?.isPlaying == true } catch (_: Exception) { false }
    fun volume(v: Float) { try { mp?.setVolume(v, v) } catch (_: Exception) {} }
    fun release() { try { mp?.release() } catch (_: Exception) {}; mp = null }
}

/** Shared play-head: voice-over (when present) acts as the clock, otherwise wall-clock time. */
class VoiceClip(val path: String, val startMs: Long, val endMs: Long)

class Playback {
    val voice = Voice()
    var clips: List<VoiceClip> = emptyList()
    private var cvp: MediaPlayer? = null
    private var cvpPath: String? = null

    private fun stopClip() { try { cvp?.release() } catch (_: Exception) {}; cvp = null; cvpPath = null }
    private fun pauseClip() { try { if (cvp?.isPlaying == true) cvp?.pause() } catch (_: Exception) {} }

    /** Plays the voice clip that belongs to the card under the play-head. */
    private fun syncClip() {
        if (!playing) { pauseClip(); return }
        val c = clips.firstOrNull { positionMs >= it.startMs && positionMs < it.endMs }
        if (c == null) { stopClip(); return }
        if (cvpPath != c.path) {
            stopClip()
            cvpPath = c.path
            cvp = try { MediaPlayer().apply { setDataSource(c.path); prepare() } } catch (e: Exception) { null }
            try { cvp?.seekTo((positionMs - c.startMs).toInt()); cvp?.start() } catch (_: Exception) {}
        } else if (cvp != null && cvp?.isPlaying == false && positionMs - c.startMs < 300) {
            try { cvp?.seekTo((positionMs - c.startMs).toInt()); cvp?.start() } catch (_: Exception) {}
        }
    }

    fun releaseClips() = stopClip()
    var positionMs by mutableLongStateOf(0L)
    var playing by mutableStateOf(false)
    var totalMs: Long = 0L
    var audioMs: Long = 0L

    fun load(path: String?, volume: Float, dur: Long) {
        pause()
        voice.load(path)
        voice.volume(volume)
        audioMs = if (voice.ready) dur else 0L
    }

    fun play() {
        if (positionMs >= totalMs) positionMs = 0
        if (voice.ready && positionMs < audioMs) { voice.seek(positionMs); voice.play() }
        playing = true
        stopClip(); syncClip()
    }

    fun pause() { voice.pause(); playing = false; pauseClip() }
    fun toggle() { if (playing) pause() else play() }

    fun seek(ms: Long) {
        positionMs = ms.coerceIn(0L, totalMs.coerceAtLeast(0L))
        if (voice.ready) {
            voice.seek(positionMs)
            if (playing && positionMs < audioMs) voice.play()
        }
        stopClip()
        if (playing) syncClip()
    }

    /** Moves the play-head only (no audio seek). Used while the finger scrubs / flings the timeline: seeking the
     *  MediaPlayer on every touch event made the timeline stutter. Call seek() once when the scrub ends. */
    fun scrub(ms: Long) {
        positionMs = ms.coerceIn(0L, totalMs.coerceAtLeast(0L))
    }

    fun tick(deltaMs: Long) {
        if (!playing) return
        positionMs = if (voice.ready && voice.isPlaying) voice.pos else positionMs + deltaMs
        syncClip()
        if (positionMs >= totalMs) { positionMs = totalMs; pause() }
    }
}
