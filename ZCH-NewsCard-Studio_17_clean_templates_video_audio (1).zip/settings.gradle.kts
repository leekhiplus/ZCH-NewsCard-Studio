pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // uCrop (image cropper) is published only on JitPack.
        maven("https://jitpack.io") { content { includeGroup("com.github.yalantis") } }
        // TarsosDSP (audio analysis) is published on the author's own Maven server.
        maven("https://mvn.0110.be/releases") { content { includeGroup("be.tarsos.dsp") } }
    }
}
rootProject.name = "ZCHNewsCardStudio"
include(":app")
