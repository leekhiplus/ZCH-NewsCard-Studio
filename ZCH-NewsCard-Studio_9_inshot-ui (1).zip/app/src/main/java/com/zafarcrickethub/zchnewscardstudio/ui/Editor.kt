package com.zafarcrickethub.zchnewscardstudio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Surface
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.zafarcrickethub.zchnewscardstudio.data.Overlay
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Palette
import androidx.compose.runtime.produceState
import androidx.compose.ui.layout.ContentScale
import com.zafarcrickethub.zchnewscardstudio.data.pictures
import com.zafarcrickethub.zchnewscardstudio.graphics.Bmp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zafarcrickethub.zchnewscardstudio.audio.Playback
import com.zafarcrickethub.zchnewscardstudio.data.Opt
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.data.Samples
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportState
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportUi
import com.zafarcrickethub.zchnewscardstudio.renderer.Thumbs
import com.zafarcrickethub.zchnewscardstudio.utils.GeminiTts
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.floor
import com.zafarcrickethub.zchnewscardstudio.data.Card as NCard

@Composable
fun PlaybackLoop(pb: Playback) {
    LaunchedEffect(pb.playing) {
        if (pb.playing) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                pb.tick((now - last) / 1_000_000L)
                last = now
            }
        }
    }
}

// =====================================================================================
//  InShot-style editor: top bar · big preview · play row · tool row · timeline
// =====================================================================================
private val EdBg = Color(0xFF232323)
private val EdMuted = Color(0xFFB4B4B4)

@Composable
fun EditorScreen(vm: MainViewModel) {
    val p = vm.current ?: run { vm.go(Screen.Projects); return }
    PlaybackLoop(vm.playback)
    AiDialogs(vm)
    if (vm.showExport) { ExportScreen(vm, p); return }
    val ec = vm.editingCard
    if (ec != null) { CardEditor(vm, p, ec); return }
    var picker by remember { mutableStateOf(0) }       // 1 = add a card, 2 = change the template of the selected card
    var full by remember { mutableStateOf(false) }
    var help by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val pickPicture = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importOverlayPicture(u) }
    val selCard = if (vm.sel.startsWith("card:")) p.cards.find { it.id == vm.sel.removePrefix("card:") } else null
    val selOv = if (vm.sel.startsWith("ov:")) p.overlays.find { it.id == vm.sel.removePrefix("ov:") } else null
    if (picker != 0) TemplatePicker(if (picker == 1) "Add a card" else "Change template", { picker = 0 }, false) { t ->
        if (picker == 1) vm.addCard(t) else selCard?.let { c -> vm.updateCard(c.id) { it.copy(template = t) } }
        picker = 0
    }
    if (full) FullScreenPreview(vm, p) { full = false }
    if (help) HelpDialog { help = false }
    LaunchedEffect(vm.sheet, selOv?.id) { if (vm.sheet == "overlay" && selOv == null) vm.sheet = "" }
    val dragFn: ((Float, Float) -> Unit)? = selOv?.let { o ->
        { dx: Float, dy: Float -> vm.updateOverlay(o.id) { it.copy(x = (it.x + dx).coerceIn(0f, 1f), y = (it.y + dy).coerceIn(0f, 1f)) } }
    }

    Column(Modifier.fillMaxSize().background(EdBg).statusBarsPadding().navigationBarsPadding()) {
        // top bar
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            IconButton(onClick = { help = true }) { Icon(Icons.Default.HelpOutline, "Help", tint = Color.White) }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { vm.playback.pause(); vm.showExport = true }) {
                Text("Export", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
        // preview
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp), contentAlignment = Alignment.Center) {
            FitPreview(p, { vm.playback.positionMs }, Modifier.fillMaxSize(), onDrag = dragFn)
        }
        // undo · redo · play · full screen
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.undo() }, enabled = vm.undoCount > 0) { Icon(Icons.AutoMirrored.Filled.Undo, "Undo", tint = if (vm.undoCount > 0) Color.White else Color(0xFF5A5A5A)) }
            IconButton(onClick = { vm.redo() }, enabled = vm.redoCount > 0) { Icon(Icons.AutoMirrored.Filled.Redo, "Redo", tint = if (vm.redoCount > 0) Color.White else Color(0xFF5A5A5A)) }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); vm.playback.toggle() }, modifier = Modifier.size(56.dp)) {
                Icon(if (vm.playback.playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play / Pause", tint = Color.White, modifier = Modifier.size(42.dp))
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { vm.zoomDp = (vm.zoomDp / 1.4f).coerceAtLeast(12f) }) { Icon(Icons.Default.ZoomOut, "Zoom out", tint = Color.White) }
            IconButton(onClick = { vm.zoomDp = (vm.zoomDp * 1.4f).coerceAtMost(500f) }) { Icon(Icons.Default.ZoomIn, "Zoom in", tint = Color.White) }
            IconButton(onClick = { full = true }) { Icon(Icons.Default.Fullscreen, "Full screen", tint = Color.White) }
        }
        if (vm.sheet.isEmpty()) {
            // tools
            ToolRow(vm, p, onTemplate = { picker = 2 }, onPicture = { pickPicture.launch(arrayOf("image/jpeg", "image/png", "image/webp")) })
            // timeline
            TimelineBlock(vm, p, onAdd = { picker = 1 })
        } else {
            // InShot-style editing panel (the preview above stays visible and live)
            SheetPanel(vm, p)
        }
    }
}

@Composable
private fun Tool(icon: ImageVector, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    Column(
        Modifier.width(78.dp).clickable { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }.padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp, color = EdMuted, maxLines = 1)
    }
}

@Composable
private fun ToolRow(vm: MainViewModel, p: Project, onTemplate: () -> Unit, onPicture: () -> Unit) {
    val card = if (vm.sel.startsWith("card:")) p.cards.find { it.id == vm.sel.removePrefix("card:") } else null
    val ov = if (vm.sel.startsWith("ov:")) p.overlays.find { it.id == vm.sel.removePrefix("ov:") } else null
    var confirm by remember { mutableStateOf(false) }
    if (confirm && card != null) ConfirmDialog("Delete this card?", { confirm = false }) { vm.deleteCard(card.id) }
    LazyRow(Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 6.dp)) {
        if (card != null) {
            item { Tool(Icons.Default.Check, "Done", Color(0xFFFFC107)) { vm.sel = "" } }
            item { Tool(Icons.Default.Edit, "Edit") { vm.cardTab = 0; vm.editingCard = card.id } }
            item { Tool(Icons.Default.Dashboard, "Template") { onTemplate() } }
            item { Tool(Icons.Default.Mic, "Voice") { vm.cardTab = 5; vm.editingCard = card.id } }
            item { Tool(Icons.Default.Image, "Pictures") { vm.cardTab = 1; vm.editingCard = card.id } }
            item { Tool(Icons.Default.Animation, "Motion") { vm.cardTab = 3; vm.editingCard = card.id } }
            item { Tool(Icons.Default.Timer, "Time") { vm.sheet = "timing" } }
            item { Tool(Icons.Default.ContentCut, "Split") { vm.splitCard(card.id, vm.playback.positionMs) } }
            item { Tool(Icons.Default.ContentCopy, "Copy") { vm.duplicateCard(card.id) } }
            item { Tool(Icons.Default.Delete, "Delete", Color(0xFFFF8A80)) { confirm = true } }
        } else if (ov != null) {
            item { Tool(Icons.Default.Check, "Done", Color(0xFFFFC107)) { vm.sel = "" } }
            item { Tool(Icons.Default.Edit, "Edit") { vm.sheet = "overlay" } }
            item { Tool(Icons.Default.ContentCopy, "Copy") { vm.duplicateOverlay(ov.id) } }
            item { Tool(Icons.Default.Delete, "Delete", Color(0xFFFF8A80)) { vm.deleteOverlay(ov.id) } }
        } else {
            item { Tool(Icons.Default.AspectRatio, "Canvas") { vm.sheet = "style" } }
            item { Tool(Icons.Default.MusicNote, "Audio") { vm.sheet = "voice" } }
            item { Tool(Icons.Default.EmojiEmotions, "Sticker") { vm.sheet = "sticker" } }
            item { Tool(Icons.Default.TextFields, "Text") { vm.addOverlay(0, "Your text"); vm.sheet = "overlay" } }
            item { Tool(Icons.Default.Image, "Picture") { onPicture() } }
            item { Tool(Icons.Default.AutoAwesome, "Script") { vm.sheet = "aiscript" } }
            item { Tool(Icons.Default.Timer, "Timing") { vm.sheet = "timing" } }
        }
    }
}

@Composable
private fun HelpDialog(onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose, title = { Text("How to edit") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "• Drag the timeline to move the play-head (white line).\n" +
                        "• Tap a card to select it. Drag its white edges to trim it. Drag the selected card sideways to change its place in the order.\n" +
                        "• Text, Sticker and Picture add layers above the video. Tap a layer to select it: drag it on the timeline to move it in time, drag its edges to trim, drag it on the preview to move it on screen.\n" +
                        "• + adds a card (pick a design from the pictures).\n" +
                        "• Audio: voice-over for the whole video. Each card also has its own Voice (select a card → Voice).\n" +
                        "• Script: paste a script and cards are made for you."
                )
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("OK") } }
    )
}

@Composable
private fun FullScreenPreview(vm: MainViewModel, p: Project, onClose: () -> Unit) {
    Dialog(onDismissRequest = { vm.playback.pause(); onClose() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Box(Modifier.fillMaxSize()) {
                FitPreview(p, { vm.playback.positionMs }, Modifier.fillMaxSize().clickable { vm.playback.toggle() })
                Row(Modifier.align(Alignment.BottomCenter).padding(20.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    IconButton(onClick = { vm.playback.toggle() }) { Icon(if (vm.playback.playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(40.dp)) }
                    IconButton(onClick = { vm.playback.pause(); onClose() }) { Icon(Icons.Default.FullscreenExit, "Close", tint = Color.White, modifier = Modifier.size(36.dp)) }
                }
            }
        }
    }
}

/** Progress and result of the AI jobs. Dialogs sit above everything, so the user always sees what is happening. */
@Composable
private fun AiDialogs(vm: MainViewModel) {
    if (vm.aiBusy || vm.ttsBusy) {
        AlertDialog(
            onDismissRequest = {}, confirmButton = {},
            title = { Text("Please wait…") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(vm.aiStatus.ifBlank { "Working…" })
                    Text("This can take up to a minute. Keep the app open.", style = MaterialTheme.typography.bodySmall)
                }
            }
        )
    }
    val r = vm.aiResult
    if (r != null && !vm.aiBusy && !vm.ttsBusy) {
        AlertDialog(
            onDismissRequest = { vm.aiResult = null },
            title = { Text(if (r.startsWith("✅")) "Done" else "Problem") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(r) } },
            confirmButton = { TextButton(onClick = { vm.aiResult = null }) { Text("OK") } }
        )
    }
}

@Composable
private fun rememberCardThumbs(p: Project): Map<String, ImageBitmap> {
    val ctx = LocalContext.current
    val map = remember { mutableStateMapOf<String, ImageBitmap>() }
    val keys = remember { HashMap<String, Int>() }
    val sig = p.cards.map { it.id to it.copy(startMs = 0, endMs = 5000).hashCode() } + listOf("land" to p.settings.landscape.hashCode())
    LaunchedEffect(sig) {
        withContext(Dispatchers.Default) {
            for (c in p.cards) {
                val h = c.copy(startMs = 0, endMs = 5000).hashCode() * 31 + p.settings.landscape.hashCode()
                if (keys[c.id] != h) {
                    val bmp = runCatching { Thumbs.render(ctx, p, c, 240) }.getOrNull() ?: continue
                    keys[c.id] = h
                    withContext(Dispatchers.Main) { map[c.id] = bmp.asImageBitmap() }
                }
            }
        }
    }
    return map
}

// =====================================================================================
//  Timeline: overlay lanes · cards (main track) · voice · ruler. "+" on the left, big time under it.
// =====================================================================================
private const val LANE_DP = 30f
private const val CARD_DP = 64f
private const val VOICE_DP = 36f
private const val RULER_DP = 26f
private const val GAP_DP = 4f

/** Overlays that overlap in time are placed on separate lanes. */
private fun overlayLanes(list: List<Overlay>): Pair<Map<String, Int>, Int> {
    val ends = ArrayList<Long>()
    val m = HashMap<String, Int>()
    for (o in list.sortedBy { it.startMs }) {
        var lane = ends.indexOfFirst { it <= o.startMs }
        if (lane < 0) { ends.add(o.endMs); lane = ends.size - 1 } else ends[lane] = o.endMs
        m[o.id] = lane
    }
    return m to ends.size
}

@Composable
private fun TimelineBlock(vm: MainViewModel, p: Project, onAdd: () -> Unit) {
    val lanes = remember(p.overlays) { overlayLanes(p.overlays) }.second
    val lanesDp = lanes * (LANE_DP + GAP_DP)
    val totalDp = lanesDp + CARD_DP + GAP_DP + VOICE_DP + GAP_DP + RULER_DP
    val pb = vm.playback
    val total = Timing.totalMs(p)
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(totalDp.dp)) {
            TimelineCanvas(vm, p, Modifier.fillMaxSize())
            // "+" button sits on the left, aligned with the main (card) track, like InShot
            Column(Modifier.padding(start = 10.dp, top = lanesDp.dp).width(70.dp).height(CARD_DP.dp), verticalArrangement = Arrangement.Center) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(16.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFFFF5A7A), Color(0xFFE91E4A))))
                        .clickable { onAdd() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.AddCircle, "Add card", tint = Color.White, modifier = Modifier.size(30.dp)) }
            }
        }
        Box(Modifier.fillMaxWidth().height(30.dp)) {
            Text(Timing.fmt(pb.positionMs), Modifier.align(Alignment.Center), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(Timing.fmt(total), Modifier.align(Alignment.CenterEnd).padding(end = 16.dp), color = EdMuted, fontSize = 14.sp)
        }
    }
}

@Composable
private fun TimelineCanvas(vm: MainViewModel, p: Project, modifier: Modifier = Modifier) {
    val pb = vm.playback
    val density = LocalDensity.current.density
    val total = Timing.totalMs(p)
    val s = p.settings
    val thumbs = rememberCardThumbs(p)
    val wf = vm.waveform
    val pNow by rememberUpdatedState(p)
    val laneInfo = remember(p.overlays) { overlayLanes(p.overlays) }
    val lanesNow by rememberUpdatedState(laneInfo.first)
    val laneCount = laneInfo.second

    val laneH = LANE_DP * density
    val cardH = CARD_DP * density
    val voiceH = VOICE_DP * density
    val rulerH = RULER_DP * density
    val gap = GAP_DP * density
    val yCard = laneCount * (laneH + gap)
    val yVoice = yCard + cardH + gap
    val yRuler = yVoice + voiceH + gap
    val textPaint = remember(density) {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f * density; color = android.graphics.Color.WHITE }
    }
    val hues = remember { listOf(Color(0xFFB3213B), Color(0xFF9A7B0A), Color(0xFF2756B5), Color(0xFF1E8F5B), Color(0xFF7B3FA0), Color(0xFFB45A2E)) }

    Canvas(
        modifier.background(Color(0xFF1B1B1B))
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { o ->
                        val w = size.width.toFloat()
                        val ppm = vm.zoomDp * density / 1000f
                        val ms = pb.positionMs + (o.x - w / 2f) / ppm
                        when {
                            o.y >= yRuler -> pb.seek(ms.toLong())
                            o.y >= yVoice -> vm.sheet = "voice"
                            o.y >= yCard -> {
                                val c = pNow.cards.lastOrNull { ms >= it.startMs && ms <= it.endMs }
                                vm.sel = if (c != null) "card:" + c.id else ""
                            }
                            else -> {
                                val lane = (o.y / (laneH + gap)).toInt()
                                val ov = pNow.overlays.lastOrNull { (lanesNow[it.id] ?: 0) == lane && ms >= it.startMs && ms <= it.endMs }
                                vm.sel = if (ov != null) "ov:" + ov.id else ""
                            }
                        }
                    },
                    onDoubleTap = { o ->
                        val w = size.width.toFloat()
                        val ppm = vm.zoomDp * density / 1000f
                        val ms = pb.positionMs + (o.x - w / 2f) / ppm
                        if (o.y >= yCard && o.y < yCard + cardH) {
                            val c = pNow.cards.lastOrNull { ms >= it.startMs && ms <= it.endMs }
                            if (c != null) { vm.sel = "card:" + c.id; vm.cardTab = 0; vm.editingCard = c.id }
                        } else if (o.y < yCard) {
                            val lane = (o.y / (laneH + gap)).toInt()
                            val ov = pNow.overlays.lastOrNull { (lanesNow[it.id] ?: 0) == lane && ms >= it.startMs && ms <= it.endMs }
                            if (ov != null) { vm.sel = "ov:" + ov.id; vm.sheet = "overlay" }
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                // 0 scrub · 1/2 trim card · 3 move (re-order) card · 4/5 trim overlay · 6 move overlay in time
                var mode = 0
                var tIdx = -1
                var tid = ""
                var acc = 0f
                val finish: () -> Unit = {
                    if (mode == 3) {
                        val id = vm.dragCard
                        val c = if (id != null) pNow.cards.find { it.id == id } else null
                        if (id != null && c != null) {
                            val ppm = vm.zoomDp * density / 1000f
                            val center = (c.startMs + c.endMs) / 2f + vm.dragShiftPx / ppm
                            val idx = pNow.cards.filter { it.id != id }.count { (it.startMs + it.endMs) / 2f < center }
                            vm.moveCardTo(id, idx)
                        }
                        vm.dragCard = null; vm.dragShiftPx = 0f
                    }
                    mode = 0
                }
                detectDragGestures(
                    onDragStart = { o ->
                        val w = size.width.toFloat()
                        val ppm = vm.zoomDp * density / 1000f
                        mode = 0; acc = 0f; vm.dragShiftPx = 0f
                        val hit = 30f * density
                        val selNow = vm.sel
                        if (selNow.startsWith("card:") && o.y >= yCard && o.y < yCard + cardH) {
                            val i = pNow.cards.indexOfFirst { it.id == selNow.removePrefix("card:") }
                            if (i >= 0) {
                                val c = pNow.cards[i]
                                val xl = w / 2f + (c.startMs - pb.positionMs) * ppm
                                val xr = w / 2f + (c.endMs - pb.positionMs) * ppm
                                when {
                                    abs(o.x - xl) < hit && abs(o.x - xl) <= abs(o.x - xr) -> { mode = 1; tIdx = i }
                                    abs(o.x - xr) < hit -> { mode = 2; tIdx = i }
                                    o.x >= xl && o.x <= xr -> { mode = 3; vm.dragCard = c.id }
                                }
                            }
                        } else if (selNow.startsWith("ov:")) {
                            val oid = selNow.removePrefix("ov:")
                            val ov = pNow.overlays.find { it.id == oid }
                            val ly = (lanesNow[oid] ?: 0) * (laneH + gap)
                            if (ov != null && o.y >= ly && o.y < ly + laneH) {
                                val xl = w / 2f + (ov.startMs - pb.positionMs) * ppm
                                val xr = w / 2f + (ov.endMs - pb.positionMs) * ppm
                                tid = oid
                                when {
                                    abs(o.x - xl) < hit && abs(o.x - xl) <= abs(o.x - xr) -> mode = 4
                                    abs(o.x - xr) < hit -> mode = 5
                                    o.x >= xl && o.x <= xr -> mode = 6
                                }
                            }
                        }
                        if (mode == 0) pb.pause()
                    },
                    onDragEnd = { finish() },
                    onDragCancel = { finish() }
                ) { change, drag ->
                    change.consume()
                    val w = size.width.toFloat()
                    val ppm = vm.zoomDp * density / 1000f
                    val ms = (pb.positionMs + (change.position.x - w / 2f) / ppm).toLong().coerceAtLeast(0L)
                    when (mode) {
                        0 -> {
                            acc += -drag.x / ppm
                            val whole = acc.toLong()
                            acc -= whole
                            if (whole != 0L) pb.seek(pb.positionMs + whole)
                        }
                        1 -> vm.setEdge(tIdx, false, ms)
                        2 -> vm.setEdge(tIdx, true, ms)
                        3 -> vm.dragShiftPx += drag.x
                        4 -> vm.trimOverlay(tid, false, ms)
                        5 -> vm.trimOverlay(tid, true, ms)
                        else -> {
                            acc += drag.x / ppm
                            val whole = acc.toLong()
                            if (whole != 0L) { acc -= whole; vm.moveOverlay(tid, whole) }
                        }
                    }
                }
            }
    ) {
        val w = size.width
        val ppm = vm.zoomDp * density / 1000f
        val cx = w / 2f
        val pos = pb.positionMs
        val sel = vm.sel
        fun xOf(ms: Long): Float = cx + (ms - pos) * ppm
        fun label(t: String, x: Float, y: Float, color: Int = android.graphics.Color.WHITE) {
            textPaint.color = color
            drawIntoCanvas { it.nativeCanvas.drawText(t, x, y, textPaint) }
        }
        val corner = CornerRadius(8f * density)

        // overlay lanes
        p.overlays.forEach { o ->
            val lane = lanesNow[o.id] ?: 0
            val ly = lane * (laneH + gap)
            val x0 = xOf(o.startMs)
            val x1 = xOf(o.endMs)
            if (x1 < -40f || x0 > w + 40f) return@forEach
            val ow = (x1 - x0).coerceAtLeast(4f)
            val col = when (o.type) { 0 -> Color(0xFF6E4FD6); 1 -> Color(0xFFE0A100); else -> Color(0xFF1F9AA8) }
            drawRoundRect(col, Offset(x0, ly), Size(ow, laneH), corner)
            clipRect(x0, ly, x0 + ow, ly + laneH) {
                label(when (o.type) { 0 -> "T  " + o.text.replace('\n', ' ').take(24); 1 -> o.text; else -> "picture" }, x0 + 6f * density, ly + laneH / 2f + 4f * density)
            }
            val selected = sel == "ov:" + o.id
            if (selected) {
                drawRoundRect(Color.White, Offset(x0, ly), Size(ow, laneH), corner, style = Stroke(2.5f * density))
                val hw = 8f * density
                drawRoundRect(Color.White, Offset(x0 - 1f, ly), Size(hw, laneH), CornerRadius(4f * density))
                drawRoundRect(Color.White, Offset(x1 - hw + 1f, ly), Size(hw, laneH), CornerRadius(4f * density))
            }
        }

        // main track: cards
        drawRect(Color(0xFF262626), Offset(0f, yCard), Size(w, cardH))
        fun drawClip(i: Int, c: NCard, dx: Float, ghost: Boolean) {
            val x0 = xOf(c.startMs) + dx
            val x1 = xOf(c.endMs) + dx
            if (x1 < -40f || x0 > w + 40f) return
            val cw = (x1 - x0).coerceAtLeast(3f)
            drawRoundRect(hues[i % hues.size].copy(alpha = if (ghost) 0.85f else 1f), Offset(x0, yCard), Size(cw, cardH), corner)
            val bmp = thumbs[c.id]
            if (bmp != null) {
                val tileW = (cardH * bmp.width / bmp.height).coerceAtLeast(8f)
                clipRect(x0, yCard, x0 + cw, yCard + cardH) {
                    var tx = x0
                    while (tx < x0 + cw) {
                        if (tx + tileW >= 0f && tx <= w) drawImage(image = bmp, dstOffset = IntOffset(tx.toInt(), yCard.toInt()), dstSize = IntSize(tileW.toInt(), cardH.toInt()), alpha = if (ghost) 0.85f else 1f)
                        tx += tileW
                    }
                    drawRect(Color(0xAA000000), Offset(x0, yCard), Size(cw, 16f * density))
                    label("${i + 1}  " + c.headline.replace('\n', ' ').take(24), x0 + 4f * density, yCard + 12f * density)
                }
            }
            val selected = sel == "card:" + c.id
            drawRoundRect(if (selected) Color.White else Color(0x55FFFFFF), Offset(x0, yCard), Size(cw, cardH), corner, style = Stroke(if (selected) 3f * density else 1f))
            if (selected && !ghost) {
                val hw = 10f * density
                drawRoundRect(Color.White, Offset(x0 - 1f, yCard), Size(hw, cardH), CornerRadius(4f * density))
                drawRoundRect(Color.White, Offset(x1 - hw + 1f, yCard), Size(hw, cardH), CornerRadius(4f * density))
                drawLine(Color(0xFF333333), Offset(x0 + hw / 2f, yCard + cardH * 0.3f), Offset(x0 + hw / 2f, yCard + cardH * 0.7f), 2f)
                drawLine(Color(0xFF333333), Offset(x1 - hw / 2f + 1f, yCard + cardH * 0.3f), Offset(x1 - hw / 2f + 1f, yCard + cardH * 0.7f), 2f)
            }
        }
        val dragId = vm.dragCard
        p.cards.forEachIndexed { i, c -> if (c.id != dragId) drawClip(i, c, 0f, false) }
        if (dragId != null) {
            val i = p.cards.indexOfFirst { it.id == dragId }
            if (i >= 0) drawClip(i, p.cards[i], vm.dragShiftPx, true)
        }
        if (p.cards.isEmpty()) label("Tap + to add your first card", cx + 12f * density, yCard + cardH / 2f + 4f * density, 0xFFB4B4B4.toInt())

        // voice track: whole-video voice-over + the voice of single cards
        drawRect(Color(0xFF262626), Offset(0f, yVoice), Size(w, voiceH))
        if (s.audioPath != null) {
            val ax0 = xOf(0L)
            val ax1 = xOf(s.audioDurMs)
            drawRoundRect(Color(0xFF14636B), Offset(ax0, yVoice), Size((ax1 - ax0).coerceAtLeast(3f), voiceH), corner)
            if (wf != null && wf.isNotEmpty()) {
                val bw = (ax1 - ax0) / wf.size
                for (i in wf.indices) {
                    val x = ax0 + (i + 0.5f) * bw
                    if (x < -2f || x > w + 2f) continue
                    val hh = wf[i] * voiceH * 0.4f + 1f
                    drawLine(Color(0xDDFFFFFF), Offset(x, yVoice + voiceH / 2f - hh), Offset(x, yVoice + voiceH / 2f + hh), maxOf(1f, bw * 0.8f))
                }
            }
        }
        p.cards.forEach { c ->
            if (c.voicePath != null && c.voiceDurMs > 0) {
                val x0 = xOf(c.startMs)
                val x1 = xOf(c.startMs + c.voiceDurMs)
                drawRoundRect(Color(0xFF2E9E8F), Offset(x0, yVoice + 3f * density), Size((x1 - x0).coerceAtLeast(3f), voiceH - 6f * density), corner)
                clipRect(x0, yVoice, x1, yVoice + voiceH) { label("🎙", x0 + 4f * density, yVoice + voiceH / 2f + 4f * density) }
            }
        }
        if (s.audioPath == null && p.cards.none { it.voicePath != null }) label("🎙 Tap here to add voice", 12f * density + 70f * density, yVoice + voiceH / 2f + 4f * density, 0xFFB4B4B4.toInt())

        // ruler with a dot every second and a label every few seconds (under the tracks, like InShot)
        val secPx = vm.zoomDp * density
        val stepMs = when { secPx >= 110f -> 1000L; secPx >= 55f -> 2000L; secPx >= 22f -> 5000L; else -> 10000L }
        val leftMs = pos - cx / ppm
        var t = (floor(leftMs / stepMs).toLong() * stepMs).coerceAtLeast(0L)
        val rightMs = pos + cx / ppm
        while (t <= rightMs && t <= total + stepMs) {
            val x = xOf(t)
            drawCircle(Color(0xFF8A8A8A), 2.5f * density, Offset(x, yRuler + 5f * density))
            label("${"%02d".format(t / 60000)}:${"%02d".format((t / 1000) % 60)}", x - 14f * density, yRuler + 20f * density, 0xFF9A9A9A.toInt())
            t += stepMs
        }

        // end marker + play-head
        val ex1 = xOf(total)
        drawLine(Color(0x99FFC107), Offset(ex1, 0f), Offset(ex1, yVoice + voiceH), 2f)
        drawLine(Color.White, Offset(cx, 0f), Offset(cx, yRuler), 3f * density)
    }
}

// =====================================================================================
//  Export screen
// =====================================================================================
@Composable
private fun ExportScreen(vm: MainViewModel, p: Project) {
    ScreenScaffold("Export video", { vm.showExport = false }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) { ExportTab(vm, p) }
    }
}

@Composable
fun ExportTab(vm: MainViewModel, p: Project) {
    val ctx = LocalContext.current
    val st by vm.settings.collectAsState()
    val state by ExportState.state.collectAsState()
    var res by remember(st.resolution) { mutableStateOf(st.resolution) }
    var fps by remember(st.fps) { mutableStateOf(st.fps) }
    var quality by remember { mutableStateOf(1) }
    var aq by remember { mutableStateOf(1) }
    var soft by remember { mutableStateOf(false) }
    var name by remember(p.id) { mutableStateOf("ZCH_" + p.name.replace(Regex("[^\\p{L}\\p{N}]+"), "_")) }
    val land = p.settings.landscape
    val total = Timing.totalMs(p)
    val longSide = if (res == 720) 1280 else 1920
    val w = if (land) longSide else res
    val h = if (land) res else longSide
    val baseBr = if (res == 720) intArrayOf(2_500_000, 4_000_000, 6_000_000) else intArrayOf(5_000_000, 8_000_000, 12_000_000)
    val vbr = (baseBr[quality] * fps / 30.0).toInt()
    val abr = intArrayOf(96_000, 128_000, 192_000)[aq]
    val legacyPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val needLegacy = android.os.Build.VERSION.SDK_INT < 29
    val running = state is ExportUi.Running
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Export settings", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFC107))
        Text("Resolution")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(720, 1080).forEach { r -> FilterChip(res == r, { res = r }, { Text("${r}p") }) } }
        Text("Aspect ratio")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(land, { vm.updateSettings { it.copy(landscape = true) } }, { Text("16:9") })
            FilterChip(!land, { vm.updateSettings { it.copy(landscape = false) } }, { Text("9:16") })
        }
        Text("Frame rate")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(24, 25, 30).forEach { f -> FilterChip(fps == f, { fps = f }, { Text("$f fps") }) } }
        DropdownField("Video quality", listOf("Low (small file)", "Medium", "High"), quality, { quality = it })
        DropdownField("Audio quality", listOf("96 kbps", "128 kbps", "192 kbps"), aq, { aq = it })
        PopupField("Output file name", name, { name = it })
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(soft, { soft = it })
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text("Compatibility mode (slower)")
                Text("Rendering normally uses the phone's GPU (fast). Turn this on only if the exported video is black or garbled.", style = MaterialTheme.typography.bodySmall)
            }
        }
        val mb = (((vbr + abr) / 8.0) * total / 1000.0 / 1_000_000)
        Text("Output: ${w}×${h}, $fps fps, about ${"%.1f".format(mb)} MB, ${Timing.fmt(total)} long")
        if (total > 10 * 60_000L) Text("⚠ Long project: export may take a long time and a lot of storage.", color = Color(0xFFFFC107))
        if (res == 1080) Text("⚠ 1080p needs more time/memory on older phones. Use 720p if the export fails.", color = Color(0xFFFFC107), style = MaterialTheme.typography.bodySmall)
        if (p.cards.isEmpty()) Text("Add at least one card first.", color = Color(0xFFFF8A80))

        when (val s = state) {
            is ExportUi.Running -> {
                LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                Text("${(s.progress * 100).toInt()}%  ${s.msg}")
                Button(onClick = { vm.cancelExport() }) { Text("Cancel export") }
            }
            is ExportUi.Done -> {
                Text("✅ Export finished: Movies/ZCH NewsCard Studio", color = Color(0xFF69F0AE))
                Text("Find it in Recent Exports to play, share or delete.", style = MaterialTheme.typography.bodySmall)
            }
            is ExportUi.Failed -> Text("❌ Export failed: ${s.msg}", color = Color(0xFFFF8A80))
            ExportUi.Cancelled -> Text("Export cancelled.")
            ExportUi.Idle -> {}
        }
        if (p.exportStatus == "interrupted") Text("The previous export was interrupted. Start again to retry.", color = Color(0xFFFFC107))
        Button(enabled = !running && p.cards.isNotEmpty(), modifier = Modifier.fillMaxWidth(), onClick = {
            if (android.os.Build.VERSION.SDK_INT >= 33) notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            val ok = !needLegacy || androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (ok) vm.startExport(w, h, fps, vbr, abr, name, land, p.settings.endMode, p.settings.customEndMs, soft)
            else {
                legacyPerm.launch(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE))
                vm.message = "Allow storage access, then press Export again"
            }
        }) { Text("Export MP4") }
        if (p.exports.isNotEmpty()) TextButton(onClick = { vm.go(Screen.Exports) }) { Text("Open Recent Exports") }
    }
}
