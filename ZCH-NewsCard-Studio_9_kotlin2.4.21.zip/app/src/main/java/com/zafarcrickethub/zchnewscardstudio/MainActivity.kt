package com.zafarcrickethub.zchnewscardstudio

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.zafarcrickethub.zchnewscardstudio.ui.EditorScreen
import com.zafarcrickethub.zchnewscardstudio.ui.HelpScreen
import com.zafarcrickethub.zchnewscardstudio.ui.HomeScreen
import com.zafarcrickethub.zchnewscardstudio.ui.MainViewModel
import com.zafarcrickethub.zchnewscardstudio.ui.Screen
import com.zafarcrickethub.zchnewscardstudio.ui.ThumbnailScreen
import com.zafarcrickethub.zchnewscardstudio.ui.ZchTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent { ZchTheme { AppRoot(vm) } }
    }

    override fun onPause() {
        super.onPause()
        vm.saveNow() // protect against data loss when the app is backgrounded or killed
    }
}

@Composable
fun AppRoot(vm: MainViewModel) {
    val ctx = LocalContext.current
    // Toasts are drawn above bottom sheets and dialogs, so messages are never hidden.
    LaunchedEffect(vm.message) {
        vm.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); vm.message = null }
    }
    BackHandler(enabled = vm.screen != Screen.Dashboard) { vm.back() }
    // The five home tabs share one route, so the bottom bar stays put while content cross-fades.
    val route = when (vm.screen) {
        Screen.Dashboard, Screen.Projects, Screen.Templates, Screen.Exports, Screen.Settings -> Screen.Dashboard
        else -> vm.screen
    }
    AnimatedContent(
        targetState = route,
        transitionSpec = {
            val deeper = targetState != Screen.Dashboard
            (slideInHorizontally(tween(280)) { if (deeper) it / 6 else -it / 6 } + fadeIn(tween(220))) togetherWith
                (slideOutHorizontally(tween(280)) { if (deeper) -it / 6 else it / 6 } + fadeOut(tween(160)))
        },
        label = "nav"
    ) { r ->
        when (r) {
            Screen.Help -> HelpScreen(vm)
            Screen.Editor -> EditorScreen(vm)
            Screen.Thumbnail -> ThumbnailScreen(vm)
            else -> HomeScreen(vm)
        }
    }
}
