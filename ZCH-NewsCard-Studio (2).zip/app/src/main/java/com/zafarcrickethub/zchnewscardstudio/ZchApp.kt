package com.zafarcrickethub.zchnewscardstudio

import android.app.Application
import com.zafarcrickethub.zchnewscardstudio.data.Repo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class ZchApp : Application() {
    lateinit var repo: Repo

    override fun onCreate() {
        super.onCreate()
        repo = Repo(this)
        CoroutineScope(Dispatchers.IO).launch {
            // Recovery after a crash / process death during an export
            repo.markInterrupted()
            File(cacheDir, "export").deleteRecursively()
        }
    }
}
