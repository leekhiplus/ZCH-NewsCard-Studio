# ZCH NewsCard Studio (Zafar Cricket Hub)

Offline Urdu news-card & automated video creator for Android (Kotlin, Jetpack Compose, Material 3,
Room, DataStore, MediaCodec/MediaMuxer, Media3, uCrop, GPUImage, ML Kit, Lottie, TarsosDSP, Oboe). No accounts or ads; the internet is used only for the optional Google voice-over.

## Build with GitHub Actions (no Android Studio needed)
1. Create a GitHub repository.
2. Upload `ZCH-NewsCard-Studio.zip` **as is** (do not extract) to the repository root
   (Add file → Upload files).
3. Add the workflow file: Add file → Create new file → name it `.github/workflows/android.yml`
   and paste the contents of the separate `android.yml`.
4. Open the **Actions** tab → *Build ZCH NewsCard Studio* → run (it also runs on every push).
5. When finished, download **ZCH-NewsCard-Studio-debug-apk** from the run's Artifacts, unzip, install the APK.

The workflow extracts the ZIP itself, uses the SDK preinstalled on the runner (platform 36), downloads the Noto Nastaliq Urdu font into
the app assets, generates the Gradle wrapper, runs unit tests and builds the debug APK. For a signed release APK add the
secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

## Local build
`gradle wrapper --gradle-version 9.7.1 && ./gradlew assembleDebug` (JDK 17, Android SDK 36).
Toolchain: Kotlin 2.4.21, Android Gradle Plugin 9.3.1 (built-in Kotlin), Gradle 9.7.1, KSP 2.3.13.

## Editor layout (InShot style)
Top: back · help · **Export**. Big preview in the middle. Under it: undo · redo · **play** · zoom · full screen.
Then a horizontally scrolling **tool row** (Canvas, Audio, Sticker, Text, Picture, Script, Timing; when a card or a layer is
selected the row changes to Edit, Template, Voice, Pictures, Motion, Time, Split, Copy, Delete ...).
Bottom: the **timeline** with a red **+** button at the left (opens a picture-preview template chooser), the cards as the main
track, extra **layers** (text, stickers, pictures) above it on their own lanes, the voice track below it, a ruler with a dot for every
second, and the current time (big) / total time under it.
* Drag the timeline to scrub (white line = play-head). Tap a clip to select it.
* Selected **card**: drag its white edges to trim, drag its body sideways to change its place in the order. Trimming never lets a card
  go over or under another one: the **end** edge pushes / pulls the cards after it (InShot style), the **start** edge moves the shared
  boundary with the previous card. (Only with *Timing > Rules > Allow overlapping cards* switched on can cards overlap.)
* The timeline follows the finger 1:1 without a dead zone and keeps gliding after a fast swipe (momentum); tap it to stop.
* Selected **layer**: drag its body to move it in time, drag the edges to trim, drag it on the preview to move it on screen.
* Starting a project shows every template as a picture (and an "empty project" option).
* **Card editor**: live preview on top, an InShot-style panel under it. The panel has a title and a tick (done), a sideways-scrolling
  strip of tools (icon over label, thin lines between groups) and the controls of ONE tool below it. Tools: Template · Text · Match ·
  Size · Ticker | Media · Crop · Slides · Extras | Colour · Tint · Logo | Text anim · Image anim · Loop · Transition · Speed |
  Time · Set · Order | Script · Voice. The Script tool makes cards from a pasted script right at that card; the Voice tool makes a voice
  for that single card (Google key, optional) and can stretch the card to the length of the voice. Card voices are mixed with the
  project voice-over in the exported video.

## InShot-style menus
Every menu of the editor (Canvas, Audio, Script, Sticker / Text / Picture layers, Timing, Card editor) uses the same panel:
the preview stays visible above it and updates live, the timeline is hidden while a panel is open (the play button stays), and the
tick closes the panel. Canvas: Format | Strip · Text · Scroll (direction right-to-left / left-to-right, speed, font size) · Colour · Background | Logo · Logo look · Position · Channel.
Audio: Audio · Volume | Key · Model · Voice · Script · Create. Script: Script · Cards · Design · Options · Voice (the red
*Create cards* button is in the panel header). Layer: Text · Colour · Plate | Size · Rotate · Move · Time · Animation.
Card time: Time · Set · Order. Whole-video timing: Rules · Spread · End · All cards.

## Text size
Headline / description text is fitted to its box automatically (Urdu text may use more of the box than before, so it is bigger).
*Card editor > Size* (50 - 250 %) now always scales the fitted text up or down in every template.

## Speed & native feel
* Export draws every frame on the phone's **GPU** (`Surface.lockHardwareCanvas`) straight into the hardware H.264 encoder; the voice-over is
  encoded on a second thread at the same time. Text layouts are cached, pictures are uploaded to the GPU once. *Compatibility mode* in the
  Export screen switches back to the slower software canvas if a device shows a black / garbled video.
* Native Android look: native splash screen, edge-to-edge, bottom navigation bar + FAB, animated screen transitions, predictive back,
  haptic feedback. Every text box opens in a pop-up editor (big field, keyboard open, Paste / Clear).
* FFmpeg: the community-maintained FFmpegKit fork (`dev.ffmpegkit-maintained:ffmpeg`, LGPL free build, arm64) is bundled as a **fallback converter**:
  if the phone cannot decode an imported audio file, FFmpeg converts it to WAV. It does not render the video (the free build has no H.264
  encoder and no hardware acceleration - the Android hardware encoder is the fastest path). If the library cannot be downloaded the
  workflow retries the build with `-PwithFfmpeg=false`.

## Pictures and videos
Each card can hold unlimited pictures **and videos**: *Media → Add pictures / videos* (select many, mix freely). The first one is the
main picture / video, the others play one after another inside the card (equal share of the card time) with a chosen change effect
(crossfade / slide / zoom / wipe). A video works in every template exactly like a picture (full-bleed, framed, collage, player
portraits ...), also in the second slot of the Extras / Player 2 tools, and can be cropped / zoomed with the Crop tool.
* Videos are **silent** (use the Audio tool for music or a voice-over) and **repeat** when the card is longer than the video;
  the "Image anim" motion is not applied to a video. A card that holds just one video has a **Card length = video length** button.
* Export reads every frame at its exact time (`VideoFrames.frameSync`), so the MP4 is frame-accurate. The live preview never waits for
  the decoder: it shows the newest decoded frame and a background thread catches up (about 20 fps at most; on slow phones the
  preview can look less smooth than the exported file). Export of video cards is slower than of picture cards.
* Picture lists show the first frame of a video with a play badge and its length.

## AI Script → cards + voice-over (optional, online)
Paste a full news script (AI Script button or the dashboard tile). With your Google AI Studio key the app asks Gemini to split
it into cards (headline, description, match fields, ticker) and can create the voice-over in the same go. Card times are NOT
guessed: set each card's start / end with the play-head ("Start = play-head" / "End = play-head") or type them.

## Templates (23)
13-22 are the clean **TV news flash** family (full-bleed photo, small BREAKING NEWS + LIVE tag, solid headline bar right above a
red ticker strip): News Flash Classic, Red Alert Bar, Black & Gold Bar, Pakistan Green Bar, Score Bar Live, Light Panel News,
Top Stories Counter, Cinematic Headline, Side Banner News, Kicker + Headline.

### 0-12 layered broadcast designs
Every template is built from layers, each with its own delayed entrance animation: full-bleed picture (or an animated stadium
scene when there is no picture) → colour tint + vignette → light leak / bokeh / sun-burst → slanted panels, banners, brackets,
LIVE badge, flags, score strips, photo frames → text. Loop effects (shine sweep, breathing, floating) run after the entrance.
0 Classic Breaking News · 1 TV Bulletin · 2 Cricket Sports · 3 Headline News · 4 Special Report (cinematic letter-box) ·
5 Match Score Update · 6 Player Performance · 7 Breaking Alert · 8 Match Photo Collage · 9 Match Day Live ·
10 Triple Photo Gallery · 11 Player of the Match · 12 Stadium Photo Story. Templates 8-12 have the red BREAKING NEWS banner
on top, match pictures (main + up to 2 extra) and the ticker strip at the bottom.

### 23-27 two-player comparison designs
Five different layouts (same drawing pipeline, so preview = export) that put TWO players side by side:
23 Face-Off Split (two big pictures cut by a gold diagonal + one stat table) · 24 Stat Bars Duel (round portraits, a bar per stat
growing from the centre, "WINS" counters) · 25 Versus Cards (two tall player cards with picture, name and stat list) ·
26 Scoreboard Table (header with both headshots, one table row per stat, "STATS WON" footer) ·
27 Duel Lower Third (full-bleed split pictures, name plates and a strip of stat capsules).
In the card editor: **Players** tool = player 1 / player 2 name + statistics (one stat per line, `Runs: 112`), **Player 1 pic** =
main picture, **Player 2 pic** = second picture. Stats are matched by NAME between the two players (Runs with Runs, Strike Rate
with Strike Rate...) and the better value of each pair is highlighted (for Economy / Wides / No-balls / Extras the LOWER value wins).
Up to 5 stats are shown in landscape, 6 in portrait. They appear first in the "Add card" / "Templates" lists under
"Player comparison (2 players)".

## Animations
* 24 layer / text entrance animations (fade, slides, pop, zoom in/out, bounce, flip, rotate, spin-zoom, 3 wipes, elastic,
  shake, swing, glitch, stretch, skew, flash, typewriter, rise) + an exit animation (any entrance played backwards) + looping effects.
* 14 picture motions (zooms, pans, diagonal drift, breathing, slow rotate, handheld shake, punch-in, swing pan ...).
* 22 transitions (fade, slides ×4, crossfade, cut, wipes ×4, zoom in/out, push, circle reveal, blinds, diagonal wipe, flash,
  spin, glitch, split open, flip, auto-varied) with adjustable length.

## Optional AI voice-over (Google AI Studio)
Voice-over sheet → paste your API key (aistudio.google.com/apikey), choose model/voice, write or "Fill from cards" the script,
tap Generate. The app calls the Gemini TTS API (`models/<model>:generateContent`, default `gemini-3.1-flash-tts-preview`),
wraps the returned 24 kHz PCM into a WAV and uses it as the voice-over. Only the script text is sent to Google; the key is
stored on the phone. This is the only feature that uses the internet (INTERNET permission); everything else stays offline.

## Libraries and what they do in the app
| Library | Where you see it |
|---|---|
| AndroidX Media3 **ExoPlayer** + UI | Exports list → **Play**: plays the exported video inside the app (seek bar, pause) |
| AndroidX Media3 **Transformer** + effect | Exports list → **Small**: makes a small copy (short side up to 720 px, 2.5 Mbit/s) for WhatsApp; the original stays |
| **uCrop** | Card editor → Crop tool → **Crop picture** (free crop, rotate, zoom) |
| **GPUImage** for Android (OpenGL ES shaders) | Card editor → Crop tool → **Filter** (Vivid, Warm, Cool, B&W, Sepia, Drama, Bright, Soft fade) |
| **Google ML Kit** Selfie Segmentation | Card editor → Crop tool → **Remove background** (person cut-out, on-device, model bundled) |
| **Lottie** | Stickers → **Animated stickers** (4 built-in, `assets/lottie/`) and **Import Lottie animation (.json)**; drawn by the same renderer for preview and export |
| **TarsosDSP** | Card Time tool → **Auto-time cards from voice pauses** (finds pauses in the voice-over and puts card changes there) |
| **Oboe** (C++/JNI, `app/src/main/cpp`) | Audio → **Record**: low-latency microphone voice-over; falls back to Android `AudioRecord` if the native part is missing |
| **FFmpegKit** (optional, reflection) | Audio → **Clean voice** (high-pass, noise reduction, loudness levelling) and conversion of audio the phone cannot decode |
| Android **Canvas** / **OpenGL ES** | Already the core of `FrameRenderer` and the video exporter (no extra library needed) |

Not added, on purpose: **Mp4Composer-android** (unmaintained, and Media3 Transformer already does the same job), **MediaPipe** and
**TensorFlow Lite** (they need a model file; ML Kit already covers background removal; add them once a model is chosen).

### Extra Maven repositories (settings.gradle.kts)
`https://jitpack.io` (only group `com.github.yalantis`, for uCrop) and `https://mvn.0110.be/releases` (only group `be.tarsos.dsp`).
If CI cannot reach one of them, the build fails at dependency resolution; tell me and that library is swapped out.

### Build switches
* `-PwithOboe=false` – build without the native Oboe recorder (no NDK / CMake needed; recording uses `AudioRecord`).
* `-PwithFfmpeg=false` – build without FFmpegKit (Clean voice and unusual audio formats are then hidden / unavailable).

### Licence note
TarsosDSP is **GPL-3.0**. If the APK is only for your own use this is fine; if you publish the app, either publish its source under
a GPL-compatible licence or remove `be.tarsos.dsp:core` (only `audio/VoicePauses.kt` uses it).

## Architecture
`data/` Room + DataStore + models · `graphics/` font, bitmap cache, Urdu text layout, flags ·
`renderer/` FrameRenderer (8 templates, animations, transitions, ticker, logo) used by preview AND export,
`VideoExporter` (frame-by-frame H.264 via MediaCodec surface + AAC audio + MediaMuxer), `ExportService` (foreground service,
progress, cancel) · `audio/` playback + waveform · `ui/` Compose screens · `utils/` timing validation, MediaStore saving.

## Testing checklist
Unit tests: `./gradlew testDebugUnitTest`. On a device run through: create project → add Urdu cards → import audio →
set timings → reorder → images → templates → animations → ticker → logo → preview → export 720p/1080p, 16:9/9:16 →
check audio sync and Urdu shaping in the exported file → close/reopen project → cancel an export.

## Known limitations
* Card timing is manual (Start / End / Duration fields, nudge buttons, drag markers), evenly distributed, or set from pauses in the voice-over (TarsosDSP). The app does not understand the words, only the silences.
* Image "crop" = zoom + position inside the frame. Flags are simplified drawings.
* Exported video frame timestamps are fixed at the chosen FPS; if a device encoder drops frames, video may end slightly early.
* On Android 8–9 the app asks for storage permission to write into Movies/Pictures.
