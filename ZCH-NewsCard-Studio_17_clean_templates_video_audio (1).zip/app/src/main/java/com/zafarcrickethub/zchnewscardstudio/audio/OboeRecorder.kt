package com.zafarcrickethub.zchnewscardstudio.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.abs

/**
 * Records the microphone (16-bit, mono) into a WAV file: the voice-over recorder.
 *
 * Main path: Oboe (C++, see src/main/cpp). The audio thread only fills a ring buffer; this class drains it on its own thread
 * and writes the file, so recording stays glitch-free and low-latency.
 * Fallback: android.media.AudioRecord, used automatically when the native library is not part of the build
 * (built with -PwithOboe=false) or Oboe cannot open the microphone.
 *
 * The caller must hold the RECORD_AUDIO permission before calling [start].
 */
class OboeRecorder {
    companion object {
        const val RATE = 48000

        /** False when the app was built without the native Oboe library. */
        val nativeAvailable: Boolean = try {
            System.loadLibrary("zchaudio")
            true
        } catch (t: Throwable) {
            false
        }
    }

    private external fun nativeStart(sampleRate: Int): Int
    private external fun nativeStop()
    private external fun nativeRead(buffer: ShortArray, max: Int): Int
    private external fun nativeOverruns(): Int

    @Volatile
    var running: Boolean = false
        private set

    /** Peak level of the last block, 0..1 (for the level meter). */
    @Volatile
    var level: Float = 0f
        private set

    /** "Oboe (low latency)" or "Android AudioRecord". */
    @Volatile
    var engine: String = ""
        private set

    @Volatile
    var error: String? = null
        private set

    @Volatile
    private var samples: Long = 0L

    @Volatile
    private var rate: Int = RATE

    val elapsedMs: Long get() = samples * 1000L / rate.coerceAtLeast(1)

    private var thread: Thread? = null

    /** Starts recording into `target`. Returns null when recording started, otherwise a message for the user. */
    @SuppressLint("MissingPermission")
    @Synchronized
    fun start(target: File): String? {
        if (running) return null
        error = null
        samples = 0L
        level = 0f

        var useNative = false
        var actualRate = 0
        if (nativeAvailable) {
            actualRate = try { nativeStart(RATE) } catch (t: Throwable) { -9 }
            useNative = actualRate > 0
        }

        var record: AudioRecord? = null
        if (!useNative) {
            actualRate = 44100
            val minBuf = AudioRecord.getMinBufferSize(actualRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuf <= 0) return "This phone cannot record audio"
            val r = try {
                AudioRecord(
                    MediaRecorder.AudioSource.MIC, actualRate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf * 2, 16384)
                )
            } catch (e: Exception) {
                null
            }
            if (r == null || r.state != AudioRecord.STATE_INITIALIZED) {
                r?.release()
                return "The microphone could not be opened (is it in use by another app?)"
            }
            try {
                r.startRecording()
            } catch (e: Exception) {
                r.release()
                return "The microphone could not be started"
            }
            record = r
        }

        val file = try {
            RandomAccessFile(target, "rw").also { it.setLength(0L); it.write(wavHeader(actualRate, 0L)) }
        } catch (e: Exception) {
            if (useNative) try { nativeStop() } catch (_: Throwable) {}
            record?.release()
            return "Cannot create the recording file"
        }

        rate = actualRate
        engine = if (useNative) "Oboe, low latency" else "Android AudioRecord"
        running = true
        val ar = record
        val t = Thread({ capture(file, useNative, ar, actualRate) }, "zch-voice-recorder")
        thread = t
        t.start()
        return null
    }

    /** Stops recording and waits until the file is complete. Returns true when something was recorded. Blocking (short). */
    fun stop(): Boolean {
        val t = synchronized(this) { thread } ?: return samples > 0L
        running = false
        try { t.join(4000) } catch (_: InterruptedException) {}
        synchronized(this) { thread = null }
        return samples > 0L
    }

    private fun capture(file: RandomAccessFile, useNative: Boolean, record: AudioRecord?, sampleRate: Int) {
        val buf = ShortArray(4096)
        val bytes = ByteArray(buf.size * 2)
        var total = 0L
        try {
            fun drain(n: Int) {
                var peak = 0
                for (i in 0 until n) {
                    val v = buf[i].toInt()
                    bytes[i * 2] = (v and 0xFF).toByte()
                    bytes[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
                    val a = abs(v)
                    if (a > peak) peak = a
                }
                file.write(bytes, 0, n * 2)
                total += n
                samples = total
                level = peak / 32768f
            }
            while (running) {
                if (useNative) {
                    val n = nativeRead(buf, buf.size)
                    if (n > 0) drain(n) else Thread.sleep(5)
                } else {
                    val n = record!!.read(buf, 0, buf.size)
                    if (n > 0) drain(n) else if (n < 0) { error = "The microphone stopped delivering sound"; break }
                }
            }
            if (useNative) {
                try { nativeStop() } catch (_: Throwable) {}
                while (true) {              // whatever is still in the ring buffer
                    val n = nativeRead(buf, buf.size)
                    if (n <= 0) break
                    drain(n)
                }
                if (nativeOverruns() > 0) error = "Some sound was lost because the phone was busy"
            }
        } catch (e: Exception) {
            error = "Recording stopped: ${e.message}"
        } finally {
            running = false
            level = 0f
            try { record?.stop() } catch (_: Exception) {}
            try { record?.release() } catch (_: Exception) {}
            if (useNative) try { nativeStop() } catch (_: Throwable) {}
            try {
                file.seek(0L)
                file.write(wavHeader(sampleRate, total * 2L))
                file.close()
            } catch (_: Exception) {}
        }
    }

    private fun wavHeader(sampleRate: Int, dataBytes: Long): ByteArray {
        val h = ByteArray(44)
        fun put4(at: Int, v: Long) { for (i in 0..3) h[at + i] = ((v shr (8 * i)) and 0xFF).toByte() }
        fun put2(at: Int, v: Int) { h[at] = (v and 0xFF).toByte(); h[at + 1] = ((v shr 8) and 0xFF).toByte() }
        "RIFF".toByteArray().copyInto(h, 0)
        put4(4, 36L + dataBytes)
        "WAVEfmt ".toByteArray().copyInto(h, 8)
        put4(16, 16L)
        put2(20, 1)                       // PCM
        put2(22, 1)                       // mono
        put4(24, sampleRate.toLong())
        put4(28, sampleRate.toLong() * 2L)  // byte rate
        put2(32, 2)                       // block align
        put2(34, 16)                      // bits per sample
        "data".toByteArray().copyInto(h, 36)
        put4(40, dataBytes)
        return h
    }
}
