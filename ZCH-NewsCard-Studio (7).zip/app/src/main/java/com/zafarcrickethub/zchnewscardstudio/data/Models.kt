package com.zafarcrickethub.zchnewscardstudio.data

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.util.UUID

object Pal {
    val Navy = 0xFF0A1A3F.toInt()
    val DeepNavy = 0xFF050E26.toInt()
    val Red = 0xFFD90429.toInt()
    val DarkRed = 0xFF7A0016.toInt()
    val Gold = 0xFFFFC107.toInt()
    val White = 0xFFFFFFFF.toInt()
    val Black = 0xFF000000.toInt()
    val swatches: List<Int> = listOf(
        White, Gold, Red, Navy, DeepNavy, Black,
        0xFF1B5E20.toInt(), 0xFF0D47A1.toInt(), 0xFF6A1B9A.toInt(),
        0xFFFF6F00.toInt(), 0xFF00838F.toInt(), 0xFF424242.toInt()
    )
}

object Opt {
    val templates = listOf(
        "Classic Breaking News", "Professional TV Bulletin", "Cricket Sports News", "Headline News",
        "Special Report", "Match Score Update", "Player Performance", "Breaking News Alert",
        "Match Photo Collage", "Match Day Live", "Triple Photo Gallery", "Player of the Match", "Stadium Photo Story",
        "News Flash Classic", "Red Alert Bar", "Black & Gold Bar", "Pakistan Green Bar", "Score Bar Live",
        "Light Panel News", "Top Stories Counter", "Cinematic Headline", "Side Banner News", "Kicker + Headline"
    )
    val slideFx = listOf("Crossfade", "Slide", "Zoom", "Wipe")
    /** Templates grouped for the "Add card" sheet. */
    val tvStyle = (13..22).toList()
    val classic = (0..12).toList()
    /** How many extra pictures a template can show (besides the main image). */
    fun extraSlots(t: Int) = when (t) { 8 -> 2; 9 -> 1; 10 -> 2; 11 -> 1; 12 -> 2; else -> 0 }
    val textAnims = listOf(
        "Fade In", "Slide From Right", "Slide From Left", "Slide From Bottom", "Pop In", "Zoom In",
        "Slide From Top", "Zoom Out", "Bounce Drop", "Flip", "Rotate In", "Spin Zoom",
        "Wipe Left → Right", "Wipe Right → Left", "Wipe Top → Bottom", "Elastic", "Shake In", "Swing",
        "Glitch", "Stretch", "Skew Slide", "Flash", "Typewriter", "Rise & Fade"
    )
    val imageAnims = listOf(
        "Slow Zoom In", "Slow Zoom Out", "Pan Left", "Pan Right", "Static Image",
        "Pan Up", "Pan Down", "Diagonal Drift", "Breathing Zoom", "Slow Rotate",
        "Handheld Shake", "Punch In", "Zoom Out Drift", "Swing Pan"
    )
    val transitions = listOf(
        "Fade", "Slide", "Crossfade", "Simple Cut",
        "Slide Right", "Slide Up", "Slide Down", "Wipe →", "Wipe ←", "Wipe ↓",
        "Zoom In", "Zoom Out", "Push", "Circle Reveal", "Blinds", "Diagonal Wipe",
        "Flash", "Spin", "Glitch", "Split Open", "Flip", "Auto (varied)"
    )
    val idleFx = listOf("None", "Shine sweep", "Breathing pulse", "Floating", "Shine + Floating")
    val logoPositions = listOf("Top Left", "Top Right", "Bottom Left", "Bottom Right")
}

@Serializable
data class Card(
    val id: String = UUID.randomUUID().toString(),
    val template: Int = 0,
    val headline: String = "",
    val description: String = "",
    val textScale: Float = 1f,
    val textColor: Int = Pal.White,
    val bgColor: Int = Pal.Navy,
    val imagePath: String? = null,
    val extraImages: List<String> = emptyList(),
    val gallery: List<String> = emptyList(),   // unlimited extra pictures: shown one after another inside the card
    val slideFx: Int = 0,                      // transition between those pictures
    val imgScale: Float = 1f,
    val imgX: Float = 0f,
    val imgY: Float = 0f,
    val logoPos: Int = 1,
    val tickerText: String = "",
    val textAnim: Int = 0,
    val imageAnim: Int = 0,
    val transition: Int = 0,
    val animMs: Int = 700,
    val animSpeed: Float = 1f,
    val exitAnim: Int = 0,      // 0 = none, k+1 = text animation k played backwards before the card ends
    val idleFx: Int = 1,        // looping effect after the entrance
    val transMs: Int = 700,     // transition length
    val startMs: Long = 0,
    val endMs: Long = 5000,
    val team1: String = "Pakistan",
    val team2: String = "India",
    val score: String = "",
    val overs: String = "",
    val wickets: String = "",
    val status: String = "",
    val playerName: String = "",
    val stats: String = ""
)

@Serializable
data class ProjectSettings(
    val audioPath: String? = null,
    val audioDurMs: Long = 0,
    val volume: Float = 1f,
    val landscape: Boolean = true,
    val showLogo: Boolean = true,
    val logoPath: String? = null,
    val logoSize: Float = 0.16f,
    val logoOpacity: Float = 1f,
    val showChannelName: Boolean = true,
    val channelName: String = "ZAFAR CRICKET HUB",
    val tickerOn: Boolean = true,
    val tickerText: String = DEFAULT_TICKER,
    val tickerColor: Int = Pal.White,
    val tickerBg: Int = Pal.Navy,
    val tickerSize: Float = 1f,
    val tickerSpeed: Float = 120f,
    val tickerLabel: String = "BREAKING NEWS",
    val tickerStyle: Int = 0,   // 0 = label box on the right, 1 = plain full-width strip (TV style)
    val endMode: Int = 0,
    val customEndMs: Long = 0,
    val allowOverlap: Boolean = false,
    val ripple: Boolean = false
)

const val DEFAULT_TICKER = "بریکنگ نیوز: زفر کرکٹ ہب پر تازہ ترین کرکٹ خبریں  •  Zafar Cricket Hub"

/** Main picture first, then the gallery (unlimited). */
fun Card.pictures(): List<String> = (listOfNotNull(imagePath) + gallery).filter { it.isNotBlank() }

@Serializable
data class ExportRec(val uri: String, val name: String, val time: Long, val info: String)

@Serializable
data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Untitled",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val settings: ProjectSettings = ProjectSettings(),
    val cards: List<Card> = emptyList(),
    val exportStatus: String = "none",
    val exports: List<ExportRec> = emptyList()
)

val AppJson = Json { ignoreUnknownKeys = true; encodeDefaults = true }

object Samples {
    fun card(t: Int, start: Long = 0, end: Long = start + 5000): Card {
        val base = Card(template = t, startMs = start, endMs = end)
        val card = when (t) {
            0 -> base.copy(
                headline = "پاکستان نے سنسنی خیز مقابلے کے بعد سیریز جیت لی",
                description = "قومی ٹیم نے آخری اوور میں شاندار کھیل پیش کرتے ہوئے ہدف حاصل کر لیا۔",
                bgColor = Pal.Navy
            )
            1 -> base.copy(
                headline = "اہم خبر: قومی کرکٹ ٹیم کا اعلان",
                description = "سلیکشن کمیٹی نے آئندہ سیریز کے لیے اسکواڈ کا اعلان کر دیا ہے۔"
            )
            2 -> base.copy(
                headline = "پاکستان بمقابلہ بھارت: ہائی وولٹیج مقابلہ آج",
                team1 = "Pakistan", team2 = "India", score = "182/4", overs = "18.2", wickets = "4",
                status = "پاکستان کو جیت کے لیے 12 رنز درکار", bgColor = Pal.DeepNavy
            )
            3 -> base.copy(
                headline = "ہیڈ لائن: قومی ٹیم کی شاندار فتح",
                description = "کپتان نے کھلاڑیوں کی کارکردگی کو سراہا۔"
            )
            4 -> base.copy(
                headline = "خصوصی رپورٹ: کرکٹ کا نیا دور",
                description = "ڈومیسٹک کرکٹ میں نوجوان کھلاڑیوں کی شاندار کارکردگی۔",
                bgColor = Pal.DeepNavy
            )
            5 -> base.copy(
                headline = "پاکستان بمقابلہ انگلینڈ",
                team1 = "Pakistan", team2 = "England", score = "245/6", overs = "50.0", wickets = "6",
                status = "پاکستان 38 رنز سے جیت گیا"
            )
            6 -> base.copy(
                headline = "شاندار بیٹنگ کارکردگی", playerName = "بابر اعظم",
                stats = "Runs: 112\nBalls: 94\nStrike Rate: 119.1\nFours: 11\nSixes: 3"
            )
            7 -> base.copy(
                headline = "بریکنگ نیوز: بڑی خبر آ گئی",
                description = "مزید تفصیلات کے لیے دیکھتے رہیے زفر کرکٹ ہب۔",
                bgColor = Pal.Red
            )
            8 -> base.copy(
                headline = "پاک بھارت میچ کی یادگار تصاویر",
                description = "شائقین کا جوش و خروش اسٹیڈیم میں دیدنی تھا۔"
            )
            9 -> base.copy(
                headline = "ہائی وولٹیج مقابلہ: پاکستان بمقابلہ بھارت",
                team1 = "Pakistan", team2 = "India", score = "172/5", overs = "17.3", wickets = "5",
                status = "پاکستان کو 18 گیندوں پر 23 رنز درکار"
            )
            10 -> base.copy(
                headline = "فتح کے بعد کھلاڑیوں کا جشن",
                description = "کپتان اور ٹیم نے ٹرافی کے ساتھ تصاویر بنوائیں۔"
            )
            11 -> base.copy(
                headline = "مین آف دی میچ", playerName = "شاہین آفریدی",
                stats = "Wickets: 4\nOvers: 4\nEconomy: 6.5\nMaidens: 1",
                team1 = "Pakistan", team2 = "Australia"
            )
            12 -> base.copy(
                headline = "اسٹیڈیم میں شائقین کا سمندر",
                description = "نیشنل اسٹیڈیم کراچی میں ہزاروں شائقین موجود تھے۔"
            )
            13, 14, 15, 16, 22 -> base.copy(headline = "پاکستان | ٹیسٹ کرکٹ", description = "")
            17 -> base.copy(headline = "پاکستان بمقابلہ انگلینڈ | ٹیسٹ کرکٹ", team1 = "Pakistan", team2 = "England", score = "245/6", overs = "50.0", wickets = "6")
            18 -> base.copy(headline = "قومی ٹیم کی شاندار کارکردگی", textColor = Pal.DeepNavy)
            19 -> base.copy(headline = "پاکستان نے سیریز اپنے نام کر لی", description = "کپتان کا کہنا تھا کہ ٹیم نے مل کر کھیلا")
            20 -> base.copy(headline = "پاکستان کی تاریخی فتح", description = "شائقین کا جشن، سڑکوں پر خوشی کا سماں")
            else -> base.copy(headline = "پاکستان | ٹیسٹ کرکٹ", description = "BREAKING NEWS")
        }
        val k = t.coerceIn(0, TEXT_DEF.size - 1)
        return card.copy(textAnim = TEXT_DEF[k], transition = TRANS_DEF[k], imageAnim = IMG_DEF[k])
    }

    private val TEXT_DEF = intArrayOf(13, 6, 1, 22, 8, 4, 2, 16, 10, 19, 12, 9, 15, 12, 13, 2, 6, 3, 12, 6, 22, 2, 8)
    private val TRANS_DEF = intArrayOf(13, 10, 12, 7, 19, 14, 18, 16, 17, 4, 15, 20, 21, 7, 8, 5, 9, 13, 15, 4, 10, 12, 14)
    private val IMG_DEF = intArrayOf(0, 5, 7, 0, 11, 8, 0, 9, 10, 13, 0, 7, 12, 0, 1, 7, 0, 12, 0, 8, 11, 0, 13)
}
