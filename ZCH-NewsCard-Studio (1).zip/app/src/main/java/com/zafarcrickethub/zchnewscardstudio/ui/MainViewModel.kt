package com.zafarcrickethub.zchnewscardstudio.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zafarcrickethub.zchnewscardstudio.ZchApp
import com.zafarcrickethub.zchnewscardstudio.audio.AudioUtils
import com.zafarcrickethub.zchnewscardstudio.audio.Playback
import com.zafarcrickethub.zchnewscardstudio.data.AppSettings
import com.zafarcrickethub.zchnewscardstudio.data.Card
import com.zafarcrickethub.zchnewscardstudio.data.ExportRec
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.data.ProjectSettings
import com.zafarcrickethub.zchnewscardstudio.data.Samples
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportState
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportService
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportUi
import com.zafarcrickethub.zchnewscardstudio.renderer.ThumbRenderer
import com.zafarcrickethub.zchnewscardstudio.renderer.ThumbSpec
import com.zafarcrickethub.zchnewscardstudio.utils.MediaSaver
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

enum class Screen { Dashboard, Projects, Templates, Exports, Settings, Help, Editor, Thumbnail }

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as ZchApp).repo
    private val ctx: Context get() = getApplication<Application>()

    var screen by mutableStateOf(Screen.Dashboard)
    val projects = repo.projects.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val settings = repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    var current by mutableStateOf<Project?>(null)
    var tab by mutableIntStateOf(0)
    var editingCard by mutableStateOf<String?>(null)
    var waveform by mutableStateOf<FloatArray?>(null)
    var message by mutableStateOf<String?>(null)
    var thumb by mutableStateOf(ThumbSpec())
    var thumbVideoMs by mutableStateOf(0L)
    var thumbVideoUri by mutableStateOf<Uri?>(null)
    val playback = Playback()
    private var saveJob: Job? = null

    init {
        // keep export info of the open project fresh (service writes it to the DB)
        viewModelScope.launch {
            projects.collect { list ->
                val c = current ?: return@collect
                val d = list.find { it.id == c.id } ?: return@collect
                if (d.exports != c.exports || d.exportStatus != c.exportStatus) current = c.copy(exports = d.exports, exportStatus = d.exportStatus)
            }
        }
    }

    // ------------------------------------------------------------ navigation
    fun go(s: Screen) { screen = s }

    fun back() {
        if (screen == Screen.Editor) {
            if (editingCard != null) { editingCard = null; return }
            saveNow(); playback.pause()
            screen = Screen.Projects
        } else screen = Screen.Dashboard
    }

    // ------------------------------------------------------------ projects
    fun createProject(name: String, template: Int) {
        val st = settings.value
        val p = Project(
            name = name.ifBlank { "New Project" },
            settings = ProjectSettings(landscape = st.landscape, channelName = st.channelName, tickerText = st.ticker),
            cards = listOf(Samples.card(template))
        )
        viewModelScope.launch { repo.save(p); open(p.id) }
    }

    fun open(id: String) {
        viewModelScope.launch {
            val p = repo.load(id)
            if (p == null) { message = "Project could not be opened"; return@launch }
            current = p; tab = 0; editingCard = null
            playback.positionMs = 0
            reloadAudio()
            repo.setLast(id)
            screen = Screen.Editor
        }
    }

    fun rename(id: String, name: String) {
        viewModelScope.launch {
            val p = repo.load(id) ?: return@launch
            repo.save(p.copy(name = name.ifBlank { p.name }, updatedAt = System.currentTimeMillis()))
            if (current?.id == id) current = current?.copy(name = name.ifBlank { p.name })
        }
    }

    fun duplicate(id: String) { viewModelScope.launch { repo.duplicate(id); message = "Project duplicated" } }
    fun delete(id: String) { viewModelScope.launch { repo.delete(id); if (current?.id == id) current = null } }

    fun mutate(block: (Project) -> Project) {
        val p = current ?: return
        val n = block(p).copy(updatedAt = System.currentTimeMillis())
        current = n
        playback.totalMs = Timing.totalMs(n)
        saveJob?.cancel()
        saveJob = viewModelScope.launch { delay(400); repo.saveEdit(n) }
    }

    fun saveNow() {
        val p = current ?: return
        saveJob?.cancel()
        viewModelScope.launch { repo.saveEdit(p) }
    }

    fun updateSettings(f: (ProjectSettings) -> ProjectSettings) = mutate { it.copy(settings = f(it.settings)) }

    fun updateAppSettings(f: (AppSettings) -> AppSettings) { viewModelScope.launch { repo.updateSettings(f(settings.value)) } }

    // ------------------------------------------------------------ cards
    fun updateCard(id: String, f: (Card) -> Card) = mutate { p -> p.copy(cards = p.cards.map { if (it.id == id) f(it) else it }) }

    fun addCard(template: Int) = mutate { p ->
        val start = p.cards.maxOfOrNull { it.endMs } ?: 0L
        p.copy(cards = p.cards + Samples.card(template, start, start + 5000))
    }

    fun deleteCard(id: String) = mutate { p -> p.copy(cards = p.cards.filter { it.id != id }) }

    fun duplicateCard(id: String) = mutate { p ->
        val i = p.cards.indexOfFirst { it.id == id }
        if (i < 0) p else {
            val c = p.cards[i]
            val dur = c.endMs - c.startMs
            val copy = c.copy(id = UUID.randomUUID().toString(), startMs = c.endMs, endMs = c.endMs + dur)
            val before = p.cards.take(i + 1)
            val after = p.cards.drop(i + 1).map { it.copy(startMs = it.startMs + dur, endMs = it.endMs + dur) }
            p.copy(cards = before + copy + after)
        }
    }

    /** Moves card content; the time slots stay where they are so the audio alignment is kept. */
    fun moveCard(id: String, dir: Int) = mutate { p ->
        val i = p.cards.indexOfFirst { it.id == id }
        val j = i + dir
        if (i < 0 || j < 0 || j >= p.cards.size) p else {
            val l = p.cards.toMutableList()
            val a = l[i]; val b = l[j]
            l[i] = b.copy(startMs = a.startMs, endMs = a.endMs)
            l[j] = a.copy(startMs = b.startMs, endMs = b.endMs)
            p.copy(cards = l)
        }
    }

    /** Manual timing. Optionally moves the following cards (ripple) so nothing overlaps. */
    fun setTiming(id: String, start: Long?, end: Long?) {
        val p = current ?: return
        val i = p.cards.indexOfFirst { it.id == id }
        if (i < 0) return
        val c = p.cards[i]
        val s = start ?: c.startMs
        val e = end ?: c.endMs
        if (s < 0) { message = "Start time cannot be negative"; return }
        if (e <= s) { message = "End time must be after start time"; return }
        val audio = p.settings.audioDurMs
        if (audio > 0 && e > audio + 100) message = "Note: this card ends after the voice-over (${Timing.fmt(audio)})"
        val delta = e - c.endMs
        mutate { pr ->
            pr.copy(cards = pr.cards.mapIndexed { j, x ->
                when {
                    j == i -> x.copy(startMs = s, endMs = e)
                    pr.settings.ripple && j > i && delta != 0L ->
                        x.copy(startMs = (x.startMs + delta).coerceAtLeast(0L), endMs = (x.endMs + delta).coerceAtLeast(1L))
                    else -> x
                }
            })
        }
    }

    fun setDuration(id: String, durMs: Long) {
        val c = current?.cards?.find { it.id == id } ?: return
        if (durMs <= 0) { message = "Duration must be greater than zero"; return }
        setTiming(id, null, c.startMs + durMs)
    }

    fun nudge(id: String, startDelta: Long, endDelta: Long) {
        val c = current?.cards?.find { it.id == id } ?: return
        setTiming(id, (c.startMs + startDelta).coerceAtLeast(0L), c.endMs + endDelta)
    }

    fun startAfterPrevious(id: String) {
        val p = current ?: return
        val i = p.cards.indexOfFirst { it.id == id }
        if (i <= 0) return
        val c = p.cards[i]
        val s = p.cards[i - 1].endMs
        setTiming(id, s, s + (c.endMs - c.startMs))
    }

    fun setEdge(index: Int, isEnd: Boolean, ms: Long) = mutate { p ->
        val l = p.cards.toMutableList()
        if (index !in l.indices) return@mutate p
        val c = l[index]
        if (isEnd) {
            val ne = maxOf(ms, c.startMs + 200)
            l[index] = c.copy(endMs = ne)
            val n = l.getOrNull(index + 1)
            if (n != null && !p.settings.allowOverlap && kotlin.math.abs(n.startMs - c.endMs) <= 1) {
                l[index + 1] = n.copy(startMs = ne, endMs = maxOf(n.endMs, ne + 200))
            }
        } else {
            val ns = minOf(ms, c.endMs - 200).coerceAtLeast(0)
            l[index] = c.copy(startMs = ns)
            val pr = l.getOrNull(index - 1)
            if (pr != null && !p.settings.allowOverlap && kotlin.math.abs(pr.endMs - c.startMs) <= 1) {
                l[index - 1] = pr.copy(endMs = ns, startMs = minOf(pr.startMs, ns - 200).coerceAtLeast(0))
            }
        }
        p.copy(cards = l)
    }

    fun distribute() = mutate { p ->
        val total = if (p.settings.audioDurMs > 0) p.settings.audioDurMs else p.cards.size * 5000L
        p.copy(cards = Timing.distribute(p.cards, total))
    }

    // ------------------------------------------------------------ assets
    fun importCardImage(cardId: String, uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                val path = repo.importAsset(p.id, uri, "img")
                if (com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path) == null) { File(path).delete(); message = "Unsupported or damaged image"; return@launch }
                updateCard(cardId) { it.copy(imagePath = path, imgScale = 1f, imgX = 0f, imgY = 0f) }
            } catch (e: Exception) { message = "Could not import image: ${e.message}" }
        }
    }

    fun importLogo(uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                val path = repo.importAsset(p.id, uri, "logo")
                if (com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path, 800) == null) { File(path).delete(); message = "Unsupported logo image"; return@launch }
                updateSettings { it.copy(logoPath = path) }
            } catch (e: Exception) { message = "Could not import logo: ${e.message}" }
        }
    }

    fun importAudio(uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                val path = repo.importAsset(p.id, uri, "audio")
                val ok = withContext(Dispatchers.IO) { AudioUtils.canDecode(path) }
                val dur = withContext(Dispatchers.IO) { AudioUtils.duration(path) }
                if (!ok || dur <= 0) { File(path).delete(); message = "This audio file is not supported on this device"; return@launch }
                val old = current?.settings?.audioPath
                updateSettings { it.copy(audioPath = path, audioDurMs = dur) }
                if (old != null && old != path) File(old).delete()
                reloadAudio()
            } catch (e: Exception) { message = "Could not import audio: ${e.message}" }
        }
    }

    fun removeAudio() {
        val old = current?.settings?.audioPath
        updateSettings { it.copy(audioPath = null, audioDurMs = 0) }
        if (old != null) File(old).delete()
        reloadAudio()
    }

    fun setVolume(v: Float) {
        updateSettings { it.copy(volume = v) }
        playback.voice.volume(v)
    }

    fun reloadAudio() {
        val s = current?.settings
        playback.totalMs = current?.let { Timing.totalMs(it) } ?: 0L
        playback.load(s?.audioPath, s?.volume ?: 1f, s?.audioDurMs ?: 0L)
        waveform = null
        val path = s?.audioPath ?: return
        viewModelScope.launch { waveform = withContext(Dispatchers.Default) { runCatching { AudioUtils.waveform(path) }.getOrNull() } }
    }

    // ------------------------------------------------------------ export
    fun startExport(w: Int, h: Int, fps: Int, vbr: Int, abr: Int, name: String, land: Boolean, endMode: Int, customEnd: Long) {
        val p = current ?: return
        if (ExportState.busy.get()) { message = "An export is already running"; return }
        saveNow()
        playback.pause()
        ExportState.state.value = ExportUi.Running(0f, "Starting", p.id)
        val safe = name.replace(Regex("[^\\p{L}\\p{N} _.-]"), "_").ifBlank { "ZCH_video" }
        val i = Intent(ctx, ExportService::class.java)
            .putExtra("id", p.id).putExtra("w", w).putExtra("h", h).putExtra("fps", fps)
            .putExtra("vbr", vbr).putExtra("abr", abr).putExtra("name", safe).putExtra("land", land)
            .putExtra("endMode", endMode).putExtra("customEnd", customEnd)
        ContextCompat.startForegroundService(ctx, i)
    }

    fun cancelExport() { ExportState.cancel = true }

    fun deleteExport(projectId: String, rec: ExportRec) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { MediaSaver.delete(ctx, rec.uri) }
            repo.removeExport(projectId, rec.uri)
        }
    }

    // ------------------------------------------------------------ thumbnail maker
    fun importThumbImage(uri: Uri, kind: Int) {
        viewModelScope.launch {
            try {
                val path = repo.importAsset("thumbs", uri, "t")
                if (com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path) == null) { message = "Unsupported image"; return@launch }
                thumb = when (kind) {
                    0 -> thumb.copy(bgPath = path, bgMode = 3)
                    1 -> thumb.copy(playerPath = path)
                    else -> thumb.copy(logoPath = path)
                }
            } catch (e: Exception) { message = "Could not import image" }
        }
    }

    fun pickThumbVideo(uri: Uri) {
        viewModelScope.launch {
            val d = withContext(Dispatchers.IO) {
                val r = MediaMetadataRetriever()
                try { r.setDataSource(ctx, uri); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L }
                catch (e: Exception) { 0L } finally { try { r.release() } catch (_: Exception) {} }
            }
            if (d <= 0) { message = "Could not read this video"; return@launch }
            thumbVideoUri = uri; thumbVideoMs = d
            grabFrame(0f)
        }
    }

    fun grabFrame(fraction: Float) {
        val uri = thumbVideoUri ?: return
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, uri)
                    val bmp = r.getFrameAtTime((thumbVideoMs * fraction).toLong() * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                    if (bmp == null) null else {
                        val f = File(repo.projectDir("thumbs"), "frame_${System.currentTimeMillis()}.jpg")
                        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                        f.path
                    }
                } catch (e: Exception) { null } finally { try { r.release() } catch (_: Exception) {} }
            }
            if (path != null) thumb = thumb.copy(bgPath = path, bgMode = 3) else message = "Could not read a frame"
        }
    }

    fun saveThumbnail(png: Boolean) {
        val t = thumb
        viewModelScope.launch {
            val ok = withContext(Dispatchers.Default) {
                try {
                    val bmp = Bitmap.createBitmap(ThumbRenderer.W, ThumbRenderer.H, Bitmap.Config.ARGB_8888)
                    ThumbRenderer.draw(ctx, android.graphics.Canvas(bmp), ThumbRenderer.W, ThumbRenderer.H, t)
                    val f = File(ctx.cacheDir, "thumb_tmp." + if (png) "png" else "jpg")
                    f.outputStream().use { bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it) }
                    val name = "ZCH_thumbnail_${System.currentTimeMillis()}." + if (png) "png" else "jpg"
                    val uri = MediaSaver.save(ctx, f, name, if (png) "image/png" else "image/jpeg", false)
                    f.delete()
                    uri != null
                } catch (e: Exception) { false }
            }
            message = if (ok) "Thumbnail saved to Pictures/${MediaSaver.FOLDER}" else "Could not save thumbnail"
        }
    }

    override fun onCleared() { playback.voice.release(); super.onCleared() }
}
