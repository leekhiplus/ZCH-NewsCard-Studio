package com.zafarcrickethub.zchnewscardstudio.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zafarcrickethub.zchnewscardstudio.ZchApp
import com.zafarcrickethub.zchnewscardstudio.audio.AudioUtils
import com.zafarcrickethub.zchnewscardstudio.audio.OboeRecorder
import com.zafarcrickethub.zchnewscardstudio.audio.VoicePauses
import com.zafarcrickethub.zchnewscardstudio.graphics.Bmp
import com.zafarcrickethub.zchnewscardstudio.graphics.LottieSticker
import com.zafarcrickethub.zchnewscardstudio.utils.CropRequest
import com.zafarcrickethub.zchnewscardstudio.utils.PhotoTools
import com.zafarcrickethub.zchnewscardstudio.utils.VideoCompressor
import com.zafarcrickethub.zchnewscardstudio.audio.Playback
import com.zafarcrickethub.zchnewscardstudio.audio.VoiceClip
import com.zafarcrickethub.zchnewscardstudio.data.AppSettings
import com.zafarcrickethub.zchnewscardstudio.data.Card
import com.zafarcrickethub.zchnewscardstudio.data.ExportRec
import com.zafarcrickethub.zchnewscardstudio.data.Overlay
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.data.ProjectSettings
import com.zafarcrickethub.zchnewscardstudio.data.Samples
import com.zafarcrickethub.zchnewscardstudio.data.pictures
import com.zafarcrickethub.zchnewscardstudio.graphics.VideoFrames
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportState
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportService
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportUi
import com.zafarcrickethub.zchnewscardstudio.renderer.ThumbRenderer
import com.zafarcrickethub.zchnewscardstudio.renderer.ThumbSpec
import com.zafarcrickethub.zchnewscardstudio.utils.ScriptSplitter
import com.zafarcrickethub.zchnewscardstudio.utils.FFmpegHelper
import com.zafarcrickethub.zchnewscardstudio.utils.GeminiTts
import com.zafarcrickethub.zchnewscardstudio.utils.MediaSaver
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

enum class Screen { Dashboard, Projects, Templates, Exports, Settings, Help, Editor, Thumbnail }

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as ZchApp).repo
    private val ctx: Context get() = getApplication<Application>()

    var screen by mutableStateOf(Screen.Dashboard)
    val projects = repo.projects.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val settings = repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    var current by mutableStateOf<Project?>(null)
    var tab by mutableIntStateOf(0)
    var sel by mutableStateOf("")          // "", "card:<id>", "audio", "ticker", "logo"
    var sheet by mutableStateOf("")        // bottom sheet in the editor
    var fullPreview by mutableStateOf(false)
    var showExport by mutableStateOf(false)
    var ttsBusy by mutableStateOf(false)
    var aiBusy by mutableStateOf(false)
    var aiStatus by mutableStateOf("")
    var aiResult by mutableStateOf<String?>(null)   // shown in a dialog so it can never be missed
    var aiScript by mutableStateOf("")
    var ttsScript by mutableStateOf("")
    var ttsStyle by mutableStateOf("")
    var cardTab by mutableIntStateOf(0)             // tab shown in the card editor
    var cardScript by mutableStateOf("")            // script pasted in the card editor
    var dragCard by mutableStateOf<String?>(null)   // card being re-ordered on the timeline
    var dragShiftPx by mutableStateOf(0f)
    var zoomDp by mutableStateOf(60f)      // timeline zoom (dp per second)
    var undoCount by mutableIntStateOf(0)
    var redoCount by mutableIntStateOf(0)
    private val undoStack = ArrayDeque<Project>()
    private val redoStack = ArrayDeque<Project>()
    private var lastPush = 0L
    var editingCard by mutableStateOf<String?>(null)
    var waveform by mutableStateOf<FloatArray?>(null)
    var message by mutableStateOf<String?>(null)
    var thumb by mutableStateOf(ThumbSpec())
    var thumbVideoMs by mutableStateOf(0L)
    var thumbVideoUri by mutableStateOf<Uri?>(null)
    val playback = Playback()
    private var saveJob: Job? = null

    init {
        // keep export info of the open project fresh (service writes it to the DB)
        viewModelScope.launch {
            projects.collect { list ->
                val c = current ?: return@collect
                val d = list.find { it.id == c.id } ?: return@collect
                if (d.exports != c.exports || d.exportStatus != c.exportStatus) current = c.copy(exports = d.exports, exportStatus = d.exportStatus)
            }
        }
    }

    // ------------------------------------------------------------ navigation
    fun go(s: Screen) { screen = s }

    fun back() {
        if (screen == Screen.Editor) {
            when {
                showExport -> showExport = false
                fullPreview -> { playback.pause(); fullPreview = false }
                sheet.isNotEmpty() -> sheet = ""
                editingCard != null -> editingCard = null
                sel.isNotEmpty() -> sel = ""
                else -> { saveNow(); playback.pause(); screen = Screen.Projects }
            }
        } else screen = Screen.Dashboard
    }

    // ------------------------------------------------------------ projects
    fun createProject(name: String, template: Int) {
        val st = settings.value
        val p = Project(
            name = name.ifBlank { "New Project" },
            settings = ProjectSettings(landscape = st.landscape, channelName = st.channelName, tickerText = st.ticker, tickerStyle = 1, tickerBg = com.zafarcrickethub.zchnewscardstudio.data.Pal.Red),
            cards = listOf(Samples.card(template))
        )
        viewModelScope.launch { repo.save(p); open(p.id) }
    }

    fun open(id: String, sheetAfter: String = "") {
        viewModelScope.launch {
            val p = repo.load(id)
            if (p == null) { message = "Project could not be opened"; return@launch }
            current = p; tab = 0; editingCard = null
            sel = ""; sheet = sheetAfter; showExport = false; fullPreview = false
            undoStack.clear(); redoStack.clear(); undoCount = 0; redoCount = 0; lastPush = 0L
            playback.positionMs = 0
            syncClips(p)
            reloadAudio()
            repo.setLast(id)
            screen = Screen.Editor
        }
    }

    fun rename(id: String, name: String) {
        viewModelScope.launch {
            val p = repo.load(id) ?: return@launch
            repo.save(p.copy(name = name.ifBlank { p.name }, updatedAt = System.currentTimeMillis()))
            if (current?.id == id) current = current?.copy(name = name.ifBlank { p.name })
        }
    }

    fun duplicate(id: String) { viewModelScope.launch { repo.duplicate(id); message = "Project duplicated" } }
    fun delete(id: String) { viewModelScope.launch { repo.delete(id); if (current?.id == id) current = null } }

    fun mutate(block: (Project) -> Project) {
        val p = current ?: return
        val n = block(p).copy(updatedAt = System.currentTimeMillis())
        val now = System.currentTimeMillis()
        if (now - lastPush > 700L) {   // coalesce continuous edits (typing, slider drags)
            undoStack.addLast(p)
            if (undoStack.size > 60) undoStack.removeFirst()
            redoStack.clear()
        }
        lastPush = now
        undoCount = undoStack.size; redoCount = redoStack.size
        current = n
        playback.totalMs = Timing.totalMs(n)
        syncClips(n)
        saveJob?.cancel()
        saveJob = viewModelScope.launch { delay(400); repo.saveEdit(n) }
    }

    fun saveNow() {
        val p = current ?: return
        saveJob?.cancel()
        viewModelScope.launch { repo.saveEdit(p) }
    }

    private fun restore(target: Project) {
        val cur = current ?: return
        val audioChanged = cur.settings.audioPath != target.settings.audioPath
        current = target.copy(exports = cur.exports, exportStatus = cur.exportStatus, updatedAt = System.currentTimeMillis())
        playback.totalMs = Timing.totalMs(current!!)
        syncClips(current!!)
        if (audioChanged) reloadAudio()
        lastPush = 0L
        undoCount = undoStack.size; redoCount = redoStack.size
        if (sel.startsWith("card:") && current!!.cards.none { it.id == sel.removePrefix("card:") }) sel = ""
        saveNow()
    }

    fun undo() {
        val cur = current ?: return
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(cur)
        restore(prev)
    }

    fun redo() {
        val cur = current ?: return
        val nxt = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(cur)
        restore(nxt)
    }

    private fun syncClips(p: Project) {
        playback.clips = p.cards.filter { it.voicePath != null && it.voiceDurMs > 0 }.map { VoiceClip(it.voicePath!!, it.startMs, it.startMs + it.voiceDurMs) }
    }

    fun updateSettings(f: (ProjectSettings) -> ProjectSettings) = mutate { it.copy(settings = f(it.settings)) }

    fun updateAppSettings(f: (AppSettings) -> AppSettings) { viewModelScope.launch { repo.updateSettings(f(settings.value)) } }

    // ------------------------------------------------------------ cards
    fun updateCard(id: String, f: (Card) -> Card) = mutate { p -> p.copy(cards = p.cards.map { if (it.id == id) f(it) else it }) }

    fun addCard(template: Int) {
        val start = current?.cards?.maxOfOrNull { it.endMs } ?: 0L
        val card = Samples.card(template, start, start + 5000)
        mutate { p -> p.copy(cards = p.cards + card) }
        sel = "card:" + card.id
        playback.seek(start + 300)
    }

    fun deleteCard(id: String) {
        mutate { p -> p.copy(cards = p.cards.filter { it.id != id }) }
        if (sel == "card:$id") sel = ""
    }

    /** CapCut-style split: cuts the card at the play-head into two cards. */
    fun splitCard(id: String, at: Long) {
        val p = current ?: return
        val i = p.cards.indexOfFirst { it.id == id }
        if (i < 0) return
        val c = p.cards[i]
        if (at <= c.startMs + 200 || at >= c.endMs - 200) { message = "Move the play-head inside the card to split it"; return }
        val first = c.copy(endMs = at)
        val second = c.copy(id = UUID.randomUUID().toString(), startMs = at)
        mutate { pr -> pr.copy(cards = pr.cards.take(i) + first + second + pr.cards.drop(i + 1)) }
        sel = "card:" + second.id
    }

    fun duplicateCard(id: String) = mutate { p ->
        val i = p.cards.indexOfFirst { it.id == id }
        if (i < 0) p else {
            val c = p.cards[i]
            val dur = c.endMs - c.startMs
            val copy = c.copy(id = UUID.randomUUID().toString(), startMs = c.endMs, endMs = c.endMs + dur)
            val before = p.cards.take(i + 1)
            val after = p.cards.drop(i + 1).map { it.copy(startMs = it.startMs + dur, endMs = it.endMs + dur) }
            p.copy(cards = before + copy + after)
        }
    }

    /** Moves card content; the time slots stay where they are so the audio alignment is kept. */
    fun moveCard(id: String, dir: Int) = mutate { p ->
        val i = p.cards.indexOfFirst { it.id == id }
        val j = i + dir
        if (i < 0 || j < 0 || j >= p.cards.size) p else {
            val l = p.cards.toMutableList()
            val a = l[i]; val b = l[j]
            l[i] = b.copy(startMs = a.startMs, endMs = a.endMs)
            l[j] = a.copy(startMs = b.startMs, endMs = b.endMs)
            p.copy(cards = l)
        }
    }

    /** Manual timing. Optionally moves the following cards (ripple) so nothing overlaps. */
    fun setTiming(id: String, start: Long?, end: Long?) {
        val p = current ?: return
        val i = p.cards.indexOfFirst { it.id == id }
        if (i < 0) return
        val c = p.cards[i]
        val s = start ?: c.startMs
        val e = end ?: c.endMs
        if (s < 0) { message = "Start time cannot be negative"; return }
        if (e <= s) { message = "End time must be after start time"; return }
        val audio = p.settings.audioDurMs
        if (audio > 0 && e > audio + 100) message = "Note: this card ends after the voice-over (${Timing.fmt(audio)})"
        val delta = e - c.endMs
        mutate { pr ->
            pr.copy(cards = pr.cards.mapIndexed { j, x ->
                when {
                    j == i -> x.copy(startMs = s, endMs = e)
                    pr.settings.ripple && j > i && delta != 0L ->
                        x.copy(startMs = (x.startMs + delta).coerceAtLeast(0L), endMs = (x.endMs + delta).coerceAtLeast(1L))
                    else -> x
                }
            })
        }
    }

    fun setDuration(id: String, durMs: Long) {
        val c = current?.cards?.find { it.id == id } ?: return
        if (durMs <= 0) { message = "Duration must be greater than zero"; return }
        setTiming(id, null, c.startMs + durMs)
    }

    fun nudge(id: String, startDelta: Long, endDelta: Long) {
        val c = current?.cards?.find { it.id == id } ?: return
        setTiming(id, (c.startMs + startDelta).coerceAtLeast(0L), c.endMs + endDelta)
    }

    fun startAfterPrevious(id: String) {
        val p = current ?: return
        val i = p.cards.indexOfFirst { it.id == id }
        if (i <= 0) return
        val c = p.cards[i]
        val s = p.cards[i - 1].endMs
        setTiming(id, s, s + (c.endMs - c.startMs))
    }

    /**
     * Drag of a card edge on the timeline (InShot style): a card can never be pushed over or under its neighbours.
     *  - end edge: the cards after it move along (pushed / pulled back), so nothing overlaps and no gap appears.
     *  - start edge: the shared boundary with the previous card moves (the previous card gets shorter / longer);
     *    `roll` = the two cards were touching when the finger grabbed the edge. Without a touching neighbour the
     *    edge simply stops at the previous card.
     * Overlapping is only possible when "Allow overlapping cards" is switched on.
     */
    fun trimCardEdge(index: Int, isEnd: Boolean, ms: Long, roll: Boolean) = mutate { p ->
        val l = p.cards.toMutableList()
        if (index !in l.indices) return@mutate p
        val c = l[index]
        val minLen = 200L
        val free = p.settings.allowOverlap
        if (isEnd) {
            val ne = maxOf(ms, c.startMs + minLen)
            val delta = ne - c.endMs
            l[index] = c.copy(endMs = ne)
            if (!free && delta != 0L) {
                for (j in index + 1 until l.size) {
                    val x = l[j]
                    l[j] = x.copy(startMs = (x.startMs + delta).coerceAtLeast(0L), endMs = (x.endMs + delta).coerceAtLeast(minLen))
                }
            }
        } else {
            val pr = l.getOrNull(index - 1)
            var ns = minOf(ms, c.endMs - minLen).coerceAtLeast(0L)
            if (pr != null && !free) ns = maxOf(ns, if (roll) pr.startMs + minLen else pr.endMs)
            ns = minOf(ns, c.endMs - minLen)
            l[index] = c.copy(startMs = ns)
            if (pr != null && !free && roll) l[index - 1] = pr.copy(endMs = ns)
        }
        p.copy(cards = l)
    }

    fun setEdge(index: Int, isEnd: Boolean, ms: Long) = mutate { p ->
        val l = p.cards.toMutableList()
        if (index !in l.indices) return@mutate p
        val c = l[index]
        if (isEnd) {
            val ne = maxOf(ms, c.startMs + 200)
            l[index] = c.copy(endMs = ne)
            val n = l.getOrNull(index + 1)
            if (n != null && !p.settings.allowOverlap && kotlin.math.abs(n.startMs - c.endMs) <= 1) {
                l[index + 1] = n.copy(startMs = ne, endMs = maxOf(n.endMs, ne + 200))
            }
        } else {
            val ns = minOf(ms, c.endMs - 200).coerceAtLeast(0)
            l[index] = c.copy(startMs = ns)
            val pr = l.getOrNull(index - 1)
            if (pr != null && !p.settings.allowOverlap && kotlin.math.abs(pr.endMs - c.startMs) <= 1) {
                l[index - 1] = pr.copy(endMs = ns, startMs = minOf(pr.startMs, ns - 200).coerceAtLeast(0))
            }
        }
        p.copy(cards = l)
    }

    fun distribute() = mutate { p ->
        val total = if (p.settings.audioDurMs > 0) p.settings.audioDurMs else p.cards.size * 5000L
        p.copy(cards = Timing.distribute(p.cards, total))
    }

    // ------------------------------------------------------------ assets
    fun importCardImage(cardId: String, uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                val path = repo.importAsset(p.id, uri, "img")
                if (com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path) == null) { File(path).delete(); message = "Unsupported or damaged image"; return@launch }
                updateCard(cardId) { it.copy(imagePath = path, imgScale = 1f, imgX = 0f, imgY = 0f) }
            } catch (e: Exception) { message = "Could not import image: ${e.message}" }
        }
    }

    fun importExtraImage(cardId: String, slot: Int, uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                val path = repo.importAsset(p.id, uri, mediaPrefix(uri))
                if (!mediaReadable(path)) { File(path).delete(); message = "Unsupported or damaged picture / video"; return@launch }
                updateCard(cardId) { c ->
                    val l = c.extraImages.toMutableList()
                    while (l.size <= slot) l.add("")
                    l[slot] = path
                    c.copy(extraImages = l)
                }
            } catch (e: Exception) { message = "Could not import image: ${e.message}" }
        }
    }

    fun removeExtraImage(cardId: String, slot: Int) = updateCard(cardId) { c ->
        val l = c.extraImages.toMutableList()
        if (slot < l.size) l[slot] = ""
        c.copy(extraImages = l)
    }

    fun importLogo(uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                val path = repo.importAsset(p.id, uri, "logo")
                if (com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path, 800) == null) { File(path).delete(); message = "Unsupported logo image"; return@launch }
                updateSettings { it.copy(logoPath = path) }
            } catch (e: Exception) { message = "Could not import logo: ${e.message}" }
        }
    }

    fun importAudio(uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                var path = repo.importAsset(p.id, uri, "audio")
                var ok = withContext(Dispatchers.IO) { AudioUtils.canDecode(path) }
                if (!ok) {   // the phone cannot decode it: let FFmpeg convert it to WAV
                    val wav = File(path.substringBeforeLast('.') + "_converted.wav")
                    val done = withContext(Dispatchers.IO) { FFmpegHelper.toWav(path, wav.path) }
                    if (done && wav.exists() && wav.length() > 0) {
                        File(path).delete()
                        path = wav.path
                        ok = withContext(Dispatchers.IO) { AudioUtils.canDecode(path) }
                    }
                }
                val dur = withContext(Dispatchers.IO) { AudioUtils.duration(path) }
                if (!ok || dur <= 0) { File(path).delete(); message = "This audio file is not supported on this device"; return@launch }
                val old = current?.settings?.audioPath
                updateSettings { it.copy(audioPath = path, audioDurMs = dur) }
                reloadAudio()
            } catch (e: Exception) { message = "Could not import audio: ${e.message}" }
        }
    }

    fun removeAudio() {
        updateSettings { it.copy(audioPath = null, audioDurMs = 0) }
        reloadAudio()
    }

    /** Fills the voice-over script from the headlines / descriptions of all cards. */
    fun scriptFromCards() {
        val p = current ?: return
        ttsScript = p.cards.joinToString("\n") { c -> listOf(c.headline, c.description).filter { it.isNotBlank() }.joinToString("۔ ") }
    }

    /** Generates the voice-over WAV and installs it in the project. Returns the duration in ms (0 = failed). */
    private suspend fun makeVoice(projectId: String, text: String, style: String): Long {
        val st = settings.value
        val (pcm, rate) = withContext(Dispatchers.IO) { GeminiTts.synthesize(st.geminiKey, st.geminiModel, st.geminiVoice, text, style) }
        val file = withContext(Dispatchers.IO) {
            File(repo.projectDir(projectId), "voice_${System.currentTimeMillis()}.wav").also { it.writeBytes(GeminiTts.pcmToWav(pcm, rate)) }
        }
        val dur = withContext(Dispatchers.IO) { AudioUtils.duration(file.path) }
        if (dur <= 0) { message = "The generated audio could not be read"; return 0L }
        if (current?.id != projectId) { message = "Voice-over finished, but the project was closed"; return 0L }
        updateSettings { it.copy(audioPath = file.path, audioDurMs = dur) }
        reloadAudio()
        return dur
    }

    private fun friendly(e: Exception): String = when (e) {
        is GeminiTts.TtsException -> e.message ?: "Error"
        is java.io.IOException -> "Network error. Check your internet connection and try again."
        else -> "Failed: ${e.message}"
    }

    /** Optional online feature: Gemini text-to-speech through the user's own Google AI Studio key. */
    fun generateVoice() {
        val p = current ?: return
        if (ttsBusy) return
        if (settings.value.geminiKey.isBlank()) { message = "Paste your Google AI Studio API key first"; return }
        if (ttsScript.isBlank()) { message = "Write the script or tap \"Fill from cards\" first"; return }
        ttsBusy = true
        sheet = ""
        aiResult = null
        aiStatus = "Creating the voice-over with AI…"
        val script = ttsScript
        val style = ttsStyle
        viewModelScope.launch {
            try {
                val dur = makeVoice(p.id, script, style)
                aiResult = if (dur > 0) "✅ Voice-over created (${Timing.fmt(dur)}).\n\nPress ▶ to listen. Then set each card's time with the play-head (select a card → Time → Start / End = play-head)."
                else "❌ The voice-over could not be created."
            } catch (e: Exception) {
                aiResult = "❌ " + friendly(e)
            } finally {
                ttsBusy = false
                aiStatus = ""
            }
        }
    }

    /** Model ids to show in the drop-down: the list loaded for the user's key, or the built-in list. */
    fun modelList(): List<String> {
        val loaded = settings.value.geminiModels.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        return if (loaded.isEmpty()) GeminiTts.models else loaded
    }

    var modelsBusy by mutableStateOf(false)

    /** "Load my models": asks Google which TTS models this key can use (also checks that the key works). */
    fun loadModels() {
        val key = settings.value.geminiKey
        if (key.isBlank()) { message = "Paste your Google AI Studio API key first"; return }
        if (modelsBusy) return
        modelsBusy = true
        viewModelScope.launch {
            try {
                val list = withContext(Dispatchers.IO) { GeminiTts.listTtsModels(key) }
                if (list.isEmpty()) message = "The key works, but no voice (TTS) models were found for it."
                else {
                    updateAppSettings { s -> s.copy(geminiModels = list.joinToString(","), geminiModel = if (s.geminiModel in list) s.geminiModel else list.first()) }
                    message = "✓ Key works. ${list.size} voice models loaded."
                }
            } catch (e: Exception) {
                message = friendly(e)
            } finally {
                modelsBusy = false
            }
        }
    }

    /**
     * Paste a full news script -> cards are made right here on the phone (offline, no API).
     * Only the optional voice-over uses the user's Google key. Card times are left to the user.
     * tpl: -1 = best template per content, -2 = TV-style templates, -3 = classic templates, >=0 = that template for all.
     */
    fun generateFromScript(maxCards: Int, tpl: Int, replace: Boolean, withVoice: Boolean, withTicker: Boolean, spread: Boolean) {
        val p = current ?: return
        if (aiBusy) return
        if (aiScript.isBlank()) { message = "Paste the news script first"; return }
        val script = aiScript
        val plan = ScriptSplitter.plan(script, maxCards)
        if (plan.segs.isEmpty()) { message = "The script has no readable text"; return }
        sheet = ""
        aiResult = null
        val byKind = mapOf(
            "breaking" to listOf(0, 14, 7, 13),
            "score" to listOf(5, 9, 17, 2),
            "general" to listOf(13, 15, 18, 19, 21, 22, 16, 3, 1, 20)
        )
        val used = HashMap<String, Int>()
        val base = if (replace) 0L else (current?.cards?.maxOfOrNull { it.endMs } ?: 0L)
        val cards = plan.segs.mapIndexed { i, sg ->
            val kind = if (byKind.containsKey(sg.kind)) sg.kind else "general"
            val t = when {
                tpl >= 0 -> tpl
                tpl == -2 -> com.zafarcrickethub.zchnewscardstudio.data.Opt.tvStyle[i % 10]
                tpl == -3 -> com.zafarcrickethub.zchnewscardstudio.data.Opt.classic[i % 13]
                else -> { val l = byKind.getValue(kind); val n = used.getOrDefault(kind, 0); used[kind] = n + 1; l[n % l.size] }
            }
            val start = base + i * 5000L
            Samples.card(t, start, start + 5000L).copy(
                headline = sg.headline, description = sg.description,
                team1 = sg.team1, team2 = sg.team2, score = sg.score, overs = sg.overs, wickets = sg.wickets,
                status = "", playerName = "", stats = "", playerName2 = "", stats2 = ""
            )
        }
        mutate { pr ->
            pr.copy(
                cards = if (replace) cards else pr.cards + cards,
                settings = if (withTicker && plan.ticker.isNotBlank()) pr.settings.copy(tickerText = plan.ticker) else pr.settings
            )
        }
        sel = ""
        playback.seek(0)
        val list = cards.mapIndexed { i, c -> "${i + 1}. ${c.headline.replace('\n', ' ').take(60)}" }.joinToString("\n")
        val next = "Next: add pictures, then set each card's time with the play-head (select a card → Time → Start / End = play-head)."
        if (!withVoice) { aiResult = "✅ ${cards.size} cards created\n\n$list\n\n$next"; return }
        if (settings.value.geminiKey.isBlank()) {
            aiResult = "✅ ${cards.size} cards created\n\n$list\n\n(No voice-over: paste your Google AI Studio key in Voice to create one.)\n\n$next"
            return
        }
        aiBusy = true
        aiStatus = "Creating the voice-over with Google…"
        val style = ttsStyle
        viewModelScope.launch {
            try {
                val dur = makeVoice(p.id, script, style)
                if (dur > 0 && spread) distribute()
                aiResult = if (dur > 0) "✅ ${cards.size} cards created\n🎙 Voice-over ready (${Timing.fmt(dur)})\n\n$list\n\n$next"
                else "⚠ ${cards.size} cards were created, but the voice-over failed. Retry it from the Voice button."
            } catch (e: Exception) {
                aiResult = "⚠ ${cards.size} cards were created, but the voice-over failed:\n" + friendly(e) + "\n\nRetry it from the Voice button."
            } finally {
                aiBusy = false
                aiStatus = ""
            }
        }
    }

    /** Prefix of the file name inside the project folder: pictures and videos live side by side. */
    private fun mediaPrefix(uri: Uri) = if (ctx.contentResolver.getType(uri)?.startsWith("video/") == true) "vid" else "img"

    /** A picture or video that can really be shown (checked off the UI thread). */
    private suspend fun mediaReadable(path: String): Boolean = withContext(Dispatchers.Default) {
        if (VideoFrames.isVideo(path)) VideoFrames.frameSync(path, 0L, 160) != null
        else com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path) != null
    }

    /** Several pictures and/or videos at once for one card (unlimited). The first becomes the main one, the rest the slide-show. */
    fun importPictures(cardId: String, uris: List<Uri>) {
        val p = current ?: return
        viewModelScope.launch {
            val ok = ArrayList<String>()
            var bad = 0
            var videos = 0
            for (u in uris) {
                try {
                    val path = repo.importAsset(p.id, u, mediaPrefix(u))
                    if (mediaReadable(path)) {
                        ok.add(path)
                        if (VideoFrames.isVideo(path)) videos++
                    } else { File(path).delete(); bad++ }
                } catch (e: Exception) { bad++ }
            }
            if (ok.isNotEmpty()) updateCard(cardId) { c ->
                if (c.imagePath == null) c.copy(imagePath = ok.first(), gallery = c.gallery + ok.drop(1))
                else c.copy(gallery = c.gallery + ok)
            }
            val what = if (videos > 0) "${ok.size} added ($videos video${if (videos > 1) "s" else ""})" else "${ok.size} pictures added"
            message = if (bad > 0) "$what, $bad could not be read" else what
        }
    }

    /** Card length = length of its video (only for a card that holds exactly one picture/video). Following cards move along. */
    fun fitCardToVideo(cardId: String) {
        val p = current ?: return
        val c = p.cards.find { it.id == cardId } ?: return
        val path = c.pictures().singleOrNull()?.takeIf { VideoFrames.isVideo(it) } ?: return
        viewModelScope.launch {
            val d = withContext(Dispatchers.Default) { VideoFrames.durationMs(path) }
            val i = current?.cards?.indexOfFirst { it.id == cardId } ?: -1
            if (d > 0L && i >= 0) trimCardEdge(i, true, (current?.cards?.get(i)?.startMs ?: 0L) + d, false)
        }
    }

    /** index 0 = main picture, 1.. = gallery */
    fun removePicture(cardId: String, index: Int) = updateCard(cardId) { c ->
        if (index == 0) c.copy(imagePath = c.gallery.firstOrNull(), gallery = c.gallery.drop(1), imgScale = 1f, imgX = 0f, imgY = 0f)
        else c.copy(gallery = c.gallery.filterIndexed { i, _ -> i != index - 1 })
    }

    fun makePictureFirst(cardId: String, index: Int) = updateCard(cardId) { c ->
        if (index <= 0) c else {
            val all = c.pictures().toMutableList()
            val x = all.removeAt(index)
            all.add(0, x)
            c.copy(imagePath = all.first(), gallery = all.drop(1))
        }
    }

    /** New empty project that opens straight in the "AI script" sheet. */
    fun createFromScript() {
        val st = settings.value
        val p = Project(
            name = "AI News",
            settings = ProjectSettings(landscape = st.landscape, channelName = st.channelName, tickerText = st.ticker, tickerStyle = 1, tickerBg = com.zafarcrickethub.zchnewscardstudio.data.Pal.Red),
            cards = emptyList()
        )
        viewModelScope.launch { repo.save(p); open(p.id, "aiscript") }
    }

    fun setVolume(v: Float) {
        updateSettings { it.copy(volume = v) }
        playback.voice.volume(v)
    }

    fun reloadAudio() {
        val s = current?.settings
        playback.totalMs = current?.let { Timing.totalMs(it) } ?: 0L
        playback.load(s?.audioPath, s?.volume ?: 1f, s?.audioDurMs ?: 0L)
        waveform = null
        val path = s?.audioPath ?: return
        viewModelScope.launch { waveform = withContext(Dispatchers.Default) { runCatching { AudioUtils.waveform(path) }.getOrNull() } }
    }

    // ------------------------------------------------------------ export
    fun startExport(w: Int, h: Int, fps: Int, vbr: Int, abr: Int, name: String, land: Boolean, endMode: Int, customEnd: Long, soft: Boolean = false) {
        val p = current ?: return
        if (ExportState.busy.get()) { message = "An export is already running"; return }
        saveNow()
        playback.pause()
        ExportState.state.value = ExportUi.Running(0f, "Starting", p.id)
        val safe = name.replace(Regex("[^\\p{L}\\p{N} _.-]"), "_").ifBlank { "ZCH_video" }
        val i = Intent(ctx, ExportService::class.java)
            .putExtra("id", p.id).putExtra("w", w).putExtra("h", h).putExtra("fps", fps)
            .putExtra("vbr", vbr).putExtra("abr", abr).putExtra("name", safe).putExtra("land", land)
            .putExtra("endMode", endMode).putExtra("customEnd", customEnd).putExtra("soft", soft)
        ContextCompat.startForegroundService(ctx, i)
    }

    fun cancelExport() { ExportState.cancel = true }

    fun deleteExport(projectId: String, rec: ExportRec) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { MediaSaver.delete(ctx, rec.uri) }
            repo.removeExport(projectId, rec.uri)
        }
    }

    // ------------------------------------------------------------ project creation from the template picker
    private fun autoName() = "News " + java.text.SimpleDateFormat("dd MMM HH:mm", java.util.Locale.getDefault()).format(java.util.Date())

    fun createProjectFrom(template: Int) = createProject(autoName(), template)

    fun createEmptyProject() {
        val st = settings.value
        val p = Project(
            name = autoName(),
            settings = ProjectSettings(landscape = st.landscape, channelName = st.channelName, tickerText = st.ticker, tickerStyle = 1, tickerBg = com.zafarcrickethub.zchnewscardstudio.data.Pal.Red),
            cards = emptyList()
        )
        viewModelScope.launch { repo.save(p); open(p.id) }
    }

    // ------------------------------------------------------------ re-order cards (drag on the timeline)
    /** Moves a card to a new place in the order; every card keeps its own length and the cards follow each other. */
    fun moveCardTo(id: String, newIndex: Int) = mutate { p ->
        val i = p.cards.indexOfFirst { it.id == id }
        if (i < 0) p else {
            val l = p.cards.toMutableList()
            val c = l.removeAt(i)
            val j = newIndex.coerceIn(0, l.size)
            if (j == i) p else {
                l.add(j, c)
                var t = p.cards.minOf { it.startMs }
                p.copy(cards = l.map { x ->
                    val d = x.endMs - x.startMs
                    val n = x.copy(startMs = t, endMs = t + d)
                    t += d
                    n
                })
            }
        }
    }

    // ------------------------------------------------------------ overlays (text / sticker / picture layers)
    fun addOverlay(type: Int, text: String = "", imagePath: String? = null) {
        val pos = playback.positionMs
        val total = current?.let { Timing.totalMs(it) } ?: 5000L
        val o = Overlay(
            type = type, text = text, imagePath = imagePath, startMs = pos,
            endMs = minOf(pos + 3000L, maxOf(total, pos + 1000L)), y = if (type == 0) 0.3f else 0.5f
        )
        mutate { it.copy(overlays = it.overlays + o) }
        sel = "ov:" + o.id
    }

    fun updateOverlay(id: String, f: (Overlay) -> Overlay) = mutate { p -> p.copy(overlays = p.overlays.map { if (it.id == id) f(it) else it }) }

    fun deleteOverlay(id: String) {
        mutate { it.copy(overlays = it.overlays.filter { o -> o.id != id }) }
        if (sel == "ov:$id") sel = ""
    }

    fun duplicateOverlay(id: String) {
        val o = current?.overlays?.find { it.id == id } ?: return
        val d = o.copy(id = UUID.randomUUID().toString(), startMs = o.endMs, endMs = o.endMs + (o.endMs - o.startMs))
        mutate { it.copy(overlays = it.overlays + d) }
        sel = "ov:" + d.id
    }

    fun moveOverlay(id: String, deltaMs: Long) = updateOverlay(id) {
        val d = maxOf(deltaMs, -it.startMs)
        it.copy(startMs = it.startMs + d, endMs = it.endMs + d)
    }

    fun trimOverlay(id: String, isEnd: Boolean, ms: Long) = updateOverlay(id) {
        if (isEnd) it.copy(endMs = maxOf(ms, it.startMs + 300)) else it.copy(startMs = minOf(maxOf(ms, 0L), it.endMs - 300))
    }

    fun importOverlayPicture(uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                val path = repo.importAsset(p.id, uri, "ovl")
                if (com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path) == null) { File(path).delete(); message = "Unsupported or damaged image"; return@launch }
                addOverlay(2, imagePath = path)
            } catch (e: Exception) { message = "Could not import image: ${e.message}" }
        }
    }

    // ------------------------------------------------------------ per-card script and voice
    /** Paste a script into one card: new cards are made from it (offline) right there, in place of this card or after it. */
    fun cardsFromScript(cardId: String, script: String, sameDesign: Boolean, replaceThis: Boolean) {
        val p = current ?: return
        val i = p.cards.indexOfFirst { it.id == cardId }
        if (i < 0) return
        if (script.isBlank()) { message = "Paste the script first"; return }
        val plan = ScriptSplitter.plan(script, 0)
        if (plan.segs.isEmpty()) { message = "The script has no readable text"; return }
        val src = p.cards[i]
        val auto = mapOf("breaking" to listOf(0, 14, 7, 13), "score" to listOf(5, 9, 17, 2), "general" to listOf(13, 15, 18, 19, 21, 22, 16, 3, 1, 20))
        val used = HashMap<String, Int>()
        val blockStart = if (replaceThis) src.startMs else src.endMs
        val made = plan.segs.mapIndexed { k, sg ->
            val start = blockStart + k * 5000L
            val base = if (sameDesign) src.copy(id = UUID.randomUUID().toString(), voicePath = null, voiceDurMs = 0)
            else {
                val kind = if (auto.containsKey(sg.kind)) sg.kind else "general"
                val l = auto.getValue(kind)
                val n = used.getOrDefault(kind, 0); used[kind] = n + 1
                Samples.card(l[n % l.size])
            }
            base.copy(
                startMs = start, endMs = start + 5000L, headline = sg.headline, description = sg.description,
                team1 = sg.team1, team2 = sg.team2, score = sg.score, overs = sg.overs, wickets = sg.wickets
            )
        }
        val delta = made.size * 5000L - (if (replaceThis) src.endMs - src.startMs else 0L)
        mutate { pr ->
            val before = pr.cards.take(i + (if (replaceThis) 0 else 1))
            val after = pr.cards.drop(i + 1).map { it.copy(startMs = it.startMs + delta, endMs = it.endMs + delta) }
            pr.copy(cards = before + made + after)
        }
        sel = "card:" + made.first().id
        editingCard = null
        message = "${made.size} cards created. Set their times with the play-head."
    }

    /** Voice for ONE card (Google AI Studio key). The card can be stretched to the length of the voice. */
    fun generateCardVoice(cardId: String, text: String, fit: Boolean) {
        val p = current ?: return
        if (aiBusy || ttsBusy) return
        val st = settings.value
        if (st.geminiKey.isBlank()) { message = "Paste your Google AI Studio key first (Voice or Settings)"; return }
        if (text.isBlank()) { message = "Write the text to read first"; return }
        ttsBusy = true
        aiResult = null
        aiStatus = "Creating the voice for this card…"
        val style = ttsStyle
        viewModelScope.launch {
            try {
                val (pcm, rate) = withContext(Dispatchers.IO) { GeminiTts.synthesize(st.geminiKey, st.geminiModel, st.geminiVoice, text, style) }
                val file = withContext(Dispatchers.IO) {
                    File(repo.projectDir(p.id), "cardvoice_${System.currentTimeMillis()}.wav").also { it.writeBytes(GeminiTts.pcmToWav(pcm, rate)) }
                }
                val dur = withContext(Dispatchers.IO) { AudioUtils.duration(file.path) }
                if (dur <= 0) { aiResult = "❌ The generated audio could not be read"; return@launch }
                if (current?.id != p.id) return@launch
                mutate { pr ->
                    val i = pr.cards.indexOfFirst { it.id == cardId }
                    if (i < 0) pr else {
                        val c = pr.cards[i]
                        val newEnd = if (fit) c.startMs + dur + 300L else c.endMs
                        val delta = newEnd - c.endMs
                        pr.copy(cards = pr.cards.mapIndexed { j, x ->
                            when {
                                j == i -> x.copy(voicePath = file.path, voiceDurMs = dur, endMs = newEnd)
                                fit && j > i && delta != 0L -> x.copy(startMs = x.startMs + delta, endMs = x.endMs + delta)
                                else -> x
                            }
                        })
                    }
                }
                aiResult = "✅ Voice added to this card (${Timing.fmt(dur)})" + if (fit) ". The card length now matches the voice." else "."
            } catch (e: Exception) {
                aiResult = "❌ " + friendly(e)
            } finally {
                ttsBusy = false
                aiStatus = ""
            }
        }
    }

    fun removeCardVoice(cardId: String) = updateCard(cardId) { it.copy(voicePath = null, voiceDurMs = 0) }

    // ------------------------------------------------------------ thumbnail maker
    fun importThumbImage(uri: Uri, kind: Int) {
        viewModelScope.launch {
            try {
                val path = repo.importAsset("thumbs", uri, "t")
                if (com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path) == null) { message = "Unsupported image"; return@launch }
                thumb = when (kind) {
                    0 -> thumb.copy(bgPath = path, bgMode = 3)
                    1 -> thumb.copy(playerPath = path)
                    else -> thumb.copy(logoPath = path)
                }
            } catch (e: Exception) { message = "Could not import image" }
        }
    }

    fun pickThumbVideo(uri: Uri) {
        viewModelScope.launch {
            val d = withContext(Dispatchers.IO) {
                val r = MediaMetadataRetriever()
                try { r.setDataSource(ctx, uri); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L }
                catch (e: Exception) { 0L } finally { try { r.release() } catch (_: Exception) {} }
            }
            if (d <= 0) { message = "Could not read this video"; return@launch }
            thumbVideoUri = uri; thumbVideoMs = d
            grabFrame(0f)
        }
    }

    fun grabFrame(fraction: Float) {
        val uri = thumbVideoUri ?: return
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, uri)
                    val bmp = r.getFrameAtTime((thumbVideoMs * fraction).toLong() * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                    if (bmp == null) null else {
                        val f = File(repo.projectDir("thumbs"), "frame_${System.currentTimeMillis()}.jpg")
                        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                        f.path
                    }
                } catch (e: Exception) { null } finally { try { r.release() } catch (_: Exception) {} }
            }
            if (path != null) thumb = thumb.copy(bgPath = path, bgMode = 3) else message = "Could not read a frame"
        }
    }

    fun saveThumbnail(png: Boolean) {
        val t = thumb
        viewModelScope.launch {
            val ok = withContext(Dispatchers.Default) {
                try {
                    val bmp = Bitmap.createBitmap(ThumbRenderer.W, ThumbRenderer.H, Bitmap.Config.ARGB_8888)
                    ThumbRenderer.draw(ctx, android.graphics.Canvas(bmp), ThumbRenderer.W, ThumbRenderer.H, t)
                    val f = File(ctx.cacheDir, "thumb_tmp." + if (png) "png" else "jpg")
                    f.outputStream().use { bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it) }
                    val name = "ZCH_thumbnail_${System.currentTimeMillis()}." + if (png) "png" else "jpg"
                    val uri = MediaSaver.save(ctx, f, name, if (png) "image/png" else "image/jpeg", false)
                    f.delete()
                    uri != null
                } catch (e: Exception) { false }
            }
            message = if (ok) "Thumbnail saved to Pictures/${MediaSaver.FOLDER}" else "Could not save thumbnail"
        }
    }

    // ------------------------------------------------------------ voice-over recorder (Oboe, with AudioRecord as fallback)
    val recorder = OboeRecorder()
    var recording by mutableStateOf(false)
    var recMs by mutableStateOf(0L)
    var recLevel by mutableStateOf(0f)
    private var recFile: File? = null

    /** Makes an audio file in the project folder the project's voice-over, after checking that it can be played. */
    private suspend fun installAudio(path: String, failText: String): Boolean {
        val ok = withContext(Dispatchers.IO) { AudioUtils.canDecode(path) }
        val dur = withContext(Dispatchers.IO) { AudioUtils.duration(path) }
        if (!ok || dur <= 0) { File(path).delete(); message = failText; return false }
        updateSettings { it.copy(audioPath = path, audioDurMs = dur) }
        reloadAudio()
        return true
    }

    /** The microphone permission must already be granted (the panel asks for it). */
    fun startRecording() {
        val p = current ?: return
        if (recording) return
        playback.pause()
        val file = File(repo.projectDir(p.id), "voice_rec_${System.currentTimeMillis()}.wav")
        val err = recorder.start(file)
        if (err != null) { message = err; return }
        recFile = file
        recMs = 0L
        recLevel = 0f
        recording = true
        viewModelScope.launch {
            while (recording && recorder.running) {
                recLevel = recorder.level
                recMs = recorder.elapsedMs
                delay(80)
            }
            if (recording && !recorder.running) stopRecording()    // the microphone was taken away (call, other app)
        }
    }

    fun stopRecording() {
        if (!recording) return
        recording = false
        val file = recFile
        recFile = null
        viewModelScope.launch {
            val got = withContext(Dispatchers.IO) { recorder.stop() }
            if (!got || file == null) { file?.delete(); message = recorder.error ?: "Nothing was recorded"; return@launch }
            if (installAudio(file.path, "The recording could not be used")) message = recorder.error ?: "Voice-over recorded"
        }
    }

    // ------------------------------------------------------------ voice clean-up (FFmpeg)
    var cleaning by mutableStateOf(false)

    fun cleanVoice() {
        val p = current ?: return
        val src = p.settings.audioPath ?: return
        if (!FFmpegHelper.available) { message = "FFmpeg is not part of this build"; return }
        if (cleaning) return
        cleaning = true
        viewModelScope.launch {
            try {
                val out = File(repo.projectDir(p.id), "voice_clean_${System.currentTimeMillis()}.wav")
                val done = withContext(Dispatchers.IO) { FFmpegHelper.cleanVoice(src, out.path) }
                if (!done || !out.exists() || out.length() == 0L) {
                    out.delete()
                    message = "Voice clean-up failed (this FFmpeg build may not include the filters)"
                    return@launch
                }
                if (installAudio(out.path, "The cleaned audio could not be used")) message = "Voice cleaned: noise reduced, loudness levelled"
            } catch (e: Exception) {
                message = "Voice clean-up failed: ${e.message}"
            } finally {
                cleaning = false
            }
        }
    }

    // ------------------------------------------------------------ automatic card timing from the pauses of the voice-over (TarsosDSP)
    var autoTiming by mutableStateOf(false)

    fun autoTimeFromVoice() {
        val p = current ?: return
        val path = p.settings.audioPath
        if (path == null) { message = "Import or record a voice-over first"; return }
        if (p.cards.size < 2) { message = "Add at least two cards first"; return }
        if (autoTiming) return
        autoTiming = true
        viewModelScope.launch {
            try {
                val need = p.cards.size - 1
                val pauses = withContext(Dispatchers.Default) { VoicePauses.find(path) }
                val cuts = VoicePauses.pick(pauses, need)
                if (cuts == null) {
                    message = "Found ${pauses.size} clear pauses but $need are needed (one between every two cards). Use Distribute evenly or set the times by hand."
                    return@launch
                }
                val total = p.settings.audioDurMs
                mutate { q ->
                    if (q.cards.size != p.cards.size) q else q.copy(cards = q.cards.mapIndexed { i, c ->
                        val start = if (i == 0) 0L else cuts[i - 1]
                        val end = if (i == q.cards.size - 1) maxOf(total, start + 300L) else cuts[i]
                        c.copy(startMs = start, endMs = maxOf(end, start + 300L))
                    })
                }
                message = "Cards timed from the pauses of the voice-over"
            } catch (e: Exception) {
                message = "Could not analyse the voice-over: ${e.message}"
            } finally {
                autoTiming = false
            }
        }
    }

    // ------------------------------------------------------------ split the cards by the pauses of the voice-over
    var splitBusy by mutableStateOf(false)
    private var splitPauses by mutableStateOf<List<VoicePauses.Pause>?>(null)
    private var splitPausesFor by mutableStateOf<String?>(null)

    /** The pauses of this voice-over file, or null while it is still being analysed (or was not analysed yet). */
    fun pausesFor(path: String?): List<VoicePauses.Pause>? = if (path != null && splitPausesFor == path) splitPauses else null

    /** Listens to the project's voice-over once and remembers every pause (TarsosDSP). The result is filtered by length in the panel. */
    fun analysePauses(force: Boolean = false) {
        val path = current?.settings?.audioPath ?: return
        if (splitBusy) return
        if (!force && splitPausesFor == path && splitPauses != null) return
        splitBusy = true
        viewModelScope.launch {
            try {
                val found = withContext(Dispatchers.Default) { VoicePauses.find(path) }
                if (current?.settings?.audioPath == path) {
                    splitPauses = found
                    splitPausesFor = path
                }
            } catch (e: Exception) {
                message = "Could not analyse the voice-over: ${e.message}"
            } finally {
                splitBusy = false
            }
            // the voice-over was replaced while we were listening: listen to the new one
            val now = current?.settings?.audioPath
            if (now != null && splitPausesFor != now) analysePauses()
        }
    }

    /**
     * One card for every spoken part of the voice-over (parts are separated by pauses of at least `minPauseMs`).
     * Every card gets the start / end of its part. keepCards = the cards the project already has keep their text and design
     * (in order) and only get new times; extra parts get new cards. template < 0 = new cards copy the design of the last card.
     */
    fun splitCardsFromVoice(minPauseMs: Long, template: Int, keepCards: Boolean) {
        val p = current ?: return
        val path = p.settings.audioPath
        if (path == null) { message = "Upload a voice-over first"; return }
        val pauses = pausesFor(path)
        if (pauses == null) { message = "Still listening to the voice-over, try again in a moment"; return }
        val total = p.settings.audioDurMs
        val cuts = VoicePauses.cuts(pauses, minPauseMs, total)
        val parts = cuts.size + 1
        if (parts < 2) { message = "No pauses of this length were found. Choose a shorter pause."; return }
        val old = if (keepCards) p.cards else emptyList()
        if (old.size > parts) {
            message = "You have ${old.size} cards but only $parts parts were found. Choose a shorter pause, or switch off \"Keep my cards\"."
            return
        }
        val last = p.cards.lastOrNull()
        fun fresh(k: Int): Card {
            val base = if (template < 0 && last != null) {
                last.copy(
                    id = UUID.randomUUID().toString(), voicePath = null, voiceDurMs = 0,
                    imagePath = null, extraImages = emptyList(), gallery = emptyList(), photoBase = null, photoOut = null
                )
            } else Samples.card(if (template >= 0) template else 0)
            return base.copy(headline = "Card ${k + 1}", description = "")
        }
        val made = (0 until parts).map { k ->
            val start = if (k == 0) 0L else cuts[k - 1]
            val end = if (k == parts - 1) maxOf(total, start + 300L) else cuts[k]
            (old.getOrNull(k) ?: fresh(k)).copy(startMs = start, endMs = maxOf(end, start + 300L))
        }
        mutate { q -> q.copy(cards = made) }
        sel = "card:" + made.first().id
        editingCard = null
        playback.seek(300)
        message = "$parts cards made from the voice-over pauses" + if (old.isEmpty() && p.cards.isNotEmpty()) " (your earlier cards were replaced; Undo brings them back)" else ""
    }

    // ------------------------------------------------------------ picture tools: crop (uCrop), cut-out (ML Kit), filters (GPUImage)
    var photoBusy by mutableStateOf(false)
    private var pendingCropCard: String? = null

    /** The main picture of the card as a file that the picture tools can work on, or null (with a message). */
    private fun editablePicture(cardId: String): String? {
        val src = current?.cards?.find { it.id == cardId }?.imagePath
        if (src == null || VideoFrames.isVideo(src) || !File(src).exists()) {
            message = "The main item of this card is not a picture. Make a picture the main one first."
            return null
        }
        return src
    }

    fun prepareCrop(cardId: String): CropRequest? {
        val src = editablePicture(cardId) ?: return null
        val ext = src.substringAfterLast('.', "").lowercase()
        val png = ext == "png" || ext == "webp"
        val dst = File(File(src).parentFile, "img_${System.currentTimeMillis()}_crop.${if (png) "png" else "jpg"}")
        pendingCropCard = cardId
        return CropRequest(src, dst.path, png)
    }

    fun onCropResult(uri: Uri?) {
        val id = pendingCropCard ?: return
        pendingCropCard = null
        val path = uri?.path ?: return          // cancelled
        viewModelScope.launch {
            val ok = withContext(Dispatchers.Default) { File(path).length() > 0L && Bmp.load(path) != null }
            if (!ok) { message = "The cropped picture could not be read"; return@launch }
            updateCard(id) { it.copy(imagePath = path, imgScale = 1f, imgX = 0f, imgY = 0f) }
        }
    }

    fun removeBackground(cardId: String) {
        val src = editablePicture(cardId) ?: return
        if (photoBusy) return
        photoBusy = true
        viewModelScope.launch {
            try {
                val out = PhotoTools.removeBackground(src)
                if (out == null) message = "No person found in this picture. Background removal works for photos of people."
                else updateCard(cardId) { it.copy(imagePath = out, imgScale = 1f, imgX = 0f, imgY = 0f) }
            } catch (e: Exception) {
                message = "Background removal failed: ${e.message}"
            } finally {
                photoBusy = false
            }
        }
    }

    /** index 0 = back to the picture as it was before any filter, 1.. = a filter of PhotoTools.filterNames. */
    fun applyFilter(cardId: String, index: Int) {
        val c = current?.cards?.find { it.id == cardId } ?: return
        val src = editablePicture(cardId) ?: return
        val savedBase = c.photoBase
        // filters are always applied to the unfiltered picture, so choosing another filter never stacks them
        val base = if (c.photoOut == src && savedBase != null && File(savedBase).exists()) savedBase else src
        if (index <= 0) {
            if (base != src) updateCard(cardId) { it.copy(imagePath = base, photoBase = null, photoOut = null) }
            return
        }
        if (photoBusy) return
        photoBusy = true
        viewModelScope.launch {
            try {
                val out = PhotoTools.applyFilter(ctx, base, index)
                if (out == null) message = "The filter could not be applied to this picture"
                else updateCard(cardId) { it.copy(imagePath = out, photoBase = base, photoOut = out) }
            } catch (e: Exception) {
                message = "The filter failed: ${e.message}"
            } finally {
                photoBusy = false
            }
        }
    }

    // ------------------------------------------------------------ animated (Lottie) stickers
    fun importLottieSticker(uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                val path = repo.importAsset(p.id, uri, "lottie")
                val ok = withContext(Dispatchers.IO) { LottieSticker.isValidFile(path) }
                if (!ok) { File(path).delete(); message = "This is not a valid Lottie animation (.json file)"; return@launch }
                val name = (uri.lastPathSegment ?: "animation").substringAfterLast('/').substringBeforeLast('.').take(18).ifBlank { "animation" }
                addOverlay(1, LottieSticker.PREFIX + name, imagePath = path)
                sheet = "overlay"
            } catch (e: Exception) {
                message = "Could not import the animation: ${e.message}"
            }
        }
    }

    // ------------------------------------------------------------ small copy of an export (Media3 Transformer)
    var compressingUri by mutableStateOf<String?>(null)

    private fun videoSize(uri: Uri): Pair<Int, Int> {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
            Pair(w, h)
        } catch (e: Exception) {
            Pair(1280, 720)
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    /** Re-encodes an exported video with a short side of at most 720 px and 2.5 Mbit/s and adds it to the exports list. */
    fun makeSmallCopy(projectId: String, rec: ExportRec) {
        if (compressingUri != null) { message = "Another video is being compressed"; return }
        if (ExportState.busy.get()) { message = "Wait until the running export has finished"; return }
        compressingUri = rec.uri
        viewModelScope.launch {
            val tmp = File(ctx.cacheDir, "small_${System.currentTimeMillis()}.mp4")
            try {
                val src = Uri.parse(rec.uri)
                val (w, h) = withContext(Dispatchers.IO) { videoSize(src) }
                val targetHeight = if (h <= w) 720 else 1280
                val err = VideoCompressor.compress(ctx, src, tmp, minOf(h, targetHeight).coerceAtLeast(2), 2_500_000)
                if (err != null || !tmp.exists() || tmp.length() == 0L) {
                    message = "Could not make a small copy: ${err ?: "empty file"}"
                    return@launch
                }
                val name = rec.name + "_small"
                val uri = withContext(Dispatchers.IO) { MediaSaver.save(ctx, tmp, "$name.mp4", "video/mp4", true) }
                if (uri == null) { message = "Could not save the small copy"; return@launch }
                repo.addExport(projectId, ExportRec(uri.toString(), name, System.currentTimeMillis(), "small copy • ${minOf(h, targetHeight)}p • 2.5 Mbit/s"))
                message = "Small copy saved in Movies/${MediaSaver.FOLDER}"
            } catch (e: Exception) {
                message = "Could not make a small copy: ${e.message}"
            } finally {
                tmp.delete()
                compressingUri = null
            }
        }
    }

    override fun onCleared() {
        if (recording) { recording = false; recorder.stop() }
        playback.voice.release(); playback.releaseClips(); super.onCleared()
    }
}
