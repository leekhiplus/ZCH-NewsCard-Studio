plugins {
    id("com.android.application") version "9.3.1" apply false
    // Kotlin 2.4.21 (latest stable). AGP 9 compiles Kotlin by itself ("built-in Kotlin"), so this plugin is NOT applied
    // in :app - it is only declared here so the Kotlin Gradle plugin version used by AGP is exactly 2.4.21.
    id("org.jetbrains.kotlin.android") version "2.4.21" apply false
    id("org.jetbrains.kotlin.plugin.serialization") version "2.4.21" apply false
    // Compose compiler now ships with Kotlin (same version number) - replaces composeOptions.kotlinCompilerExtensionVersion.
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.21" apply false
    // KSP2 versions are independent of the Kotlin version (2.3.x works with Kotlin 2.2 and newer).
    id("com.google.devtools.ksp") version "2.3.13" apply false
}
