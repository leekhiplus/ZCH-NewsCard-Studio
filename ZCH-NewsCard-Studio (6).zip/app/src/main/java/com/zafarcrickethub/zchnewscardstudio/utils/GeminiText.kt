package com.zafarcrickethub.zchnewscardstudio.utils

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Optional online feature: turns a pasted news script into on-screen cards using the Gemini API
 * (the user's own Google AI Studio key). Timing of the cards is left to the user.
 */
object GeminiText {
    class Seg(
        val headline: String, val description: String, val voice: String, val kind: String,
        val team1: String, val team2: String, val score: String, val overs: String, val wickets: String,
        val status: String, val player: String, val stats: List<String>
    )

    class Plan(val segs: List<Seg>, val ticker: String)

    private fun prompt(script: String, maxCards: Int): String {
        val count = if (maxCards > 0) "exactly $maxCards" else "a suitable number (between 3 and 10)"
        return """
You are a TV news graphics editor. Split the news script below into $count short on-screen cards.
Write every text in the SAME LANGUAGE as the script (Urdu stays Urdu, English stays English). Never invent facts.
Return ONLY valid JSON, no markdown, with this exact shape:
{"ticker":"one scrolling ticker line made of the top headlines separated by  •  ",
 "cards":[{"headline":"max 10 words","description":"max 25 words, can be empty",
 "voice":"the exact part of the script this card covers, unchanged",
 "kind":"breaking|report|score|player|general",
 "team1":"","team2":"","score":"","overs":"","wickets":"","status":"","player":"","stats":["Label: value"]}]}
Rules: the "voice" parts of all cards, joined in order, must cover the whole script. Use kind "score" only for live match
scores (fill team1, team2, score, overs, wickets, status when the script contains them), "player" for a player's performance
(fill player and stats), "breaking" for urgent news, "report" for in-depth stories, otherwise "general". Leave unknown fields empty.

SCRIPT:
$script
""".trim()
    }

    /** Blocking call: run it on a background thread. */
    fun plan(apiKey: String, model: String, script: String, maxCards: Int): Plan {
        if (apiKey.isBlank()) throw GeminiTts.TtsException("Paste your Google AI Studio API key first")
        if (script.isBlank()) throw GeminiTts.TtsException("Paste the news script first")
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt(script.trim(), maxCards))))))
            put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.3))
        }
        val con = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent").openConnection() as HttpURLConnection
        val raw: String = try {
            con.requestMethod = "POST"
            con.connectTimeout = 20_000
            con.readTimeout = 120_000
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json")
            con.setRequestProperty("x-goog-api-key", apiKey.trim())
            con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = con.responseCode
            val txt = (if (code in 200..299) con.inputStream else con.errorStream)?.use { it.readBytes() }?.toString(Charsets.UTF_8) ?: ""
            if (code !in 200..299) throw GeminiTts.TtsException(GeminiTts.friendlyError(code, txt))
            txt
        } finally {
            con.disconnect()
        }
        val parts = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw GeminiTts.TtsException("Google returned no text. Try again or use another model.")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text") ?: "")
        return parse(sb.toString(), script)
    }

    fun parse(text: String, script: String): Plan {
        var t = text.trim()
        if (t.startsWith("```")) t = t.substringAfter('\n').substringBeforeLast("```").trim()
        val start = t.indexOfFirst { it == '{' || it == '[' }
        if (start > 0) t = t.substring(start)
        val root: JSONObject = if (t.startsWith("[")) JSONObject().put("cards", JSONArray(t)) else JSONObject(t)
        val arr = root.optJSONArray("cards") ?: throw GeminiTts.TtsException("The AI answer had no cards. Try again.")
        val segs = ArrayList<Seg>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val st = ArrayList<String>()
            o.optJSONArray("stats")?.let { a -> for (k in 0 until a.length()) a.optString(k).takeIf { it.isNotBlank() }?.let { st.add(it) } }
            segs.add(
                Seg(
                    o.optString("headline"), o.optString("description"), o.optString("voice"), o.optString("kind", "general"),
                    o.optString("team1"), o.optString("team2"), o.optString("score"), o.optString("overs"), o.optString("wickets"),
                    o.optString("status"), o.optString("player"), st
                )
            )
        }
        if (segs.isEmpty()) throw GeminiTts.TtsException("The AI answer had no cards. Try again.")
        return Plan(segs, root.optString("ticker"))
    }
}
