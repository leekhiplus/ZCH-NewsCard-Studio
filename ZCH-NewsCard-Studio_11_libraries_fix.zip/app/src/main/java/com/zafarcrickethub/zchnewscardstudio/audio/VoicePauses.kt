package com.zafarcrickethub.zchnewscardstudio.audio

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import be.tarsos.dsp.AudioDispatcher
import be.tarsos.dsp.AudioEvent
import be.tarsos.dsp.AudioProcessor
import be.tarsos.dsp.SilenceDetector
import be.tarsos.dsp.io.TarsosDSPAudioFormat
import be.tarsos.dsp.io.TarsosDSPAudioInputStream
import java.nio.ByteOrder

/**
 * Finds the pauses between sentences in a voice-over so the news cards can be timed automatically.
 * The audio is decoded to mono PCM (about 16-22 kHz) and analysed block by block with TarsosDSP's SilenceDetector.
 */
object VoicePauses {
    class Pause(val startMs: Long, val endMs: Long) {
        val lengthMs: Long get() = endMs - startMs
        val midMs: Long get() = (startMs + endMs) / 2
    }

    private class Pcm(val data: ShortArray, val length: Int, val sampleRate: Int)

    private const val MAX_SECONDS = 20 * 60      // longer audio is analysed only up to 20 minutes
    private const val BLOCK = 1024               // samples per analysis block (about 50 ms)

    /** Interior pauses (not the silence at the start / end), longest first is NOT guaranteed: sorted by time. Blocking. */
    fun find(path: String, minPauseMs: Long = 150L): List<Pause> {
        val pcm = decode(path) ?: return emptyList()
        if (pcm.length < BLOCK * 4) return emptyList()

        val stream = ShortPcmStream(pcm)
        val dispatcher = AudioDispatcher(stream, BLOCK, 0)
        val detector = SilenceDetector(-60.0, false)
        val levels = ArrayList<Float>()
        dispatcher.addAudioProcessor(detector)
        dispatcher.addAudioProcessor(object : AudioProcessor {
            override fun process(audioEvent: AudioEvent): Boolean {
                levels.add(detector.currentSPL().toFloat())
                return true
            }

            override fun processingFinished() {}
        })
        dispatcher.run()
        if (levels.size < 8) return emptyList()

        // The loudness scale of SilenceDetector is only relative, so the threshold is taken from the recording itself:
        // between its quiet floor (10th percentile) and its normal speech level (90th percentile).
        val sorted = levels.sorted()
        val floor = sorted[(sorted.size * 0.10).toInt()]
        val speech = sorted[((sorted.size - 1) * 0.90).toInt()]
        if (speech - floor < 8f) return emptyList()      // no clear difference between speech and pauses
        val threshold = floor + (speech - floor) * 0.30f

        val hopMs = BLOCK * 1000.0 / pcm.sampleRate
        val out = ArrayList<Pause>()
        var i = 0
        while (i < levels.size) {
            if (levels[i] < threshold) {
                var j = i
                while (j + 1 < levels.size && levels[j + 1] < threshold) j++
                val startMs = (i * hopMs).toLong()
                val endMs = ((j + 1) * hopMs).toLong()
                val interior = i > 0 && j < levels.size - 1
                if (interior && endMs - startMs >= minPauseMs) out.add(Pause(startMs, endMs))
                i = j + 1
            } else i++
        }
        return out
    }

    /** The `count` best cut points (ms, ascending): the middle of the `count` longest pauses. Null if there are not enough pauses. */
    fun pick(pauses: List<Pause>, count: Int): List<Long>? {
        if (count <= 0) return emptyList()
        if (pauses.size < count) return null
        return pauses.sortedByDescending { it.lengthMs }.take(count).map { it.midMs }.sorted()
    }

    // ------------------------------------------------------------------ decoding
    private fun decode(path: String): Pcm? {
        val ex = MediaExtractor()
        var dec: MediaCodec? = null
        try {
            ex.setDataSource(path)
            val t = AudioUtils.audioTrack(ex)
            if (t < 0) return null
            ex.selectTrack(t)
            val fmt = ex.getTrackFormat(t)
            var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channels = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1
            val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            dec = codec
            codec.configure(fmt, null, null, 0)
            codec.start()

            var pcm = ShortArray(1 shl 20)
            var len = 0
            var step = (rate / 16000).coerceAtLeast(1)     // keep about 16-22 kHz: plenty for finding pauses
            var acc = 0L
            var accN = 0
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            while (!outDone) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(5000)
                    if (i >= 0) {
                        val n = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 5000)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    step = (rate / 16000).coerceAtLeast(1)
                } else if (o >= 0) {
                    if (info.size > 0) {
                        val sb = codec.getOutputBuffer(o)!!.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        val n = info.size / 2
                        val ch = channels.coerceAtLeast(1)
                        var k = 0
                        while (k + ch <= n) {
                            var sum = 0
                            for (c in 0 until ch) sum += sb.get(k + c).toInt()
                            acc += (sum / ch).toLong()
                            accN++
                            if (accN >= step) {
                                if (len == pcm.size) pcm = pcm.copyOf(len * 2)
                                pcm[len++] = (acc / accN).toInt().coerceIn(-32768, 32767).toShort()
                                acc = 0L
                                accN = 0
                            }
                            k += ch
                        }
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    if (len > MAX_SECONDS * (rate / step)) outDone = true
                }
            }
            return Pcm(pcm, len, (rate / step).coerceAtLeast(1))
        } catch (e: Exception) {
            return null
        } finally {
            try { dec?.stop() } catch (_: Exception) {}
            try { dec?.release() } catch (_: Exception) {}
            ex.release()
        }
    }

    /** Feeds the decoded samples to TarsosDSP as 16-bit little-endian mono PCM. */
    private class ShortPcmStream(private val pcm: Pcm) : TarsosDSPAudioInputStream {
        private var pos = 0     // in samples
        private val fmt = TarsosDSPAudioFormat(pcm.sampleRate.toFloat(), 16, 1, true, false)

        override fun skip(bytesToSkip: Long): Long {
            val s = (bytesToSkip / 2).toInt().coerceIn(0, pcm.length - pos)
            pos += s
            return s * 2L
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val remaining = pcm.length - pos
            if (remaining <= 0) return -1
            val n = minOf(len / 2, remaining)
            for (i in 0 until n) {
                val v = pcm.data[pos + i].toInt()
                b[off + i * 2] = (v and 0xFF).toByte()
                b[off + i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
            }
            pos += n
            return n * 2
        }

        override fun close() {}

        override fun getFormat(): TarsosDSPAudioFormat = fmt

        override fun getFrameLength(): Long = pcm.length.toLong()
    }
}
