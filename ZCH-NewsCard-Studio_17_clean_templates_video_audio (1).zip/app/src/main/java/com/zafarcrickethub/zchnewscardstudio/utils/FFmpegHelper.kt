package com.zafarcrickethub.zchnewscardstudio.utils

/**
 * Thin wrapper around FFmpegKit (community-maintained fork, package com.arthenica.ffmpegkit).
 * Reflection keeps the app safe: if the native library is missing (e.g. a 32-bit phone, or the app was built with
 * -PwithFfmpeg=false) the calls just return false.
 */
object FFmpegHelper {
    val available: Boolean
        get() = try { Class.forName("com.arthenica.ffmpegkit.FFmpegKit"); true } catch (t: Throwable) { false }

    /** Runs one FFmpeg command line. Blocking. True when FFmpeg reports success. */
    private fun run(command: String): Boolean = try {
        val kit = Class.forName("com.arthenica.ffmpegkit.FFmpegKit")
        val session = kit.getMethod("execute", String::class.java).invoke(null, command)
        val rc = session!!.javaClass.getMethod("getReturnCode").invoke(session)
        val rcClass = Class.forName("com.arthenica.ffmpegkit.ReturnCode")
        rcClass.getMethod("isSuccess", rcClass).invoke(null, rc) as Boolean
    } catch (t: Throwable) {
        false
    }

    /** Converts any audio (or the audio of a video) to 44.1 kHz stereo WAV. Blocking. */
    fun toWav(input: String, output: String): Boolean =
        run("-y -i \"$input\" -vn -ar 44100 -ac 2 -c:a pcm_s16le \"$output\"")

    /**
     * Voice clean-up for a recorded voice-over: removes rumble (high-pass 80 Hz), reduces steady background noise (afftdn)
     * and levels the loudness to about -16 LUFS (loudnorm, the level used by YouTube / podcasts). Output: 44.1 kHz mono WAV.
     */
    fun cleanVoice(input: String, output: String): Boolean =
        run("-y -i \"$input\" -vn -af \"highpass=f=80,afftdn=nf=-25,loudnorm=I=-16:TP=-1.5:LRA=11\" -ar 44100 -ac 1 -c:a pcm_s16le \"$output\"")
}
