package com.zafarcrickethub.zchnewscardstudio.renderer

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import com.zafarcrickethub.zchnewscardstudio.audio.AudioUtils
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.ceil

class ExportCancelled : RuntimeException("Export cancelled")

class ExportParams(
    val projectId: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val videoBitrate: Int,
    val audioBitrate: Int,
    val fileName: String,
    val landscape: Boolean,
    val endMode: Int,
    val customEndMs: Long,
    val soft: Boolean = false     // compatibility mode: software canvas (slower, works everywhere)
)

/**
 * Streaming MP4 export: every frame is drawn by FrameRenderer straight into the H.264
 * encoder's input surface (no frames kept in memory), the voice-over is decoded -> volume
 * applied -> AAC encoded, and both are muxed into one MP4.
 */
class VideoExporter(
    private val ctx: Context,
    private val project: Project,
    private val prm: ExportParams,
    private val progress: (Float, String) -> Unit,
    private val cancelled: () -> Boolean
) {
    private val abort = AtomicBoolean(false)
    private fun stop() = abort.get() || cancelled()

    fun run(): File {
        val dir = File(ctx.cacheDir, "export").apply { mkdirs() }
        val stamp = System.nanoTime()
        val vTmp = File(dir, "v_$stamp.mp4")
        val aTmp = File(dir, "a_$stamp.m4a")
        val out = File(dir, "out_$stamp.mp4")
        try {
            val totalMs = Timing.totalMs(project)
            val sources = audioSources()
            val hasAudio = sources.isNotEmpty()
            // Voice-over + card voices are mixed and encoded on their own thread while the GPU renders the frames.
            var audioError: Throwable? = null
            val audioThread = if (hasAudio) Thread { try { encodeAudio(sources, aTmp, totalMs) } catch (t: Throwable) { audioError = t } }.also { it.start() } else null
            try {
                encodeVideo(vTmp, totalMs)
            } catch (t: Throwable) {
                abort.set(true)
                throw t
            } finally {
                audioThread?.join()
            }
            audioError?.let { throw it }
            progress(0.97f, "Finalising MP4")
            merge(vTmp, if (hasAudio) aTmp else null, out, totalMs)
            progress(1f, "Done")
            return out
        } catch (e: Throwable) {
            out.delete()
            throw e
        } finally {
            vTmp.delete(); aTmp.delete()
        }
    }

    // ------------------------------------------------------------------ video
    private fun encodeVideo(file: File, totalMs: Long) {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, prm.width, prm.height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, prm.videoBitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, prm.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface()
        enc.start()
        val muxer = MediaMuxer(file.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var started = false
        var outCount = 0L
        val info = MediaCodec.BufferInfo()

        fun drain(eos: Boolean) {
            var idle = 0
            while (true) {
                val i = enc.dequeueOutputBuffer(info, if (eos) 10_000L else 0L)
                if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!eos) return
                    if (++idle > 3000) throw IllegalStateException("Video encoder did not finish")
                } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(enc.outputFormat); muxer.start(); started = true
                } else if (i >= 0) {
                    idle = 0
                    val buf = enc.getOutputBuffer(i)!!
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && started) {
                        // Canvas-surface timestamps are wall-clock; use exact frame time instead.
                        info.presentationTimeUs = outCount * 1_000_000L / prm.fps
                        outCount++
                        buf.position(info.offset); buf.limit(info.offset + info.size)
                        muxer.writeSampleData(track, buf, info)
                    }
                    enc.releaseOutputBuffer(i, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }

        try {
            val renderer = FrameRenderer(ctx, project.copy(settings = project.settings.copy(landscape = prm.landscape)))
            val totalFrames = ceil(totalMs / 1000.0 * prm.fps).toInt().coerceAtLeast(1)
            var hw = !prm.soft
            for (f in 0 until totalFrames) {
                if (cancelled()) throw ExportCancelled()
                val tMs = f * 1000L / prm.fps
                val canvas = if (hw) {
                    try { surface.lockHardwareCanvas() } catch (e: Exception) { hw = false; surface.lockCanvas(null) }
                } else surface.lockCanvas(null)
                try {
                    renderer.render(canvas, prm.width, prm.height, tMs)
                } finally {
                    surface.unlockCanvasAndPost(canvas)
                }
                drain(false)
                if (f % 4 == 0) progress(f.toFloat() / totalFrames * 0.95f, "Rendering frame ${f + 1}/$totalFrames")
            }
            enc.signalEndOfInputStream()
            drain(true)
        } finally {
            try { enc.stop() } catch (_: Exception) {}
            enc.release()
            surface.release()
            try { if (started) muxer.stop() } catch (_: Exception) {}
            muxer.release()
        }
    }

    // ------------------------------------------------------------------ audio (voice-over + card voices, mixed)
    private class AudioSrc(val path: String, val startMs: Long, val volume: Float)

    private fun audioSources(): List<AudioSrc> {
        val l = ArrayList<AudioSrc>()
        val a = project.settings.audioPath
        if (a != null && File(a).exists()) l.add(AudioSrc(a, 0L, project.settings.volume))
        for (c in project.cards) {
            val v = c.voicePath
            if (v != null && File(v).exists()) l.add(AudioSrc(v, c.startMs, 1f))
        }
        return l
    }

    /** Linear resampler to 44.1 kHz (streaming). */
    private class Resampler(inRate: Int) {
        private val step = inRate / 44100.0
        private var frac = 0.0
        private var pl = 0
        private var pr = 0
        private var started = false
        fun push(l: Int, r: Int, out: java.io.OutputStream): Long {
            if (!started) { pl = l; pr = r; started = true }
            var n = 0L
            while (frac < 1.0) {
                val ol = (pl + (l - pl) * frac).toInt()
                val orr = (pr + (r - pr) * frac).toInt()
                out.write(ol and 0xFF); out.write((ol shr 8) and 0xFF)
                out.write(orr and 0xFF); out.write((orr shr 8) and 0xFF)
                n++
                frac += step
            }
            frac -= 1.0
            pl = l; pr = r
            return n
        }
    }

    /** Decodes any audio file to raw 44.1 kHz stereo 16-bit PCM (volume applied). Returns the number of frames. */
    private fun decodeToPcm(path: String, volume: Float, out: File): Long {
        val ex = MediaExtractor()
        ex.setDataSource(path)
        val t = AudioUtils.audioTrack(ex)
        if (t < 0) { ex.release(); return 0L }
        ex.selectTrack(t)
        val inFmt = ex.getTrackFormat(t)
        val dec = MediaCodec.createDecoderByType(inFmt.getString(MediaFormat.KEY_MIME)!!)
        dec.configure(inFmt, null, null, 0)
        dec.start()
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        var rs: Resampler? = null
        var channels = 2
        var frames = 0L
        try {
            java.io.BufferedOutputStream(java.io.FileOutputStream(out), 1 shl 16).use { os ->
                while (!outDone) {
                    if (stop()) throw ExportCancelled()
                    if (!inDone) {
                        val i = dec.dequeueInputBuffer(0)
                        if (i >= 0) {
                            val n = ex.readSampleData(dec.getInputBuffer(i)!!, 0)
                            if (n < 0) { dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                            else { dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
                        }
                    }
                    val o = dec.dequeueOutputBuffer(info, 5000)
                    if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val f = dec.outputFormat
                        rs = Resampler(f.getInteger(MediaFormat.KEY_SAMPLE_RATE)); channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                    } else if (o >= 0) {
                        if (rs == null) {
                            val f = dec.outputFormat
                            rs = Resampler(f.getInteger(MediaFormat.KEY_SAMPLE_RATE)); channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                        }
                        if (info.size > 0) {
                            val bb = dec.getOutputBuffer(o)!!
                            bb.position(info.offset); bb.limit(info.offset + info.size)
                            val sb = bb.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                            val n = sb.remaining() / channels
                            for (k in 0 until n) {
                                val l = (sb.get(k * channels) * volume).toInt().coerceIn(-32768, 32767)
                                val r = if (channels > 1) (sb.get(k * channels + 1) * volume).toInt().coerceIn(-32768, 32767) else l
                                frames += rs!!.push(l, r, os)
                            }
                        }
                        dec.releaseOutputBuffer(o, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                    }
                }
            }
        } finally {
            try { dec.stop() } catch (_: Exception) {}
            dec.release()
            ex.release()
        }
        return frames
    }

    private fun encodeAudio(srcs: List<AudioSrc>, file: File, totalMs: Long) {
        val dir = file.parentFile ?: file
        class Pcm(val file: File, val startFrame: Long, val frames: Long)
        val pcms = ArrayList<Pcm>()
        val rafs = ArrayList<java.io.RandomAccessFile>()
        var enc: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxStarted = false
        try {
            for ((i, sr) in srcs.withIndex()) {
                if (stop()) throw ExportCancelled()
                val f = File(dir, "pcm_${System.nanoTime()}_$i.raw")
                val frames = try { decodeToPcm(sr.path, sr.volume, f) } catch (e: ExportCancelled) { throw e } catch (e: Exception) { 0L }
                if (frames > 0) pcms.add(Pcm(f, sr.startMs * 44100L / 1000L, frames)) else f.delete()
            }
            if (pcms.isEmpty()) return
            for (p in pcms) rafs.add(java.io.RandomAccessFile(p.file, "r"))

            val ef = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, 44100, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, prm.audioBitrate)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 65536)
            }
            val e = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            enc = e
            e.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            e.start()
            val mx = MediaMuxer(file.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mx
            var track = -1
            val info = MediaCodec.BufferInfo()

            fun drain(wait: Boolean): Boolean {
                while (true) {
                    val o = e.dequeueOutputBuffer(info, if (wait) 10_000L else 0L)
                    if (o == MediaCodec.INFO_TRY_AGAIN_LATER) return false
                    if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = mx.addTrack(e.outputFormat); mx.start(); muxStarted = true }
                    else if (o >= 0) {
                        val ob = e.getOutputBuffer(o)!!
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                        if (info.size > 0 && muxStarted) { ob.position(info.offset); ob.limit(info.offset + info.size); mx.writeSampleData(track, ob, info) }
                        e.releaseOutputBuffer(o, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true
                    }
                }
            }

            val totalFrames = totalMs * 44100L / 1000L
            val chunk = 4096
            val mix = IntArray(chunk * 2)
            val raw = ByteArray(chunk * 4)
            val outB = ByteArray(chunk * 4)
            var fp = 0L
            while (fp < totalFrames) {
                if (stop()) throw ExportCancelled()
                val n = minOf(chunk.toLong(), totalFrames - fp).toInt()
                java.util.Arrays.fill(mix, 0)
                for ((k, p) in pcms.withIndex()) {
                    val os = maxOf(fp, p.startFrame)
                    val oe = minOf(fp + n, p.startFrame + p.frames)
                    if (oe <= os) continue
                    val cnt = (oe - os).toInt()
                    rafs[k].seek((os - p.startFrame) * 4)
                    rafs[k].readFully(raw, 0, cnt * 4)
                    val base = (os - fp).toInt() * 2
                    for (j in 0 until cnt * 2) {
                        val v = (raw[j * 2].toInt() and 0xFF) or (raw[j * 2 + 1].toInt() shl 8)
                        mix[base + j] += v.toShort().toInt()
                    }
                }
                for (j in 0 until n * 2) {
                    val v = mix[j].coerceIn(-32768, 32767)
                    outB[j * 2] = (v and 0xFF).toByte(); outB[j * 2 + 1] = ((v shr 8) and 0xFF).toByte()
                }
                var off = 0
                var pts = fp * 1_000_000L / 44100
                val bytes = n * 4
                while (off < bytes) {
                    if (stop()) throw ExportCancelled()
                    val i = e.dequeueInputBuffer(10_000L)
                    if (i >= 0) {
                        val buf = e.getInputBuffer(i)!!
                        buf.clear()
                        val m = minOf(buf.remaining(), bytes - off)
                        buf.put(outB, off, m)
                        e.queueInputBuffer(i, 0, m, pts, 0)
                        off += m; pts += (m / 4) * 1_000_000L / 44100
                    }
                    drain(false)
                }
                fp += n
            }
            var queued = false
            var idle = 0
            while (!queued) {
                val i = e.dequeueInputBuffer(10_000L)
                if (i >= 0) { e.queueInputBuffer(i, 0, 0, totalFrames * 1_000_000L / 44100, MediaCodec.BUFFER_FLAG_END_OF_STREAM); queued = true }
                else { drain(false); if (++idle > 3000) throw IllegalStateException("Audio encoder stuck") }
            }
            idle = 0
            while (!drain(true)) { if (++idle > 3000) throw IllegalStateException("Audio encoder did not finish") }
        } finally {
            for (r in rafs) try { r.close() } catch (_: Exception) {}
            for (p in pcms) p.file.delete()
            try { enc?.stop() } catch (_: Exception) {}
            try { enc?.release() } catch (_: Exception) {}
            try { if (muxStarted) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }

    // ------------------------------------------------------------------ mux
    private fun firstTrack(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith(prefix) == true) return i
        }
        return -1
    }

    private fun merge(video: File, audio: File?, out: File, totalMs: Long) {
        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val vEx = MediaExtractor().apply { setDataSource(video.path) }
        val vi = firstTrack(vEx, "video/")
        vEx.selectTrack(vi)
        val vt = muxer.addTrack(vEx.getTrackFormat(vi))
        var aEx: MediaExtractor? = null
        var at = -1
        if (audio != null && audio.exists() && audio.length() > 0) {
            val e = MediaExtractor().apply { setDataSource(audio.path) }
            val ai = firstTrack(e, "audio/")
            if (ai >= 0) { e.selectTrack(ai); at = muxer.addTrack(e.getTrackFormat(ai)); aEx = e } else e.release()
        }
        muxer.start()
        try {
            copy(vEx, muxer, vt, Long.MAX_VALUE)
            if (aEx != null) copy(aEx, muxer, at, totalMs * 1000L)
        } finally {
            try { muxer.stop() } catch (_: Exception) {}
            muxer.release(); vEx.release(); aEx?.release()
        }
    }

    private fun copy(ex: MediaExtractor, muxer: MediaMuxer, track: Int, limitUs: Long) {
        val buf = ByteBuffer.allocate(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        while (true) {
            if (cancelled()) throw ExportCancelled()
            buf.clear()
            val n = ex.readSampleData(buf, 0)
            if (n < 0 || ex.sampleTime > limitUs) break
            info.set(0, n, ex.sampleTime, if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
            muxer.writeSampleData(track, buf, info)
            ex.advance()
        }
    }
}
