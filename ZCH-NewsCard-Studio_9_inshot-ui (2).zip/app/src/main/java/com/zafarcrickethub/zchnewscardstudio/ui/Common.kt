package com.zafarcrickethub.zchnewscardstudio.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import com.zafarcrickethub.zchnewscardstudio.data.Opt
import com.zafarcrickethub.zchnewscardstudio.data.Samples
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.layout.heightIn
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.zafarcrickethub.zchnewscardstudio.data.Card
import com.zafarcrickethub.zchnewscardstudio.data.Pal
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.renderer.FrameRenderer
import com.zafarcrickethub.zchnewscardstudio.renderer.Thumbs
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val NavyC = Color(0xFF0A1A3F)
val NavyDark = Color(0xFF07122B)
val SurfaceC = Color(0xFF12275A)
val RedC = Color(0xFFD90429)
val GoldC = Color(0xFFFFC107)

@Composable
fun ZchTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = RedC, onPrimary = Color.White, secondary = GoldC, onSecondary = NavyDark,
            background = NavyDark, onBackground = Color.White, surface = SurfaceC, onSurface = Color.White,
            surfaceVariant = Color(0xFF1B3270), onSurfaceVariant = Color(0xFFD0D8EE),
            primaryContainer = RedC, onPrimaryContainer = Color.White, outline = Color(0xFF5C6E9C),
            secondaryContainer = Color(0xFF7A0016), onSecondaryContainer = Color.White
        ),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenScaffold(
    title: String,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    fab: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        containerColor = NavyDark,
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = actions,
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NavyC, titleContentColor = Color.White,
                    navigationIconContentColor = Color.White, actionIconContentColor = Color.White
                )
            )
        },
        bottomBar = bottomBar,
        floatingActionButton = fab,
        content = content
    )
}

@Composable
fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(valueText, color = GoldC, style = MaterialTheme.typography.bodyMedium)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun DropdownField(label: String, options: List<String>, index: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${options.getOrElse(index) { "" }}", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEachIndexed { i, o -> DropdownMenuItem(text = { Text(o) }, onClick = { onSelect(i); open = false }) }
        }
    }
}

@Composable
fun ColorRow(label: String, selected: Int, onPick: (Int) -> Unit) {
    Column {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 6.dp)) {
            items(Pal.swatches) { c ->
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                        .border(if (c == selected) 3.dp else 1.dp, if (c == selected) GoldC else Color.Gray, CircleShape)
                        .clickable { onPick(c) }
                )
            }
        }
        PopupField(
            "Custom colour (hex)", String.format("%06X", selected and 0xFFFFFF),
            { v ->
                val h = v.uppercase().filter { it in "0123456789ABCDEF" }.take(6)
                if (h.length == 6) onPick(0xFF000000.toInt() or h.toInt(16))
            },
            Modifier.width(220.dp), hint = "6 letters / digits, for example FFC107"
        )
    }
}

/**
 * Every text box in the app looks like a normal field but opens a pop-up editor when tapped:
 * big, focused, keyboard open, Paste / Clear buttons. Typing is much easier on a phone and the project
 * is saved once (on OK) instead of on every key press.
 */
@Composable
fun PopupField(
    label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier,
    minLines: Int = 1, keyboardType: KeyboardType = KeyboardType.Text, password: Boolean = false,
    placeholder: String = "", hint: String = ""
) {
    var open by remember { mutableStateOf(false) }
    val shown = if (password && value.isNotEmpty()) "•".repeat(minOf(value.length, 24)) else value
    Box(modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = shown, onValueChange = {}, readOnly = true,
            label = { Text(label) },
            placeholder = { if (placeholder.isNotEmpty()) Text(placeholder) },
            maxLines = if (minLines > 1) 3 else 1,
            textStyle = LocalTextStyle.current.copy(textDirection = TextDirection.Content),
            trailingIcon = { Icon(Icons.Default.Edit, null, Modifier.size(18.dp)) },
            modifier = Modifier.fillMaxWidth()
        )
        Box(Modifier.matchParentSize().clickable { open = true })
    }
    if (open) PopupEditor(label, value, minLines, keyboardType, password, placeholder, hint, { open = false }) { open = false; onValue(it) }
}

@Composable
fun PopupEditor(
    label: String, initial: String, minLines: Int, keyboardType: KeyboardType, password: Boolean,
    placeholder: String, hint: String, onDismiss: () -> Unit, onOk: (String) -> Unit
) {
    var tv by remember { mutableStateOf(TextFieldValue(initial, TextRange(initial.length))) }
    var show by remember { mutableStateOf(!password) }
    val focus = remember { FocusRequester() }
    val clip = LocalClipboardManager.current
    LaunchedEffect(Unit) { delay(200); try { focus.requestFocus() } catch (e: Exception) { } }
    val multi = minLines > 1
    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        title = { Text(label) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = tv, onValueChange = { tv = it },
                    modifier = Modifier.fillMaxWidth().then(if (multi) Modifier.heightIn(min = 190.dp) else Modifier).focusRequester(focus),
                    textStyle = LocalTextStyle.current.copy(textDirection = TextDirection.Content),
                    placeholder = { if (placeholder.isNotEmpty()) Text(placeholder) },
                    singleLine = !multi, minLines = if (multi) minLines else 1, maxLines = if (multi) 14 else 1,
                    keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = if (multi) ImeAction.Default else ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { onOk(tv.text) }),
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation()
                )
                if (hint.isNotEmpty()) Text(hint, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        val t = clip.getText()?.text
                        if (!t.isNullOrEmpty()) tv = TextFieldValue(tv.text + t, TextRange(tv.text.length + t.length))
                    }) { Icon(Icons.Default.ContentPaste, null, Modifier.size(18.dp)); Text("  Paste") }
                    if (tv.text.isNotEmpty()) TextButton(onClick = { tv = TextFieldValue("") }) { Text("Clear") }
                    if (password) TextButton(onClick = { show = !show }) { Text(if (show) "Hide" else "Show") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onOk(tv.text) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun RtlField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, minLines: Int = 1) {
    PopupField(label, value, onChange, modifier, minLines = minLines)
}

@Composable
fun TimeField(label: String, ms: Long, onCommit: (Long) -> Unit, modifier: Modifier = Modifier) {
    PopupField(
        label, Timing.fmtPrecise(ms), { txt -> val v = Timing.parse(txt); if (v != null) onCommit(v) }, modifier,
        hint = "Examples: 5   12.5   1:05   0:01:05.250   (minutes:seconds)"
    )
}

@Composable
fun TextInputDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    PopupEditor(title, initial, 1, KeyboardType.Text, false, "", "", onDismiss, onOk)
}

@Composable
fun ConfirmDialog(text: String, onDismiss: () -> Unit, onOk: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, text = { Text(text) },
        confirmButton = { TextButton(onClick = { onOk(); onDismiss() }) { Text("Yes") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("No") } }
    )
}

/** Live preview that uses exactly the same renderer as the exporter. */
@Composable
fun FramePreview(project: Project, tMs: () -> Long, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val renderer = remember(project) { FrameRenderer(ctx, project) }
    Canvas(modifier.fillMaxWidth().aspectRatio(renderer.dw / renderer.dh).clip(RoundedCornerShape(10.dp)).background(Color.Black)) {
        drawIntoCanvas { renderer.render(it.nativeCanvas, size.width.toInt().coerceAtLeast(1), size.height.toInt().coerceAtLeast(1), tMs()) }
    }
}

/** Preview that always fits inside the space it is given (16:9 or 9:16). onDrag gets the finger movement as a fraction of the picture. */
@Composable
fun FitPreview(project: Project, tMs: () -> Long, modifier: Modifier = Modifier, onDrag: ((Float, Float) -> Unit)? = null) {
    val ctx = LocalContext.current
    val renderer = remember(project) { FrameRenderer(ctx, project) }
    val dragNow by rememberUpdatedState(onDrag)
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val r = renderer.dw / renderer.dh
        val w: Dp
        val h: Dp
        if (maxWidth / maxHeight > r) { h = maxHeight; w = maxHeight * r } else { w = maxWidth; h = maxWidth / r }
        Canvas(
            Modifier.size(w, h).graphicsLayer().background(Color.Black).pointerInput(onDrag != null) {
                if (onDrag != null) detectDragGestures { change, d ->
                    change.consume()
                    dragNow?.invoke(d.x / size.width, d.y / size.height)
                }
            }
        ) {
            drawIntoCanvas { renderer.render(it.nativeCanvas, size.width.toInt().coerceAtLeast(1), size.height.toInt().coerceAtLeast(1), tMs()) }
        }
    }
}

/** Template list with real picture previews. */
@Composable
fun TemplateGrid(p: Project, ids: List<Int>, onPick: (Int) -> Unit) {
    ids.chunked(2).forEach { rowIdx ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            rowIdx.forEach { i ->
                val sample = remember(i) { Samples.card(i) }
                androidx.compose.material3.Card(
                    onClick = { onPick(i) }, modifier = Modifier.weight(1f),
                    colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = NavyC)
                ) {
                    Column(Modifier.padding(6.dp)) {
                        CardThumb(p, sample, Modifier.fillMaxWidth(), 360)
                        Text(Opt.templates[i], style = MaterialTheme.typography.labelMedium, maxLines = 2, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
            if (rowIdx.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

/** Full-screen template chooser: every design is shown as a picture before you pick it. */
@Composable
fun TemplatePicker(title: String, onDismiss: () -> Unit, allowEmpty: Boolean, onEmpty: () -> Unit = {}, onPick: (Int) -> Unit) {
    val demo = remember { Project() }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        androidx.compose.material3.Surface(Modifier.fillMaxSize(), color = NavyDark) {
            Column(Modifier.statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Close") }
                    Text(title, style = MaterialTheme.typography.titleLarge)
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Tap a picture to choose that design.", style = MaterialTheme.typography.bodySmall)
                    if (allowEmpty) OutlinedButton(onClick = onEmpty, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("  Empty project (add cards later)") }
                    Text("TV news style", style = MaterialTheme.typography.titleSmall, color = GoldC)
                    TemplateGrid(demo, Opt.tvStyle, onPick)
                    Text("Classic & match designs", style = MaterialTheme.typography.titleSmall, color = GoldC)
                    TemplateGrid(demo, Opt.classic, onPick)
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
fun CardThumb(project: Project, card: Card, modifier: Modifier = Modifier, width: Int = 480) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, card, project.settings) {
        value = withContext(Dispatchers.Default) { runCatching { Thumbs.render(ctx, project, card, width) }.getOrNull() }
    }
    Box(modifier.clip(RoundedCornerShape(8.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
        bmp?.let { androidx.compose.foundation.Image(it.asImageBitmap(), null, Modifier.fillMaxWidth()) }
    }
}

@Composable
fun Spacer8() = Spacer(Modifier.size(8.dp))

fun statusText(s: String) = when (s) {
    "done" -> "Exported"; "running" -> "Exporting…"; "failed" -> "Export failed"
    "cancelled" -> "Export cancelled"; "interrupted" -> "Export interrupted"; else -> "Not exported"
}

fun dateText(t: Long): String = java.text.SimpleDateFormat("dd MMM yyyy, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(t))

@Composable
fun IconText(icon: ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text(text) }
}
