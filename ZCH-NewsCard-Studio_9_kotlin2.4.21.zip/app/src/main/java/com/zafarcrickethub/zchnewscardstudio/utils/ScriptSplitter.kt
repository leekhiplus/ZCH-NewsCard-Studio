package com.zafarcrickethub.zchnewscardstudio.utils

import kotlin.math.ceil
import kotlin.math.min

/**
 * Turns a pasted news script into card texts on the phone itself (offline, instant, no API).
 * Works with Urdu (۔ ؟ ،) and English punctuation. Card times are left to the user.
 */
object ScriptSplitter {
    class Seg(
        val headline: String, val description: String, val voice: String, val kind: String,
        val team1: String, val team2: String, val score: String, val overs: String, val wickets: String
    )

    class Plan(val segs: List<Seg>, val ticker: String)

    private val teams = listOf(
        "Pakistan" to listOf("پاکستان", "pakistan"),
        "India" to listOf("بھارت", "انڈیا", "india"),
        "England" to listOf("انگلینڈ", "انگلستان", "england"),
        "Australia" to listOf("آسٹریلیا", "australia"),
        "South Africa" to listOf("جنوبی افریقہ", "south africa"),
        "New Zealand" to listOf("نیوزی لینڈ", "نیوزی", "new zealand"),
        "Sri Lanka" to listOf("سری لنکا", "sri lanka"),
        "Bangladesh" to listOf("بنگلہ دیش", "bangladesh"),
        "Afghanistan" to listOf("افغانستان", "afghanistan"),
        "West Indies" to listOf("ویسٹ انڈیز", "west indies")
    )
    private val breakingWords = listOf("بریکنگ", "breaking", "فوری", "ابھی ابھی", "just in", "urgent")
    private val scoreRe = Regex("(\\d{1,3})\\s*/\\s*(\\d{1,2})")
    private val oversRe = Regex("(\\d{1,2}(?:\\.\\d)?)\\s*(?:overs?|اوور)", RegexOption.IGNORE_CASE)
    private val spaceRe = Regex("\\s+")

    private fun words(s: String) = s.trim().split(spaceRe).filter { it.isNotEmpty() }
    private fun cleanEnd(s: String) = s.trim().trimEnd('۔', '.', ' ', '،', ',', ':', '؛', ';')
    private fun clipWords(s: String, max: Int): String {
        val w = words(s)
        return if (w.size <= max) s.trim() else w.take(max).joinToString(" ") + "…"
    }

    /** Sentences end with ۔ ؟ ! ? or a full stop (not a decimal point); a line break also ends one. */
    fun sentences(script: String): List<String> {
        val text = script.replace("\r", "").trim()
        val out = ArrayList<String>()
        val sb = StringBuilder()
        fun flush() {
            val s = sb.toString().trim()
            if (s.isNotEmpty()) out.add(s)
            sb.setLength(0)
        }
        for (i in text.indices) {
            val ch = text[i]
            if (ch == '\n') { flush(); continue }
            sb.append(ch)
            val isEnd = when (ch) {
                '۔', '؟', '!', '?' -> true
                '.' -> {
                    val prev = text.getOrNull(i - 1)
                    val next = text.getOrNull(i + 1)
                    !(prev != null && prev.isDigit() && next != null && next.isDigit()) && (next == null || next.isWhitespace())
                }
                else -> false
            }
            if (isEnd) flush()
        }
        flush()
        return out
    }

    private fun headlineOf(sentence: String): Pair<String, String> {
        val s = sentence.trim()
        val w = words(s)
        if (w.size <= 12) return cleanEnd(s) to ""
        val comma = s.indexOfFirst { it == '،' || it == ',' }
        if (comma > 0) {
            val head = s.substring(0, comma)
            if (words(head).size in 3..12) return head.trim() to s.substring(comma + 1).trim()
        }
        return (w.take(10).joinToString(" ") + "…") to w.drop(10).joinToString(" ")
    }

    private fun findTeams(text: String): List<String> {
        val low = text.lowercase()
        return teams.mapNotNull { (name, keys) ->
            val at = keys.map { low.indexOf(it) }.filter { it >= 0 }.minOrNull()
            if (at == null) null else name to at
        }.sortedBy { it.second }.map { it.first }
    }

    /** maxCards = 0 means automatic (about 220 characters per card, 1-12 cards). */
    fun plan(script: String, maxCards: Int): Plan {
        val sents = sentences(script)
        if (sents.isEmpty()) return Plan(emptyList(), "")
        val total = sents.sumOf { it.length }
        val target = if (maxCards > 0) maxCards else ceil(total / 220.0).toInt().coerceIn(1, 12)
        val n = min(target, sents.size)

        val groups = ArrayList<List<String>>()
        var idx = 0
        for (g in 0 until n) {
            val leftGroups = n - g - 1
            val goal = sents.drop(idx).sumOf { it.length } / (n - g)
            val cur = ArrayList<String>()
            var len = 0
            while (idx < sents.size) {
                val leftSentences = sents.size - idx
                if (cur.isNotEmpty() && (leftSentences <= leftGroups || len >= goal)) break
                cur.add(sents[idx]); len += sents[idx].length; idx++
            }
            groups.add(cur)
        }

        val segs = groups.map { g ->
            val joined = g.joinToString(" ")
            val (headline, extra) = headlineOf(g.first())
            val desc = clipWords((extra + " " + g.drop(1).joinToString(" ")).trim(), 30)
            val found = findTeams(joined)
            val score = scoreRe.find(joined)
            val overs = oversRe.find(joined)?.groupValues?.get(1) ?: ""
            val kind = when {
                score != null && (found.isNotEmpty() || overs.isNotEmpty()) -> "score"
                breakingWords.any { joined.lowercase().contains(it) } -> "breaking"
                else -> "general"
            }
            Seg(
                headline, desc, joined, kind,
                found.getOrNull(0) ?: "", found.getOrNull(1) ?: "",
                if (kind == "score") score!!.value.replace(" ", "") else "",
                if (kind == "score") overs else "",
                if (kind == "score") score!!.groupValues[2] else ""
            )
        }
        return Plan(segs, segs.joinToString("  •  ") { it.headline })
    }
}
