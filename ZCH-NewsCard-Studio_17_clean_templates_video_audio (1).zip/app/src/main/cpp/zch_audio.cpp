// Low-latency microphone capture for the voice-over recorder, built on Google's Oboe.
//
// Design: the Oboe data callback (real-time thread) only copies samples into a lock-free single-producer /
// single-consumer ring buffer. The Kotlin side (OboeRecorder.kt) reads the ring from its own thread and writes the WAV file,
// so the audio thread never blocks on disk, locks or JNI.

#include <jni.h>
#include <oboe/Oboe.h>

#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>

namespace {

constexpr uint32_t kRingSize = 1u << 20;          // samples (16-bit mono): about 21 s at 48 kHz
constexpr uint32_t kRingMask = kRingSize - 1u;

class Recorder : public oboe::AudioStreamDataCallback {
public:
    Recorder() : ring_(kRingSize) {}

    // Returns the real sample rate (> 0) or a negative value on failure.
    int start(int sampleRate) {
        std::lock_guard<std::mutex> lock(mutex_);
        stopLocked();

        write_.store(0, std::memory_order_relaxed);
        read_.store(0, std::memory_order_relaxed);
        overruns_.store(0, std::memory_order_relaxed);

        oboe::AudioStreamBuilder builder;
        builder.setDirection(oboe::Direction::Input)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::I16)
            ->setFormatConversionAllowed(true)
            ->setChannelConversionAllowed(true)
            ->setChannelCount(oboe::ChannelCount::Mono)
            ->setSampleRate(sampleRate)
            ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
            ->setInputPreset(oboe::InputPreset::VoiceRecognition)
            ->setDataCallback(std::shared_ptr<oboe::AudioStreamDataCallback>(this, [](oboe::AudioStreamDataCallback *) {}));

        oboe::Result result = builder.openStream(stream_);
        if (result != oboe::Result::OK || !stream_) {
            stream_.reset();
            return -1;
        }
        if (stream_->getFormat() != oboe::AudioFormat::I16) {   // the callback below only understands 16-bit samples
            stream_->close();
            stream_.reset();
            return -3;
        }
        result = stream_->requestStart();
        if (result != oboe::Result::OK) {
            stream_->close();
            stream_.reset();
            return -2;
        }
        return stream_->getSampleRate();
    }

    void stop() {
        std::lock_guard<std::mutex> lock(mutex_);
        stopLocked();
    }

    // Copies up to `max` samples out of the ring. Called from the Kotlin recording thread only.
    int read(int16_t *dst, int max) {
        uint64_t r = read_.load(std::memory_order_relaxed);
        uint64_t w = write_.load(std::memory_order_acquire);
        uint64_t avail = w - r;
        if (avail == 0) return 0;
        uint64_t n = avail < static_cast<uint64_t>(max) ? avail : static_cast<uint64_t>(max);
        for (uint64_t i = 0; i < n; ++i) dst[i] = ring_[(r + i) & kRingMask];
        read_.store(r + n, std::memory_order_release);
        return static_cast<int>(n);
    }

    int overruns() const { return overruns_.load(std::memory_order_relaxed); }

    // Real-time audio thread.
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream * /*stream*/, void *audioData, int32_t numFrames) override {
        const int16_t *in = static_cast<const int16_t *>(audioData);
        uint64_t w = write_.load(std::memory_order_relaxed);
        uint64_t r = read_.load(std::memory_order_acquire);
        uint64_t freeSpace = kRingSize - (w - r);
        uint64_t n = static_cast<uint64_t>(numFrames);
        if (n > freeSpace) {                       // the Kotlin side is too slow: drop the newest samples, never block
            overruns_.fetch_add(1, std::memory_order_relaxed);
            n = freeSpace;
        }
        for (uint64_t i = 0; i < n; ++i) ring_[(w + i) & kRingMask] = in[i];
        write_.store(w + n, std::memory_order_release);
        return oboe::DataCallbackResult::Continue;
    }

private:
    void stopLocked() {
        if (stream_) {
            stream_->requestStop();
            stream_->close();
            stream_.reset();
        }
    }

    std::mutex mutex_;
    std::shared_ptr<oboe::AudioStream> stream_;
    std::vector<int16_t> ring_;
    std::atomic<uint64_t> write_{0};
    std::atomic<uint64_t> read_{0};
    std::atomic<int> overruns_{0};
};

Recorder &recorder() {
    static Recorder instance;
    return instance;
}

}  // namespace

extern "C" {

JNIEXPORT jint JNICALL
Java_com_zafarcrickethub_zchnewscardstudio_audio_OboeRecorder_nativeStart(JNIEnv * /*env*/, jobject /*thiz*/, jint sampleRate) {
    return recorder().start(sampleRate);
}

JNIEXPORT void JNICALL
Java_com_zafarcrickethub_zchnewscardstudio_audio_OboeRecorder_nativeStop(JNIEnv * /*env*/, jobject /*thiz*/) {
    recorder().stop();
}

JNIEXPORT jint JNICALL
Java_com_zafarcrickethub_zchnewscardstudio_audio_OboeRecorder_nativeRead(JNIEnv *env, jobject /*thiz*/, jshortArray buffer, jint max) {
    if (buffer == nullptr || max <= 0) return 0;
    const jsize len = env->GetArrayLength(buffer);
    const int cap = max < len ? max : len;
    jshort *dst = env->GetShortArrayElements(buffer, nullptr);
    if (dst == nullptr) return 0;
    const int n = recorder().read(reinterpret_cast<int16_t *>(dst), cap);
    env->ReleaseShortArrayElements(buffer, dst, 0);
    return n;
}

JNIEXPORT jint JNICALL
Java_com_zafarcrickethub_zchnewscardstudio_audio_OboeRecorder_nativeOverruns(JNIEnv * /*env*/, jobject /*thiz*/) {
    return recorder().overruns();
}

}  // extern "C"
