package com.zafarcrickethub.zchnewscardstudio

import com.zafarcrickethub.zchnewscardstudio.data.AppJson
import com.zafarcrickethub.zchnewscardstudio.data.Card
import com.zafarcrickethub.zchnewscardstudio.data.Opt
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.data.Samples
import com.zafarcrickethub.zchnewscardstudio.utils.GeminiTts
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import kotlinx.serialization.encodeToString
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TimingTest {
    @Test fun distributesEvenly() {
        val r = Timing.distribute(List(3) { Card() }, 18000)
        assertEquals(listOf(0L, 6000L, 12000L), r.map { it.startMs })
        assertEquals(18000L, r.last().endMs)
    }

    @Test fun detectsProblems() {
        val cards = listOf(Card(startMs = 0, endMs = 5000), Card(startMs = 4000, endMs = 9000), Card(startMs = 9000, endMs = 3000))
        assertTrue(Timing.validate(cards, 8000, false).any { it.text.contains("overlaps") })
        assertTrue(Timing.validate(cards, 8000, false).any { it.text.contains("beyond") })
        assertTrue(Timing.validate(cards, 8000, false).any { it.text.contains("after start") })
        assertTrue(Timing.validate(cards.take(2), 20000, true).isEmpty())
    }

    @Test fun parsesTimes() {
        assertEquals(65500L, Timing.parse("1:05.5"))
        assertEquals(12000L, Timing.parse("12"))
        assertNull(Timing.parse("abc"))
        assertEquals("1:05.5", Timing.fmt(65500))
    }

    @Test fun projectJsonRoundTrip() {
        val p = Project(name = "تجربہ", cards = (0..12).map { Samples.card(it) })
        val back = AppJson.decodeFromString<Project>(AppJson.encodeToString(p))
        assertNotNull(back)
        assertEquals(13, back.cards.size)
        assertEquals(13, Opt.templates.size)
        assertEquals(p.cards[0].headline, back.cards[0].headline)
    }

    @Test fun wavHeaderIsValid() {
        val w = GeminiTts.pcmToWav(ByteArray(100), 24000)
        assertEquals(144, w.size)
        assertEquals("RIFF", String(w, 0, 4))
        assertEquals("WAVE", String(w, 8, 4))
        assertEquals(24000, java.nio.ByteBuffer.wrap(w).order(java.nio.ByteOrder.LITTLE_ENDIAN).getInt(24))
    }
}
