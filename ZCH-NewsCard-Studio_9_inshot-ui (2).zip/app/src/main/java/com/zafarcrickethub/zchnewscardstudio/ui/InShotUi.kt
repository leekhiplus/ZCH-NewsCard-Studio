package com.zafarcrickethub.zchnewscardstudio.ui

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zafarcrickethub.zchnewscardstudio.data.Pal
import com.zafarcrickethub.zchnewscardstudio.utils.Timing

// =====================================================================================
//  InShot-style editing panels.
//  A panel sits under the preview (the preview stays visible and live). It has a title and a
//  tick (done) on top, a strip of tools (icon above label) and the controls of ONE tool below.
// =====================================================================================
val EditorBg = Color(0xFF232323)
val PanelBg = Color(0xFF2B2B2B)
val PanelChip = Color(0xFF3C3C3C)
val PanelLine = Color(0xFF444444)
val PanelMuted = Color(0xFFB4B4B4)
const val PANEL_BODY_DP = 210

/** One tool of the strip. A tool without an icon is only a thin divider between groups. */
class PTool(val key: String, val label: String, val icon: ImageVector?)

fun pSep() = PTool("|", "", null)

@Composable
fun PToolStrip(tools: List<PTool>, selected: String, onSelect: (String) -> Unit) {
    LazyRow(Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        items(tools) { t ->
            val ic = t.icon
            if (ic == null) {
                Box(Modifier.padding(horizontal = 6.dp).width(1.dp).height(34.dp).background(PanelLine))
            } else {
                val on = t.key == selected
                Column(
                    Modifier.width(72.dp).clickable { onSelect(t.key) }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(ic, t.label, tint = if (on) GoldC else Color.White, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.height(5.dp))
                    Text(t.label, fontSize = 11.sp, color = if (on) GoldC else PanelMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
fun InShotPanel(
    title: String,
    onDone: () -> Unit,
    tools: List<PTool>,
    selected: String,
    onSelect: (String) -> Unit,
    action: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val scroll = remember(selected) { ScrollState(0) }
    Surface(color = PanelBg, contentColor = Color.White, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().height(48.dp).padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = GoldC, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (action != null) action()
                IconButton(onClick = onDone) { Icon(Icons.Default.Check, "Done", tint = Color.White, modifier = Modifier.size(28.dp)) }
            }
            PToolStrip(tools, selected, onSelect)
            HorizontalDivider(color = PanelLine)
            Column(
                Modifier.fillMaxWidth().height(PANEL_BODY_DP.dp).verticalScroll(scroll).padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                content = content
            )
        }
    }
}

/** Small grey help / status line. */
@Composable
fun PHint(text: String, color: Color = PanelMuted) {
    Text(text, color = color, fontSize = 12.sp, lineHeight = 16.sp)
}

/** Label on the left, slider in the middle, value on the right (one compact row). */
@Composable
fun PSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(92.dp), color = PanelMuted, fontSize = 13.sp, maxLines = 2)
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = GoldC, inactiveTrackColor = Color(0xFF5A5A5A))
        )
        Text(valueText, Modifier.width(64.dp), color = GoldC, fontSize = 13.sp, textAlign = TextAlign.End, maxLines = 1)
    }
}

@Composable
fun PSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }, verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f).padding(end = 12.dp), color = Color.White, fontSize = 14.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Horizontal list of rounded choices; tap one to apply it (index < 0 = nothing selected). */
@Composable
fun PChips(options: List<String>, index: Int, onSelect: (Int) -> Unit) {
    val state = rememberLazyListState()
    LaunchedEffect(options.size) { if (index > 1 && index < options.size) state.scrollToItem(index - 1) }
    LazyRow(state = state, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(options) { i, o ->
            val on = i == index
            Text(
                o, color = if (on) Color(0xFF1A1A1A) else Color.White, fontSize = 13.sp, maxLines = 1,
                modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(if (on) GoldC else PanelChip)
                    .clickable { onSelect(i) }.padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }
    }
}

/** Small label with a row of choices under it. */
@Composable
fun PChoice(label: String, options: List<String>, index: Int, onSelect: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        PHint(label)
        PChips(options, index, onSelect)
    }
}

/** Colour circles in one row, plus a small button for a custom hex colour. */
@Composable
fun PColors(selected: Int, onPick: (Int) -> Unit) {
    var hex by remember { mutableStateOf(false) }
    val code = String.format("%06X", selected and 0xFFFFFF)
    if (hex) TextInputDialog("Custom colour (hex, 6 letters / digits)", code, { hex = false }) { v ->
        hex = false
        val h = v.uppercase().filter { it in "0123456789ABCDEF" }.take(6)
        if (h.length == 6) onPick(0xFF000000.toInt() or h.toInt(16))
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
            items(Pal.swatches) { c ->
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                        .border(if (c == selected) 3.dp else 1.dp, if (c == selected) GoldC else Color.Gray, CircleShape)
                        .clickable { onPick(c) }
                )
            }
        }
        TextButton(onClick = { hex = true }) { Text("#$code", fontSize = 12.sp, color = Color.White) }
    }
}

/** Rounded button for panels (grey, or red when it is the main action). */
@Composable
fun PButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, enabled: Boolean = true, primary: Boolean = false) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (primary) RedC else PanelChip, contentColor = Color.White,
            disabledContainerColor = Color(0xFF333333), disabledContentColor = Color(0xFF777777)
        ),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    ) {
        if (icon != null) {
            Icon(icon, null, Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, fontSize = 13.sp, maxLines = 1)
    }
}

/** Compact text field: small label above the value; tapping it opens the big pop-up editor (same editor as everywhere else). */
@Composable
fun PField(
    label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier,
    minLines: Int = 1, placeholder: String = "", hint: String = "", password: Boolean = false
) {
    var open by remember { mutableStateOf(false) }
    val shown = if (password && value.isNotEmpty()) "\u2022".repeat(minOf(value.length, 24)) else value
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(PanelChip).clickable { open = true }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = PanelMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (shown.isBlank()) placeholder.ifBlank { "(empty)" } else shown,
                style = TextStyle(textDirection = TextDirection.Content),
                color = if (shown.isBlank()) Color(0xFF8A8A8A) else Color.White,
                fontSize = 14.sp, maxLines = if (minLines > 1) 3 else 1, overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Icon(Icons.Default.Edit, null, tint = PanelMuted, modifier = Modifier.size(18.dp))
    }
    if (open) PopupEditor(label, value, minLines, KeyboardType.Text, password, placeholder, hint, { open = false }) { open = false; onValue(it) }
}

/** Compact time box: label above, time below; tap to type a new time. */
@Composable
fun PTime(label: String, ms: Long, onCommit: (Long) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(PanelChip).clickable { open = true }
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(label, color = PanelMuted, fontSize = 11.sp, maxLines = 1)
        Text(Timing.fmtPrecise(ms), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
    if (open) PopupEditor(
        label, Timing.fmtPrecise(ms), 1, KeyboardType.Text, false, "",
        "Examples: 5   12.5   1:05   0:01:05.250   (minutes:seconds)", { open = false }
    ) { txt ->
        open = false
        val v = Timing.parse(txt)
        if (v != null) onCommit(v)
    }
}
