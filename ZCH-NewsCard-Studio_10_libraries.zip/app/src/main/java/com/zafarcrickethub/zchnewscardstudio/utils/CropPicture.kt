package com.zafarcrickethub.zchnewscardstudio.utils

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContract
import com.yalantis.ucrop.UCrop
import java.io.File

/** What to crop (a file in the project folder) and where uCrop must write the result. */
class CropRequest(val src: String, val dst: String, val png: Boolean)

/** Opens the uCrop screen (free-style crop, rotate, zoom). The result is the Uri of the cropped file, or null when cancelled. */
class CropPicture : ActivityResultContract<CropRequest, Uri?>() {
    override fun createIntent(context: Context, input: CropRequest): Intent {
        val options = UCrop.Options()
        options.setCompressionFormat(if (input.png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG)
        options.setCompressionQuality(95)
        options.setFreeStyleCropEnabled(true)
        options.setToolbarTitle("Crop picture")
        options.setToolbarColor(0xFF232323.toInt())
        options.setStatusBarColor(0xFF232323.toInt())
        options.setToolbarWidgetColor(0xFFFFFFFF.toInt())
        options.setActiveControlsWidgetColor(0xFFFFC107.toInt())
        return UCrop.of(Uri.fromFile(File(input.src)), Uri.fromFile(File(input.dst)))
            .withOptions(options)
            .getIntent(context)
    }

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
        if (resultCode == Activity.RESULT_OK && intent != null) UCrop.getOutput(intent) else null
}
