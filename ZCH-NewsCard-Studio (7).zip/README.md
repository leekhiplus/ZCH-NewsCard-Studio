# ZCH NewsCard Studio (Zafar Cricket Hub)

Offline Urdu news-card & automated video creator for Android (Kotlin, Jetpack Compose, Material 3,
Room, DataStore, MediaCodec/MediaMuxer). No internet, accounts, ads or AI services are used by the app.

## Build with GitHub Actions (no Android Studio needed)
1. Create a GitHub repository.
2. Upload `ZCH-NewsCard-Studio.zip` **as is** (do not extract) to the repository root
   (Add file → Upload files).
3. Add the workflow file: Add file → Create new file → name it `.github/workflows/android.yml`
   and paste the contents of the separate `android.yml`.
4. Open the **Actions** tab → *Build ZCH NewsCard Studio* → run (it also runs on every push).
5. When finished, download **ZCH-NewsCard-Studio-debug-apk** from the run's Artifacts, unzip, install the APK.

The workflow extracts the ZIP itself, uses the SDK preinstalled on the runner (platform 34), downloads the Noto Nastaliq Urdu font into
the app assets, generates the Gradle wrapper, runs unit tests and builds the debug APK. For a signed release APK add the
secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

## Local build
`gradle wrapper --gradle-version 8.7 && ./gradlew assembleDebug` (JDK 17, Android SDK 34).

## Editor layout (simple, InShot style)
1. Top bar: back, project name, undo / redo, **Export**.
2. Big preview (16:9 or 9:16).
3. Play bar: play button, seek slider with times, timeline zoom.
4. Timeline: card clips with thumbnails + the voice-over waveform. Drag it to scrub (white line = play-head). Tap a clip to
   select it, drag its white edges to trim, double-tap to open the card editor, tap **+** to add a card.
5. Five big buttons. Nothing selected: **Add card · Voice · AI Script · Style (ticker / logo / format) · Timing**.
   Card selected: **Edit · Time · Split · Copy · Delete**.
The card editor has five tabs: **Text · Pictures · Look · Motion · Time**.

## Speed & native feel
* Export draws every frame on the phone's **GPU** (`Surface.lockHardwareCanvas`) straight into the hardware H.264 encoder; the voice-over is
  encoded on a second thread at the same time. Text layouts are cached, pictures are uploaded to the GPU once. *Compatibility mode* in the
  Export screen switches back to the slower software canvas if a device shows a black / garbled video.
* Native Android look: native splash screen, edge-to-edge, bottom navigation bar + FAB, animated screen transitions, predictive back,
  haptic feedback. Every text box opens in a pop-up editor (big field, keyboard open, Paste / Clear).
* FFmpeg: the community-maintained FFmpegKit fork (`dev.ffmpegkit-maintained:ffmpeg`, LGPL free build, arm64) is bundled as a **fallback converter**:
  if the phone cannot decode an imported audio file, FFmpeg converts it to WAV. It does not render the video (the free build has no H.264
  encoder and no hardware acceleration - the Android hardware encoder is the fastest path). If the library cannot be downloaded the
  workflow retries the build with `-PwithFfmpeg=false`.

## Pictures
Each card can hold unlimited pictures: *Pictures → Add pictures (select many)*. They play one after another inside the card
(equal share of the card time) with a chosen change effect (crossfade / slide / zoom / wipe).

## AI Script → cards + voice-over (optional, online)
Paste a full news script (AI Script button or the dashboard tile). With your Google AI Studio key the app asks Gemini to split
it into cards (headline, description, match fields, ticker) and can create the voice-over in the same go. Card times are NOT
guessed: set each card's start / end with the play-head ("Start = play-head" / "End = play-head") or type them.

## Templates (23)
13-22 are the clean **TV news flash** family (full-bleed photo, small BREAKING NEWS + LIVE tag, solid headline bar right above a
red ticker strip): News Flash Classic, Red Alert Bar, Black & Gold Bar, Pakistan Green Bar, Score Bar Live, Light Panel News,
Top Stories Counter, Cinematic Headline, Side Banner News, Kicker + Headline.

### 0-12 layered broadcast designs
Every template is built from layers, each with its own delayed entrance animation: full-bleed picture (or an animated stadium
scene when there is no picture) → colour tint + vignette → light leak / bokeh / sun-burst → slanted panels, banners, brackets,
LIVE badge, flags, score strips, photo frames → text. Loop effects (shine sweep, breathing, floating) run after the entrance.
0 Classic Breaking News · 1 TV Bulletin · 2 Cricket Sports · 3 Headline News · 4 Special Report (cinematic letter-box) ·
5 Match Score Update · 6 Player Performance · 7 Breaking Alert · 8 Match Photo Collage · 9 Match Day Live ·
10 Triple Photo Gallery · 11 Player of the Match · 12 Stadium Photo Story. Templates 8-12 have the red BREAKING NEWS banner
on top, match pictures (main + up to 2 extra) and the ticker strip at the bottom.

## Animations
* 24 layer / text entrance animations (fade, slides, pop, zoom in/out, bounce, flip, rotate, spin-zoom, 3 wipes, elastic,
  shake, swing, glitch, stretch, skew, flash, typewriter, rise) + an exit animation (any entrance played backwards) + looping effects.
* 14 picture motions (zooms, pans, diagonal drift, breathing, slow rotate, handheld shake, punch-in, swing pan ...).
* 22 transitions (fade, slides ×4, crossfade, cut, wipes ×4, zoom in/out, push, circle reveal, blinds, diagonal wipe, flash,
  spin, glitch, split open, flip, auto-varied) with adjustable length.

## Optional AI voice-over (Google AI Studio)
Voice-over sheet → paste your API key (aistudio.google.com/apikey), choose model/voice, write or "Fill from cards" the script,
tap Generate. The app calls the Gemini TTS API (`models/<model>:generateContent`, default `gemini-3.1-flash-tts-preview`),
wraps the returned 24 kHz PCM into a WAV and uses it as the voice-over. Only the script text is sent to Google; the key is
stored on the phone. This is the only feature that uses the internet (INTERNET permission); everything else stays offline.

## Architecture
`data/` Room + DataStore + models · `graphics/` font, bitmap cache, Urdu text layout, flags ·
`renderer/` FrameRenderer (8 templates, animations, transitions, ticker, logo) used by preview AND export,
`VideoExporter` (frame-by-frame H.264 via MediaCodec surface + AAC audio + MediaMuxer), `ExportService` (foreground service,
progress, cancel) · `audio/` playback + waveform · `ui/` Compose screens · `utils/` timing validation, MediaStore saving.

## Testing checklist
Unit tests: `./gradlew testDebugUnitTest`. On a device run through: create project → add Urdu cards → import audio →
set timings → reorder → images → templates → animations → ticker → logo → preview → export 720p/1080p, 16:9/9:16 →
check audio sync and Urdu shaping in the exported file → close/reopen project → cancel an export.

## Known limitations
* Card timing is fully manual (Start / End / Duration fields per card, nudge buttons, drag markers) or evenly distributed; the app does not understand speech.
* Image "crop" = zoom + position inside the frame. Flags are simplified drawings.
* Exported video frame timestamps are fixed at the chosen FPS; if a device encoder drops frames, video may end slightly early.
* On Android 8–9 the app asks for storage permission to write into Movies/Pictures.
