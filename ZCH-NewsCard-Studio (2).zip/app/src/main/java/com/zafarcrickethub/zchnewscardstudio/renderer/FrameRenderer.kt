package com.zafarcrickethub.zchnewscardstudio.renderer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import com.zafarcrickethub.zchnewscardstudio.data.Card
import com.zafarcrickethub.zchnewscardstudio.data.Pal
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.graphics.Bmp
import com.zafarcrickethub.zchnewscardstudio.graphics.Shapes
import com.zafarcrickethub.zchnewscardstudio.graphics.TextKit
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/**
 * Single drawing pipeline used by the editor preview, thumbnails AND the MP4 exporter,
 * so the preview matches the exported video. Everything is a pure function of time (tMs).
 */
class FrameRenderer(private val ctx: Context, private val project: Project) {
    private val s = project.settings
    private val port = !s.landscape
    val dw = if (port) 720f else 1280f
    val dh = if (port) 1280f else 720f
    private val m = 24f
    private val pt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
    private val mtx = Matrix()

    private val tickerH get() = dh * (if (port) 0.055f else 0.085f)
    private val contentBottom get() = if (s.tickerOn) dh - tickerH else dh

    // ---------------------------------------------------------------- main entry
    fun render(cv: Canvas, w: Int, h: Int, tMs: Long) {
        val save = cv.save()
        cv.scale(w / dw, h / dh)
        cv.clipRect(0f, 0f, dw, dh)
        cv.drawColor(Pal.Navy)
        val cards = project.cards
        if (cards.isEmpty()) {
            fillGrad(cv, RectF(0f, 0f, dw, dh), Pal.Navy, Pal.DeepNavy)
            TextKit.draw(ctx, cv, "ZAFAR CRICKET HUB", RectF(40f, dh * 0.4f, dw - 40f, dh * 0.6f), 70f, Pal.Gold, latin = true)
            cv.restoreToCount(save)
            return
        }
        val idx = currentIndex(tMs)
        val cur = cards[idx]
        val lt = tMs - cur.startMs
        val prev = if (idx > 0) cards[idx - 1] else null
        val td = (cur.animMs / cur.animSpeed.coerceAtLeast(0.25f)).toLong().coerceIn(150L, 2500L)
        if (prev != null && lt in 0 until td && cur.transition != 3) {
            val x = lt / td.toFloat()
            val p = 1f - (1f - x) * (1f - x) * (1f - x)
            val pl = (tMs - prev.startMs).coerceAtLeast(0L)
            when (cur.transition) {
                0 -> if (p < 0.5f) layer(cv, 1f - p * 2f) { drawCard(cv, prev, pl) }
                     else layer(cv, (p - 0.5f) * 2f) { drawCard(cv, cur, lt) }
                1 -> {
                    cv.save(); cv.translate(-p * dw * 0.3f, 0f); drawCard(cv, prev, pl); cv.restore()
                    cv.save(); cv.translate((1f - p) * dw, 0f); drawCard(cv, cur, lt); cv.restore()
                }
                else -> { drawCard(cv, prev, pl); layer(cv, p) { drawCard(cv, cur, lt) } }
            }
        } else {
            drawCard(cv, cur, lt.coerceAtLeast(0L))
        }
        drawTicker(cv, if (cur.tickerText.isNotBlank()) cur.tickerText else s.tickerText, tMs)
        drawLogo(cv, cur)
        cv.restoreToCount(save)
    }

    private fun currentIndex(t: Long): Int {
        val c = project.cards
        var best = -1
        for (i in c.indices) if (t >= c[i].startMs && t < c[i].endMs) best = i
        if (best >= 0) return best
        for (i in c.indices) if (t >= c[i].startMs) best = i
        return if (best >= 0) best else 0
    }

    private fun layer(cv: Canvas, alpha: Float, block: () -> Unit) {
        val sc = cv.saveLayerAlpha(0f, 0f, dw, dh, (alpha.coerceIn(0f, 1f) * 255).toInt())
        block()
        cv.restoreToCount(sc)
    }

    // ---------------------------------------------------------------- primitives
    private fun shade(c: Int, f: Float) = Color.rgb(
        (Color.red(c) * f).toInt().coerceIn(0, 255), (Color.green(c) * f).toInt().coerceIn(0, 255), (Color.blue(c) * f).toInt().coerceIn(0, 255)
    )
    private fun fillRect(cv: Canvas, r: RectF, c: Int) { pt.reset(); pt.isAntiAlias = true; pt.color = c; cv.drawRect(r, pt) }
    private fun fillRR(cv: Canvas, r: RectF, rad: Float, c: Int) { pt.reset(); pt.isAntiAlias = true; pt.color = c; cv.drawRoundRect(r, rad, rad, pt) }
    private fun strokeRR(cv: Canvas, r: RectF, rad: Float, c: Int, w: Float) {
        pt.reset(); pt.isAntiAlias = true; pt.style = Paint.Style.STROKE; pt.strokeWidth = w; pt.color = c
        cv.drawRoundRect(r, rad, rad, pt)
    }
    private fun fillGrad(cv: Canvas, r: RectF, c1: Int, c2: Int, rad: Float = 0f) {
        pt.reset(); pt.isAntiAlias = true
        pt.shader = LinearGradient(r.left, r.top, r.left, r.bottom, c1, c2, Shader.TileMode.CLAMP)
        if (rad > 0f) cv.drawRoundRect(r, rad, rad, pt) else cv.drawRect(r, pt)
        pt.shader = null
    }
    private fun bgGrad(cv: Canvas, c: Int) = fillGrad(cv, RectF(0f, 0f, dw, dh), c, shade(c, 0.55f))

    private fun split(a: RectF, frac: Float): Pair<RectF, RectF> =
        if (!port) {
            val x = a.left + a.width() * frac
            RectF(a.left + m, a.top + m, x - m / 2, a.bottom - m) to RectF(x + m / 2, a.top + m, a.right - m, a.bottom - m)
        } else {
            val y = a.top + a.height() * frac
            RectF(a.left + m, a.top + m, a.right - m, y - m / 2) to RectF(a.left + m, y + m / 2, a.right - m, a.bottom - m)
        }

    // ---------------------------------------------------------------- animation helpers
    private fun anim(cv: Canvas, c: Card, lt: Long, b: RectF, block: () -> Unit) {
        val rp = (lt / (c.animMs / c.animSpeed.coerceAtLeast(0.25f)).coerceAtLeast(50f)).coerceIn(0f, 1f)
        val p = 1f - (1f - rp) * (1f - rp) * (1f - rp)
        var alpha = 1f
        cv.save()
        when (c.textAnim) {
            0 -> alpha = p
            1 -> { cv.translate((1f - p) * dw * 0.5f, 0f); alpha = min(1f, p * 2f) }
            2 -> { cv.translate(-(1f - p) * dw * 0.5f, 0f); alpha = min(1f, p * 2f) }
            3 -> { cv.translate(0f, (1f - p) * dh * 0.35f); alpha = min(1f, p * 2f) }
            4 -> {
                val x = rp - 1f
                val back = 1f + 2.70158f * x * x * x + 1.70158f * x * x
                val sc = 0.5f + 0.5f * back
                cv.scale(sc, sc, b.centerX(), b.centerY()); alpha = min(1f, rp * 4f)
            }
            else -> { val sc = 0.4f + 0.6f * p; cv.scale(sc, sc, b.centerX(), b.centerY()); alpha = p }
        }
        if (alpha < 0.999f) {
            val sv = cv.saveLayerAlpha(b.left - 60f, b.top - 60f, b.right + 60f, b.bottom + 60f, (alpha.coerceIn(0f, 1f) * 255).toInt())
            block()
            cv.restoreToCount(sv)
        } else block()
        cv.restore()
    }

    private fun img(c: Card, slot: Int): String? = c.extraImages.getOrNull(slot)?.takeIf { it.isNotBlank() }

    private fun drawImage(cv: Canvas, c: Card, dest: RectF, lt: Long, dur: Long, rad: Float = 0f) =
        drawImg(cv, c.imagePath, dest, lt, dur, rad, c.imageAnim, c.imgScale, c.imgX, c.imgY)

    /** Extra match pictures; each slot pans in a different direction so galleries feel alive. */
    private fun drawExtra(cv: Canvas, c: Card, slot: Int, dest: RectF, lt: Long, dur: Long, rad: Float = 0f, optional: Boolean = false) {
        val p = img(c, slot)
        if (p == null && optional) return
        val an = if (c.imageAnim == 4) 4 else (c.imageAnim + slot + 1) % 4
        drawImg(cv, p, dest, lt, dur, rad, an, 1f, 0f, 0f)
    }

    private fun drawImg(cv: Canvas, path: String?, dest: RectF, lt: Long, dur: Long, rad: Float, anim: Int, zoom0: Float, px0: Float, py0: Float) {
        val bmp: Bitmap? = Bmp.load(path)
        cv.save()
        if (rad > 0f) cv.clipPath(Path().apply { addRoundRect(dest, rad, rad, Path.Direction.CW) }) else cv.clipRect(dest)
        if (bmp == null) {
            fillGrad(cv, dest, 0xFF22345F.toInt(), 0xFF0B1630.toInt())
            pt.reset(); pt.isAntiAlias = true; pt.color = 0x22FFFFFF
            val cx = dest.centerX(); val cy = dest.centerY(); val u = min(dest.width(), dest.height()) * 0.18f
            cv.drawCircle(cx, cy - u * 0.8f, u, pt)
            cv.drawOval(RectF(cx - u * 1.9f, cy + u * 0.4f, cx + u * 1.9f, cy + u * 3.2f), pt)
        } else {
            val q = (lt.toFloat() / dur.coerceAtLeast(1)).coerceIn(0f, 1f)
            var zoom = zoom0.coerceIn(1f, 3f)
            var panX = px0; val panY = py0
            when (anim) {
                0 -> zoom *= 1f + 0.15f * q
                1 -> zoom *= 1.15f - 0.15f * q
                2 -> { zoom *= 1.2f; panX += 1f - 2f * q }
                3 -> { zoom *= 1.2f; panX += -1f + 2f * q }
            }
            val bw = bmp.width.toFloat(); val bh = bmp.height.toFloat()
            val dr = dest.width() / dest.height()
            var sw: Float; var sh: Float
            if (bw / bh > dr) { sh = bh; sw = sh * dr } else { sw = bw; sh = sw / dr }
            sw /= zoom; sh /= zoom
            val left = (bw / 2f + panX.coerceIn(-1f, 1f) * (bw - sw) / 2f - sw / 2f).coerceIn(0f, bw - sw)
            val top = (bh / 2f + panY.coerceIn(-1f, 1f) * (bh - sh) / 2f - sh / 2f).coerceIn(0f, bh - sh)
            val sc = dest.width() / sw
            mtx.reset(); mtx.setScale(sc, sc); mtx.postTranslate(dest.left - left * sc, dest.top - top * sc)
            cv.drawBitmap(bmp, mtx, bmpPaint)
        }
        cv.restore()
    }

    // ---------------------------------------------------------------- templates
    private fun drawCard(cv: Canvas, c: Card, lt: Long) {
        val a = RectF(0f, 0f, dw, contentBottom)
        val dur = (c.endMs - c.startMs).coerceAtLeast(1L)
        when (c.template) {
            0 -> t0(cv, c, lt, a, dur)
            1 -> t1(cv, c, lt, a, dur)
            2 -> t2(cv, c, lt, a, dur)
            3 -> t3(cv, c, lt, a, dur)
            4 -> t4(cv, c, lt, a, dur)
            5 -> t5(cv, c, lt, a, dur)
            6 -> t6(cv, c, lt, a, dur)
            7 -> t7(cv, c, lt, a, dur)
            8 -> t8(cv, c, lt, a, dur)
            9 -> t9(cv, c, lt, a, dur)
            10 -> t10(cv, c, lt, a, dur)
            11 -> t11(cv, c, lt, a, dur)
            else -> t12(cv, c, lt, a, dur)
        }
    }

    private fun t0(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgGrad(cv, c.bgColor)
        val (img, txt) = split(a, 0.5f)
        drawImage(cv, c, img, lt, dur, 18f); strokeRR(cv, img, 18f, Pal.Gold, 4f)
        fillGrad(cv, txt, 0xFFE0112B.toInt(), Pal.DarkRed, 22f); strokeRR(cv, txt, 22f, Pal.Gold, 5f)
        val badge = RectF(txt.left + 16, txt.top + 16, txt.right - 16, txt.top + 16 + (if (port) 56f else 62f))
        fillRR(cv, badge, 12f, Pal.Gold)
        TextKit.draw(ctx, cv, "BREAKING NEWS  •  بریکنگ نیوز", badge, 34f, Pal.DeepNavy, latin = true, shadow = false)
        val body = RectF(txt.left + 20, badge.bottom + 12, txt.right - 20, txt.bottom - 16)
        val hb = RectF(body.left, body.top, body.right, body.top + body.height() * 0.66f)
        val db = RectF(body.left, hb.bottom, body.right, body.bottom)
        anim(cv, c, lt, body) {
            TextKit.draw(ctx, cv, c.headline, hb, 84f, c.textColor, true, true, 1, c.textScale)
            TextKit.draw(ctx, cv, c.description, db, 40f, c.textColor, false, true, 1, c.textScale)
        }
    }

    private fun t1(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgGrad(cv, c.bgColor)
        val top = RectF(0f, a.top, dw, a.top + a.height() * 0.26f)
        fillRect(cv, top, Pal.DeepNavy); fillRect(cv, RectF(0f, top.bottom - 6f, dw, top.bottom), Pal.Gold)
        val hb = RectF(m * 2, top.top + 10f, dw - m * 2, top.bottom - 14f)
        anim(cv, c, lt, hb) { TextKit.draw(ctx, cv, c.headline, hb, 72f, c.textColor, true, true, 1, c.textScale) }
        val img = RectF(m * 2, top.bottom + m, dw - m * 2, a.bottom - a.height() * 0.22f - m * 0.5f)
        drawImage(cv, c, img, lt, dur, 14f); strokeRR(cv, img, 14f, Pal.Gold, 4f)
        val db = RectF(m * 2, img.bottom + m * 0.5f, dw - m * 2, a.bottom - 8f)
        fillRR(cv, db, 12f, 0xCC000000.toInt()); fillRect(cv, RectF(db.right - 10f, db.top, db.right, db.bottom), Pal.Red)
        val tb = RectF(db.left + 16, db.top + 6, db.right - 26, db.bottom - 6)
        anim(cv, c, lt, db) { TextKit.draw(ctx, cv, c.description, tb, 40f, c.textColor, false, true, 1, c.textScale) }
    }

    private fun versus(cv: Canvas, box: RectF, n1: String, n2: String) {
        val fh = box.height() * 0.6f; val fw = fh * 1.5f
        val lx = box.centerX() - box.width() * 0.27f; val rx = box.centerX() + box.width() * 0.27f
        val l = RectF(lx - fw / 2, box.top, lx + fw / 2, box.top + fh)
        val r = RectF(rx - fw / 2, box.top, rx + fw / 2, box.top + fh)
        Shapes.flag(cv, n1, l); Shapes.flag(cv, n2, r)
        TextKit.draw(ctx, cv, "VS", RectF(box.centerX() - 50f, box.top, box.centerX() + 50f, box.top + fh), 44f, Pal.Gold, latin = true)
        TextKit.draw(ctx, cv, n1, RectF(l.left - 30f, l.bottom + 2f, l.right + 30f, box.bottom), 28f, Pal.White, latin = true)
        TextKit.draw(ctx, cv, n2, RectF(r.left - 30f, r.bottom + 2f, r.right + 30f, box.bottom), 28f, Pal.White, latin = true)
    }

    private fun scoreboard(cv: Canvas, r: RectF, items: List<Pair<String, String>>) {
        fillRR(cv, r, 16f, 0xE6050E26.toInt()); strokeRR(cv, r, 16f, Pal.Gold, 4f)
        val w = r.width() / items.size
        items.forEachIndexed { i, (k, v) ->
            val col = RectF(r.left + w * i, r.top, r.left + w * (i + 1), r.bottom)
            TextKit.draw(ctx, cv, k, RectF(col.left, col.top + 8f, col.right, col.top + col.height() * 0.32f), 26f, Pal.Gold, latin = true)
            TextKit.draw(ctx, cv, v.ifBlank { "-" }, RectF(col.left + 6f, col.top + col.height() * 0.32f, col.right - 6f, col.bottom - 8f), 64f, Pal.White, latin = true)
            if (i > 0) fillRect(cv, RectF(col.left - 1.5f, r.top + 14f, col.left + 1.5f, r.bottom - 14f), 0x55FFC107)
        }
    }

    private fun t2(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        fillGrad(cv, RectF(0f, 0f, dw, dh), Pal.DeepNavy, shade(c.bgColor, 0.9f))
        pt.reset(); pt.color = 0x0AFFFFFF
        for (i in -3..12) {
            val x = i * 130f
            cv.drawPath(Path().apply { moveTo(x, 0f); lineTo(x + 50f, 0f); lineTo(x + 50f - dh * 0.4f, dh); lineTo(x - dh * 0.4f, dh); close() }, pt)
        }
        val (img, r) = split(a, 0.42f)
        drawImage(cv, c, img, lt, dur, 20f); strokeRR(cv, img, 20f, Pal.Gold, 4f)
        val h = r.height()
        versus(cv, RectF(r.left, r.top, r.right, r.top + h * 0.24f), c.team1, c.team2)
        val hb = RectF(r.left + 8f, r.top + h * 0.26f, r.right - 8f, r.top + h * 0.56f)
        val db = RectF(r.left + 8f, r.top + h * 0.56f, r.right - 8f, r.top + h * 0.68f)
        anim(cv, c, lt, r) {
            TextKit.draw(ctx, cv, c.headline, hb, 64f, c.textColor, true, true, 1, c.textScale)
            TextKit.draw(ctx, cv, if (c.status.isNotBlank()) c.status else c.description, db, 32f, Pal.Gold, false, true, 1, c.textScale)
        }
        scoreboard(cv, RectF(r.left, r.top + h * 0.70f, r.right, r.bottom), listOf("SCORE" to c.score, "OVERS" to c.overs, "WICKETS" to c.wickets))
    }

    private fun t3(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgGrad(cv, c.bgColor)
        val (img, txt) = split(a, 0.5f)
        drawImage(cv, c, img, lt, dur, 16f); strokeRR(cv, img, 16f, Pal.White, 3f)
        fillRR(cv, txt, 18f, 0xF2050E26.toInt()); fillRect(cv, RectF(txt.right - 12f, txt.top + 18f, txt.right, txt.bottom - 18f), Pal.Red)
        val cw = min(txt.width() * 0.5f, 260f)
        val chip = RectF(txt.right - 28f - cw, txt.top + 16f, txt.right - 28f, txt.top + 66f)
        fillRR(cv, chip, 10f, Pal.Red)
        TextKit.draw(ctx, cv, "HEADLINE", chip, 34f, Pal.White, latin = true, shadow = false)
        val hb = RectF(txt.left + 20f, chip.bottom + 10f, txt.right - 30f, txt.top + txt.height() * 0.68f)
        val db = RectF(txt.left + 20f, hb.bottom + 18f, txt.right - 30f, txt.bottom - 14f)
        fillRect(cv, RectF(txt.left + 20f, hb.bottom + 6f, txt.right - 30f, hb.bottom + 9f), Pal.Gold)
        anim(cv, c, lt, txt) {
            TextKit.draw(ctx, cv, c.headline, hb, 76f, c.textColor, true, true, 1, c.textScale)
            TextKit.draw(ctx, cv, c.description, db, 38f, 0xFFDDE3F0.toInt(), false, true, 1, c.textScale)
        }
    }

    private fun t4(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        if (c.imagePath == null) bgGrad(cv, c.bgColor)
        drawImage(cv, c, RectF(0f, 0f, dw, dh), lt, dur)
        pt.reset(); pt.shader = LinearGradient(0f, dh * 0.3f, 0f, dh, 0x00000000, 0xDD000000.toInt(), Shader.TileMode.CLAMP)
        cv.drawRect(0f, dh * 0.3f, dw, dh, pt); pt.shader = null
        val h = a.height()
        val chip = RectF(dw - m * 2 - 400f, a.bottom - h * 0.56f, dw - m * 2, a.bottom - h * 0.56f + 56f)
        fillRR(cv, chip, 10f, Pal.Gold)
        TextKit.draw(ctx, cv, "SPECIAL REPORT  •  خصوصی رپورٹ", chip, 32f, Pal.DeepNavy, latin = true, shadow = false)
        val hb = RectF(m * 2, a.bottom - h * 0.48f, dw - m * 2, a.bottom - h * 0.2f)
        val db = RectF(m * 2, a.bottom - h * 0.2f, dw - m * 2, a.bottom - m)
        anim(cv, c, lt, RectF(m * 2, hb.top, dw - m * 2, db.bottom)) {
            TextKit.draw(ctx, cv, c.headline, hb, 88f, c.textColor, true, true, 2, c.textScale)
            TextKit.draw(ctx, cv, c.description, db, 40f, c.textColor, false, true, 0, c.textScale)
        }
    }

    private fun t5(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgGrad(cv, c.bgColor)
        val h = a.height()
        val hb = RectF(m * 2, a.top + m, dw - m * 2, a.top + h * 0.2f)
        fillRect(cv, RectF(m * 2, hb.bottom + 4f, dw - m * 2, hb.bottom + 8f), Pal.Gold)
        val fw = if (port) dw * 0.3f else dw * 0.2f; val fh = fw * 0.66f
        val score: RectF; val info: RectF; val status: RectF
        val l: RectF; val r: RectF
        if (!port) {
            val cy = a.top + h * 0.42f
            l = RectF(dw * 0.15f - fw / 2, cy - fh / 2, dw * 0.15f + fw / 2, cy + fh / 2)
            r = RectF(dw * 0.85f - fw / 2, cy - fh / 2, dw * 0.85f + fw / 2, cy + fh / 2)
            score = RectF(l.right + m * 1.5f, a.top + h * 0.26f, r.left - m * 1.5f, a.top + h * 0.6f)
            info = RectF(m * 2, a.top + h * 0.66f, dw - m * 2, a.top + h * 0.8f)
            status = RectF(m * 2, a.top + h * 0.83f, dw - m * 2, a.bottom - m)
        } else {
            val cy = a.top + h * 0.3f
            l = RectF(dw * 0.25f - fw / 2, cy - fh / 2, dw * 0.25f + fw / 2, cy + fh / 2)
            r = RectF(dw * 0.75f - fw / 2, cy - fh / 2, dw * 0.75f + fw / 2, cy + fh / 2)
            score = RectF(m * 2, a.top + h * 0.45f, dw - m * 2, a.top + h * 0.6f)
            info = RectF(m * 2, a.top + h * 0.64f, dw - m * 2, a.top + h * 0.74f)
            status = RectF(m * 2, a.top + h * 0.78f, dw - m * 2, a.bottom - m)
        }
        Shapes.flag(cv, c.team1, l); Shapes.flag(cv, c.team2, r)
        TextKit.draw(ctx, cv, c.team1, RectF(l.left - 40f, l.bottom + 6f, l.right + 40f, l.bottom + 56f), 36f, Pal.White, latin = true)
        TextKit.draw(ctx, cv, c.team2, RectF(r.left - 40f, r.bottom + 6f, r.right + 40f, r.bottom + 56f), 36f, Pal.White, latin = true)
        anim(cv, c, lt, a) {
            TextKit.draw(ctx, cv, c.headline, hb, 64f, c.textColor, true, true, 1, c.textScale)
            TextKit.draw(ctx, cv, c.score.ifBlank { "-" }, score, 140f, Pal.Gold, true, true, 1, 1f, latin = true)
            val half = (info.width() - m) / 2
            val b1 = RectF(info.left, info.top, info.left + half, info.bottom)
            val b2 = RectF(info.right - half, info.top, info.right, info.bottom)
            fillRR(cv, b1, 14f, 0x66000000); fillRR(cv, b2, 14f, 0x66000000)
            TextKit.draw(ctx, cv, "OVERS  ${c.overs.ifBlank { "-" }}", b1, 44f, Pal.White, latin = true)
            TextKit.draw(ctx, cv, "WICKETS  ${c.wickets.ifBlank { "-" }}", b2, 44f, Pal.White, latin = true)
            fillRR(cv, status, 16f, Pal.Red); strokeRR(cv, status, 16f, Pal.Gold, 4f)
            TextKit.draw(ctx, cv, c.status, RectF(status.left + 16f, status.top, status.right - 16f, status.bottom), 54f, Pal.White, true, true, 1, c.textScale)
        }
    }

    private fun parseStats(s: String): List<Pair<String, String>> =
        s.lines().filter { it.isNotBlank() }.map { ln ->
            val i = ln.indexOfFirst { it == ':' || it == '=' }
            if (i < 0) ln.trim() to "" else ln.substring(0, i).trim() to ln.substring(i + 1).trim()
        }

    private fun t6(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        fillGrad(cv, RectF(0f, 0f, dw, dh), c.bgColor, shade(Pal.DarkRed, 0.8f))
        val (img, r) = split(a, 0.42f)
        drawImage(cv, c, img, lt, dur, 20f); strokeRR(cv, img, 20f, Pal.Gold, 5f)
        val h = r.height()
        val chip = RectF(r.left, r.top, r.right, r.top + h * 0.09f)
        fillRR(cv, chip, 10f, Pal.Red)
        TextKit.draw(ctx, cv, "PLAYER PERFORMANCE", chip, 34f, Pal.White, latin = true, shadow = false)
        val nb = RectF(r.left, chip.bottom + 6f, r.right, r.top + h * 0.30f)
        val hb = RectF(r.left, nb.bottom, r.right, r.top + h * 0.40f)
        val rows = parseStats(c.stats).take(6)
        val area = RectF(r.left, r.top + h * 0.43f, r.right, r.bottom)
        val rh = area.height() / 6f
        anim(cv, c, lt, r) {
            TextKit.draw(ctx, cv, c.playerName, nb, 90f, Pal.Gold, true, true, 1, c.textScale)
            TextKit.draw(ctx, cv, c.headline, hb, 38f, c.textColor, false, true, 1, c.textScale)
            rows.forEachIndexed { i, (k, v) ->
                val y = area.top + rh * i
                val row = RectF(area.left, y + 4f, area.right, y + rh - 4f)
                fillRR(cv, row, 12f, 0x55000000)
                fillRect(cv, RectF(row.left, row.top + 8f, row.left + 6f, row.bottom - 8f), Pal.Gold)
                TextKit.draw(ctx, cv, k, RectF(row.left + 20f, row.top, row.centerX(), row.bottom), 34f, c.textColor, false, false, 1, 1f, latin = true)
                TextKit.draw(ctx, cv, v, RectF(row.centerX(), row.top, row.right - 16f, row.bottom), 50f, Pal.Gold, true, true, 1, 1f, latin = true)
            }
        }
    }

    private fun t7(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgGrad(cv, c.bgColor)
        pt.reset(); pt.isAntiAlias = true; pt.color = 0x16FFFFFF
        val off = (lt * 0.08f) % 140f
        for (k in -4..((dw / 140f).toInt() + 4)) {
            val x = k * 140f + off
            cv.drawPath(Path().apply { moveTo(x, 0f); lineTo(x + 60f, 0f); lineTo(x + 60f - dh * 0.3f, dh); lineTo(x - dh * 0.3f, dh); close() }, pt)
        }
        pt.color = 0x1EFFFFFF
        cv.drawCircle(dw * 0.88f, a.top + a.height() * 0.5f, 70f + 45f * abs(sin(lt / 500.0)).toFloat(), pt)
        val slide = (1f - (lt / 450f).coerceIn(0f, 1f)).let { it * it }
        val banner = RectF(0f, a.top + a.height() * 0.07f, dw, a.top + a.height() * 0.07f + a.height() * 0.15f)
        cv.save(); cv.translate(-slide * dw, 0f)
        fillRect(cv, banner, Pal.White)
        fillRect(cv, RectF(0f, banner.top, dw, banner.top + 7f), Pal.Gold); fillRect(cv, RectF(0f, banner.bottom - 7f, dw, banner.bottom), Pal.Gold)
        TextKit.draw(ctx, cv, "BREAKING NEWS  |  بریکنگ نیوز", RectF(m, banner.top + 8f, dw - m, banner.bottom - 8f), 76f, Pal.Red, latin = true, shadow = false)
        cv.restore()
        val body = RectF(0f, banner.bottom + m, dw, a.bottom)
        val txt: RectF
        if (c.imagePath != null) {
            val (img, t) = split(body, 0.38f)
            drawImage(cv, c, img, lt, dur, 18f); strokeRR(cv, img, 18f, Pal.White, 4f); txt = t
        } else txt = RectF(m * 2, body.top, dw - m * 2, a.bottom - m)
        val hb = RectF(txt.left, txt.top, txt.right, txt.top + txt.height() * 0.62f)
        val db = RectF(txt.left, hb.bottom, txt.right, txt.bottom)
        anim(cv, c, lt, txt) {
            TextKit.draw(ctx, cv, c.headline, hb, 92f, c.textColor, true, true, 1, c.textScale)
            TextKit.draw(ctx, cv, c.description, db, 42f, c.textColor, false, true, 1, c.textScale)
        }
    }


    // ---------------------------------------------------------------- match templates (top breaking banner + pictures)
    /** Red BREAKING NEWS banner at the top (slides in, blinking live dot). Returns its bottom edge. */
    private fun topBanner(cv: Canvas, lt: Long, a: RectF): Float {
        val h = if (port) 84f else 78f
        val r = RectF(0f, a.top, dw, a.top + h)
        val slide = (1f - (lt / 400f).coerceIn(0f, 1f)).let { it * it }
        cv.save(); cv.translate(0f, -slide * h)
        fillGrad(cv, r, 0xFFE0112B.toInt(), Pal.DarkRed)
        fillRect(cv, RectF(0f, r.bottom - 6f, dw, r.bottom), Pal.Gold)
        pt.reset(); pt.isAntiAlias = true
        pt.color = if ((lt / 500L) % 2L == 0L) Pal.White else 0x55FFFFFF
        cv.drawCircle(m + 20f, r.centerY() - 2f, 12f, pt)
        TextKit.draw(ctx, cv, "BREAKING NEWS  |  بریکنگ نیوز", RectF(m * 2 + 30f, r.top + 6f, dw - m, r.bottom - 12f), 58f, Pal.White, latin = true)
        cv.restore()
        return r.bottom
    }

    private fun lowerBand(cv: Canvas, c: Card, lt: Long, r: RectF, frac: Float) {
        fillRR(cv, r, 14f, 0xE6050E26.toInt()); fillRect(cv, RectF(r.right - 10f, r.top + 10f, r.right, r.bottom - 10f), Pal.Red)
        val f = if (c.description.isBlank()) 1f else frac
        val hb = RectF(r.left + 16f, r.top + 6f, r.right - 26f, r.top + r.height() * f)
        val db = RectF(r.left + 16f, hb.bottom, r.right - 26f, r.bottom - 6f)
        anim(cv, c, lt, r) {
            TextKit.draw(ctx, cv, c.headline, hb, 70f, c.textColor, true, true, 1, c.textScale)
            TextKit.draw(ctx, cv, c.description, db, 36f, 0xFFDDE3F0.toInt(), false, true, 1, c.textScale)
        }
    }

    private fun t8(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgGrad(cv, c.bgColor)
        val top = topBanner(cv, lt, a) + 14f
        val band = a.height() * (if (port) 0.2f else 0.26f)
        val g = RectF(m, top, dw - m, a.bottom - band - 14f)
        val gp = 10f
        val main: RectF; val s1: RectF; val s2: RectF
        if (!port) {
            val mw = (g.width() - gp) * 0.62f
            main = RectF(g.left, g.top, g.left + mw, g.bottom)
            val sh = (g.height() - gp) / 2f
            s1 = RectF(main.right + gp, g.top, g.right, g.top + sh)
            s2 = RectF(main.right + gp, g.top + sh + gp, g.right, g.bottom)
        } else {
            val mh = (g.height() - gp) * 0.6f
            main = RectF(g.left, g.top, g.right, g.top + mh)
            val sw = (g.width() - gp) / 2f
            s1 = RectF(g.left, main.bottom + gp, g.left + sw, g.bottom)
            s2 = RectF(g.left + sw + gp, main.bottom + gp, g.right, g.bottom)
        }
        drawImage(cv, c, main, lt, dur, 12f); strokeRR(cv, main, 12f, Pal.Gold, 3f)
        drawExtra(cv, c, 0, s1, lt, dur, 12f); strokeRR(cv, s1, 12f, Pal.White, 3f)
        drawExtra(cv, c, 1, s2, lt, dur, 12f); strokeRR(cv, s2, 12f, Pal.White, 3f)
        lowerBand(cv, c, lt, RectF(m, g.bottom + 14f, dw - m, a.bottom - 8f), 0.6f)
    }

    private fun t9(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        if (c.imagePath == null) bgGrad(cv, c.bgColor)
        drawImage(cv, c, RectF(0f, 0f, dw, dh), lt, dur)
        pt.reset(); pt.shader = LinearGradient(0f, 0f, 0f, dh, 0x66000000, 0xEE000000.toInt(), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, dw, dh, pt); pt.shader = null
        val top = topBanner(cv, lt, a) + 14f
        val pw = if (port) dw * 0.38f else dw * 0.22f
        val pip = RectF(dw - m - pw, top, dw - m, top + pw * 0.7f)
        drawExtra(cv, c, 0, pip, lt, dur, 12f, optional = true)
        if (img(c, 0) != null) strokeRR(cv, pip, 12f, Pal.Gold, 4f)
        val sh = a.height() * (if (port) 0.22f else 0.3f)
        val strip = RectF(m, a.bottom - sh - 8f, dw - m, a.bottom - 8f)
        fillRR(cv, strip, 18f, 0xEE050E26.toInt()); strokeRR(cv, strip, 18f, Pal.Gold, 4f)
        val topRow = RectF(strip.left + 16f, strip.top + 10f, strip.right - 16f, strip.top + strip.height() * 0.72f)
        val fh = strip.height() * (if (port) 0.26f else 0.42f); val fw = fh * 1.5f
        val l = RectF(topRow.left, topRow.centerY() - fh / 2, topRow.left + fw, topRow.centerY() + fh / 2)
        val r = RectF(topRow.right - fw, topRow.centerY() - fh / 2, topRow.right, topRow.centerY() + fh / 2)
        Shapes.flag(cv, c.team1, l); Shapes.flag(cv, c.team2, r)
        val nw = topRow.width() * (if (port) 0.2f else 0.17f)
        TextKit.draw(ctx, cv, c.team1, RectF(l.right + 6f, topRow.top, l.right + 6f + nw, topRow.bottom), 40f, Pal.White, latin = true)
        TextKit.draw(ctx, cv, c.team2, RectF(r.left - 6f - nw, topRow.top, r.left - 6f, topRow.bottom), 40f, Pal.White, latin = true)
        val center = RectF(l.right + nw + 12f, topRow.top, r.left - nw - 12f, topRow.bottom)
        TextKit.draw(ctx, cv, c.score.ifBlank { "-" }, RectF(center.left, center.top, center.right, center.top + center.height() * 0.68f), 110f, Pal.Gold, true, true, 1, 1f, latin = true)
        TextKit.draw(ctx, cv, "OVERS ${c.overs.ifBlank { "-" }}  •  WKTS ${c.wickets.ifBlank { "-" }}", RectF(center.left, center.top + center.height() * 0.68f, center.right, center.bottom), 30f, Pal.White, latin = true)
        val bottom = RectF(strip.left + 16f, topRow.bottom, strip.right - 16f, strip.bottom - 8f)
        val hb = RectF(m * 2, strip.top - a.height() * 0.2f - 10f, dw - m * 2, strip.top - 10f)
        anim(cv, c, lt, RectF(hb.left, hb.top, hb.right, strip.bottom)) {
            TextKit.draw(ctx, cv, c.headline, hb, 76f, c.textColor, true, true, 2, c.textScale)
            TextKit.draw(ctx, cv, c.status, bottom, 40f, Pal.Gold, false, true, 1, c.textScale)
        }
    }

    private fun t10(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        bgGrad(cv, c.bgColor)
        val top = topBanner(cv, lt, a) + 14f
        val band = a.height() * (if (port) 0.2f else 0.24f)
        val g = RectF(m, top, dw - m, a.bottom - band - 14f)
        val gp = 12f
        val rects = List(3) { i ->
            if (!port) {
                val w3 = (g.width() - 2 * gp) / 3f
                RectF(g.left + (w3 + gp) * i, g.top, g.left + (w3 + gp) * i + w3, g.bottom)
            } else {
                val h3 = (g.height() - 2 * gp) / 3f
                RectF(g.left, g.top + (h3 + gp) * i, g.right, g.top + (h3 + gp) * i + h3)
            }
        }
        drawImage(cv, c, rects[0], lt, dur, 14f)
        drawExtra(cv, c, 0, rects[1], lt, dur, 14f)
        drawExtra(cv, c, 1, rects[2], lt, dur, 14f)
        rects.forEachIndexed { i, r ->
            strokeRR(cv, r, 14f, Pal.Gold, 3f)
            pt.reset(); pt.isAntiAlias = true; pt.color = Pal.Red
            cv.drawCircle(r.left + 34f, r.top + 34f, 24f, pt)
            TextKit.draw(ctx, cv, "${i + 1}", RectF(r.left + 10f, r.top + 10f, r.left + 58f, r.top + 58f), 34f, Pal.White, latin = true, shadow = false)
        }
        lowerBand(cv, c, lt, RectF(m, g.bottom + 14f, dw - m, a.bottom - 8f), 0.6f)
    }

    private fun t11(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        fillGrad(cv, RectF(0f, 0f, dw, dh), c.bgColor, shade(Pal.DarkRed, 0.7f))
        val top = topBanner(cv, lt, a) + 8f
        val (pic, r) = split(RectF(a.left, top, a.right, a.bottom), 0.42f)
        drawImage(cv, c, pic, lt, dur, 20f); strokeRR(cv, pic, 20f, Pal.Gold, 5f)
        val sw = min(pic.width(), pic.height()) * 0.38f
        val small = RectF(pic.left + 10f, pic.bottom - 10f - sw * 0.75f, pic.left + 10f + sw, pic.bottom - 10f)
        drawExtra(cv, c, 0, small, lt, dur, 10f, optional = true)
        if (img(c, 0) != null) strokeRR(cv, small, 10f, Pal.White, 3f)
        val h = r.height()
        val chip = RectF(r.left, r.top, r.right, r.top + h * 0.1f)
        fillRR(cv, chip, 10f, Pal.Gold)
        TextKit.draw(ctx, cv, "PLAYER OF THE MATCH  •  مین آف دی میچ", chip, 32f, Pal.DeepNavy, latin = true, shadow = false)
        val nb = RectF(r.left, chip.bottom + 4f, r.right, r.top + h * 0.28f)
        val hb = RectF(r.left, nb.bottom, r.right, r.top + h * 0.38f)
        val rows = parseStats(c.stats).take(4)
        val area = RectF(r.left, r.top + h * 0.4f, r.right, r.top + h * 0.8f)
        val rh = area.height() / 4f
        anim(cv, c, lt, r) {
            TextKit.draw(ctx, cv, c.playerName, nb, 90f, Pal.Gold, true, true, 1, c.textScale)
            TextKit.draw(ctx, cv, c.headline, hb, 38f, c.textColor, false, true, 1, c.textScale)
            rows.forEachIndexed { i, (k, v) ->
                val y = area.top + rh * i
                val row = RectF(area.left, y + 4f, area.right, y + rh - 4f)
                fillRR(cv, row, 12f, 0x55000000)
                fillRect(cv, RectF(row.left, row.top + 8f, row.left + 6f, row.bottom - 8f), Pal.Gold)
                TextKit.draw(ctx, cv, k, RectF(row.left + 20f, row.top, row.centerX(), row.bottom), 32f, c.textColor, false, false, 1, 1f, latin = true)
                TextKit.draw(ctx, cv, v, RectF(row.centerX(), row.top, row.right - 16f, row.bottom), 46f, Pal.Gold, true, true, 1, 1f, latin = true)
            }
        }
        versus(cv, RectF(r.left, r.top + h * 0.82f, r.right, r.bottom), c.team1, c.team2)
    }

    private fun t12(cv: Canvas, c: Card, lt: Long, a: RectF, dur: Long) {
        if (c.imagePath == null) bgGrad(cv, c.bgColor)
        drawImage(cv, c, RectF(0f, 0f, dw, dh), lt, dur)
        pt.reset(); pt.shader = LinearGradient(0f, dh * 0.35f, 0f, dh, 0x00000000, 0xDD000000.toInt(), Shader.TileMode.CLAMP)
        cv.drawRect(0f, dh * 0.35f, dw, dh, pt); pt.shader = null
        val top = topBanner(cv, lt, a) + 14f
        val sw = if (port) (dw - 2 * m - 12f) / 2f else dw * 0.2f
        val sh = sw * 0.68f
        val s1: RectF; val s2: RectF
        if (!port) {
            s1 = RectF(dw - m - sw, top, dw - m, top + sh)
            s2 = RectF(dw - m - sw, top + sh + 12f, dw - m, top + 2 * sh + 12f)
        } else {
            s1 = RectF(m, top, m + sw, top + sh)
            s2 = RectF(m + sw + 12f, top, m + 2 * sw + 12f, top + sh)
        }
        drawExtra(cv, c, 0, s1, lt, dur, 12f); strokeRR(cv, s1, 12f, Pal.Gold, 4f)
        drawExtra(cv, c, 1, s2, lt, dur, 12f); strokeRR(cv, s2, 12f, Pal.Gold, 4f)
        val h = a.height()
        val panel = RectF(m, a.bottom - h * 0.3f, if (port) dw - m else dw * 0.72f, a.bottom - m * 0.6f)
        fillRR(cv, panel, 16f, 0xEE7A0016.toInt()); fillRect(cv, RectF(panel.left, panel.top + 10f, panel.left + 10f, panel.bottom - 10f), Pal.Gold)
        val hb = RectF(panel.left + 24f, panel.top + 6f, panel.right - 16f, panel.top + panel.height() * (if (c.description.isBlank()) 0.95f else 0.62f))
        val db = RectF(panel.left + 24f, hb.bottom, panel.right - 16f, panel.bottom - 6f)
        anim(cv, c, lt, panel) {
            TextKit.draw(ctx, cv, c.headline, hb, 72f, c.textColor, true, true, 1, c.textScale)
            TextKit.draw(ctx, cv, c.description, db, 36f, 0xFFDDE3F0.toInt(), false, true, 1, c.textScale)
        }
    }

    // ---------------------------------------------------------------- ticker + logo
    private fun drawTicker(cv: Canvas, text: String, tMs: Long) {
        if (!s.tickerOn) return
        val th = tickerH; val top = dh - th
        fillRect(cv, RectF(0f, top, dw, dh), s.tickerBg)
        fillRect(cv, RectF(0f, top, dw, top + 4f), Pal.Gold)
        val lw = dw * (if (port) 0.34f else 0.2f)
        val vr = dw - lw
        if (text.isNotBlank()) {
            val lay = TextKit.tickerLayout(ctx, text, th * 0.5f * s.tickerSize, s.tickerColor)
            val tw = lay.width.toFloat()
            val period = vr + tw
            val x = vr - ((tMs / 1000f) * s.tickerSpeed) % period   // right-to-left scrolling
            cv.save(); cv.clipRect(0f, top + 4f, vr, dh)
            cv.translate(x, top + (th - lay.height) / 2f); lay.draw(cv); cv.restore()
        }
        val label = RectF(vr, top, dw, dh)
        fillRect(cv, label, Pal.Red)
        TextKit.draw(ctx, cv, s.tickerLabel, RectF(label.left + 8f, label.top + 4f, label.right - 8f, label.bottom - 4f), th * 0.5f, Pal.White, latin = true, shadow = false)
    }

    private fun drawLogo(cv: Canvas, c: Card) {
        if (!s.showLogo) return
        val bmp = Bmp.load(s.logoPath, 800)
        val lw = dw * s.logoSize
        val lh = if (bmp != null) lw * bmp.height / bmp.width else lw * 0.34f
        val nameH = if (bmp != null && s.showChannelName) lw * 0.18f else 0f
        val total = lh + nameH
        val mg = 20f
        val x = if (c.logoPos == 0 || c.logoPos == 2) mg else dw - mg - lw
        val y = if (c.logoPos < 2) mg else contentBottom - mg - total
        val sc = cv.saveLayerAlpha(x - 20f, y - 20f, x + lw + 20f, y + total + 20f, (s.logoOpacity.coerceIn(0f, 1f) * 255).toInt())
        if (bmp != null) {
            cv.drawBitmap(bmp, null, RectF(x, y, x + lw, y + lh), bmpPaint)
            if (s.showChannelName) TextKit.draw(ctx, cv, s.channelName, RectF(x - 10f, y + lh, x + lw + 10f, y + total), lw * 0.12f, Pal.White, latin = true)
        } else {
            val r = RectF(x, y, x + lw, y + lh)
            fillRR(cv, r, lh / 2, 0xE60A1A3F.toInt()); strokeRR(cv, r, lh / 2, Pal.Gold, 3f)
            pt.reset(); pt.isAntiAlias = true; pt.color = Pal.Red
            cv.drawCircle(r.left + lh / 2, r.centerY(), lh * 0.34f, pt)
            pt.color = Pal.White; pt.style = Paint.Style.STROKE; pt.strokeWidth = 2.5f
            cv.drawArc(RectF(r.left + lh * 0.3f, r.centerY() - lh * 0.2f, r.left + lh * 0.9f, r.centerY() + lh * 0.2f), 200f, 140f, false, pt)
            val tb = RectF(r.left + lh * 0.95f, r.top + lh * 0.12f, r.right - lh * 0.3f, r.bottom - lh * 0.12f)
            TextKit.draw(ctx, cv, if (s.showChannelName) s.channelName else "ZCH", tb, lh * 0.5f, Pal.White, latin = true, shadow = false)
        }
        cv.restoreToCount(sc)
    }
}

object Thumbs {
    fun render(ctx: Context, project: Project, card: Card, width: Int, tMs: Long = 3500): Bitmap {
        val dur = maxOf(card.endMs - card.startMs, 6000L)
        val p = project.copy(cards = listOf(card.copy(startMs = 0, endMs = dur)))
        val r = FrameRenderer(ctx, p)
        val h = (width * r.dh / r.dw).toInt()
        val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
        r.render(Canvas(bmp), width, h, tMs)
        return bmp
    }
}
