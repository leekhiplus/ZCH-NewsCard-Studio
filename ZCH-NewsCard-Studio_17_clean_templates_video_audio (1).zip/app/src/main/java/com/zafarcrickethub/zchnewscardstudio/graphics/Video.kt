package com.zafarcrickethub.zchnewscardstudio.graphics

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/**
 * Video clips used like pictures inside a card (they are silent and loop when the card is longer than the clip).
 *
 * Frames are read with MediaMetadataRetriever:
 *  - export / thumbnails ask for a frame and wait for it ([frameSync], exact time, always the right frame);
 *  - the live preview never waits: [framePreview] returns the newest frame it already has and a background thread
 *    decodes the wanted one, then bumps [version] so the canvas that read it is redrawn.
 */
object VideoFrames {
    private val EXT = setOf("mp4", "m4v", "mov", "3gp", "3gpp", "webm", "mkv")

    fun isVideo(path: String?): Boolean = !path.isNullOrBlank() && path.substringAfterLast('.', "").lowercase() in EXT

    /** Changes whenever the background thread finished a frame; a Compose canvas that reads it is redrawn. */
    var version by mutableIntStateOf(0)
        private set

    private const val PREVIEW_STEP_MS = 50L   // preview shows at most 20 distinct frames per second

    // A long, high-resolution clip decoded one exact frame at a time (MediaMetadataRetriever seeks from the last
    // keyframe for every single call) is the slow part of exporting a card that uses a video: at a true 30 fps that is
    // up to 30 of these expensive seeks per second of clip. Sampling a video source at this rate during export instead
    // (same idea as the live preview above) cuts that by roughly half while staying smooth; everything else in the
    // frame (ticker, text, logo) still renders at the full export frame rate, only the video's own motion is sampled.
    private const val EXPORT_STEP_MS = 66L    // ~15 distinct video frames per second

    private class Clip(val path: String) {
        private var r: MediaMetadataRetriever? = null
        @Volatile var durMs = 0L
        @Volatile var bad = false
        private var closed = false

        init {
            try {
                val m = MediaMetadataRetriever()
                m.setDataSource(path)
                r = m
                durMs = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                if (durMs <= 0L) bad = true
            } catch (e: Throwable) {
                bad = true
                try { r?.release() } catch (_: Throwable) {}
                r = null
            }
        }

        /** One frame, scaled down so that its longest side is at most [maxDim]. MediaMetadataRetriever is not thread-safe. */
        @Synchronized
        fun decode(tMs: Long, maxDim: Int): Bitmap? {
            val m = r ?: return null
            if (closed) return null
            return try {
                var b = m.getFrameAtTime(tMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST) ?: return null
                val big = max(b.width, b.height)
                if (big > maxDim) {
                    val s = maxDim.toFloat() / big
                    val sb = Bitmap.createScaledBitmap(b, (b.width * s).toInt().coerceAtLeast(2), (b.height * s).toInt().coerceAtLeast(2), true)
                    if (sb !== b) b.recycle()
                    b = sb
                }
                b
            } catch (e: Throwable) {
                null
            }
        }

        @Synchronized
        fun close() {
            closed = true
            try { r?.release() } catch (_: Throwable) {}
            r = null
        }
    }

    /** At most 6 open clips; the least recently used one is closed. */
    private val clips = object : LinkedHashMap<String, Clip>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Clip>): Boolean {
            if (size > 6) { eldest.value.close(); return true }
            return false
        }
    }

    private fun clip(path: String): Clip? {
        val c = synchronized(clips) { clips.getOrPut(path) { Clip(path) } }
        return if (c.bad) null else c
    }

    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 6).toInt().coerceIn(16 * 1024 * 1024, 64 * 1024 * 1024)
    ) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val durations = ConcurrentHashMap<String, Long>()
    private val newest = ConcurrentHashMap<String, Bitmap>()   // newest decoded frame of every clip (shown while the next one is decoded)

    /** Length of the clip in ms (0 = unreadable). Blocks while the file is opened the first time: never call it from the UI thread. */
    fun durationMs(path: String): Long {
        durations[path]?.let { return it }
        val d = clip(path)?.durMs ?: 0L
        durations[path] = d
        return d
    }

    /** Time inside the clip: loops when the card is longer than the clip, rounded down to [step]. */
    private fun clipTime(tMs: Long, dur: Long, step: Long): Long {
        val t = tMs.coerceAtLeast(0L) % dur
        return ((t / step) * step).coerceAtMost((dur - 1L).coerceAtLeast(0L))
    }

    /** Frame at [tMs] (waits for the decoder). For export, thumbnails and picture lists. */
    fun frameSync(path: String, tMs: Long, maxDim: Int): Bitmap? {
        val c = clip(path) ?: return null
        durations[path] = c.durMs
        val tq = clipTime(tMs, c.durMs, EXPORT_STEP_MS)
        val key = "$path|$tq|$maxDim"
        cache.get(key)?.let { return it }
        val b = c.decode(tq, maxDim) ?: return null
        cache.put(key, b)
        return b
    }

    // ------------------------------------------------------------------ preview (never blocks)
    private class Req(val path: String, val tMs: Long, val maxDim: Int)

    private val wanted = ConcurrentHashMap<String, Req>()
    private val busy = AtomicBoolean(false)
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "video-frames").apply { isDaemon = true } }

    /** Frame for the live preview. Returns the newest frame already decoded (or null before the first one arrives). */
    fun framePreview(path: String, tMs: Long, maxDim: Int): Bitmap? {
        if (version == Int.MIN_VALUE) return null   // reading the state makes the canvas redraw when a new frame arrives
        val dur = durations[path]
        if (dur == null) { request(path, tMs, maxDim); return newest[path] }
        if (dur <= 0L) return null
        val key = "$path|${clipTime(tMs, dur, PREVIEW_STEP_MS)}|$maxDim"
        cache.get(key)?.let { newest[path] = it; return it }
        request(path, tMs, maxDim)
        return newest[path]
    }

    private fun request(path: String, tMs: Long, maxDim: Int) {
        wanted[path] = Req(path, tMs, maxDim)
        kick()
    }

    private fun kick() {
        if (!busy.compareAndSet(false, true)) return
        worker.execute {
            try {
                while (true) {
                    val k = wanted.keys.firstOrNull() ?: break
                    val rq = wanted.remove(k) ?: continue
                    try { decodeForPreview(rq) } catch (_: Throwable) {}
                }
            } finally {
                busy.set(false)
                if (wanted.isNotEmpty()) kick()
            }
        }
    }

    private fun decodeForPreview(rq: Req) {
        val c = clip(rq.path)
        val dur = c?.durMs ?: 0L
        durations[rq.path] = dur
        if (c != null && dur > 0L) {
            val tq = clipTime(rq.tMs, dur, PREVIEW_STEP_MS)
            val key = "${rq.path}|$tq|${rq.maxDim}"
            var b = cache.get(key)
            if (b == null) {
                b = c.decode(tq, rq.maxDim)
                if (b != null) cache.put(key, b)
            }
            if (b != null) newest[rq.path] = b
        }
        version = version + 1
    }
}
