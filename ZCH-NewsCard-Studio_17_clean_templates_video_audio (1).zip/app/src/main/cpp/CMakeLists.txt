cmake_minimum_required(VERSION 3.18.1)
project("zchaudio")

# Oboe comes as a prefab package from the com.google.oboe:oboe AAR (buildFeatures.prefab = true).
find_package(oboe REQUIRED CONFIG)

add_library(zchaudio SHARED zch_audio.cpp)

target_compile_features(zchaudio PRIVATE cxx_std_17)
target_link_libraries(zchaudio oboe::oboe)
