plugins {
    id("com.android.application")
    // No "org.jetbrains.kotlin.android" here: AGP 9 has built-in Kotlin support.
    id("org.jetbrains.kotlin.plugin.serialization")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

// Native low-latency microphone recorder (Oboe, C++). Needs the NDK + CMake. If it cannot be built, build with
// -PwithOboe=false: the app then records with Android's AudioRecord instead (same feature, slightly higher latency).
val withOboe = project.findProperty("withOboe")?.toString() != "false"

android {
    namespace = "com.zafarcrickethub.zchnewscardstudio"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.zafarcrickethub.zchnewscardstudio"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
        if (withOboe) {
            externalNativeBuild { cmake { arguments += "-DANDROID_STL=c++_shared" } }
        }
    }

    if (withOboe) {
        externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt") } }
    }

    val ksFile: String? = System.getenv("KEYSTORE_FILE")
    val hasSigning = ksFile != null && File(ksFile).exists()
    if (hasSigning) {
        signingConfigs {
            create("release") {
                storeFile = file(ksFile!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            // Shrinks unused code and renames classes/methods/fields (R8) so the release APK's own Kotlin code is not
            // readable as-is if someone unpacks it; see app/proguard-rules.pro for what has to stay untouched (JNI,
            // reflection-based libraries). The plain (non-"optimize") default rules are used on purpose: they keep R8
            // to shrinking + renaming only, without the extra bytecode rewrites that occasionally break reflection.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
            if (hasSigning) signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    // Kotlin jvmTarget follows compileOptions.targetCompatibility (17) automatically with built-in Kotlin.
    buildFeatures {
        compose = true
        if (withOboe) prefab = true   // Oboe is delivered as a prefab AAR
    }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")
    // Room 2.8.x: first line with proper KSP2 support (needed with Kotlin 2.x / KSP 2.3.x)
    implementation("androidx.room:room-runtime:2.8.5")
    implementation("androidx.room:room-ktx:2.8.5")
    ksp("androidx.room:room-compiler:2.8.5")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("androidx.core:core-splashscreen:1.0.1")
    // FFmpeg (community-maintained FFmpegKit fork, LGPL, free build from Maven Central). Used as a fallback to
    // convert audio formats the phone cannot decode. The CI workflow retries without it (-PwithFfmpeg=false) if it cannot be resolved.
    if (project.findProperty("withFfmpeg")?.toString() != "false") {
        implementation("dev.ffmpegkit-maintained:ffmpeg:8.1.7")
        implementation("com.arthenica:smart-exception-java:0.2.1")
    }

    // ---- Video: AndroidX Media3 (the successor of the old ExoPlayer / Mp4Composer / GPU video libraries)
    //  * ExoPlayer: in-app player for exported videos
    //  * Transformer + effect: hardware re-encoding ("small copy" for WhatsApp)
    val media3 = "1.11.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("androidx.media3:media3-transformer:$media3")
    implementation("androidx.media3:media3-effect:$media3")
    implementation("androidx.media3:media3-common:$media3")

    // ---- Pictures
    //  * uCrop: free-form picture cropper (JitPack)
    //  * GPUImage: OpenGL ES picture filters
    //  * ML Kit selfie segmentation: on-device "remove background" for player pictures (model is bundled, works offline)
    implementation("com.github.yalantis:ucrop:2.2.11")
    implementation("jp.co.cyberagent.android:gpuimage:2.1.0")
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")

    // ---- Animation: Lottie animated stickers (View-based artifact: it does not pull a newer Compose into the app)
    implementation("com.airbnb.android:lottie:6.7.1")

    // ---- Audio
    //  * TarsosDSP (core, pure Java): finds the pauses in the voice-over to time the cards automatically (GPL-3.0!)
    //  * Oboe: low-latency native microphone capture for recording a voice-over
    implementation("be.tarsos.dsp:core:2.5")
    if (withOboe) implementation("com.google.oboe:oboe:1.10.0")

    testImplementation("junit:junit:4.13.2")
}
