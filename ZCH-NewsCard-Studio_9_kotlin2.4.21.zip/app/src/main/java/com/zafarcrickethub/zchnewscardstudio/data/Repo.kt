package com.zafarcrickethub.zchnewscardstudio.data

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import java.io.File

private val Context.dataStore by preferencesDataStore("zch_settings")

data class AppSettings(
    val landscape: Boolean = true,
    val resolution: Int = 720,
    val fps: Int = 30,
    val channelName: String = "ZAFAR CRICKET HUB",
    val ticker: String = DEFAULT_TICKER,
    val lastProject: String = "",
    val geminiKey: String = "",
    val geminiModel: String = "gemini-3.1-flash-tts-preview",
    val geminiVoice: String = "Kore",
    val geminiModels: String = ""      // comma separated list loaded for the user's key
)

class Repo(private val ctx: Context) {
    private val db = Room.databaseBuilder(ctx, AppDb::class.java, "zch.db").build()
    private val dao = db.dao()
    private val lock = Mutex()

    private val kLand = booleanPreferencesKey("landscape")
    private val kRes = intPreferencesKey("resolution")
    private val kFps = intPreferencesKey("fps")
    private val kChan = stringPreferencesKey("channel")
    private val kTick = stringPreferencesKey("ticker")
    private val kLast = stringPreferencesKey("last")
    private val kKey = stringPreferencesKey("gemini_key")
    private val kModel = stringPreferencesKey("gemini_model")
    private val kVoice = stringPreferencesKey("gemini_voice")
    private val kModels = stringPreferencesKey("gemini_models")

    val settings: Flow<AppSettings> = ctx.dataStore.data.map {
        AppSettings(
            it[kLand] ?: true, it[kRes] ?: 720, it[kFps] ?: 30,
            it[kChan] ?: "ZAFAR CRICKET HUB", it[kTick] ?: DEFAULT_TICKER, it[kLast] ?: "",
            it[kKey] ?: "", it[kModel] ?: "gemini-3.1-flash-tts-preview", it[kVoice] ?: "Kore", it[kModels] ?: ""
        )
    }

    suspend fun updateSettings(s: AppSettings) {
        ctx.dataStore.edit {
            it[kLand] = s.landscape; it[kRes] = s.resolution; it[kFps] = s.fps
            it[kChan] = s.channelName; it[kTick] = s.ticker
            it[kKey] = s.geminiKey; it[kModel] = s.geminiModel; it[kVoice] = s.geminiVoice; it[kModels] = s.geminiModels
        }
    }

    suspend fun setLast(id: String) {
        ctx.dataStore.edit { it[kLast] = id }
    }

    val projects: Flow<List<Project>> = dao.all().map { list ->
        list.mapNotNull { runCatching { AppJson.decodeFromString<Project>(it.body) }.getOrNull() }
    }

    suspend fun load(id: String): Project? =
        dao.get(id)?.let { runCatching { AppJson.decodeFromString<Project>(it.body) }.getOrNull() }

    private fun entity(p: Project) =
        ProjectEntity(p.id, p.name, p.createdAt, p.updatedAt, p.exportStatus, AppJson.encodeToString(p))

    /** Full save (create / duplicate). */
    suspend fun save(p: Project) = lock.withLock { dao.upsert(entity(p)) }

    /** Editor save: keeps export info that the export service may have written meanwhile. */
    suspend fun saveEdit(p: Project) = lock.withLock {
        val db0 = dao.get(p.id)?.let { runCatching { AppJson.decodeFromString<Project>(it.body) }.getOrNull() }
        val merged = if (db0 != null) p.copy(exports = db0.exports, exportStatus = db0.exportStatus) else p
        dao.upsert(entity(merged))
    }

    suspend fun setStatus(id: String, status: String) = lock.withLock {
        load(id)?.let { dao.upsert(entity(it.copy(exportStatus = status))) }
    }

    suspend fun addExport(id: String, rec: ExportRec) = lock.withLock {
        load(id)?.let { dao.upsert(entity(it.copy(exportStatus = "done", exports = listOf(rec) + it.exports))) }
    }

    suspend fun removeExport(id: String, uri: String) = lock.withLock {
        load(id)?.let { p ->
            val left = p.exports.filter { it.uri != uri }
            dao.upsert(entity(p.copy(exports = left, exportStatus = if (left.isEmpty()) "none" else p.exportStatus)))
        }
    }

    suspend fun markInterrupted() = lock.withLock {
        dao.allOnce().forEach { e ->
            if (e.exportStatus == "running") {
                load(e.id)?.let { dao.upsert(entity(it.copy(exportStatus = "interrupted"))) }
            }
        }
    }

    fun projectDir(id: String): File = File(ctx.filesDir, "projects/$id").apply { mkdirs() }

    suspend fun delete(id: String) {
        lock.withLock { dao.delete(id) }
        withContext(Dispatchers.IO) { File(ctx.filesDir, "projects/$id").deleteRecursively() }
    }

    suspend fun duplicate(id: String): String? {
        val p = load(id) ?: return null
        val nid = java.util.UUID.randomUUID().toString()
        return withContext(Dispatchers.IO) {
            val src = File(ctx.filesDir, "projects/$id")
            val dst = File(ctx.filesDir, "projects/$nid")
            if (src.exists()) src.copyRecursively(dst, true)
            fun fix(s: String?) = s?.replace(src.path, dst.path)
            val np = p.copy(
                id = nid, name = p.name + " (copy)", createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis(), exportStatus = "none", exports = emptyList(),
                settings = p.settings.copy(audioPath = fix(p.settings.audioPath), logoPath = fix(p.settings.logoPath)),
                cards = p.cards.map { c -> c.copy(imagePath = fix(c.imagePath), voicePath = fix(c.voicePath), gallery = c.gallery.map { x -> fix(x) ?: x }, extraImages = c.extraImages.map { x -> fix(x) ?: x }) },
                overlays = p.overlays.map { o -> o.copy(imagePath = fix(o.imagePath)) }
            )
            save(np)
            nid
        }
    }

    /** Copies a SAF uri into project-private storage so it survives permission loss. */
    suspend fun importAsset(projectId: String, uri: Uri, prefix: String): String = withContext(Dispatchers.IO) {
        val type = ctx.contentResolver.getType(uri)
        val ext = (type?.let { MimeTypeMap.getSingleton().getExtensionFromMimeType(it) }
            ?: uri.lastPathSegment?.substringAfterLast('.', "")?.takeIf { it.length in 2..4 }
            ?: "bin")
        val f = File(projectDir(projectId), "${prefix}_${System.currentTimeMillis()}.$ext")
        ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            ?: throw IllegalStateException("Cannot open file")
        f.path
    }
}
