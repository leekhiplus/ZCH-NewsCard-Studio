package com.zafarcrickethub.zchnewscardstudio

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.zafarcrickethub.zchnewscardstudio.security.AppGuard
import com.zafarcrickethub.zchnewscardstudio.ui.EditorScreen
import com.zafarcrickethub.zchnewscardstudio.ui.HelpScreen
import com.zafarcrickethub.zchnewscardstudio.ui.HomeScreen
import com.zafarcrickethub.zchnewscardstudio.ui.MainViewModel
import com.zafarcrickethub.zchnewscardstudio.ui.Screen
import com.zafarcrickethub.zchnewscardstudio.ui.ThumbnailScreen
import com.zafarcrickethub.zchnewscardstudio.ui.ZchTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        val guard = AppGuard.check(this)
        setContent {
            ZchTheme {
                val blocked = guard == AppGuard.Result.WRONG_PACKAGE || guard == AppGuard.Result.WRONG_SIGNATURE
                if (blocked) GuardBlockScreen { finishAffinity() } else AppRoot(vm)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        vm.saveNow() // protect against data loss when the app is backgrounded or killed
    }
}

/** Shown instead of the app when it is not a genuine, unmodified copy (see AppGuard). */
@Composable
fun GuardBlockScreen(onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Icon(Icons.Default.Lock, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.error)
            Text("This copy of ZCH NewsCard Studio could not be verified", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
            Text(
                "It looks like this app was repackaged or re-signed, so it will not open. Please get the app from Zafar Cricket Hub.",
                style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center
            )
        }
    }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(6000); onClose() }
}

@Composable
fun AppRoot(vm: MainViewModel) {
    val ctx = LocalContext.current
    // Toasts are drawn above bottom sheets and dialogs, so messages are never hidden.
    LaunchedEffect(vm.message) {
        vm.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); vm.message = null }
    }
    BackHandler(enabled = vm.screen != Screen.Dashboard) { vm.back() }
    // The five home tabs share one route, so the bottom bar stays put while content cross-fades.
    val route = when (vm.screen) {
        Screen.Dashboard, Screen.Projects, Screen.Templates, Screen.Exports, Screen.Settings -> Screen.Dashboard
        else -> vm.screen
    }
    AnimatedContent(
        targetState = route,
        transitionSpec = {
            val deeper = targetState != Screen.Dashboard
            (slideInHorizontally(tween(280)) { if (deeper) it / 6 else -it / 6 } + fadeIn(tween(220))) togetherWith
                (slideOutHorizontally(tween(280)) { if (deeper) -it / 6 else it / 6 } + fadeOut(tween(160)))
        },
        label = "nav"
    ) { r ->
        when (r) {
            Screen.Help -> HelpScreen(vm)
            Screen.Editor -> EditorScreen(vm)
            Screen.Thumbnail -> ThumbnailScreen(vm)
            else -> HomeScreen(vm)
        }
    }
}
