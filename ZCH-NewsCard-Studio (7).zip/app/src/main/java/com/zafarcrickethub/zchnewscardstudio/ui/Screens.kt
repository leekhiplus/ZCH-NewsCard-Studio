package com.zafarcrickethub.zchnewscardstudio.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.ui.unit.dp
import com.zafarcrickethub.zchnewscardstudio.data.Opt
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.data.Samples

@Composable
private fun RowScope.Tile(title: String, sub: String, icon: ImageVector, color: Color, onClick: () -> Unit) {
    Card(
        onClick = onClick, modifier = Modifier.weight(1f).height(112.dp),
        colors = CardDefaults.cardColors(containerColor = color)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = Color.White)
            Column { Text(title, style = MaterialTheme.typography.titleSmall); Text(sub, style = MaterialTheme.typography.bodySmall, color = Color(0xFFDDE3F5)) }
        }
    }
}

@Composable
fun NewProjectDialog(initialTemplate: Int, onDismiss: () -> Unit, onCreate: (String, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var t by remember { mutableStateOf(initialTemplate) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss, title = { Text("New project") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PopupField("Project name", name, { name = it }, placeholder = "e.g. Match report")
                DropdownField("First card", Opt.templates, t, { t = it })
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(name, t) }) { Text("Create") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ProjectItem(vm: MainViewModel, p: Project, extra: @Composable () -> Unit = {}) {
    Card(onClick = { vm.open(p.id) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            val c = p.cards.firstOrNull()
            if (c != null) CardThumb(p, c, Modifier.width(130.dp), 320)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(p.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text(dateText(p.createdAt), style = MaterialTheme.typography.bodySmall)
                Text("${p.cards.size} cards • ${statusText(p.exportStatus)}", style = MaterialTheme.typography.bodySmall, color = Color(0xFFFFC107))
            }
            extra()
        }
    }
}

// =====================================================================================
//  Home: native bottom navigation (Home · Projects · Templates · Exports · Settings) + FAB
// =====================================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainViewModel) {
    val haptic = LocalHapticFeedback.current
    var showNew by remember { mutableStateOf(false) }
    if (showNew) NewProjectDialog(0, { showNew = false }) { n, t -> showNew = false; vm.createProject(n, t) }
    val tabs = listOf(
        Triple(Screen.Dashboard, "Home", Icons.Default.Home),
        Triple(Screen.Projects, "Projects", Icons.Default.FolderOpen),
        Triple(Screen.Templates, "Templates", Icons.Default.Dashboard),
        Triple(Screen.Exports, "Exports", Icons.Default.MovieCreation),
        Triple(Screen.Settings, "Settings", Icons.Default.Settings)
    )
    val title = when (vm.screen) {
        Screen.Projects -> "My projects"; Screen.Templates -> "Templates"; Screen.Exports -> "Exports"
        Screen.Settings -> "Settings"; else -> "ZCH NewsCard Studio"
    }
    Scaffold(
        containerColor = NavyDark,
        topBar = {
            TopAppBar(
                title = { Text(title) },
                actions = { IconButton(onClick = { vm.go(Screen.Help) }) { Icon(Icons.Default.Info, "Help & About") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark, titleContentColor = Color.White, actionIconContentColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = NavyC) {
                tabs.forEach { (s, label, icon) ->
                    NavigationBarItem(
                        selected = vm.screen == s,
                        onClick = { if (vm.screen != s) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); vm.go(s) } },
                        icon = { Icon(icon, label) },
                        label = { Text(label, maxLines = 1) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (vm.screen == Screen.Dashboard || vm.screen == Screen.Projects) {
                ExtendedFloatingActionButton(
                    onClick = { showNew = true }, containerColor = RedC, contentColor = Color.White,
                    icon = { Icon(Icons.Default.Add, null) }, text = { Text("New project") }
                )
            }
        }
    ) { pad ->
        Crossfade(targetState = vm.screen, label = "home") { s ->
            when (s) {
                Screen.Projects -> ProjectsContent(vm, pad)
                Screen.Templates -> TemplatesContent(vm, pad)
                Screen.Exports -> ExportsContent(vm, pad)
                Screen.Settings -> SettingsContent(vm, pad)
                else -> HomeContent(vm, pad)
            }
        }
    }
}

@Composable
private fun HomeContent(vm: MainViewModel, pad: PaddingValues) {
    val projects by vm.projects.collectAsState()
    val settings by vm.settings.collectAsState()
    LazyColumn(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 96.dp, top = 4.dp)) {
        item {
            Text("Zafar Cricket Hub", style = MaterialTheme.typography.headlineSmall, color = Color(0xFFFFC107))
            Text("Make Urdu news videos in minutes", style = MaterialTheme.typography.bodyMedium)
        }
        val last = projects.find { it.id == settings.lastProject }
        if (last != null) item {
            Card(onClick = { vm.open(last.id) }, colors = CardDefaults.cardColors(containerColor = Color(0xFF7A0016))) {
                Row(Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayArrow, null)
                    Column(Modifier.padding(start = 10.dp)) {
                        Text("Continue editing", style = MaterialTheme.typography.labelMedium)
                        Text(last.name, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile("Script → Video", "Paste news, get cards", Icons.Default.AutoAwesome, Color(0xFF8A6D00)) { vm.createFromScript() }
                Tile("Thumbnail maker", "1280×720 JPG / PNG", Icons.Default.Image, Color(0xFF1B3270)) { vm.go(Screen.Thumbnail) }
            }
        }
        if (projects.isNotEmpty()) {
            item { Text("Recent projects", style = MaterialTheme.typography.titleMedium) }
            items(projects.take(5), key = { it.id }) { ProjectItem(vm, it) }
        } else item {
            Text("No projects yet. Tap “New project” or use Script → Video.", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun ProjectsContent(vm: MainViewModel, pad: PaddingValues) {
    val projects by vm.projects.collectAsState()
    var rename by remember { mutableStateOf<Project?>(null) }
    var del by remember { mutableStateOf<Project?>(null) }
    rename?.let { p -> TextInputDialog("Rename project", p.name, { rename = null }) { vm.rename(p.id, it); rename = null } }
    del?.let { p -> ConfirmDialog("Delete \"${p.name}\" and all of its files?", { del = null }) { vm.delete(p.id) } }
    if (projects.isEmpty()) {
        Column(Modifier.padding(pad).fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("No projects yet. Tap “New project” to create your first news video.")
        }
    } else LazyColumn(Modifier.padding(pad).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 96.dp, top = 4.dp)) {
        items(projects, key = { it.id }) { p ->
            ProjectItem(vm, p) {
                Column {
                    Row {
                        IconButton(onClick = { rename = p }) { Icon(Icons.Default.Edit, "Rename") }
                        IconButton(onClick = { vm.duplicate(p.id) }) { Icon(Icons.Default.ContentCopy, "Duplicate") }
                    }
                    IconButton(onClick = { del = p }) { Icon(Icons.Default.Delete, "Delete") }
                }
            }
        }
    }
}

@Composable
private fun TemplatesContent(vm: MainViewModel, pad: PaddingValues) {
    var pick by remember { mutableStateOf(-1) }
    if (pick >= 0) NewProjectDialog(pick, { pick = -1 }) { n, t -> pick = -1; vm.createProject(n, t) }
    val demo = Project(cards = emptyList())
    LazyVerticalGrid(
        GridCells.Adaptive(170.dp), Modifier.padding(pad).padding(horizontal = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 16.dp, top = 4.dp)
    ) {
        items((Opt.tvStyle + Opt.classic).toList()) { i ->
            Card(onClick = { pick = i }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(8.dp)) {
                    CardThumb(demo, remember(i) { Samples.card(i) }, Modifier.fillMaxWidth(), 420)
                    Text(Opt.templates[i], Modifier.padding(top = 6.dp), style = MaterialTheme.typography.labelLarge, maxLines = 2)
                    Text("Tap to start a project", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun ExportsContent(vm: MainViewModel, pad: PaddingValues) {
    val projects by vm.projects.collectAsState()
    val ctx = LocalContext.current
    val all = projects.flatMap { p -> p.exports.map { p to it } }.sortedByDescending { it.second.time }
    if (all.isEmpty()) {
        Column(Modifier.padding(pad).fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) { Text("No exported videos yet.") }
    } else LazyColumn(Modifier.padding(pad).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp, top = 4.dp)) {
        items(all, key = { it.second.uri }) { (p, rec) ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(12.dp)) {
                    Text(rec.name, style = MaterialTheme.typography.titleMedium)
                    Text("${p.name} • ${rec.info}", style = MaterialTheme.typography.bodySmall)
                    Text(dateText(rec.time), style = MaterialTheme.typography.bodySmall, color = Color(0xFFFFC107))
                    Row {
                        TextButton(onClick = {
                            try { ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(rec.uri), "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                            catch (e: Exception) { vm.message = "No video player found" }
                        }) { IconText(Icons.Default.PlayArrow, "Play") }
                        TextButton(onClick = {
                            val i = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, Uri.parse(rec.uri)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            ctx.startActivity(Intent.createChooser(i, "Share video"))
                        }) { IconText(Icons.Default.Share, "Share") }
                        TextButton(onClick = { vm.deleteExport(p.id, rec) }) { IconText(Icons.Default.Delete, "Delete") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsContent(vm: MainViewModel, pad: PaddingValues) {
    val st by vm.settings.collectAsState()
    Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("New projects & exports", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFC107))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Portrait 9:16 by default", Modifier.weight(1f))
            Switch(checked = !st.landscape, onCheckedChange = { v -> vm.updateAppSettings { it.copy(landscape = !v) } })
        }
        Text("Default resolution")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(720, 1080).forEach { r -> FilterChip(selected = st.resolution == r, onClick = { vm.updateAppSettings { it.copy(resolution = r) } }, label = { Text("${r}p") }) }
        }
        Text("Default frame rate")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(24, 25, 30).forEach { f -> FilterChip(selected = st.fps == f, onClick = { vm.updateAppSettings { it.copy(fps = f) } }, label = { Text("$f fps") }) }
        }
        PopupField("Channel name", st.channelName, { v -> vm.updateAppSettings { s -> s.copy(channelName = v) } })
        RtlField("Default ticker text", st.ticker, { v -> vm.updateAppSettings { s -> s.copy(ticker = v) } }, minLines = 2)
        Text("AI voice-over (optional, online)", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFC107))
        GeminiKeyFields(vm)
        Text("Settings are stored on this phone. The internet is used only when you press “Generate voice-over” or “Load models”.", style = MaterialTheme.typography.bodySmall)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpScreen(vm: MainViewModel) {
    ScreenScaffold("Help & About", { vm.back() }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("ZCH NewsCard Studio", style = MaterialTheme.typography.headlineSmall, color = Color(0xFFFFC107))
            Text("Zafar Cricket Hub • version 1.0.0")
            Text("Make a video", style = MaterialTheme.typography.titleMedium)
            Text(
                "1. Tap New project, or use Script → Video: paste the full news script and the cards are made for you (offline).\n" +
                    "2. Voice: import a recording, or paste your Google AI Studio key, pick a voice model and let AI read the script.\n" +
                    "3. Timeline: drag to scrub (white line = play-head). Tap a card to select it, drag its white edges to trim, double-tap to edit it. Time → type exact start / end, or use “Start = play-head”.\n" +
                    "4. Edit → Text · Pictures (unlimited) · Look · Motion · Time.\n" +
                    "5. Style: ticker, logo, 16:9 or 9:16.\n" +
                    "6. Export (top right): 720p / 1080p, FPS, quality → MP4 in Movies/ZCH NewsCard Studio."
            )
            Text("Good to know", style = MaterialTheme.typography.titleMedium)
            Text(
                "• Card times are set by you (or spread evenly). The app does not understand speech.\n" +
                    "• Cards are made on your phone. The internet is used only for the optional AI voice-over.\n" +
                    "• Every text box opens in a pop-up, so typing is easy.\n" +
                    "• If an exported video is black or garbled, export again with “Compatibility mode”.\n" +
                    "• 1080p needs more time and storage than 720p."
            )
        }
    }
}
