package com.zafarcrickethub.zchnewscardstudio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.text.input.KeyboardType
import com.zafarcrickethub.zchnewscardstudio.audio.Playback
import com.zafarcrickethub.zchnewscardstudio.data.Opt
import com.zafarcrickethub.zchnewscardstudio.data.Pal
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportState
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportUi
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import com.zafarcrickethub.zchnewscardstudio.data.Card as NCard

@Composable
fun PlaybackLoop(pb: Playback) {
    LaunchedEffect(pb.playing) {
        if (pb.playing) {
            var last = androidx.compose.runtime.withFrameNanos { it }
            while (true) {
                val now = androidx.compose.runtime.withFrameNanos { it }
                pb.tick((now - last) / 1_000_000L)
                last = now
            }
        }
    }
}

@Composable
fun EditorScreen(vm: MainViewModel) {
    val p = vm.current ?: run { vm.go(Screen.Projects); return }
    PlaybackLoop(vm.playback)
    val ec = vm.editingCard
    if (ec != null) { CardEditor(vm, p, ec); return }
    var rename by remember { mutableStateOf(false) }
    if (rename) TextInputDialog("Rename project", p.name, { rename = false }) { vm.rename(p.id, it); rename = false }
    val tabs = listOf("Cards", "Timeline", "Style", "Preview", "Export")
    ScreenScaffold(p.name, { vm.back() }, actions = {
        IconButton(onClick = { rename = true }) { Icon(Icons.Default.Edit, "Rename") }
    }, bottomBar = {
        NavigationBar(containerColor = NavyC) {
            tabs.forEachIndexed { i, t ->
                NavigationBarItem(selected = vm.tab == i, onClick = { if (i != 3) vm.playback.pause(); vm.tab = i },
                    icon = { Text(listOf("🗂", "🎚", "🎨", "▶", "📤")[i]) }, label = { Text(t) })
            }
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            when (vm.tab) {
                0 -> CardsTab(vm, p)
                1 -> TimelineTab(vm, p)
                2 -> StyleTab(vm, p)
                3 -> PreviewTab(vm, p)
                else -> ExportTab(vm, p)
            }
        }
    }
}

// ---------------------------------------------------------------- cards
@Composable
fun CardsTab(vm: MainViewModel, p: Project) {
    var del by remember { mutableStateOf<NCard?>(null) }
    del?.let { c -> ConfirmDialog("Delete this card?", { del = null }) { vm.deleteCard(c.id) } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            var t by remember { mutableStateOf(0) }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DropdownField("Template", Opt.templates, t, { t = it }, Modifier.weight(1f))
                Button(onClick = { vm.addCard(t) }) { Icon(Icons.Default.AddCircle, null); Text(" Add") }
            }
        }
        items(p.cards, key = { it.id }) { c ->
            val i = p.cards.indexOf(c)
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CardThumb(p, c, Modifier.width(150.dp), 360)
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Text("Card ${i + 1} • ${Opt.templates[c.template]}", style = MaterialTheme.typography.labelMedium, color = Color(0xFFFFC107))
                            Text(c.headline.ifBlank { "(no headline)" }, maxLines = 2)
                            Text("${Timing.fmt(c.startMs)} → ${Timing.fmt(c.endMs)}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Row {
                        IconButton(onClick = { vm.editingCard = c.id }) { Icon(Icons.Default.Edit, "Edit") }
                        TextButton(onClick = { vm.editingCard = c.id }) { Text("⏱ Set time") }
                        IconButton(onClick = { vm.duplicateCard(c.id) }) { Icon(Icons.Default.ContentCopy, "Duplicate") }
                        IconButton(onClick = { vm.moveCard(c.id, -1) }, enabled = i > 0) { Icon(Icons.Default.ArrowUpward, "Up") }
                        IconButton(onClick = { vm.moveCard(c.id, 1) }, enabled = i < p.cards.size - 1) { Icon(Icons.Default.ArrowDownward, "Down") }
                        IconButton(onClick = { del = c }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            }
        }
        item { Text("Reordering swaps the cards but keeps their time slots, so the audio alignment stays intact.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun CardEditor(vm: MainViewModel, p: Project, id: String) {
    val c = p.cards.find { it.id == id } ?: run { vm.editingCard = null; return }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importCardImage(id, u) }
    val dur = (c.endMs - c.startMs).coerceAtLeast(1L)
    var t by remember { mutableStateOf(dur.toFloat()) }
    var anim by remember { mutableStateOf(false) }
    LaunchedEffect(anim, c.id) {
        if (anim) {
            var last = androidx.compose.runtime.withFrameNanos { it }
            t = 0f
            while (anim) {
                val now = androidx.compose.runtime.withFrameNanos { it }
                t += (now - last) / 1_000_000f; last = now
                if (t > dur) { t = dur.toFloat(); anim = false }
            }
        }
    }
    val solo = remember(p, c) { p.copy(cards = listOf(c.copy(startMs = 0, endMs = dur))) }
    ScreenScaffold("Edit card", { vm.editingCard = null }) { pad ->
        Column(Modifier.padding(pad).padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            FramePreview(solo, { t.toLong() })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { anim = true }) { Icon(Icons.Default.PlayArrow, null); Text(" Play animation") }
                Text("  ${Timing.fmt(t.toLong())}")
            }
            androidx.compose.material3.Slider(value = t, onValueChange = { anim = false; t = it }, valueRange = 0f..dur.toFloat())

            // ---- manual timing (user decides exactly when this card appears)
            val idx = p.cards.indexOfFirst { it.id == id }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("⏱ Card ${idx + 1} timing (manual)", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TimeField("Start", c.startMs, { v -> vm.setTiming(id, v, null) }, Modifier.weight(1f))
                        TimeField("End", c.endMs, { v -> vm.setTiming(id, null, v) }, Modifier.weight(1f))
                    }
                    TimeField("Duration", dur, { v -> vm.setDuration(id, v) }, Modifier.fillMaxWidth())
                    Text("Type a value and press Done (keyboard) or tap another field. Examples: 5   12.5   1:05   0:01:05.250", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { vm.nudge(id, -500, 0) }) { Text("Start −0.5s") }
                        TextButton(onClick = { vm.nudge(id, 500, 0) }) { Text("Start +0.5s") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { vm.nudge(id, 0, -500) }) { Text("End −0.5s") }
                        TextButton(onClick = { vm.nudge(id, 0, 500) }) { Text("End +0.5s") }
                    }
                    if (idx > 0) OutlinedButton(onClick = { vm.startAfterPrevious(id) }, modifier = Modifier.fillMaxWidth()) { Text("Start right after previous card") }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(p.settings.ripple, { v -> vm.updateSettings { it.copy(ripple = v) } })
                        Text("  Move the following cards when I change the end time", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    }
                    Timing.validate(p.cards, p.settings.audioDurMs, p.settings.allowOverlap).filter { it.index == idx }.forEach {
                        Text("⚠ ${it.text}", color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            DropdownField("Template", Opt.templates, c.template, { v -> vm.updateCard(id) { it.copy(template = v) } })
            RtlField("Headline (Urdu / English)", c.headline, { v -> vm.updateCard(id) { it.copy(headline = v) } }, minLines = 2)
            if (c.template != 2 && c.template != 5) RtlField("Description", c.description, { v -> vm.updateCard(id) { it.copy(description = v) } }, minLines = 2)
            if (c.template == 2 || c.template == 5) {
                RtlField("Team 1", c.team1, { v -> vm.updateCard(id) { it.copy(team1 = v) } })
                RtlField("Team 2", c.team2, { v -> vm.updateCard(id) { it.copy(team2 = v) } })
                RtlField("Score (e.g. 182/4)", c.score, { v -> vm.updateCard(id) { it.copy(score = v) } })
                RtlField("Overs", c.overs, { v -> vm.updateCard(id) { it.copy(overs = v) } })
                RtlField("Wickets", c.wickets, { v -> vm.updateCard(id) { it.copy(wickets = v) } })
                RtlField("Match status", c.status, { v -> vm.updateCard(id) { it.copy(status = v) } })
            }
            if (c.template == 6) {
                RtlField("Player name", c.playerName, { v -> vm.updateCard(id) { it.copy(playerName = v) } })
                RtlField("Statistics (one per line, e.g. Runs: 85)", c.stats, { v -> vm.updateCard(id) { it.copy(stats = v) } }, minLines = 5)
            }
            SliderRow("Text size", c.textScale, 0.5f..1.6f, "${(c.textScale * 100).toInt()}%") { v -> vm.updateCard(id) { it.copy(textScale = v) } }
            ColorRow("Text colour", c.textColor) { v -> vm.updateCard(id) { it.copy(textColor = v) } }
            ColorRow("Background colour", c.bgColor) { v -> vm.updateCard(id) { it.copy(bgColor = v) } }

            Text("Image", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { pick.launch(arrayOf("image/jpeg", "image/png", "image/webp")) }) { Text(if (c.imagePath == null) "Add image" else "Replace image") }
                if (c.imagePath != null) OutlinedButton(onClick = { vm.updateCard(id) { it.copy(imagePath = null) } }) { Text("Remove") }
            }
            if (c.imagePath != null) {
                SliderRow("Zoom / crop", c.imgScale, 1f..3f, "x${"%.2f".format(c.imgScale)}") { v -> vm.updateCard(id) { it.copy(imgScale = v) } }
                SliderRow("Position left ↔ right", c.imgX, -1f..1f, "%.2f".format(c.imgX)) { v -> vm.updateCard(id) { it.copy(imgX = v) } }
                SliderRow("Position up ↕ down", c.imgY, -1f..1f, "%.2f".format(c.imgY)) { v -> vm.updateCard(id) { it.copy(imgY = v) } }
            }
            DropdownField("Image animation", Opt.imageAnims, c.imageAnim, { v -> vm.updateCard(id) { it.copy(imageAnim = v) } })
            DropdownField("Text animation", Opt.textAnims, c.textAnim, { v -> vm.updateCard(id) { it.copy(textAnim = v) } })
            DropdownField("Transition into this card", Opt.transitions, c.transition, { v -> vm.updateCard(id) { it.copy(transition = v) } })
            SliderRow("Animation duration", c.animMs.toFloat(), 150f..2500f, "${c.animMs} ms") { v -> vm.updateCard(id) { it.copy(animMs = v.toInt()) } }
            SliderRow("Animation speed", c.animSpeed, 0.25f..3f, "x${"%.2f".format(c.animSpeed)}") { v -> vm.updateCard(id) { it.copy(animSpeed = v) } }
            DropdownField("Logo position", Opt.logoPositions, c.logoPos, { v -> vm.updateCard(id) { it.copy(logoPos = v) } })
            RtlField("Ticker text for this card (empty = project ticker)", c.tickerText, { v -> vm.updateCard(id) { it.copy(tickerText = v) } }, minLines = 2)
        }
    }
}

// ---------------------------------------------------------------- timeline
@Composable
fun TimelineTab(vm: MainViewModel, p: Project) {
    val pb = vm.playback
    val s = p.settings
    val total = Timing.totalMs(p).coerceAtLeast(1L)
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importAudio(u) }
    val issues = Timing.validate(p.cards, s.audioDurMs, s.allowOverlap)
    val cardsNow by rememberUpdatedState(p.cards)
    var drag by remember { mutableStateOf<Pair<Int, Boolean>?>(null) }
    val hues = listOf(Color(0xFFD90429), Color(0xFFFFC107), Color(0xFF2E7DFF), Color(0xFF2EB872), Color(0xFFAB47BC), Color(0xFFFF7043))
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Voice-over", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFC107))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { pickAudio.launch(arrayOf("audio/*")) }) { Text(if (s.audioPath == null) "Import audio" else "Replace audio") }
            if (s.audioPath != null) OutlinedButton(onClick = { vm.removeAudio() }) { Text("Remove") }
        }
        if (s.audioPath == null) Text("No voice-over yet. Without audio the video follows the last card's end time.", style = MaterialTheme.typography.bodySmall)

        // waveform + card strip
        val wf = vm.waveform
        Canvas(
            Modifier.fillMaxWidth().height(110.dp).background(Color(0xFF0B1630))
                .pointerInput(total) { detectTapGestures { o -> pb.seek((o.x / size.width * total).toLong()) } }
                .pointerInput(total) { detectHorizontalDragGestures { ch, _ -> pb.seek((ch.position.x / size.width * total).toLong()); ch.consume() } }
        ) {
            if (wf != null) {
                val n = wf.size
                for (i in 0 until n) {
                    val x = i * size.width / n
                    val h = (wf[i] * size.height * 0.45f).coerceAtLeast(1f)
                    drawLine(Color(0xFF5C8DFF), Offset(x, size.height / 2 - h), Offset(x, size.height / 2 + h), 2f)
                }
            } else drawLine(Color(0xFF334A80), Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 2f)
            val px = pb.positionMs.toFloat() / total * size.width
            drawLine(Color.White, Offset(px, 0f), Offset(px, size.height), 3f)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onClick = { pb.toggle() }) { Icon(if (pb.playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause") }
            Text("${Timing.fmt(pb.positionMs)} / ${Timing.fmt(total)}")
        }
        SliderRow("Voice-over volume", s.volume, 0f..2f, "${(s.volume * 100).toInt()}%") { vm.setVolume(it) }

        Text("Card markers (drag an edge)", style = MaterialTheme.typography.titleSmall)
        Canvas(
            Modifier.fillMaxWidth().height(54.dp).background(Color(0xFF0B1630))
                .pointerInput(total) {
                    detectDragGestures(
                        onDragStart = { o ->
                            val ms = o.x / size.width * total
                            var best: Pair<Int, Boolean>? = null
                            var bd = 36f
                            cardsNow.forEachIndexed { i, c ->
                                val ds = kotlin.math.abs(c.startMs - ms) * size.width / total
                                val de = kotlin.math.abs(c.endMs - ms) * size.width / total
                                if (ds < bd) { bd = ds.toFloat(); best = i to false }
                                if (de < bd) { bd = de.toFloat(); best = i to true }
                            }
                            drag = best
                        },
                        onDragEnd = { drag = null }, onDragCancel = { drag = null }
                    ) { ch, _ ->
                        val d = drag
                        if (d != null) vm.setEdge(d.first, d.second, (ch.position.x / size.width * total).toLong().coerceIn(0L, total))
                        ch.consume()
                    }
                }
        ) {
            cardsNow.forEachIndexed { i, c ->
                val x0 = c.startMs.toFloat() / total * size.width
                val x1 = c.endMs.toFloat() / total * size.width
                drawRect(hues[i % hues.size].copy(alpha = 0.75f), Offset(x0, 6f), Size((x1 - x0).coerceAtLeast(2f), size.height - 12f))
                drawLine(Color.White, Offset(x0, 0f), Offset(x0, size.height), 3f)
                drawLine(Color.White, Offset(x1, 0f), Offset(x1, size.height), 3f)
            }
            val px = pb.positionMs.toFloat() / total * size.width
            drawLine(Color.Yellow, Offset(px, 0f), Offset(px, size.height), 2f)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = s.allowOverlap, onCheckedChange = { v -> vm.updateSettings { it.copy(allowOverlap = v) } })
            Text("  Allow overlapping cards (transitions)", Modifier.weight(1f))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = s.ripple, onCheckedChange = { v -> vm.updateSettings { it.copy(ripple = v) } })
            Text("  Move following cards when I change a card's end time", Modifier.weight(1f))
        }
        OutlinedButton(onClick = { vm.distribute() }, modifier = Modifier.fillMaxWidth()) { Text("Distribute cards evenly over ${Timing.fmt(if (s.audioDurMs > 0) s.audioDurMs else p.cards.size * 5000L)}") }
        issues.forEach { Text("⚠ ${it.text}", color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall) }

        p.cards.forEachIndexed { i, c ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Card ${i + 1}: ${c.headline.take(40)}", maxLines = 1)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TimeField("Start", c.startMs, { v -> vm.setTiming(c.id, v, null) }, Modifier.weight(1f))
                        TimeField("End", c.endMs, { v -> vm.setTiming(c.id, null, v) }, Modifier.weight(1f))
                    }
                    TimeField("Duration", c.endMs - c.startMs, { v -> vm.setDuration(c.id, v) }, Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("", Modifier.weight(1f))
                        TextButton(onClick = { vm.setTiming(c.id, pb.positionMs, null) }) { Text("Start = ▶") }
                        TextButton(onClick = { vm.setTiming(c.id, null, pb.positionMs) }) { Text("End = ▶") }
                        TextButton(onClick = { pb.seek(c.startMs) }) { Text("Go") }
                    }
                }
            }
        }
        Text("End of video", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
        DropdownField("Video ends at", listOf("End of voice-over", "End of last card", "Custom time"), s.endMode, { v -> vm.updateSettings { it.copy(endMode = v) } })
        if (s.endMode == 2) TimeField("Custom end", if (s.customEndMs > 0) s.customEndMs else total, { v -> vm.updateSettings { it.copy(customEndMs = v) } })
    }
}

// ---------------------------------------------------------------- style (branding + ticker)
@Composable
fun StyleTab(vm: MainViewModel, p: Project) {
    val s = p.settings
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importLogo(u) }
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        FramePreview(p, { p.cards.firstOrNull()?.let { it.startMs + 2500 } ?: 0L })
        Text("Channel branding", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFC107))
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(s.showLogo, { v -> vm.updateSettings { it.copy(showLogo = v) } }); Text("  Show logo on every card") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { pickLogo.launch(arrayOf("image/png", "image/webp")) }) { Text("Upload PNG logo") }
            if (s.logoPath != null) OutlinedButton(onClick = { vm.updateSettings { it.copy(logoPath = null) } }) { Text("Use default") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(s.showChannelName, { v -> vm.updateSettings { it.copy(showChannelName = v) } }); Text("  Show channel name") }
        RtlField("Channel name", s.channelName, { v -> vm.updateSettings { it.copy(channelName = v) } })
        SliderRow("Logo size", s.logoSize, 0.06f..0.4f, "${(s.logoSize * 100).toInt()}%") { v -> vm.updateSettings { it.copy(logoSize = v) } }
        SliderRow("Logo opacity", s.logoOpacity, 0.1f..1f, "${(s.logoOpacity * 100).toInt()}%") { v -> vm.updateSettings { it.copy(logoOpacity = v) } }
        Text("Logo position for all cards:")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Opt.logoPositions.indices.toList()) { i ->
                FilterChip(selected = false, onClick = { vm.mutate { pr -> pr.copy(cards = pr.cards.map { it.copy(logoPos = i) }) } }, label = { Text(Opt.logoPositions[i]) })
            }
        }

        Text("News ticker", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFC107))
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(s.tickerOn, { v -> vm.updateSettings { it.copy(tickerOn = v) } }); Text("  Show ticker") }
        RtlField("Ticker text (Urdu / English)", s.tickerText, { v -> vm.updateSettings { it.copy(tickerText = v) } }, minLines = 2)
        RtlField("Label", s.tickerLabel, { v -> vm.updateSettings { it.copy(tickerLabel = v) } })
        SliderRow("Scrolling speed", s.tickerSpeed, 30f..400f, "${s.tickerSpeed.toInt()} px/s") { v -> vm.updateSettings { it.copy(tickerSpeed = v) } }
        SliderRow("Font size", s.tickerSize, 0.6f..1.6f, "${(s.tickerSize * 100).toInt()}%") { v -> vm.updateSettings { it.copy(tickerSize = v) } }
        ColorRow("Ticker text colour", s.tickerColor) { v -> vm.updateSettings { it.copy(tickerColor = v) } }
        ColorRow("Ticker background", s.tickerBg) { v -> vm.updateSettings { it.copy(tickerBg = v) } }
        Text("Video format", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFC107))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(s.landscape, { vm.updateSettings { it.copy(landscape = true) } }, { Text("16:9 landscape") })
            FilterChip(!s.landscape, { vm.updateSettings { it.copy(landscape = false) } }, { Text("9:16 portrait") })
        }
    }
}

// ---------------------------------------------------------------- preview
@Composable
fun PreviewTab(vm: MainViewModel, p: Project) {
    val pb = vm.playback
    val total = Timing.totalMs(p)
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        FramePreview(p, { pb.positionMs })
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = {
                val prev = p.cards.lastOrNull { it.startMs < pb.positionMs - 500 }; pb.seek(prev?.startMs ?: 0L)
            }) { Icon(Icons.Default.SkipPrevious, "Previous card") }
            Button(onClick = { pb.toggle() }) { Icon(if (pb.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null); Text(if (pb.playing) " Pause" else " Play") }
            IconButton(onClick = {
                val nx = p.cards.firstOrNull { it.startMs > pb.positionMs + 10 }; if (nx != null) pb.seek(nx.startMs)
            }) { Icon(Icons.Default.SkipNext, "Next card") }
        }
        Text("${Timing.fmt(pb.positionMs)} / ${Timing.fmt(total)}")
        androidx.compose.material3.Slider(value = pb.positionMs.toFloat(), onValueChange = { pb.seek(it.toLong()) }, valueRange = 0f..total.toFloat().coerceAtLeast(1f))
        Text("Jump to a card", style = MaterialTheme.typography.titleSmall)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(p.cards.indices.toList()) { i -> FilterChip(selected = false, onClick = { pb.seek(p.cards[i].startMs) }, label = { Text("Card ${i + 1}") }) }
        }
        Text("Preview transitions", style = MaterialTheme.typography.titleSmall)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(p.cards.indices.toList().drop(1)) { i ->
                OutlinedButton(onClick = { pb.seek((p.cards[i].startMs - 1200).coerceAtLeast(0L)); pb.play() }) { Text("→ Card ${i + 1}") }
            }
        }
        Text("The preview uses the same renderer as the exported MP4 (ticker, logo, animations, transitions).", style = MaterialTheme.typography.bodySmall)
    }
}

// ---------------------------------------------------------------- export
@Composable
fun ExportTab(vm: MainViewModel, p: Project) {
    val ctx = LocalContext.current
    val st by vm.settings.collectAsState()
    val state by ExportState.state.collectAsState()
    var res by remember(st.resolution) { mutableStateOf(st.resolution) }
    var fps by remember(st.fps) { mutableStateOf(st.fps) }
    var quality by remember { mutableStateOf(1) }
    var aq by remember { mutableStateOf(1) }
    var name by remember(p.id) { mutableStateOf("ZCH_" + p.name.replace(Regex("[^\\p{L}\\p{N}]+"), "_")) }
    val land = p.settings.landscape
    val total = Timing.totalMs(p)
    val shortSide = res
    val longSide = if (res == 720) 1280 else 1920
    val w = if (land) longSide else shortSide
    val h = if (land) shortSide else longSide
    val baseBr = if (res == 720) intArrayOf(2_500_000, 4_000_000, 6_000_000) else intArrayOf(5_000_000, 8_000_000, 12_000_000)
    val vbr = (baseBr[quality] * fps / 30.0).toInt()
    val abr = intArrayOf(96_000, 128_000, 192_000)[aq]
    val legacyPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val begin = {
        vm.startExport(w, h, fps, vbr, abr, name, land, p.settings.endMode, p.settings.customEndMs)
    }
    val needLegacy = android.os.Build.VERSION.SDK_INT < 29
    val running = state is ExportUi.Running
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Export settings", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFC107))
        Text("Resolution")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(720, 1080).forEach { r -> FilterChip(res == r, { res = r }, { Text("${r}p") }) }
        }
        Text("Aspect ratio")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(land, { vm.updateSettings { it.copy(landscape = true) } }, { Text("16:9") })
            FilterChip(!land, { vm.updateSettings { it.copy(landscape = false) } }, { Text("9:16") })
        }
        Text("Frame rate")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(24, 25, 30).forEach { f -> FilterChip(fps == f, { fps = f }, { Text("$f fps") }) } }
        DropdownField("Video quality", listOf("Low (small file)", "Medium", "High"), quality, { quality = it })
        DropdownField("Audio quality", listOf("96 kbps", "128 kbps", "192 kbps"), aq, { aq = it })
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Output file name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("Output: ${w}×${h}, ${fps} fps, about ${(((vbr + abr) / 8.0) * total / 1000.0 / 1_000_000).let { "%.1f".format(it) }} MB, ${Timing.fmt(total)} long")
        if (total > 10 * 60_000L) Text("⚠ Long project: export may take a long time and a lot of storage.", color = Color(0xFFFFC107))
        if (res == 1080) Text("⚠ 1080p needs more time/memory on older phones. Use 720p if the export fails.", color = Color(0xFFFFC107), style = MaterialTheme.typography.bodySmall)
        if (p.cards.isEmpty()) Text("Add at least one card first.", color = Color(0xFFFF8A80))

        when (val s = state) {
            is ExportUi.Running -> {
                LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                Text("${(s.progress * 100).toInt()}%  ${s.msg}")
                Button(onClick = { vm.cancelExport() }) { Text("Cancel export") }
            }
            is ExportUi.Done -> {
                Text("✅ Export finished: Movies/ZCH NewsCard Studio", color = Color(0xFF69F0AE))
                Text("Find it in Recent Exports to play, share or delete.", style = MaterialTheme.typography.bodySmall)
            }
            is ExportUi.Failed -> Text("❌ Export failed: ${s.msg}", color = Color(0xFFFF8A80))
            ExportUi.Cancelled -> Text("Export cancelled.")
            ExportUi.Idle -> {}
        }
        if (p.exportStatus == "interrupted") Text("The previous export was interrupted. Start again to retry.", color = Color(0xFFFFC107))
        Button(enabled = !running && p.cards.isNotEmpty(), modifier = Modifier.fillMaxWidth(), onClick = {
            if (android.os.Build.VERSION.SDK_INT >= 33) notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            val ok = !needLegacy || androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (ok) begin() else {
                legacyPerm.launch(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE))
                vm.message = "Allow storage access, then press Export again"
            }
        }) { Text("Export MP4") }
        if (p.exports.isNotEmpty()) TextButton(onClick = { vm.go(Screen.Exports) }) { Text("Open Recent Exports") }
    }
}
