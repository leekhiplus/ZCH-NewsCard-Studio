package com.zafarcrickethub.zchnewscardstudio

import com.zafarcrickethub.zchnewscardstudio.utils.ScriptSplitter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScriptSplitterTest {
    @Test fun splitsUrduSentences() {
        val s = ScriptSplitter.sentences("پاکستان نے میچ جیت لیا۔ کپتان نے خوشی کا اظہار کیا۔ شائقین نے جشن منایا۔")
        assertEquals(3, s.size)
    }

    @Test fun decimalPointIsNotASentenceEnd() {
        val s = ScriptSplitter.sentences("Pakistan scored 182/4 in 17.3 overs. India replied.")
        assertEquals(2, s.size)
    }

    @Test fun groupsAllSentencesInOrder() {
        val text = (1..5).joinToString(" ") { "یہ جملہ نمبر $it ہے۔" }
        val plan = ScriptSplitter.plan(text, 2)
        assertEquals(2, plan.segs.size)
        assertEquals(text, plan.segs.joinToString(" ") { it.voice })
        assertTrue(plan.segs.all { it.headline.isNotBlank() })
    }

    @Test fun neverMoreCardsThanSentences() {
        assertEquals(2, ScriptSplitter.plan("پہلی خبر۔ دوسری خبر۔", 9).segs.size)
    }

    @Test fun detectsMatchScore() {
        val plan = ScriptSplitter.plan("پاکستان نے انگلینڈ کے خلاف 17.3 اوورز میں 182/4 اسکور کیا۔", 0)
        val seg = plan.segs.single()
        assertEquals("score", seg.kind)
        assertEquals("182/4", seg.score)
        assertEquals("4", seg.wickets)
        assertEquals("17.3", seg.overs)
        assertEquals("Pakistan", seg.team1)
        assertEquals("England", seg.team2)
    }

    @Test fun longSentenceBecomesHeadlineAndDescription() {
        val plan = ScriptSplitter.plan("ایک دو تین چار پانچ چھ سات آٹھ نو دس گیارہ بارہ تیرہ چودہ پندرہ۔", 0)
        val seg = plan.segs.single()
        assertTrue(seg.headline.endsWith("…"))
        assertTrue(seg.description.isNotBlank())
    }
}
