package com.zafarcrickethub.zchnewscardstudio.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LinearScale
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zafarcrickethub.zchnewscardstudio.audio.OboeRecorder
import com.zafarcrickethub.zchnewscardstudio.audio.VoicePauses
import com.zafarcrickethub.zchnewscardstudio.data.Opt
import com.zafarcrickethub.zchnewscardstudio.data.Overlay
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.data.pictures
import com.zafarcrickethub.zchnewscardstudio.graphics.Bmp
import com.zafarcrickethub.zchnewscardstudio.graphics.LottieSticker
import com.zafarcrickethub.zchnewscardstudio.graphics.VideoFrames
import com.zafarcrickethub.zchnewscardstudio.utils.CropPicture
import com.zafarcrickethub.zchnewscardstudio.utils.FFmpegHelper
import com.zafarcrickethub.zchnewscardstudio.utils.GeminiTts
import com.zafarcrickethub.zchnewscardstudio.utils.PhotoTools
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.zafarcrickethub.zchnewscardstudio.data.Card as NCard

// =====================================================================================
//  All the editing menus of the editor, InShot style:
//  a panel under the live preview = title + tick, a strip of tools (icon over label, scrolls sideways)
//  and the controls of the chosen tool. Every feature is the same as before; only the layout changed.
// =====================================================================================

private val Warn = Color(0xFFFF8A80)
private val Good = Color(0xFF69F0AE)

/** Opens the panel that belongs to `vm.sheet` (Canvas, Audio, Script, Sticker, Layer, Timing). */
@Composable
fun SheetPanel(vm: MainViewModel, p: Project) {
    val card = if (vm.sel.startsWith("card:")) p.cards.find { it.id == vm.sel.removePrefix("card:") } else null
    val ov = if (vm.sel.startsWith("ov:")) p.overlays.find { it.id == vm.sel.removePrefix("ov:") } else null
    when (vm.sheet) {
        "style" -> CanvasPanel(vm, p)
        "voice" -> AudioPanel(vm, p)
        "aiscript" -> ScriptPanel(vm, p)
        "sticker" -> StickerPanel(vm)
        "overlay" -> if (ov != null) OverlayPanel(vm, ov)
        "timing" -> if (card != null) CardTimePanel(vm, p, card) else TimelinePanel(vm, p)
        else -> LaunchedEffect(Unit) { vm.sheet = "" }
    }
}

// ------------------------------------------------------------------ Canvas & style
@Composable
private fun CanvasPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    var tool by remember { mutableStateOf("format") }
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importLogo(u) }
    val tools = listOf(
        PTool("format", "Format", Icons.Default.AspectRatio), pSep(),
        PTool("tstrip", "Strip", Icons.Default.Subtitles),
        PTool("ttext", "Text", Icons.Default.TextFields),
        PTool("tspeed", "Scroll", Icons.Default.Speed),
        PTool("tcol", "Colour", Icons.Default.FormatColorText),
        PTool("tbg", "Background", Icons.Default.FormatColorFill), pSep(),
        PTool("logo", "Logo", Icons.Default.Image),
        PTool("llook", "Logo look", Icons.Default.Tune),
        PTool("lpos", "Position", Icons.Default.OpenWith),
        PTool("chan", "Channel", Icons.Default.Title)
    )
    InShotPanel("Canvas & style", { vm.sheet = "" }, tools, tool, { tool = it }) {
        when (tool) {
            "format" -> {
                PChoice("Video format", listOf("16:9 landscape", "9:16 portrait"), if (s.landscape) 0 else 1) { i ->
                    vm.updateSettings { it.copy(landscape = i == 0) }
                }
                PHint("16:9 is for YouTube / TV, 9:16 is for Reels, Shorts and Status.")
            }
            "tstrip" -> {
                PSwitch("Show ticker strip", s.tickerOn) { v -> vm.updateSettings { it.copy(tickerOn = v) } }
                PChoice("Ticker style", listOf("TV strip", "Label box"), if (s.tickerStyle == 1) 0 else 1) { i ->
                    vm.updateSettings { it.copy(tickerStyle = if (i == 0) 1 else 0) }
                }
            }
            "ttext" -> {
                PField("Ticker text (Urdu / English)", s.tickerText, { v -> vm.updateSettings { it.copy(tickerText = v) } }, minLines = 2)
                PField("Label", s.tickerLabel, { v -> vm.updateSettings { it.copy(tickerLabel = v) } })
            }
            "tspeed" -> {
                PChoice("Scroll direction", listOf("Right to left", "Left to right"), if (s.tickerDir == 1) 1 else 0) { i ->
                    vm.updateSettings { it.copy(tickerDir = i) }
                }
                PSlider("Scrolling speed", s.tickerSpeed, 30f..400f, "${s.tickerSpeed.toInt()} px/s") { v -> vm.updateSettings { it.copy(tickerSpeed = v) } }
                PSlider("Font size", s.tickerSize, 0.6f..1.6f, "${(s.tickerSize * 100).toInt()}%") { v -> vm.updateSettings { it.copy(tickerSize = v) } }
            }
            "tcol" -> {
                PHint("Ticker text colour")
                PColors(s.tickerColor) { v -> vm.updateSettings { it.copy(tickerColor = v) } }
            }
            "tbg" -> {
                PHint("Ticker background colour")
                PColors(s.tickerBg) { v -> vm.updateSettings { it.copy(tickerBg = v) } }
            }
            "logo" -> {
                PSwitch("Show logo on every card", s.showLogo) { v -> vm.updateSettings { it.copy(showLogo = v) } }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    PButton("Upload PNG logo", { pickLogo.launch(arrayOf("image/png", "image/webp")) }, primary = true)
                    if (s.logoPath != null) PButton("Use default", { vm.updateSettings { it.copy(logoPath = null) } })
                }
            }
            "llook" -> {
                PSlider("Logo size", s.logoSize, 0.06f..0.4f, "${(s.logoSize * 100).toInt()}%") { v -> vm.updateSettings { it.copy(logoSize = v) } }
                PSlider("Logo opacity", s.logoOpacity, 0.1f..1f, "${(s.logoOpacity * 100).toInt()}%") { v -> vm.updateSettings { it.copy(logoOpacity = v) } }
            }
            "lpos" -> {
                val common = p.cards.map { it.logoPos }.distinct().singleOrNull() ?: -1
                PChoice("Logo position for all cards", Opt.logoPositions, common) { i ->
                    vm.mutate { pr -> pr.copy(cards = pr.cards.map { it.copy(logoPos = i) }) }
                }
            }
            "chan" -> {
                PSwitch("Show channel name", s.showChannelName) { v -> vm.updateSettings { it.copy(showChannelName = v) } }
                PField("Channel name", s.channelName, { v -> vm.updateSettings { it.copy(channelName = v) } })
            }
            else -> {}
        }
    }
}

// ------------------------------------------------------------------ Audio / voice-over
@Composable
private fun AudioPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    val st by vm.settings.collectAsState()
    var tool by remember { mutableStateOf("audio") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importAudio(u) }
    val ctx = LocalContext.current
    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.startRecording() else vm.message = "Allow the microphone to record a voice-over"
    }
    // "Split" tool: pause length, keep-my-cards switch and design of the new cards
    val pauseLabels = listOf("0.2 s", "0.3 s", "0.4 s", "0.6 s", "0.8 s", "1.2 s", "2 s")
    val pauseValues = listOf(200L, 300L, 400L, 600L, 800L, 1200L, 2000L)
    var pauseIdx by remember { mutableStateOf(2) }
    val hasCards = p.cards.isNotEmpty()
    var keepCards by remember { mutableStateOf(true) }
    var designIdx by remember(hasCards) { mutableStateOf(0) }
    LaunchedEffect(tool, s.audioPath) { if (tool == "split" && s.audioPath != null) vm.analysePauses() }
    val tools = listOf(
        PTool("audio", "Audio", Icons.Default.MusicNote),
        PTool("rec", "Record", Icons.Default.Mic),
        PTool("split", "Split", Icons.Default.ContentCut),
        PTool("vol", "Volume", Icons.Default.VolumeUp), pSep(),
        PTool("key", "Key", Icons.Default.VpnKey),
        PTool("model", "Model", Icons.Default.Tune),
        PTool("voice", "Voice", Icons.Default.RecordVoiceOver),
        PTool("vscript", "Script", Icons.Default.Notes),
        PTool("make", "Create", Icons.Default.AutoAwesome)
    )
    InShotPanel("Audio and voice-over", { vm.sheet = "" }, tools, tool, { tool = it }) {
        when (tool) {
            "audio" -> {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    PButton(if (s.audioPath == null) "Import audio" else "Replace audio", { pick.launch(arrayOf("audio/*")) }, icon = Icons.Default.MusicNote, primary = true)
                    if (s.audioPath != null) PButton("Remove", { vm.removeAudio() })
                }
                if (s.audioPath != null) PHint("Length: ${Timing.fmt(s.audioDurMs)}")
                else PHint("MP3, WAV, M4A or AAC. Without audio the video ends at the last card.")
                if (s.audioPath != null && FFmpegHelper.available) {
                    PButton(
                        if (vm.cleaning) "Cleaning..." else "Clean voice (noise + loudness)", { vm.cleanVoice() },
                        icon = Icons.Default.AutoAwesome, enabled = !vm.cleaning
                    )
                    PHint("Removes rumble and steady background noise and levels the volume (FFmpeg). Makes a new copy; Undo brings the old audio back.")
                }
            }
            "rec" -> {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    PButton(
                        if (vm.recording) "Stop and use" else "Record voice-over",
                        {
                            if (vm.recording) vm.stopRecording()
                            else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.startRecording()
                            else askMic.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        icon = Icons.Default.Mic, primary = true
                    )
                    if (vm.recording) Text("\u25CF ${Timing.fmt(vm.recMs)}", color = Warn, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                if (vm.recording) Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(PanelChip)) {
                    Box(Modifier.fillMaxWidth(vm.recLevel.coerceIn(0.02f, 1f)).height(8.dp).background(Good))
                }
                val eng = if (vm.recording) vm.recorder.engine else if (OboeRecorder.nativeAvailable) "Oboe, low latency" else "Android AudioRecord"
                PHint("Records from the microphone ($eng) and uses it as the project's voice-over, replacing the current audio. Speak close to the phone in a quiet room, then use Clean voice in the Audio tool.")
            }
            "split" -> {
                PButton(
                    if (s.audioPath == null) "Upload voice-over file" else "Replace voice-over file", { pick.launch(arrayOf("audio/*")) },
                    icon = Icons.Default.MusicNote, primary = s.audioPath == null
                )
                if (s.audioPath == null) {
                    PHint("Upload the voice-over (MP3, WAV, M4A or AAC). The app finds the pauses between the sentences and makes one card for every spoken part, each card timed to its part of the voice.")
                } else {
                    val pauses = vm.pausesFor(s.audioPath)
                    if (pauses == null) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (vm.splitBusy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
                            Text(if (vm.splitBusy) "Listening for pauses..." else "The voice-over has not been analysed yet.", color = Color.White, fontSize = 13.sp)
                        }
                        if (!vm.splitBusy) PButton("Find pauses", { vm.analysePauses(true) }, icon = Icons.Default.AutoAwesome, primary = true)
                    } else {
                        PChoice("Count a pause when it lasts at least", pauseLabels, pauseIdx) { pauseIdx = it }
                        val minPause = pauseValues[pauseIdx]
                        val cuts = remember(pauses, pauseIdx, s.audioDurMs) { VoicePauses.cuts(pauses, minPause, s.audioDurMs) }
                        val parts = cuts.size + 1
                        val avgSec = if (parts > 0) s.audioDurMs / parts / 1000f else 0f
                        if (cuts.isEmpty()) {
                            PHint("No pause of ${pauseLabels[pauseIdx]} or longer was found. Choose a shorter pause. (A noisy recording or music under the voice hides the pauses.)", Warn)
                        } else {
                            PHint("Pauses used: ${cuts.size}  \u2192  cards: $parts  (about ${"%.1f".format(avgSec)} s each)", GoldC)
                        }
                        if (hasCards) {
                            PSwitch("Keep my ${p.cards.size} cards (text and design), only set their times", keepCards) { keepCards = it }
                            if (keepCards && p.cards.size > parts) {
                                PHint("You have ${p.cards.size} cards but only $parts parts. Choose a shorter pause, or switch this off.", Warn)
                            } else if (!keepCards) {
                                PHint("All current cards are replaced by the new ones (Undo brings them back).")
                            }
                        }
                        val designOpts = (if (hasCards) listOf("Same as my last card") else emptyList()) + Opt.templates
                        if (!hasCards || !keepCards || p.cards.size < parts) {
                            PChoice("Design of the new cards", designOpts, designIdx) { designIdx = it }
                        }
                        PButton(
                            "Make $parts cards from the pauses",
                            {
                                vm.splitCardsFromVoice(minPause, if (hasCards) designIdx - 1 else designIdx, keepCards && hasCards)
                                vm.sheet = ""
                            },
                            Modifier.fillMaxWidth(), icon = Icons.Default.ContentCut, primary = true,
                            enabled = cuts.isNotEmpty() && !(hasCards && keepCards && p.cards.size > parts)
                        )
                        PHint("The cards get the text \"Card 1, Card 2 ...\" (or keep your own text); write the real text in each card afterwards. The card changes just before the next sentence starts.")
                    }
                }
            }
            "vol" -> {
                if (s.audioPath != null) PSlider("Volume", s.volume, 0f..2f, "${(s.volume * 100).toInt()}%") { vm.setVolume(it) }
                else PHint("Import an audio file first (Audio tool), then change its volume here.")
            }
            "key" -> PGeminiKey(vm)
            "model" -> PGeminiModel(vm)
            "voice" -> {
                PGeminiVoice(vm)
                PField("Speaking style (optional)", vm.ttsStyle, { vm.ttsStyle = it }, placeholder = "e.g. Read like a calm Urdu news anchor")
            }
            "vscript" -> {
                PField("Voice-over script (Urdu / English)", vm.ttsScript, { vm.ttsScript = it }, minLines = 5)
                PButton("Fill from cards", { vm.scriptFromCards() })
            }
            "make" -> {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    PButton(
                        if (vm.ttsBusy) "Generating..." else "Generate voice-over", { vm.generateVoice() },
                        icon = Icons.Default.Mic, enabled = !vm.ttsBusy, primary = true
                    )
                    if (vm.ttsBusy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                }
                if (st.geminiKey.isBlank()) PHint("Add your Google key first (Key tool).", GoldC)
                PHint(
                    "The script is sent to Google with your own key; the result is saved as the project's voice-over (replacing the current one). " +
                        "Urdu (ur-PK) is a preview language in Gemini TTS, so listen to the result. Everything else in the app stays offline."
                )
            }
            else -> {}
        }
    }
}

@Composable
private fun PGeminiKey(vm: MainViewModel) {
    val st by vm.settings.collectAsState()
    val clip = LocalClipboardManager.current
    PField(
        "Google AI Studio API key", st.geminiKey, { v -> vm.updateAppSettings { s -> s.copy(geminiKey = v.trim()) } },
        password = true, hint = "Create a free key at aistudio.google.com/apikey and paste it here."
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        PButton("Paste key", {
            val t = clip.getText()?.text?.trim()
            if (t.isNullOrBlank()) vm.message = "Clipboard is empty" else vm.updateAppSettings { s -> s.copy(geminiKey = t) }
        }, icon = Icons.Default.ContentPaste)
        if (st.geminiKey.isNotBlank()) PButton("Remove key", { vm.updateAppSettings { s -> s.copy(geminiKey = "", geminiModels = "") } })
    }
    PHint("The key stays on this phone and is used only for the voice-over.")
}

@Composable
private fun PGeminiModel(vm: MainViewModel) {
    val st by vm.settings.collectAsState()
    val ids = vm.modelList()
    PChoice("Voice model", ids.map { GeminiTts.label(it) }, ids.indexOf(st.geminiModel).coerceAtLeast(0)) { i ->
        vm.updateAppSettings { s -> s.copy(geminiModel = ids[i]) }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        PButton(
            if (vm.modelsBusy) "Loading..." else "Load models for my key", { vm.loadModels() },
            icon = Icons.Default.Refresh, enabled = !vm.modelsBusy && st.geminiKey.isNotBlank()
        )
        if (vm.modelsBusy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
    }
    PHint("This also checks that your key works. Pick a model from the list; nothing has to be typed.")
}

@Composable
private fun PGeminiVoice(vm: MainViewModel) {
    val st by vm.settings.collectAsState()
    PChoice("Voice", GeminiTts.voices, GeminiTts.voices.indexOf(st.geminiVoice).coerceAtLeast(0)) { i ->
        vm.updateAppSettings { s -> s.copy(geminiVoice = GeminiTts.voices[i]) }
    }
}

/** Google AI Studio key (paste), voice model (pick from a list) and voice. Used in Settings (normal look). */
@Composable
fun GeminiKeyFields(vm: MainViewModel) {
    val st by vm.settings.collectAsState()
    val clip = LocalClipboardManager.current
    PopupField(
        "Google AI Studio API key", st.geminiKey, { v -> vm.updateAppSettings { s -> s.copy(geminiKey = v.trim()) } },
        password = true, hint = "Create a free key at aistudio.google.com/apikey and paste it here."
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = {
            val t = clip.getText()?.text?.trim()
            if (t.isNullOrBlank()) vm.message = "Clipboard is empty" else vm.updateAppSettings { s -> s.copy(geminiKey = t) }
        }) { Icon(Icons.Default.ContentPaste, null, Modifier.size(18.dp)); Text("  Paste key") }
        if (st.geminiKey.isNotBlank()) TextButton(onClick = { vm.updateAppSettings { s -> s.copy(geminiKey = "", geminiModels = "") } }) { Text("Remove key") }
    }
    Text("The key stays on this phone and is used only for the voice-over.", style = MaterialTheme.typography.bodySmall)
    val ids = vm.modelList()
    DropdownField("Voice model", ids.map { GeminiTts.label(it) }, ids.indexOf(st.geminiModel).coerceAtLeast(0), { i -> vm.updateAppSettings { s -> s.copy(geminiModel = ids[i]) } })
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { vm.loadModels() }, enabled = !vm.modelsBusy && st.geminiKey.isNotBlank()) {
            Icon(Icons.Default.Refresh, null, Modifier.size(18.dp)); Text(if (vm.modelsBusy) "  Loading…" else "  Load models for my key")
        }
        if (vm.modelsBusy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
    }
    Text("This also checks that your key works. Pick a model from the list; nothing has to be typed.", style = MaterialTheme.typography.bodySmall)
    DropdownField("Voice", GeminiTts.voices, GeminiTts.voices.indexOf(st.geminiVoice).coerceAtLeast(0), { i -> vm.updateAppSettings { s -> s.copy(geminiVoice = GeminiTts.voices[i]) } })
}

// ------------------------------------------------------------------ Script -> cards
@Composable
private fun ScriptPanel(vm: MainViewModel, p: Project) {
    val st by vm.settings.collectAsState()
    val clip = LocalClipboardManager.current
    var tool by remember { mutableStateOf("script") }
    var maxCards by remember { mutableStateOf(0f) }
    var tplMode by remember { mutableStateOf(0) }
    var single by remember { mutableStateOf(13) }
    var replace by remember { mutableStateOf(true) }
    var withVoice by remember { mutableStateOf(true) }
    var withTicker by remember { mutableStateOf(true) }
    var spread by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    val tplArg = when (tplMode) { 0 -> -1; 1 -> -2; 2 -> -3; else -> single }
    val tools = listOf(
        PTool("script", "Script", Icons.Default.Notes),
        PTool("cards", "Cards", Icons.Default.Layers),
        PTool("design", "Design", Icons.Default.Dashboard),
        PTool("opts", "Options", Icons.Default.Tune),
        PTool("voice", "Voice", Icons.Default.RecordVoiceOver)
    )
    InShotPanel(
        "Script to cards", { vm.sheet = "" }, tools, tool, { tool = it },
        action = {
            if (vm.aiBusy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
            PButton(
                if (vm.aiBusy) "Working..." else "Create cards",
                { vm.generateFromScript(maxCards.toInt(), tplArg, replace, withVoice, withTicker, spread) },
                icon = Icons.Default.AutoAwesome, enabled = !vm.aiBusy, primary = true
            )
        }
    ) {
        when (tool) {
            "script" -> {
                PHint("1. Paste the full news script.  2. Cards are made on your phone (offline, instantly).  3. The voice-over is optional (Google key).  4. You set each card's time with the play-head.")
                PField("News script (Urdu / English)", vm.aiScript, { vm.aiScript = it }, minLines = 8)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    PButton("Paste script", {
                        val t = clip.getText()?.text
                        if (t.isNullOrBlank()) vm.message = "Clipboard is empty" else vm.aiScript = t
                    }, icon = Icons.Default.ContentPaste)
                    if (vm.aiScript.isNotBlank()) PButton("Clear", { vm.aiScript = "" })
                }
                if (vm.aiStatus.isNotBlank()) PHint(vm.aiStatus, GoldC)
            }
            "cards" -> {
                PSlider("Number of cards", maxCards, 0f..12f, if (maxCards.toInt() == 0) "Auto" else "${maxCards.toInt()}") { maxCards = it }
                PSwitch("Replace the cards I already have", replace) { replace = it }
                if (vm.aiStatus.isNotBlank()) PHint(vm.aiStatus, GoldC)
            }
            "design" -> {
                PChoice(
                    "Templates", listOf("Best for each part (auto)", "TV news style (new 10)", "Classic designs", "One template for all"), tplMode
                ) { tplMode = it }
                if (tplMode == 3) PChoice("Template", Opt.templates, single) { single = it }
            }
            "opts" -> {
                PSwitch("Make the ticker text from the headlines", withTicker) { withTicker = it }
                PHint(
                    "Cards are made offline from your script: each card gets a headline and a short description, the ticker is made from the headlines. " +
                        "Add pictures to each card and set the card times to match the voice-over."
                )
            }
            "voice" -> {
                PSwitch("Also create the voice-over", withVoice) { withVoice = it }
                if (withVoice) {
                    if (st.geminiKey.isBlank() || showKey) {
                        PGeminiKey(vm); PGeminiModel(vm); PGeminiVoice(vm)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Google key saved (voice model: ${GeminiTts.label(st.geminiModel)})", Modifier.weight(1f), color = Good, fontSize = 13.sp)
                            PButton("Change", { showKey = true })
                        }
                    }
                    PField("Speaking style (optional)", vm.ttsStyle, { vm.ttsStyle = it }, placeholder = "e.g. Read like a calm Urdu news anchor")
                    PSwitch("Spread the cards evenly over the voice-over (starting point)", spread) { spread = it }
                    PHint("Only the optional voice-over is sent to Google (with your own key).")
                }
            }
            else -> {}
        }
    }
}

// ------------------------------------------------------------------ Stickers
@Composable
private fun StickerPanel(vm: MainViewModel) {
    val ctx = LocalContext.current
    val anims = remember { LottieSticker.builtIn(ctx) }
    val pickLottie = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importLottieSticker(u) }
    InShotPanel("Stickers", { vm.sheet = "" }, listOf(PTool("st", "Stickers", Icons.Default.EmojiEmotions)), "st", { }) {
        if (anims.isNotEmpty()) {
            PHint("Animated stickers", GoldC)
            PChips(anims.map { it.replace('_', ' ') }, -1) { i -> vm.addOverlay(1, LottieSticker.PREFIX + anims[i]); vm.sheet = "overlay" }
        }
        PButton("Import Lottie animation (.json)", { pickLottie.launch(arrayOf("application/json", "application/octet-stream", "text/plain", "*/*")) }, icon = Icons.Default.AddCircle)
        PHint("Emoji stickers", GoldC)
        Opt.stickers.chunked(8).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { e -> Text(e, fontSize = 30.sp, modifier = Modifier.clickable { vm.addOverlay(1, e); vm.sheet = "overlay" }.padding(6.dp)) }
            }
        }
    }
}

// ------------------------------------------------------------------ Layer (text / sticker / picture)
@Composable
private fun OverlayPanel(vm: MainViewModel, o: Overlay) {
    val id = o.id
    val ctx = LocalContext.current
    val anims = remember { LottieSticker.builtIn(ctx) }
    var tool by remember(id) { mutableStateOf(when (o.type) { 0 -> "text"; 1 -> "sticker"; else -> "size" }) }
    val first: List<PTool> = when (o.type) {
        0 -> listOf(
            PTool("text", "Text", Icons.Default.TextFields),
            PTool("ocol", "Colour", Icons.Default.FormatColorText),
            PTool("plate", "Plate", Icons.Default.FormatColorFill), pSep()
        )
        1 -> listOf(PTool("sticker", "Sticker", Icons.Default.EmojiEmotions), pSep())
        else -> emptyList()
    }
    val tools = first + listOf(
        PTool("size", "Size", Icons.Default.FormatSize),
        PTool("rot", "Rotate", Icons.Default.RotateRight),
        PTool("move", "Move", Icons.Default.OpenWith),
        PTool("time", "Time", Icons.Default.Timer),
        PTool("anim", "Animation", Icons.Default.Animation)
    )
    InShotPanel("Edit " + Opt.overlayTypes[o.type].lowercase(), { vm.sheet = "" }, tools, tool, { tool = it }) {
        when (tool) {
            "text" -> PField("Text", o.text, { v -> vm.updateOverlay(id) { it.copy(text = v) } }, minLines = 2)
            "sticker" -> {
                if (anims.isNotEmpty()) {
                    PHint("Animated stickers", GoldC)
                    PChips(anims.map { it.replace('_', ' ') }, anims.indexOf(LottieSticker.label(o.text)).takeIf { LottieSticker.isLottie(o.text) && o.imagePath == null } ?: -1) { i ->
                        vm.updateOverlay(id) { it.copy(text = LottieSticker.PREFIX + anims[i], imagePath = null) }
                    }
                    PHint("Emoji stickers", GoldC)
                }
                Opt.stickers.chunked(8).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        row.forEach { e -> Text(e, fontSize = 26.sp, modifier = Modifier.clickable { vm.updateOverlay(id) { it.copy(text = e, imagePath = null) } }.padding(4.dp)) }
                    }
                }
            }
            "ocol" -> {
                PHint("Text colour")
                PColors(o.color) { v -> vm.updateOverlay(id) { it.copy(color = v) } }
            }
            "plate" -> {
                val plates = listOf(0, 0xCC0A1A3F.toInt(), 0xCCD90429.toInt(), 0xCCFFC107.toInt(), 0xCC000000.toInt(), 0xCCFFFFFF.toInt())
                PChoice("Plate behind the text", listOf("None", "Navy", "Red", "Gold", "Black", "White"), plates.indexOf(o.bg).coerceAtLeast(0)) { i ->
                    vm.updateOverlay(id) { it.copy(bg = plates[i]) }
                }
            }
            "size" -> {
                if (o.type == 2) PHint("Picture layer. Move it on the preview with your finger, change the size here.")
                PSlider("Size", o.size, 0.3f..3f, "${(o.size * 100).toInt()}%") { v -> vm.updateOverlay(id) { it.copy(size = v) } }
            }
            "rot" -> PSlider("Rotation", o.rot, -180f..180f, "${o.rot.toInt()} deg") { v -> vm.updateOverlay(id) { it.copy(rot = v) } }
            "move" -> {
                PSlider("Horizontal", o.x, 0f..1f, "${(o.x * 100).toInt()}%") { v -> vm.updateOverlay(id) { it.copy(x = v) } }
                PSlider("Vertical", o.y, 0f..1f, "${(o.y * 100).toInt()}%") { v -> vm.updateOverlay(id) { it.copy(y = v) } }
                PHint("You can also drag the layer on the preview.")
            }
            "time" -> {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PTime("Start", o.startMs, { v -> vm.updateOverlay(id) { it.copy(startMs = v.coerceIn(0L, it.endMs - 300)) } }, Modifier.weight(1f))
                    PTime("End", o.endMs, { v -> vm.updateOverlay(id) { it.copy(endMs = maxOf(v, it.startMs + 300)) } }, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PButton("Start = play-head", { vm.trimOverlay(id, false, vm.playback.positionMs) }, Modifier.weight(1f))
                    PButton("End = play-head", { vm.trimOverlay(id, true, vm.playback.positionMs) }, Modifier.weight(1f))
                }
            }
            "anim" -> {
                PChoice("Enter animation", Opt.textAnims, o.anim) { v -> vm.updateOverlay(id) { it.copy(anim = v) } }
                PChoice("Exit animation", listOf("None") + Opt.textAnims, o.exit) { v -> vm.updateOverlay(id) { it.copy(exit = v) } }
            }
            else -> {}
        }
    }
}

// ------------------------------------------------------------------ Time of one card / of the whole video
private fun cardTimeTools() = listOf(
    PTool("time", "Time", Icons.Default.Timer),
    PTool("set", "Set", Icons.Default.Tune),
    PTool("order", "Order", Icons.Default.Sort)
)

@Composable
private fun CardTimePanel(vm: MainViewModel, p: Project, c: NCard) {
    var tool by remember { mutableStateOf("time") }
    val idx = p.cards.indexOfFirst { it.id == c.id }
    InShotPanel("Card ${idx + 1} time", { vm.sheet = "" }, cardTimeTools(), tool, { tool = it }) {
        CardTimeBody(vm, p, c, tool)
    }
}

/** The controls of the card-time tools: "time" (start / end / duration), "set" (play-head, nudge), "order". */
@Composable
private fun CardTimeBody(vm: MainViewModel, p: Project, c: NCard, part: String) {
    val id = c.id
    val dur = (c.endMs - c.startMs).coerceAtLeast(1L)
    val idx = p.cards.indexOfFirst { it.id == id }
    when (part) {
        "time" -> {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PTime("Start", c.startMs, { v -> vm.setTiming(id, v, null) }, Modifier.weight(1f))
                PTime("End", c.endMs, { v -> vm.setTiming(id, null, v) }, Modifier.weight(1f))
                PTime("Duration", dur, { v -> vm.setDuration(id, v) }, Modifier.weight(1f))
            }
            PHint("Tap a box and type a value. Examples: 5   12.5   1:05   0:01:05.250")
            Timing.validate(p.cards, p.settings.audioDurMs, p.settings.allowOverlap).filter { it.index == idx }.forEach {
                PHint("Warning: ${it.text}", Warn)
            }
        }
        "set" -> {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PButton("Start = play-head", { vm.setTiming(id, vm.playback.positionMs, null) }, Modifier.weight(1f))
                PButton("End = play-head", { vm.setTiming(id, null, vm.playback.positionMs) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PButton("Start -0.5s", { vm.nudge(id, -500, 0) }, Modifier.weight(1f))
                PButton("Start +0.5s", { vm.nudge(id, 500, 0) }, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PButton("End -0.5s", { vm.nudge(id, 0, -500) }, Modifier.weight(1f))
                PButton("End +0.5s", { vm.nudge(id, 0, 500) }, Modifier.weight(1f))
            }
            if (idx > 0) PButton("Start right after previous card", { vm.startAfterPrevious(id) }, Modifier.fillMaxWidth())
        }
        else -> {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PButton("Move earlier", { vm.moveCard(id, -1) }, Modifier.weight(1f), enabled = idx > 0)
                PButton("Move later", { vm.moveCard(id, 1) }, Modifier.weight(1f), enabled = idx < p.cards.size - 1)
            }
            PSwitch("Move the following cards when I change the end time", p.settings.ripple) { v -> vm.updateSettings { it.copy(ripple = v) } }
        }
    }
}

@Composable
private fun TimelinePanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    val total = Timing.totalMs(p)
    var tool by remember { mutableStateOf("rules") }
    val tools = listOf(
        PTool("rules", "Rules", Icons.Default.Tune),
        PTool("spread", "Spread", Icons.Default.LinearScale),
        PTool("end", "End", Icons.Default.Flag),
        PTool("cards", "All cards", Icons.Default.Layers)
    )
    InShotPanel("Timing", { vm.sheet = "" }, tools, tool, { tool = it }) {
        when (tool) {
            "rules" -> {
                PSwitch("Allow overlapping cards (transitions)", s.allowOverlap) { v -> vm.updateSettings { it.copy(allowOverlap = v) } }
                PSwitch("Move following cards when I change a card's end time", s.ripple) { v -> vm.updateSettings { it.copy(ripple = v) } }
                Timing.validate(p.cards, s.audioDurMs, s.allowOverlap).forEach { PHint("Warning: ${it.text}", Warn) }
            }
            "spread" -> {
                PButton(
                    "Distribute cards evenly over ${Timing.fmt(if (s.audioDurMs > 0) s.audioDurMs else p.cards.size * 5000L)}",
                    { vm.distribute() }, Modifier.fillMaxWidth(), primary = true
                )
                PHint("Gives every card the same length. You can fine tune each card afterwards (All cards).")
                if (s.audioPath != null && p.cards.size > 1) {
                    PButton(
                        if (vm.autoTiming) "Listening to the voice-over..." else "Auto-time cards from voice pauses", { vm.autoTimeFromVoice() },
                        Modifier.fillMaxWidth(), icon = Icons.Default.AutoAwesome, enabled = !vm.autoTiming
                    )
                    PHint("Finds the pauses between sentences in the voice-over (TarsosDSP) and starts every card after one. Best when the voice-over has a short pause between the cards.")
                }
            }
            "end" -> {
                PChoice("Video ends at", listOf("End of voice-over", "End of last card", "Custom time"), s.endMode) { v ->
                    vm.updateSettings { it.copy(endMode = v) }
                }
                if (s.endMode == 2) PTime(
                    "Custom end", if (s.customEndMs > 0) s.customEndMs else total,
                    { v -> vm.updateSettings { it.copy(customEndMs = v) } }, Modifier.fillMaxWidth()
                )
            }
            "cards" -> {
                p.cards.forEachIndexed { i, c ->
                    PHint("Card ${i + 1}: ${c.headline.take(40)}", GoldC)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PTime("Start", c.startMs, { v -> vm.setTiming(c.id, v, null) }, Modifier.weight(1f))
                        PTime("End", c.endMs, { v -> vm.setTiming(c.id, null, v) }, Modifier.weight(1f))
                        PTime("Duration", c.endMs - c.startMs, { v -> vm.setDuration(c.id, v) }, Modifier.weight(1f))
                    }
                }
            }
            else -> {}
        }
    }
}

// ------------------------------------------------------------------ Card editor
@Composable
private fun PathThumb(path: String, modifier: Modifier = Modifier) {
    val vid = VideoFrames.isVideo(path)
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.Default) {
            (if (vid) VideoFrames.frameSync(path, 300L, 300) else Bmp.load(path, 300))?.asImageBitmap()
        }
    }
    val len by produceState(0L, path) { value = if (vid) withContext(Dispatchers.Default) { VideoFrames.durationMs(path) } else 0L }
    Box(modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF1B2A55)), contentAlignment = Alignment.Center) {
        bmp?.let { androidx.compose.foundation.Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        if (vid) {
            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp).background(Color(0x99000000), CircleShape))
            if (len > 0L) Text(
                "VIDEO " + Timing.fmt(len).substringBefore('.'), color = Color.White, fontSize = 10.sp,
                modifier = Modifier.align(Alignment.TopStart).background(Color(0xAA000000)).padding(horizontal = 4.dp)
            )
        }
    }
}

/** Card editor: live preview on top, the InShot-style tool panel underneath. */
@Composable
fun CardEditor(vm: MainViewModel, p: Project, id: String) {
    val c = p.cards.find { it.id == id } ?: run { vm.editingCard = null; return }
    val dur = (c.endMs - c.startMs).coerceAtLeast(1L)
    var t by remember { mutableStateOf(dur.toFloat()) }
    var anim by remember { mutableStateOf(false) }
    LaunchedEffect(anim, c.id) {
        if (anim) {
            var last = withFrameNanos { it }
            t = 0f
            while (anim) {
                val now = withFrameNanos { it }
                t += (now - last) / 1_000_000f; last = now
                if (t > dur) { t = dur.toFloat(); anim = false }
            }
        }
    }
    val solo = remember(p, c) { p.copy(cards = listOf(c.copy(startMs = 0, endMs = dur)), overlays = emptyList()) }
    val idx = p.cards.indexOfFirst { it.id == id }
    val tpl = c.template
    val pics = c.pictures()
    val cropLauncher = rememberLauncherForActivityResult(CropPicture()) { u -> vm.onCropResult(u) }
    val slots = Opt.extraSlots(tpl)
    val cmpTpl = tpl in Opt.compare
    val matchTpl = cmpTpl || tpl in listOf(2, 5, 6, 9, 11, 16, 17)
    var tool by remember(id) {
        mutableStateOf(when (vm.cardTab) { 1 -> "pics"; 2 -> "tcol"; 3 -> "tanim"; 4 -> "time"; 5 -> "cvoice"; else -> "text" })
    }
    // states of the script / voice tools (kept here so they survive switching tools)
    var sameDesign by remember { mutableStateOf(true) }
    var replace by remember { mutableStateOf(false) }
    var fit by remember { mutableStateOf(true) }
    var vtext by remember(id) { mutableStateOf("") }

    val tools = buildList<PTool> {
        add(PTool("tpl", "Template", Icons.Default.Dashboard))
        add(PTool("text", "Text", Icons.Default.Edit))
        if (matchTpl) add(PTool("match", if (cmpTpl) "Players" else "Match", Icons.Default.Flag))
        add(PTool("size", "Size", Icons.Default.FormatSize))
        add(PTool("ticker", "Ticker", Icons.Default.Subtitles))
        add(pSep())
        add(PTool("pics", if (cmpTpl) "Player 1 pic" else "Media", Icons.Default.Image))
        if (pics.isNotEmpty()) add(PTool("crop", "Crop", Icons.Default.Crop))
        if (pics.size > 1) add(PTool("slides", "Slides", Icons.Default.Slideshow))
        if (slots > 0) add(PTool("extras", if (cmpTpl) "Player 2 pic" else "Extras", Icons.Default.AddPhotoAlternate))
        add(pSep())
        add(PTool("tcol", "Colour", Icons.Default.FormatColorText))
        add(PTool("tbg", "Tint", Icons.Default.FormatColorFill))
        add(PTool("logo", "Logo", Icons.Default.Star))
        add(pSep())
        add(PTool("tanim", "Text anim", Icons.Default.Animation))
        add(PTool("ianim", "Image anim", Icons.Default.Movie))
        add(PTool("loop", "Loop", Icons.Default.Loop))
        add(PTool("trans", "Transition", Icons.Default.SwapHoriz))
        add(PTool("speed", "Speed", Icons.Default.Speed))
        add(pSep())
        add(PTool("time", "Time", Icons.Default.Timer))
        add(PTool("set", "Set", Icons.Default.Tune))
        add(PTool("order", "Order", Icons.Default.Sort))
        add(pSep())
        add(PTool("cscript", "Script", Icons.Default.AutoAwesome))
        add(PTool("cvoice", "Voice", Icons.Default.Mic))
    }
    val cur = if (tools.any { it.icon != null && it.key == tool }) tool else tools.first().key

    Column(Modifier.fillMaxSize().background(EditorBg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.editingCard = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            Text(
                "Card ${idx + 1} of ${p.cards.size}", color = Color.White, fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
            )
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp), contentAlignment = Alignment.Center) {
            FitPreview(solo, { t.toLong() }, Modifier.fillMaxSize())
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { anim = true }) { Icon(Icons.Default.PlayArrow, "Play animation", tint = GoldC) }
            Slider(
                value = t, onValueChange = { anim = false; t = it }, valueRange = 0f..dur.toFloat(), modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = GoldC, activeTrackColor = GoldC, inactiveTrackColor = Color(0xFF5A5A5A))
            )
        }
        InShotPanel("Edit card", { vm.editingCard = null }, tools, cur, { tool = it }) {
            when (cur) {
                "tpl" -> PChoice("Template", Opt.templates, tpl) { v -> vm.updateCard(id) { it.copy(template = v) } }
                "text" -> {
                    PField("Headline (Urdu / English)", c.headline, { v -> vm.updateCard(id) { it.copy(headline = v) } }, minLines = 2)
                    if (tpl !in listOf(2, 5, 9, 11) && !cmpTpl) {
                        PField(
                            if (tpl == 22) "Kicker (small label above the bar)" else "Description", c.description,
                            { v -> vm.updateCard(id) { it.copy(description = v) } }, minLines = 2
                        )
                    }
                }
                "match" -> {
                    if (tpl in listOf(2, 5, 9, 11, 16, 17)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PField("Team 1", c.team1, { v -> vm.updateCard(id) { it.copy(team1 = v) } }, Modifier.weight(1f))
                            PField("Team 2", c.team2, { v -> vm.updateCard(id) { it.copy(team2 = v) } }, Modifier.weight(1f))
                        }
                    }
                    if (tpl in listOf(2, 5, 9, 17)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PField("Score (e.g. 182/4)", c.score, { v -> vm.updateCard(id) { it.copy(score = v) } }, Modifier.weight(1.4f))
                            PField("Overs", c.overs, { v -> vm.updateCard(id) { it.copy(overs = v) } }, Modifier.weight(1f))
                            PField("Wickets", c.wickets, { v -> vm.updateCard(id) { it.copy(wickets = v) } }, Modifier.weight(1f))
                        }
                    }
                    if (tpl in listOf(2, 5, 9)) PField("Match status", c.status, { v -> vm.updateCard(id) { it.copy(status = v) } })
                    if (tpl == 6 || tpl == 11) {
                        PField("Player name", c.playerName, { v -> vm.updateCard(id) { it.copy(playerName = v) } })
                        PField("Statistics (one per line, e.g. Runs: 85)", c.stats, { v -> vm.updateCard(id) { it.copy(stats = v) } }, minLines = 4)
                    }
                    if (cmpTpl) {
                        PHint("PLAYER 1  (picture: Player 1 pic)", GoldC)
                        PField("Player 1 name", c.playerName, { v -> vm.updateCard(id) { it.copy(playerName = v) } })
                        PField("Player 1 statistics (one per line, e.g. Runs: 112)", c.stats, { v -> vm.updateCard(id) { it.copy(stats = v) } }, minLines = 4)
                        PHint("PLAYER 2  (picture: Player 2 pic)", Color(0xFF29B6F6))
                        PField("Player 2 name", c.playerName2, { v -> vm.updateCard(id) { it.copy(playerName2 = v) } })
                        PField("Player 2 statistics (one per line, e.g. Runs: 98)", c.stats2, { v -> vm.updateCard(id) { it.copy(stats2 = v) } }, minLines = 4)
                        PHint("Use the same stat names for both players (Runs, Balls, Strike Rate…). They are matched by name and the better value is highlighted. Economy / wides / extras: the lower value wins.")
                    }
                }
                "size" -> PSlider("Text size", c.textScale, 0.5f..2.5f, "${(c.textScale * 100).toInt()}%") { v -> vm.updateCard(id) { it.copy(textScale = v) } }
                "ticker" -> PField(
                    "Ticker text for this card (empty = project ticker)", c.tickerText,
                    { v -> vm.updateCard(id) { it.copy(tickerText = v) } }, minLines = 2
                )
                "pics" -> CardPicsBody(vm, c)
                "crop" -> {
                    PSlider("Zoom / crop", c.imgScale, 1f..3f, "x${"%.2f".format(c.imgScale)}") { v -> vm.updateCard(id) { it.copy(imgScale = v) } }
                    PSlider("Horizontal", c.imgX, -1f..1f, "%.2f".format(c.imgX)) { v -> vm.updateCard(id) { it.copy(imgX = v) } }
                    PSlider("Vertical", c.imgY, -1f..1f, "%.2f".format(c.imgY)) { v -> vm.updateCard(id) { it.copy(imgY = v) } }
                    PhotoToolsBody(vm, c) { vm.prepareCrop(id)?.let { cropLauncher.launch(it) } }
                }
                "slides" -> {
                    PHint("The card's time is shared equally between the pictures; they change one after another.")
                    PChoice("Change between pictures", Opt.slideFx, c.slideFx) { v -> vm.updateCard(id) { it.copy(slideFx = v) } }
                }
                "extras" -> CardExtrasBody(vm, c)
                "tcol" -> {
                    PHint("Text colour")
                    PColors(c.textColor) { v -> vm.updateCard(id) { it.copy(textColor = v) } }
                }
                "tbg" -> {
                    PHint("Background / tint colour")
                    PColors(c.bgColor) { v -> vm.updateCard(id) { it.copy(bgColor = v) } }
                }
                "logo" -> PChoice("Logo position", Opt.logoPositions, c.logoPos) { v -> vm.updateCard(id) { it.copy(logoPos = v) } }
                "tanim" -> {
                    PChoice("Text animation", Opt.textAnims, c.textAnim) { v -> vm.updateCard(id) { it.copy(textAnim = v) } }
                    PChoice("Exit animation (before card ends)", listOf("None") + Opt.textAnims, c.exitAnim) { v -> vm.updateCard(id) { it.copy(exitAnim = v) } }
                }
                "ianim" -> PChoice("Image animation", Opt.imageAnims, c.imageAnim) { v -> vm.updateCard(id) { it.copy(imageAnim = v) } }
                "loop" -> PChoice("Looping effect", Opt.idleFx, c.idleFx) { v -> vm.updateCard(id) { it.copy(idleFx = v) } }
                "trans" -> {
                    PChoice("Transition into this card", Opt.transitions, c.transition) { v -> vm.updateCard(id) { it.copy(transition = v) } }
                    PSlider("Length", c.transMs.toFloat(), 150f..2500f, "${c.transMs} ms") { v -> vm.updateCard(id) { it.copy(transMs = v.toInt()) } }
                }
                "speed" -> {
                    PSlider("Animation duration", c.animMs.toFloat(), 150f..2500f, "${c.animMs} ms") { v -> vm.updateCard(id) { it.copy(animMs = v.toInt()) } }
                    PSlider("Animation speed", c.animSpeed, 0.25f..3f, "x${"%.2f".format(c.animSpeed)}") { v -> vm.updateCard(id) { it.copy(animSpeed = v) } }
                }
                "time", "set", "order" -> CardTimeBody(vm, p, c, cur)
                "cscript" -> CardScriptBody(vm, c, sameDesign, { sameDesign = it }, replace, { replace = it })
                "cvoice" -> CardVoiceBody(vm, c, fit, { fit = it }, vtext, { vtext = it })
                else -> {}
            }
        }
    }
}

@Composable
private fun CardPicsBody(vm: MainViewModel, c: NCard) {
    val id = c.id
    val pickMany = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list -> if (list.isNotEmpty()) vm.importPictures(id, list) }
    val pics = c.pictures()
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        PButton("Add pictures / videos", { pickMany.launch(arrayOf("image/jpeg", "image/png", "image/webp", "video/*")) }, icon = Icons.Default.AddCircle, primary = true)
        Text("${pics.size} in this card", color = PanelMuted, fontSize = 12.sp)
    }
    val onlyVideo = pics.singleOrNull()?.takeIf { VideoFrames.isVideo(it) }
    if (onlyVideo != null) PButton("Card length = video length", { vm.fitCardToVideo(id) }, icon = Icons.Default.Timer)
    if (pics.isNotEmpty()) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(pics) { i, path ->
                Box(Modifier.size(120.dp, 86.dp)) {
                    PathThumb(path, Modifier.fillMaxSize())
                    if (i == 0) Text("MAIN", fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomStart).background(Color(0xAA000000)).padding(horizontal = 4.dp))
                    else TextButton(onClick = { vm.makePictureFirst(id, i) }, modifier = Modifier.align(Alignment.BottomStart)) { Text("Make main", fontSize = 10.sp) }
                    IconButton(onClick = { vm.removePicture(id, i) }, modifier = Modifier.align(Alignment.TopEnd).size(30.dp)) {
                        Icon(Icons.Default.Close, "Remove", tint = Color.White, modifier = Modifier.background(Color(0x99000000), CircleShape))
                    }
                }
            }
        }
        if (pics.any { VideoFrames.isVideo(it) }) PHint("Videos play without sound (use the Audio tool for music or a voice-over) and repeat when the card is longer than the video. With several pictures / videos they play one after another.")
    } else PHint("No picture or video yet. The first one you add becomes the main picture of this card.")
}

/** Crop (uCrop), remove background (ML Kit) and filters (GPUImage) for the main picture of a card. */
@Composable
private fun PhotoToolsBody(vm: MainViewModel, c: NCard, onCrop: () -> Unit) {
    val main = c.imagePath
    var fIdx by remember(c.id) { mutableStateOf(0) }
    PHint("Photo tools (main picture)", GoldC)
    if (main == null || VideoFrames.isVideo(main)) {
        PHint("The main item of this card is a video or empty. Make a picture the main one first (Media tool).")
        return
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        PButton("Crop picture", onCrop, Modifier.weight(1f), icon = Icons.Default.Crop, enabled = !vm.photoBusy)
        PButton(
            if (vm.photoBusy) "Working..." else "Remove background", { vm.removeBackground(c.id) },
            Modifier.weight(1f), icon = Icons.Default.AutoAwesome, enabled = !vm.photoBusy
        )
    }
    PChoice("Filter", PhotoTools.filterNames, fIdx) { i -> fIdx = i; vm.applyFilter(c.id, i) }
    PHint("Each tool saves a new copy of the picture (the earlier one stays in the project folder; Undo in the editor goes back). Remove background works for photos of people and makes the card background show behind the player.")
}

@Composable
private fun CardExtrasBody(vm: MainViewModel, c: NCard) {
    val id = c.id
    var extraSlot by remember { mutableStateOf(0) }
    val pickExtra = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importExtraImage(id, extraSlot, u) }
    val slots = Opt.extraSlots(c.template)
    val cmp = c.template in Opt.compare
    PHint(if (cmp) "Picture or video of player 2 (the main picture / video is player 1)" else "Small match pictures (or videos) used by this template")
    for (slot in 0 until slots) {
        val has = c.extraImages.getOrNull(slot)?.isNotBlank() == true
        val label = when {
            cmp && has -> "Replace player 2 picture / video"
            cmp -> "Add player 2 picture / video"
            has -> "Replace picture ${slot + 2}"
            else -> "Add picture ${slot + 2}"
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            PButton(
                label,
                { extraSlot = slot; pickExtra.launch(arrayOf("image/jpeg", "image/png", "image/webp", "video/*")) },
                primary = !has
            )
            if (has) PButton("Remove", { vm.removeExtraImage(id, slot) })
        }
    }
}

/** Script for THIS card: paste a script here to make cards from it. */
@Composable
private fun CardScriptBody(vm: MainViewModel, c: NCard, sameDesign: Boolean, onSame: (Boolean) -> Unit, replace: Boolean, onReplace: (Boolean) -> Unit) {
    val clip = LocalClipboardManager.current
    PHint("Paste a script and cards are made from it (offline, instantly) right at this card.")
    PField("Script (paste here)", vm.cardScript, { vm.cardScript = it }, minLines = 6)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        PButton("Paste script", {
            val t = clip.getText()?.text
            if (t.isNullOrBlank()) vm.message = "Clipboard is empty" else vm.cardScript = t
        }, icon = Icons.Default.ContentPaste)
        if (vm.cardScript.isNotBlank()) PButton("Clear", { vm.cardScript = "" })
    }
    PSwitch("Use this card's design for the new cards", sameDesign, onSame)
    PSwitch("Replace this card (otherwise the new cards go after it)", replace, onReplace)
    PButton(
        "Make cards from this script", { vm.cardsFromScript(c.id, vm.cardScript, sameDesign, replace) },
        Modifier.fillMaxWidth(), icon = Icons.Default.AutoAwesome, primary = true
    )
}

/** Voice for THIS card (Google key needed). */
@Composable
private fun CardVoiceBody(vm: MainViewModel, c: NCard, fit: Boolean, onFit: (Boolean) -> Unit, vtext: String, onVtext: (String) -> Unit) {
    val st by vm.settings.collectAsState()
    if (st.geminiKey.isBlank()) {
        PHint("Paste your Google AI Studio key to create voices (the key is used only for voices).", GoldC)
        PGeminiKey(vm)
        PGeminiModel(vm)
        PGeminiVoice(vm)
    }
    PField("Text to read (empty = this card's headline + description)", vtext, onVtext, minLines = 3)
    PField("Speaking style (optional)", vm.ttsStyle, { vm.ttsStyle = it }, placeholder = "e.g. Read like a calm Urdu news anchor")
    PSwitch("Make the card as long as the voice", fit, onFit)
    PButton(
        "Generate voice for this card",
        { vm.generateCardVoice(c.id, vtext.ifBlank { listOf(c.headline, c.description).filter { it.isNotBlank() }.joinToString("۔ ") }, fit) },
        Modifier.fillMaxWidth(), icon = Icons.Default.Mic, enabled = !vm.ttsBusy && !vm.aiBusy, primary = true
    )
    if (c.voicePath != null) Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Voice added (${Timing.fmt(c.voiceDurMs)})", Modifier.weight(1f), color = Good, fontSize = 13.sp)
        PButton("Remove voice", { vm.removeCardVoice(c.id) })
    }
    PHint("Voice and model can be changed in the Audio menu of the editor. Card voices are mixed with the project voice-over.")
}
