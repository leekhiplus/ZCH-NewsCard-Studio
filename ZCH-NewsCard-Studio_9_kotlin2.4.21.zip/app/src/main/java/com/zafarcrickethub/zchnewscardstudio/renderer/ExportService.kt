package com.zafarcrickethub.zchnewscardstudio.renderer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.StatFs
import android.util.Log
import androidx.core.app.NotificationCompat
import com.zafarcrickethub.zchnewscardstudio.ZchApp
import com.zafarcrickethub.zchnewscardstudio.data.ExportRec
import com.zafarcrickethub.zchnewscardstudio.utils.MediaSaver
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

sealed class ExportUi {
    object Idle : ExportUi()
    data class Running(val progress: Float, val msg: String, val projectId: String) : ExportUi()
    data class Done(val uri: String, val projectId: String) : ExportUi()
    data class Failed(val msg: String) : ExportUi()
    object Cancelled : ExportUi()
}

object ExportState {
    val state = MutableStateFlow<ExportUi>(ExportUi.Idle)
    @Volatile var cancel = false
    val busy = AtomicBoolean(false)
}

class ExportService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val chan = "zch_export"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) { ExportState.cancel = true; return START_NOT_STICKY }
        if (intent == null || !ExportState.busy.compareAndSet(false, true)) { stopSelf(); return START_NOT_STICKY }
        ExportState.cancel = false
        startFg(0, "Preparing…")
        val prm = ExportParams(
            intent.getStringExtra("id") ?: "", intent.getIntExtra("w", 1280), intent.getIntExtra("h", 720),
            intent.getIntExtra("fps", 30), intent.getIntExtra("vbr", 4_000_000), intent.getIntExtra("abr", 128_000),
            intent.getStringExtra("name") ?: "ZCH_video", intent.getBooleanExtra("land", true),
            intent.getIntExtra("endMode", 0), intent.getLongExtra("customEnd", 0L), intent.getBooleanExtra("soft", false)
        )
        scope.launch {
            runExport(prm)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun notif(pct: Int, text: String): Notification {
        val cancelPi = PendingIntent.getService(
            this, 1, Intent(this, ExportService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, chan)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("ZCH NewsCard Studio – exporting video")
            .setContentText("$pct%  $text")
            .setProgress(100, pct, false)
            .setOngoing(true)
            .addAction(0, "Cancel", cancelPi)
            .build()
    }

    private fun startFg(pct: Int, text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(chan, "Video export", NotificationManager.IMPORTANCE_LOW))
        val n = notif(pct, text)
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(NOTIF_ID, n)
    }

    private suspend fun runExport(prm: ExportParams) {
        val repo = (application as ZchApp).repo
        var out: File? = null
        var lastNotify = 0L
        try {
            val p0 = repo.load(prm.projectId) ?: throw IllegalStateException("Project not found")
            val proj = p0.copy(settings = p0.settings.copy(landscape = prm.landscape, endMode = prm.endMode, customEndMs = prm.customEndMs))
            if (proj.cards.isEmpty()) throw IllegalStateException("Add at least one news card first")
            val secs = Timing.totalMs(proj) / 1000.0
            val need = ((prm.videoBitrate + prm.audioBitrate) / 8.0 * secs * 2.2).toLong()
            val free = StatFs(cacheDir.path).availableBytes
            if (free < need) throw IllegalStateException("Not enough free storage. Need about ${need / 1_000_000} MB, free ${free / 1_000_000} MB")
            repo.setStatus(prm.projectId, "running")
            ExportState.state.value = ExportUi.Running(0f, "Starting", prm.projectId)
            val exporter = VideoExporter(this, proj, prm, { p, msg ->
                ExportState.state.value = ExportUi.Running(p, msg, prm.projectId)
                val now = System.currentTimeMillis()
                if (now - lastNotify > 700) {
                    lastNotify = now
                    getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notif((p * 100).toInt(), msg))
                }
            }, { ExportState.cancel })
            out = exporter.run()
            val uri = MediaSaver.save(this, out, prm.fileName + ".mp4", "video/mp4", true)
                ?: throw IllegalStateException("Could not save the video to Movies/${MediaSaver.FOLDER}")
            repo.addExport(prm.projectId, ExportRec(uri.toString(), prm.fileName, System.currentTimeMillis(), "${prm.width}x${prm.height} • ${prm.fps} fps"))
            ExportState.state.value = ExportUi.Done(uri.toString(), prm.projectId)
        } catch (e: ExportCancelled) {
            repo.setStatus(prm.projectId, "cancelled")
            ExportState.state.value = ExportUi.Cancelled
        } catch (e: Throwable) {
            Log.e("ZCH", "export failed", e)
            repo.setStatus(prm.projectId, "failed")
            ExportState.state.value = ExportUi.Failed(e.message ?: e.javaClass.simpleName)
        } finally {
            out?.delete()
            ExportState.busy.set(false)
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    companion object {
        const val ACTION_CANCEL = "com.zafarcrickethub.zchnewscardstudio.CANCEL"
        const val NOTIF_ID = 77
    }
}
