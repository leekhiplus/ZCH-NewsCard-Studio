package com.zafarcrickethub.zchnewscardstudio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zafarcrickethub.zchnewscardstudio.renderer.ThumbRenderer
import androidx.compose.ui.Alignment

@Composable
fun ThumbnailScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val t = vm.thumb
    val pickBg = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importThumbImage(u, 0) }
    val pickPlayer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importThumbImage(u, 1) }
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importThumbImage(u, 2) }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.pickThumbVideo(u) }
    ScreenScaffold("Thumbnail Maker", { vm.back() }) { pad ->
        Column(Modifier.padding(pad).padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Canvas(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp))) {
                drawIntoCanvas { ThumbRenderer.draw(ctx, it.nativeCanvas, size.width.toInt().coerceAtLeast(1), size.height.toInt().coerceAtLeast(1), t) }
            }
            Text("1280 × 720", style = MaterialTheme.typography.bodySmall)
            Text("Background", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Navy", "Red", "Gold").forEachIndexed { i, n -> FilterChip(t.bgMode == i, { vm.thumb = t.copy(bgMode = i) }, { Text(n) }) }
                FilterChip(t.bgMode == 3, { if (t.bgPath != null) vm.thumb = t.copy(bgMode = 3) }, { Text("Image") })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pickBg.launch(arrayOf("image/*")) }) { Text("News image") }
                OutlinedButton(onClick = { pickVideo.launch(arrayOf("video/*")) }) { Text("Video frame") }
            }
            if (vm.thumbVideoUri != null) {
                val posState = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(0f) }
                val pos = posState.value
                SliderRow("Video position", pos, 0f..1f, "${"%.1f".format(pos * vm.thumbVideoMs / 1000f)} s") { posState.value = it }
                OutlinedButton(onClick = { vm.grabFrame(pos) }) { Text("Use this frame") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pickPlayer.launch(arrayOf("image/*")) }) { Text(if (t.playerPath == null) "Add player image" else "Replace player") }
                if (t.playerPath != null) OutlinedButton(onClick = { vm.thumb = t.copy(playerPath = null) }) { Text("Remove") }
            }
            RtlField("Urdu headline", t.urdu, { vm.thumb = t.copy(urdu = it) }, minLines = 2)
            RtlField("English text", t.english, { vm.thumb = t.copy(english = it) })
            SliderRow("Urdu text size", t.urduScale, 0.5f..1.5f, "${(t.urduScale * 100).toInt()}%") { vm.thumb = t.copy(urduScale = it) }
            SliderRow("English text size", t.engScale, 0.5f..1.5f, "${(t.engScale * 100).toInt()}%") { vm.thumb = t.copy(engScale = it) }
            ColorRow("Urdu text colour", t.color) { vm.thumb = t.copy(color = it) }
            Row(verticalAlignment = Alignment.CenterVertically) { Switch(t.showLogo, { vm.thumb = t.copy(showLogo = it) }); Text("  Channel logo") }
            OutlinedButton(onClick = { pickLogo.launch(arrayOf("image/png", "image/webp")) }) { Text("Upload logo (PNG)") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.saveThumbnail(false) }) { Text("Save JPG") }
                Button(onClick = { vm.saveThumbnail(true) }) { Text("Save PNG") }
            }
            Text("Saved to Pictures/ZCH NewsCard Studio", style = MaterialTheme.typography.bodySmall)
        }
    }
}
