package com.zafarcrickethub.zchnewscardstudio.utils

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

/**
 * "Small copy" of an exported video with AndroidX Media3 Transformer (hardware H.264 / AAC encoder, GPU scaling).
 * Handy for WhatsApp and slow connections.
 */
@OptIn(UnstableApi::class)
object VideoCompressor {
    /**
     * Re-encodes `input` into `out` with the given height (aspect ratio is kept) and video bitrate.
     * Returns null on success, otherwise an error text. Transformer must be driven from the main thread, which is why this
     * suspends on Dispatchers.Main; the encoding itself runs on the codec / GPU threads.
     */
    suspend fun compress(ctx: Context, input: Uri, out: File, height: Int, videoBitrate: Int): String? =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<String?> { cont ->
                val listener = object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (cont.isActive) cont.resume(null)
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        if (cont.isActive) cont.resume(exportException.message ?: "Compression failed")
                    }
                }
                val encoder = DefaultEncoderFactory.Builder(ctx)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(videoBitrate).build())
                    .build()
                val transformer = Transformer.Builder(ctx)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .setEncoderFactory(encoder)
                    .addListener(listener)
                    .build()
                val effects = Effects(emptyList(), listOf<Effect>(Presentation.createForHeight(height)))
                val item = EditedMediaItem.Builder(MediaItem.fromUri(input)).setEffects(effects).build()
                cont.invokeOnCancellation { transformer.cancel() }
                transformer.start(item, out.path)
            }
        }
}
