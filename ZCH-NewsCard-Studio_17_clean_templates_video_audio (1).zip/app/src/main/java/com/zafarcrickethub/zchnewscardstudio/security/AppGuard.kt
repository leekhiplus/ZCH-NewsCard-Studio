package com.zafarcrickethub.zchnewscardstudio.security

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/**
 * A light guard against the two common ways a finished app gets stolen:
 *  1) someone decompiles the APK, changes the package name / app name / icon, and republishes it as their own app;
 *  2) someone re-signs the APK with their own key and republishes it (Android requires every APK to be signed, so a
 *     stolen APK is always re-signed with a DIFFERENT key before it can be installed).
 * Both change the installed app's package name or its signing certificate, so checking both here catches a plain
 * "take the APK and rebrand it" copy without needing a server or the internet.
 *
 * Read before relying on this: this is NOT able to make the code impossible to use. Anyone who has this *source code*
 * (not just the APK) can simply delete this file and rebuild; a skilled reverse engineer can also patch the check out
 * of an APK directly. No code running on someone else's phone can rule that out completely. What this DOES stop is the
 * common, low-effort kind of app theft: grabbing the APK, changing its name/icon with a tool like Apktool, and
 * publishing it under another name — that copy fails this check and refuses to open.
 *
 * Setup (see README → "App protection"): build ONE signed release APK, find its certificate's SHA-256 fingerprint
 * (Android Studio: Build > Generate Signed App Bundle/APK, or `keytool -list -v -keystore your.keystore -alias yourAlias`,
 * the line "Certificate fingerprints: SHA256:"), then put that value (remove the colons) into ORIGINAL_CERT_SHA256
 * below and rebuild. Until it is filled in, this check is switched off and the app runs normally everywhere, including
 * in Android Studio and in debug builds — so filling it in can never accidentally lock you out of your own app, only
 * an already-signed release build can be checked.
 */
object AppGuard {
    private const val ORIGINAL_PACKAGE = "com.zafarcrickethub.zchnewscardstudio"

    // Fill in after your first signed release build, e.g. "A1B2C3D4...64 hex characters total" (case does not matter).
    private const val ORIGINAL_CERT_SHA256 = ""

    enum class Result { GENUINE, DEBUG_BUILD, CHECK_OFF, WRONG_PACKAGE, WRONG_SIGNATURE, UNKNOWN }

    fun check(ctx: Context): Result = try {
        val debuggable = (ctx.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        when {
            debuggable -> Result.DEBUG_BUILD                 // debug builds (Android Studio "Run") are never blocked
            ORIGINAL_CERT_SHA256.isBlank() -> Result.CHECK_OFF // not set up yet: see the setup note above
            ctx.packageName != ORIGINAL_PACKAGE -> Result.WRONG_PACKAGE
            else -> {
                val actual = signingCertSha256(ctx)
                when {
                    actual == null -> Result.UNKNOWN
                    actual.equals(ORIGINAL_CERT_SHA256.replace(":", ""), ignoreCase = true) -> Result.GENUINE
                    else -> Result.WRONG_SIGNATURE
                }
            }
        }
    } catch (t: Throwable) {
        Result.UNKNOWN   // never block the app just because the check itself failed on some device
    }

    /** SHA-256 of the certificate that actually signed the installed APK, as plain upper-case hex (no colons). */
    private fun signingCertSha256(ctx: Context): String? {
        val pm = ctx.packageManager
        val cert = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            info.signingInfo?.apkContentsSigners?.firstOrNull()
        } else {
            @Suppress("DEPRECATION")
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES)
            @Suppress("DEPRECATION")
            info.signatures?.firstOrNull()
        } ?: return null
        val bytes = MessageDigest.getInstance("SHA-256").digest(cert.toByteArray())
        return bytes.joinToString("") { "%02X".format(it) }
    }
}
