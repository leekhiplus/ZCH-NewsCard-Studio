package com.zafarcrickethub.zchnewscardstudio.graphics

import android.content.Context
import android.graphics.Canvas
import android.graphics.RectF
import com.airbnb.lottie.LottieComposition
import com.airbnb.lottie.LottieCompositionFactory
import com.airbnb.lottie.LottieDrawable
import java.io.File
import java.io.FileInputStream

/**
 * Animated (Lottie) stickers. A sticker layer is a Lottie sticker when its text starts with "lottie:".
 * Built-in ones live in assets/lottie/<name>.json (text = "lottie:<name>", no image path);
 * a .json file imported by the user is stored in the project folder (image path = that file, text = "lottie:<file name>").
 * The animation loops; its frame is computed from the time inside the layer, so preview and export always match.
 */
object LottieSticker {
    const val PREFIX = "lottie:"

    fun isLottie(text: String) = text.startsWith(PREFIX)

    fun label(text: String) = text.removePrefix(PREFIX)

    /** Names of the built-in animated stickers. */
    fun builtIn(ctx: Context): List<String> = try {
        ctx.assets.list("lottie")?.filter { it.endsWith(".json") }?.map { it.removeSuffix(".json") }?.sorted() ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    /** True when the file is a Lottie animation that can be drawn. */
    fun isValidFile(path: String): Boolean = try {
        FileInputStream(File(path)).use { LottieCompositionFactory.fromJsonInputStreamSync(it, null).value != null }
    } catch (t: Throwable) {
        false
    }

    private class Entry(val comp: LottieComposition, val drawable: LottieDrawable)

    // LottieDrawable is not thread-safe and the live preview and the export draw on different threads: one cache per thread.
    private val cache: ThreadLocal<HashMap<String, Entry?>> = ThreadLocal.withInitial { HashMap<String, Entry?>() }

    private fun load(ctx: Context, path: String?, name: String): Entry? = try {
        val result = if (path != null) {
            FileInputStream(File(path)).use { LottieCompositionFactory.fromJsonInputStreamSync(it, null) }
        } else {
            LottieCompositionFactory.fromAssetSync(ctx, "lottie/$name.json")
        }
        val comp = result.value
        if (comp == null) null else {
            val d = LottieDrawable()
            d.setComposition(comp)
            Entry(comp, d)
        }
    } catch (t: Throwable) {
        null
    }

    /** Draws the sticker into `box` at `tMs` milliseconds after the layer started. Draws nothing if it cannot be loaded. */
    fun draw(ctx: Context, cv: Canvas, text: String, path: String?, box: RectF, tMs: Long) {
        val key = if (path != null) "f:$path" else "a:" + label(text)
        val map = cache.get() ?: return
        val entry = if (map.containsKey(key)) map[key] else load(ctx, path, label(text)).also { map[key] = it }
        if (entry == null) return
        val dur = entry.comp.duration.coerceAtLeast(100f)
        val progress = ((tMs % dur.toLong().coerceAtLeast(1L)).toFloat() / dur).coerceIn(0f, 1f)
        val d = entry.drawable
        d.setProgress(progress)
        d.setBounds(box.left.toInt(), box.top.toInt(), box.right.toInt(), box.bottom.toInt())
        d.draw(cv)
    }
}
