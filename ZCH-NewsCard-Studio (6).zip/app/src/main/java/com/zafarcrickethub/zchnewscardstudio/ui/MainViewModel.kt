package com.zafarcrickethub.zchnewscardstudio.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zafarcrickethub.zchnewscardstudio.ZchApp
import com.zafarcrickethub.zchnewscardstudio.audio.AudioUtils
import com.zafarcrickethub.zchnewscardstudio.audio.Playback
import com.zafarcrickethub.zchnewscardstudio.data.AppSettings
import com.zafarcrickethub.zchnewscardstudio.data.Card
import com.zafarcrickethub.zchnewscardstudio.data.ExportRec
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.data.ProjectSettings
import com.zafarcrickethub.zchnewscardstudio.data.Samples
import com.zafarcrickethub.zchnewscardstudio.data.pictures
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportState
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportService
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportUi
import com.zafarcrickethub.zchnewscardstudio.renderer.ThumbRenderer
import com.zafarcrickethub.zchnewscardstudio.renderer.ThumbSpec
import com.zafarcrickethub.zchnewscardstudio.utils.GeminiText
import com.zafarcrickethub.zchnewscardstudio.utils.GeminiTts
import com.zafarcrickethub.zchnewscardstudio.utils.MediaSaver
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

enum class Screen { Dashboard, Projects, Templates, Exports, Settings, Help, Editor, Thumbnail }

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as ZchApp).repo
    private val ctx: Context get() = getApplication<Application>()

    var screen by mutableStateOf(Screen.Dashboard)
    val projects = repo.projects.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val settings = repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    var current by mutableStateOf<Project?>(null)
    var tab by mutableIntStateOf(0)
    var sel by mutableStateOf("")          // "", "card:<id>", "audio", "ticker", "logo"
    var sheet by mutableStateOf("")        // bottom sheet in the editor
    var fullPreview by mutableStateOf(false)
    var showExport by mutableStateOf(false)
    var ttsBusy by mutableStateOf(false)
    var aiBusy by mutableStateOf(false)
    var aiStatus by mutableStateOf("")
    var aiResult by mutableStateOf<String?>(null)   // shown in a dialog so it can never be missed
    var aiScript by mutableStateOf("")
    var ttsScript by mutableStateOf("")
    var ttsStyle by mutableStateOf("")
    var zoomDp by mutableStateOf(60f)      // timeline zoom (dp per second)
    var undoCount by mutableIntStateOf(0)
    var redoCount by mutableIntStateOf(0)
    private val undoStack = ArrayDeque<Project>()
    private val redoStack = ArrayDeque<Project>()
    private var lastPush = 0L
    var editingCard by mutableStateOf<String?>(null)
    var waveform by mutableStateOf<FloatArray?>(null)
    var message by mutableStateOf<String?>(null)
    var thumb by mutableStateOf(ThumbSpec())
    var thumbVideoMs by mutableStateOf(0L)
    var thumbVideoUri by mutableStateOf<Uri?>(null)
    val playback = Playback()
    private var saveJob: Job? = null

    init {
        // keep export info of the open project fresh (service writes it to the DB)
        viewModelScope.launch {
            projects.collect { list ->
                val c = current ?: return@collect
                val d = list.find { it.id == c.id } ?: return@collect
                if (d.exports != c.exports || d.exportStatus != c.exportStatus) current = c.copy(exports = d.exports, exportStatus = d.exportStatus)
            }
        }
    }

    // ------------------------------------------------------------ navigation
    fun go(s: Screen) { screen = s }

    fun back() {
        if (screen == Screen.Editor) {
            when {
                showExport -> showExport = false
                fullPreview -> { playback.pause(); fullPreview = false }
                sheet.isNotEmpty() -> sheet = ""
                editingCard != null -> editingCard = null
                sel.isNotEmpty() -> sel = ""
                else -> { saveNow(); playback.pause(); screen = Screen.Projects }
            }
        } else screen = Screen.Dashboard
    }

    // ------------------------------------------------------------ projects
    fun createProject(name: String, template: Int) {
        val st = settings.value
        val p = Project(
            name = name.ifBlank { "New Project" },
            settings = ProjectSettings(landscape = st.landscape, channelName = st.channelName, tickerText = st.ticker, tickerStyle = 1, tickerBg = com.zafarcrickethub.zchnewscardstudio.data.Pal.Red),
            cards = listOf(Samples.card(template))
        )
        viewModelScope.launch { repo.save(p); open(p.id) }
    }

    fun open(id: String, sheetAfter: String = "") {
        viewModelScope.launch {
            val p = repo.load(id)
            if (p == null) { message = "Project could not be opened"; return@launch }
            current = p; tab = 0; editingCard = null
            sel = ""; sheet = sheetAfter; showExport = false; fullPreview = false
            undoStack.clear(); redoStack.clear(); undoCount = 0; redoCount = 0; lastPush = 0L
            playback.positionMs = 0
            reloadAudio()
            repo.setLast(id)
            screen = Screen.Editor
        }
    }

    fun rename(id: String, name: String) {
        viewModelScope.launch {
            val p = repo.load(id) ?: return@launch
            repo.save(p.copy(name = name.ifBlank { p.name }, updatedAt = System.currentTimeMillis()))
            if (current?.id == id) current = current?.copy(name = name.ifBlank { p.name })
        }
    }

    fun duplicate(id: String) { viewModelScope.launch { repo.duplicate(id); message = "Project duplicated" } }
    fun delete(id: String) { viewModelScope.launch { repo.delete(id); if (current?.id == id) current = null } }

    fun mutate(block: (Project) -> Project) {
        val p = current ?: return
        val n = block(p).copy(updatedAt = System.currentTimeMillis())
        val now = System.currentTimeMillis()
        if (now - lastPush > 700L) {   // coalesce continuous edits (typing, slider drags)
            undoStack.addLast(p)
            if (undoStack.size > 60) undoStack.removeFirst()
            redoStack.clear()
        }
        lastPush = now
        undoCount = undoStack.size; redoCount = redoStack.size
        current = n
        playback.totalMs = Timing.totalMs(n)
        saveJob?.cancel()
        saveJob = viewModelScope.launch { delay(400); repo.saveEdit(n) }
    }

    fun saveNow() {
        val p = current ?: return
        saveJob?.cancel()
        viewModelScope.launch { repo.saveEdit(p) }
    }

    private fun restore(target: Project) {
        val cur = current ?: return
        val audioChanged = cur.settings.audioPath != target.settings.audioPath
        current = target.copy(exports = cur.exports, exportStatus = cur.exportStatus, updatedAt = System.currentTimeMillis())
        playback.totalMs = Timing.totalMs(current!!)
        if (audioChanged) reloadAudio()
        lastPush = 0L
        undoCount = undoStack.size; redoCount = redoStack.size
        if (sel.startsWith("card:") && current!!.cards.none { it.id == sel.removePrefix("card:") }) sel = ""
        saveNow()
    }

    fun undo() {
        val cur = current ?: return
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(cur)
        restore(prev)
    }

    fun redo() {
        val cur = current ?: return
        val nxt = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(cur)
        restore(nxt)
    }

    fun updateSettings(f: (ProjectSettings) -> ProjectSettings) = mutate { it.copy(settings = f(it.settings)) }

    fun updateAppSettings(f: (AppSettings) -> AppSettings) { viewModelScope.launch { repo.updateSettings(f(settings.value)) } }

    // ------------------------------------------------------------ cards
    fun updateCard(id: String, f: (Card) -> Card) = mutate { p -> p.copy(cards = p.cards.map { if (it.id == id) f(it) else it }) }

    fun addCard(template: Int) {
        val start = current?.cards?.maxOfOrNull { it.endMs } ?: 0L
        val card = Samples.card(template, start, start + 5000)
        mutate { p -> p.copy(cards = p.cards + card) }
        sel = "card:" + card.id
        playback.seek(start + 300)
    }

    fun deleteCard(id: String) {
        mutate { p -> p.copy(cards = p.cards.filter { it.id != id }) }
        if (sel == "card:$id") sel = ""
    }

    /** CapCut-style split: cuts the card at the play-head into two cards. */
    fun splitCard(id: String, at: Long) {
        val p = current ?: return
        val i = p.cards.indexOfFirst { it.id == id }
        if (i < 0) return
        val c = p.cards[i]
        if (at <= c.startMs + 200 || at >= c.endMs - 200) { message = "Move the play-head inside the card to split it"; return }
        val first = c.copy(endMs = at)
        val second = c.copy(id = UUID.randomUUID().toString(), startMs = at)
        mutate { pr -> pr.copy(cards = pr.cards.take(i) + first + second + pr.cards.drop(i + 1)) }
        sel = "card:" + second.id
    }

    fun duplicateCard(id: String) = mutate { p ->
        val i = p.cards.indexOfFirst { it.id == id }
        if (i < 0) p else {
            val c = p.cards[i]
            val dur = c.endMs - c.startMs
            val copy = c.copy(id = UUID.randomUUID().toString(), startMs = c.endMs, endMs = c.endMs + dur)
            val before = p.cards.take(i + 1)
            val after = p.cards.drop(i + 1).map { it.copy(startMs = it.startMs + dur, endMs = it.endMs + dur) }
            p.copy(cards = before + copy + after)
        }
    }

    /** Moves card content; the time slots stay where they are so the audio alignment is kept. */
    fun moveCard(id: String, dir: Int) = mutate { p ->
        val i = p.cards.indexOfFirst { it.id == id }
        val j = i + dir
        if (i < 0 || j < 0 || j >= p.cards.size) p else {
            val l = p.cards.toMutableList()
            val a = l[i]; val b = l[j]
            l[i] = b.copy(startMs = a.startMs, endMs = a.endMs)
            l[j] = a.copy(startMs = b.startMs, endMs = b.endMs)
            p.copy(cards = l)
        }
    }

    /** Manual timing. Optionally moves the following cards (ripple) so nothing overlaps. */
    fun setTiming(id: String, start: Long?, end: Long?) {
        val p = current ?: return
        val i = p.cards.indexOfFirst { it.id == id }
        if (i < 0) return
        val c = p.cards[i]
        val s = start ?: c.startMs
        val e = end ?: c.endMs
        if (s < 0) { message = "Start time cannot be negative"; return }
        if (e <= s) { message = "End time must be after start time"; return }
        val audio = p.settings.audioDurMs
        if (audio > 0 && e > audio + 100) message = "Note: this card ends after the voice-over (${Timing.fmt(audio)})"
        val delta = e - c.endMs
        mutate { pr ->
            pr.copy(cards = pr.cards.mapIndexed { j, x ->
                when {
                    j == i -> x.copy(startMs = s, endMs = e)
                    pr.settings.ripple && j > i && delta != 0L ->
                        x.copy(startMs = (x.startMs + delta).coerceAtLeast(0L), endMs = (x.endMs + delta).coerceAtLeast(1L))
                    else -> x
                }
            })
        }
    }

    fun setDuration(id: String, durMs: Long) {
        val c = current?.cards?.find { it.id == id } ?: return
        if (durMs <= 0) { message = "Duration must be greater than zero"; return }
        setTiming(id, null, c.startMs + durMs)
    }

    fun nudge(id: String, startDelta: Long, endDelta: Long) {
        val c = current?.cards?.find { it.id == id } ?: return
        setTiming(id, (c.startMs + startDelta).coerceAtLeast(0L), c.endMs + endDelta)
    }

    fun startAfterPrevious(id: String) {
        val p = current ?: return
        val i = p.cards.indexOfFirst { it.id == id }
        if (i <= 0) return
        val c = p.cards[i]
        val s = p.cards[i - 1].endMs
        setTiming(id, s, s + (c.endMs - c.startMs))
    }

    fun setEdge(index: Int, isEnd: Boolean, ms: Long) = mutate { p ->
        val l = p.cards.toMutableList()
        if (index !in l.indices) return@mutate p
        val c = l[index]
        if (isEnd) {
            val ne = maxOf(ms, c.startMs + 200)
            l[index] = c.copy(endMs = ne)
            val n = l.getOrNull(index + 1)
            if (n != null && !p.settings.allowOverlap && kotlin.math.abs(n.startMs - c.endMs) <= 1) {
                l[index + 1] = n.copy(startMs = ne, endMs = maxOf(n.endMs, ne + 200))
            }
        } else {
            val ns = minOf(ms, c.endMs - 200).coerceAtLeast(0)
            l[index] = c.copy(startMs = ns)
            val pr = l.getOrNull(index - 1)
            if (pr != null && !p.settings.allowOverlap && kotlin.math.abs(pr.endMs - c.startMs) <= 1) {
                l[index - 1] = pr.copy(endMs = ns, startMs = minOf(pr.startMs, ns - 200).coerceAtLeast(0))
            }
        }
        p.copy(cards = l)
    }

    fun distribute() = mutate { p ->
        val total = if (p.settings.audioDurMs > 0) p.settings.audioDurMs else p.cards.size * 5000L
        p.copy(cards = Timing.distribute(p.cards, total))
    }

    // ------------------------------------------------------------ assets
    fun importCardImage(cardId: String, uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                val path = repo.importAsset(p.id, uri, "img")
                if (com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path) == null) { File(path).delete(); message = "Unsupported or damaged image"; return@launch }
                updateCard(cardId) { it.copy(imagePath = path, imgScale = 1f, imgX = 0f, imgY = 0f) }
            } catch (e: Exception) { message = "Could not import image: ${e.message}" }
        }
    }

    fun importExtraImage(cardId: String, slot: Int, uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                val path = repo.importAsset(p.id, uri, "img")
                if (com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path) == null) { File(path).delete(); message = "Unsupported or damaged image"; return@launch }
                updateCard(cardId) { c ->
                    val l = c.extraImages.toMutableList()
                    while (l.size <= slot) l.add("")
                    l[slot] = path
                    c.copy(extraImages = l)
                }
            } catch (e: Exception) { message = "Could not import image: ${e.message}" }
        }
    }

    fun removeExtraImage(cardId: String, slot: Int) = updateCard(cardId) { c ->
        val l = c.extraImages.toMutableList()
        if (slot < l.size) l[slot] = ""
        c.copy(extraImages = l)
    }

    fun importLogo(uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                val path = repo.importAsset(p.id, uri, "logo")
                if (com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path, 800) == null) { File(path).delete(); message = "Unsupported logo image"; return@launch }
                updateSettings { it.copy(logoPath = path) }
            } catch (e: Exception) { message = "Could not import logo: ${e.message}" }
        }
    }

    fun importAudio(uri: Uri) {
        val p = current ?: return
        viewModelScope.launch {
            try {
                val path = repo.importAsset(p.id, uri, "audio")
                val ok = withContext(Dispatchers.IO) { AudioUtils.canDecode(path) }
                val dur = withContext(Dispatchers.IO) { AudioUtils.duration(path) }
                if (!ok || dur <= 0) { File(path).delete(); message = "This audio file is not supported on this device"; return@launch }
                val old = current?.settings?.audioPath
                updateSettings { it.copy(audioPath = path, audioDurMs = dur) }
                reloadAudio()
            } catch (e: Exception) { message = "Could not import audio: ${e.message}" }
        }
    }

    fun removeAudio() {
        updateSettings { it.copy(audioPath = null, audioDurMs = 0) }
        reloadAudio()
    }

    /** Fills the voice-over script from the headlines / descriptions of all cards. */
    fun scriptFromCards() {
        val p = current ?: return
        ttsScript = p.cards.joinToString("\n") { c -> listOf(c.headline, c.description).filter { it.isNotBlank() }.joinToString("۔ ") }
    }

    /** Generates the voice-over WAV and installs it in the project. Returns the duration in ms (0 = failed). */
    private suspend fun makeVoice(projectId: String, text: String, style: String): Long {
        val st = settings.value
        val (pcm, rate) = withContext(Dispatchers.IO) { GeminiTts.synthesize(st.geminiKey, st.geminiModel, st.geminiVoice, text, style) }
        val file = withContext(Dispatchers.IO) {
            File(repo.projectDir(projectId), "voice_${System.currentTimeMillis()}.wav").also { it.writeBytes(GeminiTts.pcmToWav(pcm, rate)) }
        }
        val dur = withContext(Dispatchers.IO) { AudioUtils.duration(file.path) }
        if (dur <= 0) { message = "The generated audio could not be read"; return 0L }
        if (current?.id != projectId) { message = "Voice-over finished, but the project was closed"; return 0L }
        updateSettings { it.copy(audioPath = file.path, audioDurMs = dur) }
        reloadAudio()
        return dur
    }

    private fun friendly(e: Exception): String = when (e) {
        is GeminiTts.TtsException -> e.message ?: "Error"
        is java.io.IOException -> "Network error. Check your internet connection and try again."
        else -> "Failed: ${e.message}"
    }

    /** Optional online feature: Gemini text-to-speech through the user's own Google AI Studio key. */
    fun generateVoice() {
        val p = current ?: return
        if (ttsBusy) return
        if (settings.value.geminiKey.isBlank()) { message = "Paste your Google AI Studio API key first"; return }
        if (ttsScript.isBlank()) { message = "Write the script or tap \"Fill from cards\" first"; return }
        ttsBusy = true
        sheet = ""
        aiResult = null
        aiStatus = "Creating the voice-over with AI…"
        val script = ttsScript
        val style = ttsStyle
        viewModelScope.launch {
            try {
                val dur = makeVoice(p.id, script, style)
                aiResult = if (dur > 0) "✅ Voice-over created (${Timing.fmt(dur)}).\n\nPress ▶ to listen. Then set each card's time with the play-head (select a card → Time → Start / End = play-head)."
                else "❌ The voice-over could not be created."
            } catch (e: Exception) {
                aiResult = "❌ " + friendly(e)
            } finally {
                ttsBusy = false
                aiStatus = ""
            }
        }
    }

    /**
     * Paste a full news script -> AI splits it into cards (headline, description, match fields) and,
     * optionally, creates the voice-over and the ticker. Card times are left for the user to set.
     * tpl: -1 = best template per content, -2 = TV-style templates, -3 = classic templates, >=0 = that template for all.
     */
    fun generateFromScript(maxCards: Int, tpl: Int, replace: Boolean, withVoice: Boolean, withTicker: Boolean, spread: Boolean) {
        val p = current ?: return
        if (aiBusy) return
        val st = settings.value
        if (st.geminiKey.isBlank()) { message = "Paste your Google AI Studio API key first"; return }
        if (aiScript.isBlank()) { message = "Paste the news script first"; return }
        aiBusy = true
        sheet = ""            // close the sheet so the progress / result dialogs are visible
        aiResult = null
        val script = aiScript
        val style = ttsStyle
        viewModelScope.launch {
            try {
                aiStatus = "1/3  Reading the script…"
                val plan = withContext(Dispatchers.IO) { GeminiText.plan(st.geminiKey, st.geminiTextModel, script, maxCards) }
                if (current?.id != p.id) { aiResult = "❌ The project was closed"; return@launch }
                aiStatus = "2/3  Creating ${plan.segs.size} cards…"
                val byKind = mapOf(
                    "breaking" to listOf(0, 13, 14, 7), "report" to listOf(4, 12, 20, 15), "score" to listOf(5, 9, 17, 2),
                    "player" to listOf(6, 11), "general" to listOf(1, 3, 8, 10, 16, 18, 19, 21, 22)
                )
                val used = HashMap<String, Int>()
                val base = if (replace) 0L else (current?.cards?.maxOfOrNull { it.endMs } ?: 0L)
                val cards = plan.segs.mapIndexed { i, sg ->
                    val kind = if (byKind.containsKey(sg.kind)) sg.kind else "general"
                    val t = when {
                        tpl >= 0 -> tpl
                        tpl == -2 -> com.zafarcrickethub.zchnewscardstudio.data.Opt.tvStyle[i % 10]
                        tpl == -3 -> com.zafarcrickethub.zchnewscardstudio.data.Opt.classic[i % 13]
                        else -> { val l = byKind.getValue(kind); val n = used.getOrDefault(kind, 0); used[kind] = n + 1; l[n % l.size] }
                    }
                    val start = base + i * 5000L
                    Samples.card(t, start, start + 5000L).copy(
                        headline = sg.headline, description = sg.description,
                        team1 = sg.team1, team2 = sg.team2, score = sg.score, overs = sg.overs, wickets = sg.wickets,
                        status = sg.status, playerName = sg.player, stats = sg.stats.joinToString("\n")
                    )
                }
                mutate { pr ->
                    pr.copy(
                        cards = if (replace) cards else pr.cards + cards,
                        settings = if (withTicker && plan.ticker.isNotBlank()) pr.settings.copy(tickerText = plan.ticker) else pr.settings
                    )
                }
                sel = ""
                playback.seek(0)
                val list = cards.mapIndexed { i, c -> "${i + 1}. ${c.headline.replace('\n', ' ').take(60)}" }.joinToString("\n")
                if (withVoice) {
                    aiStatus = "3/3  Creating the voice-over…"
                    val voiceText = plan.segs.joinToString("\n") { it.voice }.ifBlank { script }
                    val dur = try { makeVoice(p.id, voiceText, style) } catch (e: Exception) { aiResult = "⚠ ${cards.size} cards were created, but the voice-over failed:\n" + friendly(e) + "\n\nYou can retry it from the Voice button."; 0L }
                    if (dur > 0 && spread) distribute()
                    if (dur > 0) aiResult = "✅ ${cards.size} cards created\n🎙 Voice-over ready (${Timing.fmt(dur)})\n\n$list\n\nNext: add pictures, then set each card's time with the play-head (select a card → Time → Start / End = play-head)."
                    else if (aiResult == null) aiResult = "⚠ ${cards.size} cards were created, but the voice-over failed. You can retry it from the Voice button."
                } else aiResult = "✅ ${cards.size} cards created\n\n$list\n\nNext: add pictures and set each card's time."
            } catch (e: Exception) {
                aiResult = "❌ " + friendly(e)
            } finally {
                aiBusy = false
                aiStatus = ""
            }
        }
    }

    /** Several pictures at once for one card (unlimited). The first becomes the main picture, the rest the slide-show. */
    fun importPictures(cardId: String, uris: List<Uri>) {
        val p = current ?: return
        viewModelScope.launch {
            val ok = ArrayList<String>()
            var bad = 0
            for (u in uris) {
                try {
                    val path = repo.importAsset(p.id, u, "img")
                    if (com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path) != null) ok.add(path) else { File(path).delete(); bad++ }
                } catch (e: Exception) { bad++ }
            }
            if (ok.isNotEmpty()) updateCard(cardId) { c ->
                if (c.imagePath == null) c.copy(imagePath = ok.first(), gallery = c.gallery + ok.drop(1))
                else c.copy(gallery = c.gallery + ok)
            }
            message = if (bad > 0) "${ok.size} pictures added, $bad could not be read" else "${ok.size} pictures added"
        }
    }

    /** index 0 = main picture, 1.. = gallery */
    fun removePicture(cardId: String, index: Int) = updateCard(cardId) { c ->
        if (index == 0) c.copy(imagePath = c.gallery.firstOrNull(), gallery = c.gallery.drop(1), imgScale = 1f, imgX = 0f, imgY = 0f)
        else c.copy(gallery = c.gallery.filterIndexed { i, _ -> i != index - 1 })
    }

    fun makePictureFirst(cardId: String, index: Int) = updateCard(cardId) { c ->
        if (index <= 0) c else {
            val all = c.pictures().toMutableList()
            val x = all.removeAt(index)
            all.add(0, x)
            c.copy(imagePath = all.first(), gallery = all.drop(1))
        }
    }

    /** New empty project that opens straight in the "AI script" sheet. */
    fun createFromScript() {
        val st = settings.value
        val p = Project(
            name = "AI News",
            settings = ProjectSettings(landscape = st.landscape, channelName = st.channelName, tickerText = st.ticker, tickerStyle = 1, tickerBg = com.zafarcrickethub.zchnewscardstudio.data.Pal.Red),
            cards = emptyList()
        )
        viewModelScope.launch { repo.save(p); open(p.id, "aiscript") }
    }

    fun setVolume(v: Float) {
        updateSettings { it.copy(volume = v) }
        playback.voice.volume(v)
    }

    fun reloadAudio() {
        val s = current?.settings
        playback.totalMs = current?.let { Timing.totalMs(it) } ?: 0L
        playback.load(s?.audioPath, s?.volume ?: 1f, s?.audioDurMs ?: 0L)
        waveform = null
        val path = s?.audioPath ?: return
        viewModelScope.launch { waveform = withContext(Dispatchers.Default) { runCatching { AudioUtils.waveform(path) }.getOrNull() } }
    }

    // ------------------------------------------------------------ export
    fun startExport(w: Int, h: Int, fps: Int, vbr: Int, abr: Int, name: String, land: Boolean, endMode: Int, customEnd: Long) {
        val p = current ?: return
        if (ExportState.busy.get()) { message = "An export is already running"; return }
        saveNow()
        playback.pause()
        ExportState.state.value = ExportUi.Running(0f, "Starting", p.id)
        val safe = name.replace(Regex("[^\\p{L}\\p{N} _.-]"), "_").ifBlank { "ZCH_video" }
        val i = Intent(ctx, ExportService::class.java)
            .putExtra("id", p.id).putExtra("w", w).putExtra("h", h).putExtra("fps", fps)
            .putExtra("vbr", vbr).putExtra("abr", abr).putExtra("name", safe).putExtra("land", land)
            .putExtra("endMode", endMode).putExtra("customEnd", customEnd)
        ContextCompat.startForegroundService(ctx, i)
    }

    fun cancelExport() { ExportState.cancel = true }

    fun deleteExport(projectId: String, rec: ExportRec) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { MediaSaver.delete(ctx, rec.uri) }
            repo.removeExport(projectId, rec.uri)
        }
    }

    // ------------------------------------------------------------ thumbnail maker
    fun importThumbImage(uri: Uri, kind: Int) {
        viewModelScope.launch {
            try {
                val path = repo.importAsset("thumbs", uri, "t")
                if (com.zafarcrickethub.zchnewscardstudio.graphics.Bmp.load(path) == null) { message = "Unsupported image"; return@launch }
                thumb = when (kind) {
                    0 -> thumb.copy(bgPath = path, bgMode = 3)
                    1 -> thumb.copy(playerPath = path)
                    else -> thumb.copy(logoPath = path)
                }
            } catch (e: Exception) { message = "Could not import image" }
        }
    }

    fun pickThumbVideo(uri: Uri) {
        viewModelScope.launch {
            val d = withContext(Dispatchers.IO) {
                val r = MediaMetadataRetriever()
                try { r.setDataSource(ctx, uri); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L }
                catch (e: Exception) { 0L } finally { try { r.release() } catch (_: Exception) {} }
            }
            if (d <= 0) { message = "Could not read this video"; return@launch }
            thumbVideoUri = uri; thumbVideoMs = d
            grabFrame(0f)
        }
    }

    fun grabFrame(fraction: Float) {
        val uri = thumbVideoUri ?: return
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, uri)
                    val bmp = r.getFrameAtTime((thumbVideoMs * fraction).toLong() * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                    if (bmp == null) null else {
                        val f = File(repo.projectDir("thumbs"), "frame_${System.currentTimeMillis()}.jpg")
                        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                        f.path
                    }
                } catch (e: Exception) { null } finally { try { r.release() } catch (_: Exception) {} }
            }
            if (path != null) thumb = thumb.copy(bgPath = path, bgMode = 3) else message = "Could not read a frame"
        }
    }

    fun saveThumbnail(png: Boolean) {
        val t = thumb
        viewModelScope.launch {
            val ok = withContext(Dispatchers.Default) {
                try {
                    val bmp = Bitmap.createBitmap(ThumbRenderer.W, ThumbRenderer.H, Bitmap.Config.ARGB_8888)
                    ThumbRenderer.draw(ctx, android.graphics.Canvas(bmp), ThumbRenderer.W, ThumbRenderer.H, t)
                    val f = File(ctx.cacheDir, "thumb_tmp." + if (png) "png" else "jpg")
                    f.outputStream().use { bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it) }
                    val name = "ZCH_thumbnail_${System.currentTimeMillis()}." + if (png) "png" else "jpg"
                    val uri = MediaSaver.save(ctx, f, name, if (png) "image/png" else "image/jpeg", false)
                    f.delete()
                    uri != null
                } catch (e: Exception) { false }
            }
            message = if (ok) "Thumbnail saved to Pictures/${MediaSaver.FOLDER}" else "Could not save thumbnail"
        }
    }

    override fun onCleared() { playback.voice.release(); super.onCleared() }
}
