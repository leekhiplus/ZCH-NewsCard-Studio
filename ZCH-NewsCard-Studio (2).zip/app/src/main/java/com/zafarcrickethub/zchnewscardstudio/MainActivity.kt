package com.zafarcrickethub.zchnewscardstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.zafarcrickethub.zchnewscardstudio.ui.DashboardScreen
import com.zafarcrickethub.zchnewscardstudio.ui.EditorScreen
import com.zafarcrickethub.zchnewscardstudio.ui.ExportsScreen
import com.zafarcrickethub.zchnewscardstudio.ui.HelpScreen
import com.zafarcrickethub.zchnewscardstudio.ui.MainViewModel
import com.zafarcrickethub.zchnewscardstudio.ui.ProjectsScreen
import com.zafarcrickethub.zchnewscardstudio.ui.Screen
import com.zafarcrickethub.zchnewscardstudio.ui.SettingsScreen
import com.zafarcrickethub.zchnewscardstudio.ui.TemplatesScreen
import com.zafarcrickethub.zchnewscardstudio.ui.ThumbnailScreen
import com.zafarcrickethub.zchnewscardstudio.ui.ZchTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZchTheme { AppRoot(vm) } }
    }

    override fun onPause() {
        super.onPause()
        vm.saveNow() // protect against data loss when the app is backgrounded or killed
    }
}

@Composable
fun AppRoot(vm: MainViewModel) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let { snack.showSnackbar(it); vm.message = null }
    }
    BackHandler(enabled = vm.screen != Screen.Dashboard) { vm.back() }
    Box {
        when (vm.screen) {
            Screen.Dashboard -> DashboardScreen(vm)
            Screen.Projects -> ProjectsScreen(vm)
            Screen.Templates -> TemplatesScreen(vm)
            Screen.Exports -> ExportsScreen(vm)
            Screen.Settings -> SettingsScreen(vm)
            Screen.Help -> HelpScreen(vm)
            Screen.Editor -> EditorScreen(vm)
            Screen.Thumbnail -> ThumbnailScreen(vm)
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter))
    }
}
