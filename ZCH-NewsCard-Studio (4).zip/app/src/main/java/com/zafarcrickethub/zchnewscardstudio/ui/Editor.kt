package com.zafarcrickethub.zchnewscardstudio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Palette
import androidx.compose.runtime.produceState
import androidx.compose.ui.layout.ContentScale
import com.zafarcrickethub.zchnewscardstudio.data.pictures
import com.zafarcrickethub.zchnewscardstudio.graphics.Bmp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zafarcrickethub.zchnewscardstudio.audio.Playback
import com.zafarcrickethub.zchnewscardstudio.data.Opt
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.data.Samples
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportState
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportUi
import com.zafarcrickethub.zchnewscardstudio.renderer.Thumbs
import com.zafarcrickethub.zchnewscardstudio.utils.GeminiTts
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.floor
import com.zafarcrickethub.zchnewscardstudio.data.Card as NCard

@Composable
fun PlaybackLoop(pb: Playback) {
    LaunchedEffect(pb.playing) {
        if (pb.playing) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                pb.tick((now - last) / 1_000_000L)
                last = now
            }
        }
    }
}

@Composable
fun EditorScreen(vm: MainViewModel) {
    val p = vm.current ?: run { vm.go(Screen.Projects); return }
    PlaybackLoop(vm.playback)
    if (vm.showExport) { ExportScreen(vm, p); return }
    val ec = vm.editingCard
    if (ec != null) { CardEditor(vm, p, ec); return }
    var rename by remember { mutableStateOf(false) }
    if (rename) TextInputDialog("Rename project", p.name, { rename = false }) { vm.rename(p.id, it); rename = false }

    Column(Modifier.fillMaxSize().background(NavyDark)) {
        // 1 ─ top bar
        Row(Modifier.fillMaxWidth().background(NavyC).padding(horizontal = 2.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            Text(p.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, modifier = Modifier.weight(1f).clickable { rename = true })
            IconButton(onClick = { vm.undo() }, enabled = vm.undoCount > 0) { Icon(Icons.Default.Undo, "Undo", tint = if (vm.undoCount > 0) Color.White else Color.Gray) }
            IconButton(onClick = { vm.redo() }, enabled = vm.redoCount > 0) { Icon(Icons.Default.Redo, "Redo", tint = if (vm.redoCount > 0) Color.White else Color.Gray) }
            Button(
                onClick = { vm.playback.pause(); vm.showExport = true },
                colors = ButtonDefaults.buttonColors(containerColor = RedC),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)
            ) { Text("Export") }
            Spacer(Modifier.width(6.dp))
        }
        // 2 ─ preview
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF02060F)).padding(6.dp)) {
            FitPreview(p, { vm.playback.positionMs }, Modifier.fillMaxSize())
        }
        // 3 ─ play bar
        PlayBar(vm, p)
        // 4 ─ timeline
        TimelineView(vm, p, Modifier.fillMaxWidth())
        // 5 ─ tools
        EditorBar(vm, p)
    }
    SheetHost(vm, p)
}

@Composable
private fun PlayBar(vm: MainViewModel, p: Project) {
    val pb = vm.playback
    val total = Timing.totalMs(p).coerceAtLeast(1L)
    Row(Modifier.fillMaxWidth().background(NavyC).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Button(
            onClick = { pb.toggle() }, shape = CircleShape, contentPadding = PaddingValues(0.dp),
            colors = ButtonDefaults.buttonColors(containerColor = RedC), modifier = Modifier.size(44.dp)
        ) { Icon(if (pb.playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play / Pause") }
        Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
            Slider(
                value = pb.positionMs.toFloat().coerceIn(0f, total.toFloat()), onValueChange = { pb.seek(it.toLong()) },
                valueRange = 0f..total.toFloat()
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(Timing.fmt(pb.positionMs), style = MaterialTheme.typography.labelSmall)
                Text(Timing.fmt(total), style = MaterialTheme.typography.labelSmall)
            }
        }
        IconButton(onClick = { vm.zoomDp = (vm.zoomDp / 1.4f).coerceAtLeast(12f) }) { Icon(Icons.Default.ZoomOut, "Zoom out", tint = Color.White) }
        IconButton(onClick = { vm.zoomDp = (vm.zoomDp * 1.4f).coerceAtMost(500f) }) { Icon(Icons.Default.ZoomIn, "Zoom in", tint = Color.White) }
    }
}

@Composable
private fun BarButton(icon: ImageVector, label: String, modifier: Modifier, tint: Color = Color.White, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(26.dp))
        Text(label, fontSize = 11.sp, color = Color(0xFFDDE3F5), maxLines = 1)
    }
}

/** Five big buttons, always visible. Without a selection: add things. With a card selected: work on that card. */
@Composable
private fun EditorBar(vm: MainViewModel, p: Project) {
    val card = if (vm.sel.startsWith("card:")) p.cards.find { it.id == vm.sel.removePrefix("card:") } else null
    var confirmDelete by remember { mutableStateOf(false) }
    if (confirmDelete && card != null) ConfirmDialog("Delete this card?", { confirmDelete = false }) { vm.deleteCard(card.id) }
    Row(Modifier.fillMaxWidth().background(Color(0xFF0B1226))) {
        val w = Modifier.weight(1f)
        if (card != null) {
            BarButton(Icons.Default.Edit, "Edit", w) { vm.editingCard = card.id }
            BarButton(Icons.Default.Timer, "Time", w) { vm.sheet = "timing" }
            BarButton(Icons.Default.ContentCut, "Split", w) { vm.splitCard(card.id, vm.playback.positionMs) }
            BarButton(Icons.Default.ContentCopy, "Copy", w) { vm.duplicateCard(card.id) }
            BarButton(Icons.Default.Delete, "Delete", w, tint = Color(0xFFFF8A80)) { confirmDelete = true }
        } else {
            BarButton(Icons.Default.AddCircle, "Add card", w, tint = Color(0xFFFFC107)) { vm.sheet = "addcard" }
            BarButton(Icons.Default.Mic, "Voice", w) { vm.sheet = "voice" }
            BarButton(Icons.Default.AutoAwesome, "AI Script", w) { vm.sheet = "aiscript" }
            BarButton(Icons.Default.Palette, "Style", w) { vm.sheet = "style" }
            BarButton(Icons.Default.Timer, "Timing", w) { vm.sheet = "timing" }
        }
    }
}

// =====================================================================================
//  Timeline: ruler, card clips (with thumbnails) and the voice-over. Drag = scrub, white line = play-head.
// =====================================================================================
@Composable
private fun rememberCardThumbs(p: Project): Map<String, ImageBitmap> {
    val ctx = LocalContext.current
    val map = remember { mutableStateMapOf<String, ImageBitmap>() }
    val keys = remember { HashMap<String, Int>() }
    val sig = p.cards.map { it.id to it.copy(startMs = 0, endMs = 5000).hashCode() } + listOf("land" to p.settings.landscape.hashCode())
    LaunchedEffect(sig) {
        withContext(Dispatchers.Default) {
            for (c in p.cards) {
                val h = c.copy(startMs = 0, endMs = 5000).hashCode() * 31 + p.settings.landscape.hashCode()
                if (keys[c.id] != h) {
                    val bmp = runCatching { Thumbs.render(ctx, p, c, 240) }.getOrNull() ?: continue
                    keys[c.id] = h
                    withContext(Dispatchers.Main) { map[c.id] = bmp.asImageBitmap() }
                }
            }
        }
    }
    return map
}

@Composable
private fun TimelineView(vm: MainViewModel, p: Project, modifier: Modifier = Modifier) {
    val pb = vm.playback
    val density = LocalDensity.current.density
    val total = Timing.totalMs(p)
    val s = p.settings
    val thumbs = rememberCardThumbs(p)
    val wf = vm.waveform
    val pNow by rememberUpdatedState(p)

    val rulerH = 22f * density
    val cardH = 66f * density
    val audioH = 46f * density
    val gap = 5f * density
    val yCard = rulerH + gap
    val yAudio = yCard + cardH + gap
    val textPaint = remember(density) {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f * density; color = android.graphics.Color.WHITE }
    }
    val hues = remember { listOf(Color(0xFFB3213B), Color(0xFF9A7B0A), Color(0xFF2756B5), Color(0xFF1E8F5B), Color(0xFF7B3FA0), Color(0xFFB45A2E)) }

    fun selIdx(): Int {
        val sl = vm.sel
        return if (sl.startsWith("card:")) pNow.cards.indexOfFirst { it.id == sl.removePrefix("card:") } else -1
    }

    Canvas(
        modifier.height(((yAudio + audioH + gap) / density).dp).background(Color(0xFF0B1226))
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { o ->
                        val w = size.width.toFloat()
                        val ppm = vm.zoomDp * density / 1000f
                        val ms = pb.positionMs + (o.x - w / 2f) / ppm
                        val cards = pNow.cards
                        when {
                            o.y < yCard -> pb.seek(ms.toLong())
                            o.y < yAudio -> {
                                val c = cards.lastOrNull { ms >= it.startMs && ms <= it.endMs }
                                vm.sel = if (c != null) "card:" + c.id else ""
                                val last = cards.maxOfOrNull { it.endMs } ?: 0L
                                val plusX = w / 2f + (last - pb.positionMs) * ppm
                                if (c == null && o.x >= plusX && o.x <= plusX + 60f * density) vm.sheet = "addcard"
                            }
                            else -> vm.sheet = "voice"
                        }
                    },
                    onDoubleTap = { o ->
                        val w = size.width.toFloat()
                        val ppm = vm.zoomDp * density / 1000f
                        val ms = pb.positionMs + (o.x - w / 2f) / ppm
                        val c = pNow.cards.lastOrNull { ms >= it.startMs && ms <= it.endMs }
                        if (c != null && o.y >= yCard && o.y < yAudio) { vm.sel = "card:" + c.id; vm.editingCard = c.id }
                    }
                )
            }
            .pointerInput(Unit) {
                var mode = 0      // 0 = scrub, 1 = trim left edge, 2 = trim right edge
                var idx = -1
                var acc = 0f
                detectDragGestures(
                    onDragStart = { o ->
                        val w = size.width.toFloat()
                        val ppm = vm.zoomDp * density / 1000f
                        mode = 0; acc = 0f
                        val i = selIdx()
                        if (i >= 0 && o.y >= yCard && o.y < yAudio) {
                            val c = pNow.cards[i]
                            val xl = w / 2f + (c.startMs - pb.positionMs) * ppm
                            val xr = w / 2f + (c.endMs - pb.positionMs) * ppm
                            val hit = 30f * density
                            if (abs(o.x - xl) < hit && abs(o.x - xl) <= abs(o.x - xr)) { mode = 1; idx = i }
                            else if (abs(o.x - xr) < hit) { mode = 2; idx = i }
                        }
                        if (mode == 0) pb.pause()
                    },
                    onDragEnd = { mode = 0 },
                    onDragCancel = { mode = 0 }
                ) { change, drag ->
                    change.consume()
                    val w = size.width.toFloat()
                    val ppm = vm.zoomDp * density / 1000f
                    if (mode == 0) {
                        acc += -drag.x / ppm
                        val whole = acc.toLong()
                        acc -= whole
                        if (whole != 0L) pb.seek(pb.positionMs + whole)
                    } else {
                        val ms = pb.positionMs + (change.position.x - w / 2f) / ppm
                        vm.setEdge(idx, mode == 2, ms.toLong().coerceAtLeast(0L))
                    }
                }
            }
    ) {
        val w = size.width
        val ppm = vm.zoomDp * density / 1000f
        val cx = w / 2f
        val pos = pb.positionMs
        val sel = vm.sel
        fun xOf(ms: Long): Float = cx + (ms - pos) * ppm
        fun label(t: String, x: Float, y: Float, color: Int = android.graphics.Color.WHITE) {
            textPaint.color = color
            drawIntoCanvas { it.nativeCanvas.drawText(t, x, y, textPaint) }
        }
        val corner = CornerRadius(8f * density)

        // ruler
        drawRect(Color(0xFF111B36), Offset.Zero, Size(w, rulerH))
        val secPx = vm.zoomDp * density
        val stepMs = when { secPx >= 110f -> 1000L; secPx >= 55f -> 2000L; secPx >= 22f -> 5000L; else -> 10000L }
        val leftMs = pos - cx / ppm
        var t = (floor(leftMs / stepMs).toLong() * stepMs).coerceAtLeast(0L)
        val rightMs = pos + cx / ppm
        while (t <= rightMs && t <= total + stepMs) {
            val x = xOf(t)
            drawLine(Color(0xFF6C7BA8), Offset(x, rulerH - 8f * density), Offset(x, rulerH), 2f)
            label("${t / 60000}:${"%02d".format((t / 1000) % 60)}", x + 3f * density, rulerH - 10f * density, 0xFFB8C4E6.toInt())
            t += stepMs
        }

        // card clips
        drawRect(Color(0xFF0E1731), Offset(0f, yCard), Size(w, cardH))
        p.cards.forEachIndexed { i, c ->
            val x0 = xOf(c.startMs)
            val x1 = xOf(c.endMs)
            if (x1 < -40f || x0 > w + 40f) return@forEachIndexed
            val cw = (x1 - x0).coerceAtLeast(3f)
            drawRoundRect(hues[i % hues.size], Offset(x0, yCard), Size(cw, cardH), corner)
            val bmp = thumbs[c.id]
            if (bmp != null) {
                val tileW = (cardH * bmp.width / bmp.height).coerceAtLeast(8f)
                clipRect(x0, yCard, x0 + cw, yCard + cardH) {
                    var tx = x0
                    while (tx < x0 + cw) {
                        if (tx + tileW >= 0f && tx <= w) drawImage(image = bmp, dstOffset = IntOffset(tx.toInt(), yCard.toInt()), dstSize = IntSize(tileW.toInt(), cardH.toInt()))
                        tx += tileW
                    }
                    drawRect(Color(0xAA000000), Offset(x0, yCard), Size(cw, 16f * density))
                    label("${i + 1}  " + c.headline.replace('\n', ' ').take(24), x0 + 4f * density, yCard + 12f * density)
                }
            }
            val selected = sel == "card:" + c.id
            drawRoundRect(if (selected) Color.White else Color(0x66FFFFFF), Offset(x0, yCard), Size(cw, cardH), corner, style = Stroke(if (selected) 3f * density else 1f))
            if (selected) {
                val hw = 10f * density
                drawRoundRect(Color.White, Offset(x0 - 1f, yCard), Size(hw, cardH), CornerRadius(4f * density))
                drawRoundRect(Color.White, Offset(x1 - hw + 1f, yCard), Size(hw, cardH), CornerRadius(4f * density))
                drawLine(Color(0xFF333333), Offset(x0 + hw / 2f, yCard + cardH * 0.3f), Offset(x0 + hw / 2f, yCard + cardH * 0.7f), 2f)
                drawLine(Color(0xFF333333), Offset(x1 - hw / 2f + 1f, yCard + cardH * 0.3f), Offset(x1 - hw / 2f + 1f, yCard + cardH * 0.7f), 2f)
            }
        }
        // "+" button after the last card
        val lastEnd = p.cards.maxOfOrNull { it.endMs } ?: 0L
        val px = xOf(lastEnd) + 10f * density
        drawCircle(Color(0xFFFFC107), 18f * density, Offset(px + 18f * density, yCard + cardH / 2f))
        drawLine(Color.Black, Offset(px + 9f * density, yCard + cardH / 2f), Offset(px + 27f * density, yCard + cardH / 2f), 3f * density)
        drawLine(Color.Black, Offset(px + 18f * density, yCard + cardH / 2f - 9f * density), Offset(px + 18f * density, yCard + cardH / 2f + 9f * density), 3f * density)
        if (p.cards.isEmpty()) label("Tap + to add your first card", px + 44f * density, yCard + cardH / 2f + 4f * density, 0xFFB8C4E6.toInt())

        // voice-over
        if (s.audioPath != null) {
            val ax0 = xOf(0L)
            val ax1 = xOf(s.audioDurMs)
            drawRoundRect(Color(0xFF14636B), Offset(ax0, yAudio), Size((ax1 - ax0).coerceAtLeast(3f), audioH), corner)
            if (wf != null && wf.isNotEmpty()) {
                val bw = (ax1 - ax0) / wf.size
                for (i in wf.indices) {
                    val x = ax0 + (i + 0.5f) * bw
                    if (x < -2f || x > w + 2f) continue
                    val hh = wf[i] * audioH * 0.4f + 1f
                    drawLine(Color(0xDDFFFFFF), Offset(x, yAudio + audioH / 2f - hh), Offset(x, yAudio + audioH / 2f + hh), maxOf(1f, bw * 0.8f))
                }
            }
            clipRect(ax0, yAudio, ax1, yAudio + audioH) { label("🎙 Voice-over", maxOf(ax0, 0f) + 6f * density, yAudio + 13f * density) }
        } else {
            drawRoundRect(Color(0xFF1A2646), Offset(8f * density, yAudio), Size(w - 16f * density, audioH), corner)
            label("🎙 Tap here to add a voice-over", 18f * density, yAudio + audioH / 2f + 4f * density, 0xFFB8C4E6.toInt())
        }

        // end marker + play-head
        val ex1 = xOf(total)
        drawLine(Color(0x99FFC107), Offset(ex1, yCard), Offset(ex1, size.height), 2f)
        drawLine(Color.White, Offset(cx, 0f), Offset(cx, size.height), 2.5f * density)
        drawPath(Path().apply { moveTo(cx - 7f * density, 0f); lineTo(cx + 7f * density, 0f); lineTo(cx, 9f * density); close() }, Color.White)
    }
}

// =====================================================================================
//  Bottom sheets (only five): add card, voice, AI script, style, timing
// =====================================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SheetHost(vm: MainViewModel, p: Project) {
    val kind = vm.sheet
    if (kind.isEmpty()) return
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val card = if (vm.sel.startsWith("card:")) p.cards.find { it.id == vm.sel.removePrefix("card:") } else null
    ModalBottomSheet(onDismissRequest = { vm.sheet = "" }, sheetState = state, containerColor = SurfaceC) {
        Column(
            Modifier.padding(horizontal = 16.dp).padding(bottom = 28.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (kind) {
                "addcard" -> {
                    Text("Add a news card", style = MaterialTheme.typography.titleMedium, color = GoldC)
                    Text("TV news style", style = MaterialTheme.typography.titleSmall)
                    TemplateGrid(p, Opt.tvStyle) { t -> vm.addCard(t); vm.sheet = "" }
                    Text("Classic & match designs", style = MaterialTheme.typography.titleSmall)
                    TemplateGrid(p, Opt.classic) { t -> vm.addCard(t); vm.sheet = "" }
                }
                "voice" -> { Text("Voice-over", style = MaterialTheme.typography.titleMedium, color = GoldC); AudioPanel(vm, p) }
                "aiscript" -> { Text("AI Script → cards + voice-over", style = MaterialTheme.typography.titleMedium, color = GoldC); AiScriptPanel(vm, p) }
                "style" -> {
                    var t by remember { mutableStateOf(0) }
                    Text("Style", style = MaterialTheme.typography.titleMedium, color = GoldC)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Ticker", "Logo", "Format").forEachIndexed { i, n -> FilterChip(t == i, { t = i }, { Text(n) }) }
                    }
                    when (t) {
                        0 -> TickerPanel(vm, p)
                        1 -> BrandPanel(vm, p)
                        else -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(p.settings.landscape, { vm.updateSettings { it.copy(landscape = true) } }, { Text("16:9 landscape") })
                            FilterChip(!p.settings.landscape, { vm.updateSettings { it.copy(landscape = false) } }, { Text("9:16 portrait") })
                        }
                    }
                }
                "timing" -> {
                    if (card != null) {
                        Text("Card time", style = MaterialTheme.typography.titleMedium, color = GoldC)
                        TimingPanel(vm, p, card)
                    } else {
                        Text("Timing", style = MaterialTheme.typography.titleMedium, color = GoldC)
                        TimelineOptsPanel(vm, p)
                    }
                }
            }
            Button(onClick = { vm.sheet = "" }, modifier = Modifier.fillMaxWidth()) { Text("Done") }
        }
    }
}

@Composable
private fun TemplateGrid(p: Project, ids: List<Int>, onPick: (Int) -> Unit) {
    ids.chunked(2).forEach { rowIdx ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            rowIdx.forEach { i ->
                val sample = remember(i) { Samples.card(i) }
                Card(onClick = { onPick(i) }, modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = NavyC)) {
                    Column(Modifier.padding(6.dp)) {
                        CardThumb(p, sample, Modifier.fillMaxWidth(), 360)
                        Text(Opt.templates[i], style = MaterialTheme.typography.labelMedium, maxLines = 2, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
            if (rowIdx.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
private fun AiScriptPanel(vm: MainViewModel, p: Project) {
    val st by vm.settings.collectAsState()
    val clip = LocalClipboardManager.current
    var maxCards by remember { mutableStateOf(0f) }
    var tplMode by remember { mutableStateOf(0) }
    var single by remember { mutableStateOf(13) }
    var replace by remember { mutableStateOf(true) }
    var withVoice by remember { mutableStateOf(true) }
    var withTicker by remember { mutableStateOf(true) }
    var spread by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    Text("1. Paste the full news script.  2. AI makes the cards (and the voice-over).  3. You set each card's time with the play-head.", style = MaterialTheme.typography.bodySmall)
    if (st.geminiKey.isBlank() || showKey) GeminiKeyFields(vm)
    else Row(verticalAlignment = Alignment.CenterVertically) {
        Text("✓ API key saved", Modifier.weight(1f), color = Color(0xFF69F0AE))
        TextButton(onClick = { showKey = true }) { Text("API settings") }
    }
    RtlField("News script (Urdu / English)", vm.aiScript, { vm.aiScript = it }, minLines = 8)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = {
            val t = clip.getText()?.text
            if (t.isNullOrBlank()) vm.message = "Clipboard is empty" else vm.aiScript = t
        }) { Text("📋 Paste script") }
        if (vm.aiScript.isNotBlank()) OutlinedButton(onClick = { vm.aiScript = "" }) { Text("Clear") }
    }
    SliderRow("Number of cards", maxCards, 0f..12f, if (maxCards.toInt() == 0) "Auto" else "${maxCards.toInt()}") { maxCards = it }
    DropdownField("Templates", listOf("Best for each part (auto)", "TV news style (new 10)", "Classic designs", "One template for all"), tplMode, { tplMode = it })
    if (tplMode == 3) DropdownField("Template", Opt.templates, single, { single = it })
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(replace, { replace = it }); Text("  Replace the cards I already have", Modifier.weight(1f)) }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(withVoice, { withVoice = it }); Text("  Also create the voice-over", Modifier.weight(1f)) }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(withTicker, { withTicker = it }); Text("  Make the ticker text from the headlines", Modifier.weight(1f)) }
    if (withVoice) {
        OutlinedTextField(
            value = vm.ttsStyle, onValueChange = { vm.ttsStyle = it }, label = { Text("Speaking style (optional)") },
            placeholder = { Text("e.g. Read like a calm Urdu news anchor") }, modifier = Modifier.fillMaxWidth()
        )
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(spread, { spread = it }); Text("  Spread the cards evenly over the voice-over (starting point)", Modifier.weight(1f)) }
    }
    val tplArg = when (tplMode) { 0 -> -1; 1 -> -2; 2 -> -3; else -> single }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Button(onClick = { vm.generateFromScript(maxCards.toInt(), tplArg, replace, withVoice, withTicker, spread) }, enabled = !vm.aiBusy) {
            Text(if (vm.aiBusy) "Working…" else "✨ Create cards")
        }
        if (vm.aiBusy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
    }
    if (vm.aiStatus.isNotBlank()) Text(vm.aiStatus, color = Color(0xFFFFC107))
    Text(
        "The script is sent to Google with your own key (Settings has the key and model names). The AI only splits and shortens your text; check the cards before exporting. " +
            "After this, add pictures to each card and set the card times so they match the voice-over.",
        style = MaterialTheme.typography.bodySmall
    )
}

@Composable
fun TimingPanel(vm: MainViewModel, p: Project, c: NCard) {
    val id = c.id
    val dur = (c.endMs - c.startMs).coerceAtLeast(1L)
    val idx = p.cards.indexOfFirst { it.id == id }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Card ${idx + 1}", style = MaterialTheme.typography.labelLarge, color = Color(0xFFFFC107))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TimeField("Start", c.startMs, { v -> vm.setTiming(id, v, null) }, Modifier.weight(1f))
            TimeField("End", c.endMs, { v -> vm.setTiming(id, null, v) }, Modifier.weight(1f))
        }
        TimeField("Duration", dur, { v -> vm.setDuration(id, v) }, Modifier.fillMaxWidth())
        Text("Type a value and press Done (keyboard) or tap another field. Examples: 5   12.5   1:05   0:01:05.250", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.setTiming(id, vm.playback.positionMs, null) }, modifier = Modifier.weight(1f)) { Text("Start = play-head", fontSize = 12.sp) }
            OutlinedButton(onClick = { vm.setTiming(id, null, vm.playback.positionMs) }, modifier = Modifier.weight(1f)) { Text("End = play-head", fontSize = 12.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = { vm.nudge(id, -500, 0) }) { Text("Start −0.5s") }
            TextButton(onClick = { vm.nudge(id, 500, 0) }) { Text("Start +0.5s") }
            TextButton(onClick = { vm.nudge(id, 0, -500) }) { Text("End −0.5s") }
            TextButton(onClick = { vm.nudge(id, 0, 500) }) { Text("End +0.5s") }
        }
        if (idx > 0) OutlinedButton(onClick = { vm.startAfterPrevious(id) }, modifier = Modifier.fillMaxWidth()) { Text("Start right after previous card") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.moveCard(id, -1) }, enabled = idx > 0, modifier = Modifier.weight(1f)) { Text("◀ Move earlier") }
            OutlinedButton(onClick = { vm.moveCard(id, 1) }, enabled = idx < p.cards.size - 1, modifier = Modifier.weight(1f)) { Text("Move later ▶") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(p.settings.ripple, { v -> vm.updateSettings { it.copy(ripple = v) } })
            Text("  Move the following cards when I change the end time", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
        }
        Timing.validate(p.cards, p.settings.audioDurMs, p.settings.allowOverlap).filter { it.index == idx }.forEach {
            Text("⚠ ${it.text}", color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun AnimPanel(vm: MainViewModel, c: NCard) {
    val id = c.id
    DropdownField("Text animation", Opt.textAnims, c.textAnim, { v -> vm.updateCard(id) { it.copy(textAnim = v) } })
    DropdownField("Image animation", Opt.imageAnims, c.imageAnim, { v -> vm.updateCard(id) { it.copy(imageAnim = v) } })
    DropdownField("Exit animation (before card ends)", listOf("None") + Opt.textAnims, c.exitAnim, { v -> vm.updateCard(id) { it.copy(exitAnim = v) } })
    DropdownField("Looping effect", Opt.idleFx, c.idleFx, { v -> vm.updateCard(id) { it.copy(idleFx = v) } })
    DropdownField("Transition into this card", Opt.transitions, c.transition, { v -> vm.updateCard(id) { it.copy(transition = v) } })
    SliderRow("Transition length", c.transMs.toFloat(), 150f..2500f, "${c.transMs} ms") { v -> vm.updateCard(id) { it.copy(transMs = v.toInt()) } }
    SliderRow("Animation duration", c.animMs.toFloat(), 150f..2500f, "${c.animMs} ms") { v -> vm.updateCard(id) { it.copy(animMs = v.toInt()) } }
    SliderRow("Animation speed", c.animSpeed, 0.25f..3f, "x${"%.2f".format(c.animSpeed)}") { v -> vm.updateCard(id) { it.copy(animSpeed = v) } }
}

@Composable
private fun TickerPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(s.tickerStyle == 1, { vm.updateSettings { it.copy(tickerStyle = 1) } }, { Text("TV strip") })
        FilterChip(s.tickerStyle == 0, { vm.updateSettings { it.copy(tickerStyle = 0) } }, { Text("Label box") })
    }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(s.tickerOn, { v -> vm.updateSettings { it.copy(tickerOn = v) } }); Text("  Show ticker strip") }
    RtlField("Ticker text (Urdu / English)", s.tickerText, { v -> vm.updateSettings { it.copy(tickerText = v) } }, minLines = 2)
    RtlField("Label", s.tickerLabel, { v -> vm.updateSettings { it.copy(tickerLabel = v) } })
    SliderRow("Scrolling speed", s.tickerSpeed, 30f..400f, "${s.tickerSpeed.toInt()} px/s") { v -> vm.updateSettings { it.copy(tickerSpeed = v) } }
    SliderRow("Font size", s.tickerSize, 0.6f..1.6f, "${(s.tickerSize * 100).toInt()}%") { v -> vm.updateSettings { it.copy(tickerSize = v) } }
    ColorRow("Ticker text colour", s.tickerColor) { v -> vm.updateSettings { it.copy(tickerColor = v) } }
    ColorRow("Ticker background", s.tickerBg) { v -> vm.updateSettings { it.copy(tickerBg = v) } }
}

@Composable
private fun BrandPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importLogo(u) }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(s.showLogo, { v -> vm.updateSettings { it.copy(showLogo = v) } }); Text("  Show logo on every card") }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { pickLogo.launch(arrayOf("image/png", "image/webp")) }) { Text("Upload PNG logo") }
        if (s.logoPath != null) OutlinedButton(onClick = { vm.updateSettings { it.copy(logoPath = null) } }) { Text("Use default") }
    }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(s.showChannelName, { v -> vm.updateSettings { it.copy(showChannelName = v) } }); Text("  Show channel name") }
    RtlField("Channel name", s.channelName, { v -> vm.updateSettings { it.copy(channelName = v) } })
    SliderRow("Logo size", s.logoSize, 0.06f..0.4f, "${(s.logoSize * 100).toInt()}%") { v -> vm.updateSettings { it.copy(logoSize = v) } }
    SliderRow("Logo opacity", s.logoOpacity, 0.1f..1f, "${(s.logoOpacity * 100).toInt()}%") { v -> vm.updateSettings { it.copy(logoOpacity = v) } }
    Text("Logo position for all cards:")
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(Opt.logoPositions.indices.toList()) { i ->
            FilterChip(selected = false, onClick = { vm.mutate { pr -> pr.copy(cards = pr.cards.map { it.copy(logoPos = i) }) } }, label = { Text(Opt.logoPositions[i]) })
        }
    }
}

@Composable
private fun AudioPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importAudio(u) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { pick.launch(arrayOf("audio/*")) }) { Text(if (s.audioPath == null) "Import audio" else "Replace audio") }
        if (s.audioPath != null) OutlinedButton(onClick = { vm.removeAudio() }) { Text("Remove") }
    }
    if (s.audioPath != null) {
        Text("Length: ${Timing.fmt(s.audioDurMs)}", style = MaterialTheme.typography.bodySmall)
        SliderRow("Volume", s.volume, 0f..2f, "${(s.volume * 100).toInt()}%") { vm.setVolume(it) }
    } else Text("MP3, WAV, M4A or AAC. Without audio the video ends at the last card.", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(6.dp))
    AiVoiceSection(vm)
}

/** Google AI Studio key (paste), model and voice. Used in the voice-over sheet and in Settings. */
@Composable
fun GeminiKeyFields(vm: MainViewModel) {
    val st by vm.settings.collectAsState()
    val clip = LocalClipboardManager.current
    var show by remember { mutableStateOf(false) }
    var key by remember(st.geminiKey) { mutableStateOf(st.geminiKey) }
    OutlinedTextField(
        value = key, onValueChange = { v -> key = v; vm.updateAppSettings { s -> s.copy(geminiKey = v.trim()) } },
        label = { Text("Google AI Studio API key") }, singleLine = true,
        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
        modifier = Modifier.fillMaxWidth()
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = {
            val t = clip.getText()?.text?.trim()
            if (t.isNullOrBlank()) vm.message = "Clipboard is empty"
            else { key = t; vm.updateAppSettings { s -> s.copy(geminiKey = t) } }
        }) { Text("📋 Paste key") }
        TextButton(onClick = { show = !show }) { Text(if (show) "Hide" else "Show") }
        if (key.isNotBlank()) TextButton(onClick = { key = ""; vm.updateAppSettings { s -> s.copy(geminiKey = "") } }) { Text("Clear") }
    }
    Text("Get a free key at aistudio.google.com/apikey. It is stored only on this phone.", style = MaterialTheme.typography.bodySmall)
    OutlinedTextField(
        value = st.geminiModel, onValueChange = { v -> vm.updateAppSettings { s -> s.copy(geminiModel = v.trim()) } },
        label = { Text("TTS model") }, singleLine = true, modifier = Modifier.fillMaxWidth()
    )
    OutlinedTextField(
        value = st.geminiTextModel, onValueChange = { v -> vm.updateAppSettings { s -> s.copy(geminiTextModel = v.trim()) } },
        label = { Text("Script → cards model (text)") }, singleLine = true, modifier = Modifier.fillMaxWidth()
    )
    DropdownField("Quick pick model", GeminiTts.models, GeminiTts.models.indexOf(st.geminiModel).coerceAtLeast(0), { i -> vm.updateAppSettings { s -> s.copy(geminiModel = GeminiTts.models[i]) } })
    DropdownField("Voice", GeminiTts.voices, GeminiTts.voices.indexOf(st.geminiVoice).coerceAtLeast(0), { i -> vm.updateAppSettings { s -> s.copy(geminiVoice = GeminiTts.voices[i]) } })
}

@Composable
private fun AiVoiceSection(vm: MainViewModel) {
    Text("🤖 Create a voice-over with AI (online, optional)", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
    GeminiKeyFields(vm)
    OutlinedTextField(
        value = vm.ttsStyle, onValueChange = { vm.ttsStyle = it },
        label = { Text("Speaking style (optional)") }, placeholder = { Text("e.g. Read like a calm Urdu news anchor") },
        modifier = Modifier.fillMaxWidth()
    )
    RtlField("Voice-over script (Urdu / English)", vm.ttsScript, { vm.ttsScript = it }, minLines = 5)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { vm.scriptFromCards() }) { Text("Fill from cards") }
        Button(onClick = { vm.generateVoice() }, enabled = !vm.ttsBusy) { Text(if (vm.ttsBusy) "Generating…" else "Generate voice-over") }
        if (vm.ttsBusy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
    }
    Text(
        "The script is sent to Google with your own key; the result is saved as the project's voice-over (replacing the current one). " +
            "Urdu (ur-PK) is a preview language in Gemini TTS, so listen to the result. Everything else in the app stays offline.",
        style = MaterialTheme.typography.bodySmall
    )
}

@Composable
private fun TimelineOptsPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    val total = Timing.totalMs(p)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(s.allowOverlap, { v -> vm.updateSettings { it.copy(allowOverlap = v) } })
        Text("  Allow overlapping cards (transitions)", Modifier.weight(1f))
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(s.ripple, { v -> vm.updateSettings { it.copy(ripple = v) } })
        Text("  Move following cards when I change a card's end time", Modifier.weight(1f))
    }
    OutlinedButton(onClick = { vm.distribute() }, modifier = Modifier.fillMaxWidth()) {
        Text("Distribute cards evenly over ${Timing.fmt(if (s.audioDurMs > 0) s.audioDurMs else p.cards.size * 5000L)}")
    }
    DropdownField("Video ends at", listOf("End of voice-over", "End of last card", "Custom time"), s.endMode, { v -> vm.updateSettings { it.copy(endMode = v) } })
    if (s.endMode == 2) TimeField("Custom end", if (s.customEndMs > 0) s.customEndMs else total, { v -> vm.updateSettings { it.copy(customEndMs = v) } })
    Timing.validate(p.cards, s.audioDurMs, s.allowOverlap).forEach { Text("⚠ ${it.text}", color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall) }
    Text("All cards", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
    p.cards.forEachIndexed { i, c ->
        Card(colors = CardDefaults.cardColors(containerColor = NavyC)) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Card ${i + 1}: ${c.headline.take(40)}", maxLines = 1)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TimeField("Start", c.startMs, { v -> vm.setTiming(c.id, v, null) }, Modifier.weight(1f))
                    TimeField("End", c.endMs, { v -> vm.setTiming(c.id, null, v) }, Modifier.weight(1f))
                }
                TimeField("Duration", c.endMs - c.startMs, { v -> vm.setDuration(c.id, v) }, Modifier.fillMaxWidth())
            }
        }
    }
}

// =====================================================================================
//  Card editor: preview on top, five simple tabs underneath
// =====================================================================================
@Composable
private fun PathThumb(path: String, modifier: Modifier = Modifier) {
    val bmp by produceState<ImageBitmap?>(null, path) { value = withContext(Dispatchers.Default) { Bmp.load(path, 300)?.asImageBitmap() } }
    Box(modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF1B2A55)), contentAlignment = Alignment.Center) {
        bmp?.let { androidx.compose.foundation.Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable
private fun PicturesPanel(vm: MainViewModel, c: NCard) {
    val id = c.id
    val pickMany = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list -> if (list.isNotEmpty()) vm.importPictures(id, list) }
    var extraSlot by remember { mutableStateOf(0) }
    val pickExtra = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importExtraImage(id, extraSlot, u) }
    val pics = c.pictures()
    val slots = Opt.extraSlots(c.template)
    Text("Pictures in this card: ${pics.size}  (no limit)", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
    Button(onClick = { pickMany.launch(arrayOf("image/jpeg", "image/png", "image/webp")) }) {
        Icon(Icons.Default.AddCircle, null); Text("  Add pictures (select many)")
    }
    if (pics.isNotEmpty()) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(pics) { i, path ->
                Box(Modifier.size(120.dp, 86.dp)) {
                    PathThumb(path, Modifier.fillMaxSize())
                    if (i == 0) Text("MAIN", fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomStart).background(Color(0xAA000000)).padding(horizontal = 4.dp))
                    else TextButton(onClick = { vm.makePictureFirst(id, i) }, modifier = Modifier.align(Alignment.BottomStart)) { Text("Make main", fontSize = 10.sp) }
                    IconButton(onClick = { vm.removePicture(id, i) }, modifier = Modifier.align(Alignment.TopEnd).size(30.dp)) {
                        Icon(Icons.Default.Close, "Remove", tint = Color.White, modifier = Modifier.background(Color(0x99000000), CircleShape))
                    }
                }
            }
        }
        if (pics.size > 1) {
            Text("The card's time is shared equally between the pictures; they change one after another.", style = MaterialTheme.typography.bodySmall)
            DropdownField("Change between pictures", Opt.slideFx, c.slideFx, { v -> vm.updateCard(id) { it.copy(slideFx = v) } })
        }
        SliderRow("Main picture zoom / crop", c.imgScale, 1f..3f, "x${"%.2f".format(c.imgScale)}") { v -> vm.updateCard(id) { it.copy(imgScale = v) } }
        SliderRow("Position left ↔ right", c.imgX, -1f..1f, "%.2f".format(c.imgX)) { v -> vm.updateCard(id) { it.copy(imgX = v) } }
        SliderRow("Position up ↕ down", c.imgY, -1f..1f, "%.2f".format(c.imgY)) { v -> vm.updateCard(id) { it.copy(imgY = v) } }
    }
    if (slots > 0) {
        Text("Small match pictures used by this template", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
        for (slot in 0 until slots) {
            val has = c.extraImages.getOrNull(slot)?.isNotBlank() == true
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { extraSlot = slot; pickExtra.launch(arrayOf("image/jpeg", "image/png", "image/webp")) }) { Text(if (has) "Replace picture ${slot + 2}" else "Add picture ${slot + 2}") }
                if (has) OutlinedButton(onClick = { vm.removeExtraImage(id, slot) }) { Text("Remove") }
            }
        }
    }
}

@Composable
fun CardEditor(vm: MainViewModel, p: Project, id: String) {
    val c = p.cards.find { it.id == id } ?: run { vm.editingCard = null; return }
    var tab by remember { mutableStateOf(0) }
    val dur = (c.endMs - c.startMs).coerceAtLeast(1L)
    var t by remember { mutableStateOf(dur.toFloat()) }
    var anim by remember { mutableStateOf(false) }
    LaunchedEffect(anim, c.id) {
        if (anim) {
            var last = withFrameNanos { it }
            t = 0f
            while (anim) {
                val now = withFrameNanos { it }
                t += (now - last) / 1_000_000f; last = now
                if (t > dur) { t = dur.toFloat(); anim = false }
            }
        }
    }
    val solo = remember(p, c) { p.copy(cards = listOf(c.copy(startMs = 0, endMs = dur))) }
    val tpl = c.template
    ScreenScaffold("Edit card", { vm.editingCard = null }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Box(Modifier.fillMaxWidth().height(210.dp).background(Color(0xFF02060F)).padding(4.dp)) {
                FitPreview(solo, { t.toLong() }, Modifier.fillMaxSize())
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { anim = true }) { Icon(Icons.Default.PlayArrow, "Play animation", tint = Color(0xFFFFC107)) }
                Slider(value = t, onValueChange = { anim = false; t = it }, valueRange = 0f..dur.toFloat(), modifier = Modifier.weight(1f))
            }
            LazyRow(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(listOf("Text", "Pictures", "Look", "Motion", "Time")) { i, n -> FilterChip(tab == i, { tab = i }, { Text(n) }) }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (tab) {
                    0 -> {
                        DropdownField("Template", Opt.templates, tpl, { v -> vm.updateCard(id) { it.copy(template = v) } })
                        RtlField("Headline (Urdu / English)", c.headline, { v -> vm.updateCard(id) { it.copy(headline = v) } }, minLines = 2)
                        if (tpl !in listOf(2, 5, 9, 11)) RtlField(if (tpl == 22) "Kicker (small label above the bar)" else "Description", c.description, { v -> vm.updateCard(id) { it.copy(description = v) } }, minLines = 2)
                        if (tpl in listOf(2, 5, 9, 11, 16, 17)) {
                            RtlField("Team 1", c.team1, { v -> vm.updateCard(id) { it.copy(team1 = v) } })
                            RtlField("Team 2", c.team2, { v -> vm.updateCard(id) { it.copy(team2 = v) } })
                        }
                        if (tpl in listOf(2, 5, 9, 17)) {
                            RtlField("Score (e.g. 182/4)", c.score, { v -> vm.updateCard(id) { it.copy(score = v) } })
                            RtlField("Overs", c.overs, { v -> vm.updateCard(id) { it.copy(overs = v) } })
                            RtlField("Wickets", c.wickets, { v -> vm.updateCard(id) { it.copy(wickets = v) } })
                        }
                        if (tpl in listOf(2, 5, 9)) RtlField("Match status", c.status, { v -> vm.updateCard(id) { it.copy(status = v) } })
                        if (tpl == 6 || tpl == 11) {
                            RtlField("Player name", c.playerName, { v -> vm.updateCard(id) { it.copy(playerName = v) } })
                            RtlField("Statistics (one per line, e.g. Runs: 85)", c.stats, { v -> vm.updateCard(id) { it.copy(stats = v) } }, minLines = 4)
                        }
                        SliderRow("Text size", c.textScale, 0.5f..1.6f, "${(c.textScale * 100).toInt()}%") { v -> vm.updateCard(id) { it.copy(textScale = v) } }
                        RtlField("Ticker text for this card (empty = project ticker)", c.tickerText, { v -> vm.updateCard(id) { it.copy(tickerText = v) } }, minLines = 2)
                    }
                    1 -> PicturesPanel(vm, c)
                    2 -> {
                        ColorRow("Text colour", c.textColor) { v -> vm.updateCard(id) { it.copy(textColor = v) } }
                        ColorRow("Background / tint colour", c.bgColor) { v -> vm.updateCard(id) { it.copy(bgColor = v) } }
                        DropdownField("Logo position", Opt.logoPositions, c.logoPos, { v -> vm.updateCard(id) { it.copy(logoPos = v) } })
                    }
                    3 -> AnimPanel(vm, c)
                    else -> TimingPanel(vm, p, c)
                }
            }
        }
    }
}

// =====================================================================================
//  Export screen
// =====================================================================================
@Composable
private fun ExportScreen(vm: MainViewModel, p: Project) {
    ScreenScaffold("Export video", { vm.showExport = false }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) { ExportTab(vm, p) }
    }
}

@Composable
fun ExportTab(vm: MainViewModel, p: Project) {
    val ctx = LocalContext.current
    val st by vm.settings.collectAsState()
    val state by ExportState.state.collectAsState()
    var res by remember(st.resolution) { mutableStateOf(st.resolution) }
    var fps by remember(st.fps) { mutableStateOf(st.fps) }
    var quality by remember { mutableStateOf(1) }
    var aq by remember { mutableStateOf(1) }
    var name by remember(p.id) { mutableStateOf("ZCH_" + p.name.replace(Regex("[^\\p{L}\\p{N}]+"), "_")) }
    val land = p.settings.landscape
    val total = Timing.totalMs(p)
    val longSide = if (res == 720) 1280 else 1920
    val w = if (land) longSide else res
    val h = if (land) res else longSide
    val baseBr = if (res == 720) intArrayOf(2_500_000, 4_000_000, 6_000_000) else intArrayOf(5_000_000, 8_000_000, 12_000_000)
    val vbr = (baseBr[quality] * fps / 30.0).toInt()
    val abr = intArrayOf(96_000, 128_000, 192_000)[aq]
    val legacyPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val needLegacy = android.os.Build.VERSION.SDK_INT < 29
    val running = state is ExportUi.Running
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Export settings", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFC107))
        Text("Resolution")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(720, 1080).forEach { r -> FilterChip(res == r, { res = r }, { Text("${r}p") }) } }
        Text("Aspect ratio")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(land, { vm.updateSettings { it.copy(landscape = true) } }, { Text("16:9") })
            FilterChip(!land, { vm.updateSettings { it.copy(landscape = false) } }, { Text("9:16") })
        }
        Text("Frame rate")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(24, 25, 30).forEach { f -> FilterChip(fps == f, { fps = f }, { Text("$f fps") }) } }
        DropdownField("Video quality", listOf("Low (small file)", "Medium", "High"), quality, { quality = it })
        DropdownField("Audio quality", listOf("96 kbps", "128 kbps", "192 kbps"), aq, { aq = it })
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Output file name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        val mb = (((vbr + abr) / 8.0) * total / 1000.0 / 1_000_000)
        Text("Output: ${w}×${h}, $fps fps, about ${"%.1f".format(mb)} MB, ${Timing.fmt(total)} long")
        if (total > 10 * 60_000L) Text("⚠ Long project: export may take a long time and a lot of storage.", color = Color(0xFFFFC107))
        if (res == 1080) Text("⚠ 1080p needs more time/memory on older phones. Use 720p if the export fails.", color = Color(0xFFFFC107), style = MaterialTheme.typography.bodySmall)
        if (p.cards.isEmpty()) Text("Add at least one card first.", color = Color(0xFFFF8A80))

        when (val s = state) {
            is ExportUi.Running -> {
                LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                Text("${(s.progress * 100).toInt()}%  ${s.msg}")
                Button(onClick = { vm.cancelExport() }) { Text("Cancel export") }
            }
            is ExportUi.Done -> {
                Text("✅ Export finished: Movies/ZCH NewsCard Studio", color = Color(0xFF69F0AE))
                Text("Find it in Recent Exports to play, share or delete.", style = MaterialTheme.typography.bodySmall)
            }
            is ExportUi.Failed -> Text("❌ Export failed: ${s.msg}", color = Color(0xFFFF8A80))
            ExportUi.Cancelled -> Text("Export cancelled.")
            ExportUi.Idle -> {}
        }
        if (p.exportStatus == "interrupted") Text("The previous export was interrupted. Start again to retry.", color = Color(0xFFFFC107))
        Button(enabled = !running && p.cards.isNotEmpty(), modifier = Modifier.fillMaxWidth(), onClick = {
            if (android.os.Build.VERSION.SDK_INT >= 33) notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            val ok = !needLegacy || androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (ok) vm.startExport(w, h, fps, vbr, abr, name, land, p.settings.endMode, p.settings.customEndMs)
            else {
                legacyPerm.launch(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE))
                vm.message = "Allow storage access, then press Export again"
            }
        }) { Text("Export MP4") }
        if (p.exports.isNotEmpty()) TextButton(onClick = { vm.go(Screen.Exports) }) { Text("Open Recent Exports") }
    }
}
