plugins {
    id("com.android.application")
    // No "org.jetbrains.kotlin.android" here: AGP 9 has built-in Kotlin support.
    id("org.jetbrains.kotlin.plugin.serialization")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.zafarcrickethub.zchnewscardstudio"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.zafarcrickethub.zchnewscardstudio"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    val ksFile: String? = System.getenv("KEYSTORE_FILE")
    val hasSigning = ksFile != null && File(ksFile).exists()
    if (hasSigning) {
        signingConfigs {
            create("release") {
                storeFile = file(ksFile!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (hasSigning) signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    // Kotlin jvmTarget follows compileOptions.targetCompatibility (17) automatically with built-in Kotlin.
    buildFeatures { compose = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")
    // Room 2.8.x: first line with proper KSP2 support (needed with Kotlin 2.x / KSP 2.3.x)
    implementation("androidx.room:room-runtime:2.8.5")
    implementation("androidx.room:room-ktx:2.8.5")
    ksp("androidx.room:room-compiler:2.8.5")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("androidx.core:core-splashscreen:1.0.1")
    // FFmpeg (community-maintained FFmpegKit fork, LGPL, free build from Maven Central). Used as a fallback to
    // convert audio formats the phone cannot decode. The CI workflow retries without it (-PwithFfmpeg=false) if it cannot be resolved.
    if (project.findProperty("withFfmpeg")?.toString() != "false") {
        implementation("dev.ffmpegkit-maintained:ffmpeg:8.1.7")
        implementation("com.arthenica:smart-exception-java:0.2.1")
    }
    testImplementation("junit:junit:4.13.2")
}
