package com.zafarcrickethub.zchnewscardstudio.utils

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

object MediaSaver {
    const val FOLDER = "ZCH NewsCard Studio"

    /** Saves into Movies/ZCH NewsCard Studio (video) or Pictures/ZCH NewsCard Studio (image). */
    fun save(ctx: Context, src: File, name: String, mime: String, isVideo: Boolean): Uri? {
        val base = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
        val coll = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$base/$FOLDER")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            } else {
                val d = File(Environment.getExternalStoragePublicDirectory(base), FOLDER).apply { mkdirs() }
                put(MediaStore.MediaColumns.DATA, File(d, name).path)
            }
        }
        val uri = ctx.contentResolver.insert(coll, cv) ?: return null
        ctx.contentResolver.openOutputStream(uri)?.use { o -> src.inputStream().use { it.copyTo(o) } }
        if (Build.VERSION.SDK_INT >= 29) {
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            ctx.contentResolver.update(uri, done, null, null)
        }
        return uri
    }

    fun delete(ctx: Context, uri: String): Boolean =
        try { ctx.contentResolver.delete(Uri.parse(uri), null, null) > 0 } catch (e: Exception) { false }
}
