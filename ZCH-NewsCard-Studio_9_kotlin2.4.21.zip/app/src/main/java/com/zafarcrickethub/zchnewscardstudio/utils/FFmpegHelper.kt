package com.zafarcrickethub.zchnewscardstudio.utils

/**
 * Thin wrapper around FFmpegKit (community-maintained fork, package com.arthenica.ffmpegkit).
 * Reflection keeps the app safe: if the native library is missing (e.g. a 32-bit phone) the call just returns false.
 */
object FFmpegHelper {
    val available: Boolean
        get() = try { Class.forName("com.arthenica.ffmpegkit.FFmpegKit"); true } catch (t: Throwable) { false }

    /** Converts any audio (or the audio of a video) to 44.1 kHz stereo WAV. Blocking. */
    fun toWav(input: String, output: String): Boolean = try {
        val kit = Class.forName("com.arthenica.ffmpegkit.FFmpegKit")
        val session = kit.getMethod("execute", String::class.java).invoke(null, "-y -i \"$input\" -vn -ar 44100 -ac 2 -c:a pcm_s16le \"$output\"")
        val rc = session!!.javaClass.getMethod("getReturnCode").invoke(session)
        val rcClass = Class.forName("com.arthenica.ffmpegkit.ReturnCode")
        rcClass.getMethod("isSuccess", rcClass).invoke(null, rc) as Boolean
    } catch (t: Throwable) {
        false
    }
}
