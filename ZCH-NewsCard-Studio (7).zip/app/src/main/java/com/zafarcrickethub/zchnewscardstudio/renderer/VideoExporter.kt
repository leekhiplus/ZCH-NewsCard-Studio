package com.zafarcrickethub.zchnewscardstudio.renderer

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import com.zafarcrickethub.zchnewscardstudio.audio.AudioUtils
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.ceil

class ExportCancelled : RuntimeException("Export cancelled")

class ExportParams(
    val projectId: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val videoBitrate: Int,
    val audioBitrate: Int,
    val fileName: String,
    val landscape: Boolean,
    val endMode: Int,
    val customEndMs: Long,
    val soft: Boolean = false     // compatibility mode: software canvas (slower, works everywhere)
)

/**
 * Streaming MP4 export: every frame is drawn by FrameRenderer straight into the H.264
 * encoder's input surface (no frames kept in memory), the voice-over is decoded -> volume
 * applied -> AAC encoded, and both are muxed into one MP4.
 */
class VideoExporter(
    private val ctx: Context,
    private val project: Project,
    private val prm: ExportParams,
    private val progress: (Float, String) -> Unit,
    private val cancelled: () -> Boolean
) {
    private val abort = AtomicBoolean(false)
    private fun stop() = abort.get() || cancelled()

    fun run(): File {
        val dir = File(ctx.cacheDir, "export").apply { mkdirs() }
        val stamp = System.nanoTime()
        val vTmp = File(dir, "v_$stamp.mp4")
        val aTmp = File(dir, "a_$stamp.m4a")
        val out = File(dir, "out_$stamp.mp4")
        try {
            val totalMs = Timing.totalMs(project)
            val audio = project.settings.audioPath
            val hasAudio = audio != null && File(audio).exists()
            // The voice-over is encoded on its own thread while the GPU renders the frames.
            var audioError: Throwable? = null
            val audioThread = if (hasAudio) Thread { try { encodeAudio(audio!!, aTmp, totalMs) } catch (t: Throwable) { audioError = t } }.also { it.start() } else null
            try {
                encodeVideo(vTmp, totalMs)
            } catch (t: Throwable) {
                abort.set(true)
                throw t
            } finally {
                audioThread?.join()
            }
            audioError?.let { throw it }
            progress(0.97f, "Finalising MP4")
            merge(vTmp, if (hasAudio) aTmp else null, out, totalMs)
            progress(1f, "Done")
            return out
        } catch (e: Throwable) {
            out.delete()
            throw e
        } finally {
            vTmp.delete(); aTmp.delete()
        }
    }

    // ------------------------------------------------------------------ video
    private fun encodeVideo(file: File, totalMs: Long) {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, prm.width, prm.height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, prm.videoBitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, prm.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface()
        enc.start()
        val muxer = MediaMuxer(file.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var started = false
        var outCount = 0L
        val info = MediaCodec.BufferInfo()

        fun drain(eos: Boolean) {
            var idle = 0
            while (true) {
                val i = enc.dequeueOutputBuffer(info, if (eos) 10_000L else 0L)
                if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!eos) return
                    if (++idle > 3000) throw IllegalStateException("Video encoder did not finish")
                } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(enc.outputFormat); muxer.start(); started = true
                } else if (i >= 0) {
                    idle = 0
                    val buf = enc.getOutputBuffer(i)!!
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && started) {
                        // Canvas-surface timestamps are wall-clock; use exact frame time instead.
                        info.presentationTimeUs = outCount * 1_000_000L / prm.fps
                        outCount++
                        buf.position(info.offset); buf.limit(info.offset + info.size)
                        muxer.writeSampleData(track, buf, info)
                    }
                    enc.releaseOutputBuffer(i, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }

        try {
            val renderer = FrameRenderer(ctx, project.copy(settings = project.settings.copy(landscape = prm.landscape)))
            val totalFrames = ceil(totalMs / 1000.0 * prm.fps).toInt().coerceAtLeast(1)
            var hw = !prm.soft
            for (f in 0 until totalFrames) {
                if (cancelled()) throw ExportCancelled()
                val tMs = f * 1000L / prm.fps
                val canvas = if (hw) {
                    try { surface.lockHardwareCanvas() } catch (e: Exception) { hw = false; surface.lockCanvas(null) }
                } else surface.lockCanvas(null)
                try {
                    renderer.render(canvas, prm.width, prm.height, tMs)
                } finally {
                    surface.unlockCanvasAndPost(canvas)
                }
                drain(false)
                if (f % 4 == 0) progress(f.toFloat() / totalFrames * 0.95f, "Rendering frame ${f + 1}/$totalFrames")
            }
            enc.signalEndOfInputStream()
            drain(true)
        } finally {
            try { enc.stop() } catch (_: Exception) {}
            enc.release()
            surface.release()
            try { if (started) muxer.stop() } catch (_: Exception) {}
            muxer.release()
        }
    }

    // ------------------------------------------------------------------ audio
    private class Pcm(val data: ByteArray, var off: Int)

    private fun encodeAudio(path: String, file: File, totalMs: Long) {
        val ex = MediaExtractor()
        ex.setDataSource(path)
        val t = AudioUtils.audioTrack(ex)
        if (t < 0) { ex.release(); return }
        ex.selectTrack(t)
        val inFmt = ex.getTrackFormat(t)
        val srcDurUs = if (inFmt.containsKey(MediaFormat.KEY_DURATION)) inFmt.getLong(MediaFormat.KEY_DURATION) else totalMs * 1000
        val dec = MediaCodec.createDecoderByType(inFmt.getString(MediaFormat.KEY_MIME)!!)
        dec.configure(inFmt, null, null, 0)
        dec.start()
        val muxer = MediaMuxer(file.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var enc: MediaCodec? = null
        var track = -1
        var muxStarted = false
        var sampleRate = 44100
        var channels = 2
        var samplesFed = 0L
        val vol = project.settings.volume
        val limitUs = totalMs * 1000L
        val pending = ArrayDeque<Pcm>()
        val dInfo = MediaCodec.BufferInfo()
        val eInfo = MediaCodec.BufferInfo()
        var decInDone = false
        var decOutDone = false
        var encInDone = false
        var encDone = false

        fun ensureEncoder(f: MediaFormat) {
            if (enc != null) return
            sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val ef = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, prm.audioBitrate)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 65536)
            }
            enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).also {
                it.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); it.start()
            }
        }

        try {
            while (!encDone) {
                if (stop()) throw ExportCancelled()
                if (!decInDone) {
                    val i = dec.dequeueInputBuffer(0)
                    if (i >= 0) {
                        val n = ex.readSampleData(dec.getInputBuffer(i)!!, 0)
                        if (n < 0) {
                            dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); decInDone = true
                        } else {
                            dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance()
                        }
                    }
                }
                if (!decOutDone && pending.size < 6) {
                    val o = dec.dequeueOutputBuffer(dInfo, 0)
                    if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        ensureEncoder(dec.outputFormat)
                    } else if (o >= 0) {
                        ensureEncoder(dec.outputFormat)
                        if (dInfo.size > 0) {
                            val bb = dec.getOutputBuffer(o)!!
                            bb.position(dInfo.offset); bb.limit(dInfo.offset + dInfo.size)
                            val bytes = ByteArray(dInfo.size)
                            bb.get(bytes)
                            if (vol != 1f) {
                                val sb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                                for (k in 0 until sb.limit()) sb.put(k, (sb.get(k) * vol).toInt().coerceIn(-32768, 32767).toShort())
                            }
                            pending.addLast(Pcm(bytes, 0))
                        }
                        dec.releaseOutputBuffer(o, false)
                        if ((dInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) decOutDone = true
                    }
                }
                val e = enc
                if (e != null && !encInDone) {
                    val i = e.dequeueInputBuffer(0)
                    if (i >= 0) {
                        val ptsUs = samplesFed * 1_000_000L / sampleRate
                        if (pending.isNotEmpty() && ptsUs < limitUs) {
                            val buf = e.getInputBuffer(i)!!
                            buf.clear()
                            val chunk = pending.first()
                            val n = minOf(buf.remaining(), chunk.data.size - chunk.off)
                            buf.put(chunk.data, chunk.off, n)
                            chunk.off += n
                            if (chunk.off >= chunk.data.size) pending.removeFirst()
                            e.queueInputBuffer(i, 0, n, ptsUs, 0)
                            samplesFed += n / (2L * channels)
                        } else if ((decOutDone && pending.isEmpty()) || ptsUs >= limitUs) {
                            e.queueInputBuffer(i, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM); encInDone = true
                        }
                    }
                }
                if (e != null) {
                    val o = e.dequeueOutputBuffer(eInfo, 5000)
                    if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = muxer.addTrack(e.outputFormat); muxer.start(); muxStarted = true
                    } else if (o >= 0) {
                        val ob = e.getOutputBuffer(o)!!
                        if ((eInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) eInfo.size = 0
                        if (eInfo.size > 0 && muxStarted) {
                            ob.position(eInfo.offset); ob.limit(eInfo.offset + eInfo.size)
                            muxer.writeSampleData(track, ob, eInfo)
                        }
                        e.releaseOutputBuffer(o, false)
                        if ((eInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) encDone = true
                    }
                } else if (decOutDone) {
                    encDone = true // decoder produced nothing
                }
            }
        } finally {
            try { dec.stop() } catch (_: Exception) {}
            dec.release()
            try { enc?.stop() } catch (_: Exception) {}
            try { enc?.release() } catch (_: Exception) {}
            try { if (muxStarted) muxer.stop() } catch (_: Exception) {}
            muxer.release()
            ex.release()
        }
    }

    // ------------------------------------------------------------------ mux
    private fun firstTrack(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith(prefix) == true) return i
        }
        return -1
    }

    private fun merge(video: File, audio: File?, out: File, totalMs: Long) {
        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val vEx = MediaExtractor().apply { setDataSource(video.path) }
        val vi = firstTrack(vEx, "video/")
        vEx.selectTrack(vi)
        val vt = muxer.addTrack(vEx.getTrackFormat(vi))
        var aEx: MediaExtractor? = null
        var at = -1
        if (audio != null && audio.exists() && audio.length() > 0) {
            val e = MediaExtractor().apply { setDataSource(audio.path) }
            val ai = firstTrack(e, "audio/")
            if (ai >= 0) { e.selectTrack(ai); at = muxer.addTrack(e.getTrackFormat(ai)); aEx = e } else e.release()
        }
        muxer.start()
        try {
            copy(vEx, muxer, vt, Long.MAX_VALUE)
            if (aEx != null) copy(aEx, muxer, at, totalMs * 1000L)
        } finally {
            try { muxer.stop() } catch (_: Exception) {}
            muxer.release(); vEx.release(); aEx?.release()
        }
    }

    private fun copy(ex: MediaExtractor, muxer: MediaMuxer, track: Int, limitUs: Long) {
        val buf = ByteBuffer.allocate(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        while (true) {
            if (cancelled()) throw ExportCancelled()
            buf.clear()
            val n = ex.readSampleData(buf, 0)
            if (n < 0 || ex.sampleTime > limitUs) break
            info.set(0, n, ex.sampleTime, if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
            muxer.writeSampleData(track, buf, info)
            ex.advance()
        }
    }
}
