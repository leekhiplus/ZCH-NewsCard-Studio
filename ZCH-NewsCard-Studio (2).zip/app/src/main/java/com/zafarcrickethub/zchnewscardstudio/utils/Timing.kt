package com.zafarcrickethub.zchnewscardstudio.utils

import com.zafarcrickethub.zchnewscardstudio.data.Card
import com.zafarcrickethub.zchnewscardstudio.data.Project
import java.util.Locale

object Timing {
    data class Issue(val index: Int, val text: String)

    fun lastEnd(p: Project): Long = p.cards.maxOfOrNull { it.endMs } ?: 0L

    /** Final video length: voiceover (default), last card end, or a custom value. */
    fun totalMs(p: Project): Long {
        val s = p.settings
        val t = when (s.endMode) {
            0 -> if (s.audioDurMs > 0) s.audioDurMs else lastEnd(p)
            1 -> lastEnd(p)
            else -> if (s.customEndMs > 0) s.customEndMs else lastEnd(p)
        }
        return t.coerceAtLeast(1000L)
    }

    fun validate(cards: List<Card>, audioMs: Long, allowOverlap: Boolean): List<Issue> {
        val out = mutableListOf<Issue>()
        cards.forEachIndexed { i, c ->
            if (c.startMs < 0) out += Issue(i, "Card ${i + 1}: start time is negative")
            if (c.endMs <= c.startMs) out += Issue(i, "Card ${i + 1}: end must be after start")
            if (audioMs > 0 && c.endMs > audioMs + 100) out += Issue(i, "Card ${i + 1}: extends beyond the audio (${fmt(audioMs)})")
            if (!allowOverlap && i > 0 && c.startMs < cards[i - 1].endMs - 1) out += Issue(i, "Card ${i + 1}: overlaps card $i")
        }
        return out
    }

    /** Splits the total duration evenly across cards. Manual edits are still possible afterwards. */
    fun distribute(cards: List<Card>, totalMs: Long): List<Card> {
        if (cards.isEmpty() || totalMs <= 0) return cards
        val n = cards.size
        return cards.mapIndexed { i, c -> c.copy(startMs = totalMs * i / n, endMs = totalMs * (i + 1) / n) }
    }

    fun fmt(ms: Long): String {
        val v = ms.coerceAtLeast(0)
        val m = v / 60000
        val s = (v / 1000) % 60
        val t = (v % 1000) / 100
        return String.format(Locale.US, "%d:%02d.%d", m, s, t)
    }

    /** Millisecond precision for manual entry fields, e.g. 0:12.350 */
    fun fmtPrecise(ms: Long): String {
        val v = ms.coerceAtLeast(0)
        return String.format(Locale.US, "%d:%02d.%03d", v / 60000, (v / 1000) % 60, v % 1000)
    }

    /** Accepts "12", "12.5", "1:05", "1:05.5", "0:01:05". Returns null if unreadable. */
    fun parse(raw: String): Long? {
        val s = raw.trim().replace(',', '.')
        if (s.isEmpty()) return null
        val parts = s.split(":")
        return try {
            when (parts.size) {
                1 -> (parts[0].toDouble() * 1000).toLong()
                2 -> ((parts[0].toLong() * 60 + parts[1].toDouble()) * 1000).toLong()
                3 -> ((parts[0].toLong() * 3600 + parts[1].toLong() * 60 + parts[2].toDouble()) * 1000).toLong()
                else -> null
            }
        } catch (e: NumberFormatException) {
            null
        }
    }
}
