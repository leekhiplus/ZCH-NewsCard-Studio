package com.zafarcrickethub.zchnewscardstudio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Surface
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.zafarcrickethub.zchnewscardstudio.data.Overlay
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Palette
import androidx.compose.runtime.produceState
import androidx.compose.ui.layout.ContentScale
import com.zafarcrickethub.zchnewscardstudio.data.pictures
import com.zafarcrickethub.zchnewscardstudio.graphics.Bmp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zafarcrickethub.zchnewscardstudio.audio.Playback
import com.zafarcrickethub.zchnewscardstudio.data.Opt
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.data.Samples
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportState
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportUi
import com.zafarcrickethub.zchnewscardstudio.renderer.Thumbs
import com.zafarcrickethub.zchnewscardstudio.utils.GeminiTts
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.floor
import com.zafarcrickethub.zchnewscardstudio.data.Card as NCard

@Composable
fun PlaybackLoop(pb: Playback) {
    LaunchedEffect(pb.playing) {
        if (pb.playing) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                pb.tick((now - last) / 1_000_000L)
                last = now
            }
        }
    }
}

// =====================================================================================
//  InShot-style editor: top bar · big preview · play row · tool row · timeline
// =====================================================================================
private val EdBg = Color(0xFF232323)
private val EdMuted = Color(0xFFB4B4B4)

@Composable
fun EditorScreen(vm: MainViewModel) {
    val p = vm.current ?: run { vm.go(Screen.Projects); return }
    PlaybackLoop(vm.playback)
    AiDialogs(vm)
    if (vm.showExport) { ExportScreen(vm, p); return }
    val ec = vm.editingCard
    if (ec != null) { CardEditor(vm, p, ec); return }
    var picker by remember { mutableStateOf(0) }       // 1 = add a card, 2 = change the template of the selected card
    var full by remember { mutableStateOf(false) }
    var help by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val pickPicture = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importOverlayPicture(u) }
    val selCard = if (vm.sel.startsWith("card:")) p.cards.find { it.id == vm.sel.removePrefix("card:") } else null
    val selOv = if (vm.sel.startsWith("ov:")) p.overlays.find { it.id == vm.sel.removePrefix("ov:") } else null
    if (picker != 0) TemplatePicker(if (picker == 1) "Add a card" else "Change template", { picker = 0 }, false) { t ->
        if (picker == 1) vm.addCard(t) else selCard?.let { c -> vm.updateCard(c.id) { it.copy(template = t) } }
        picker = 0
    }
    if (full) FullScreenPreview(vm, p) { full = false }
    if (help) HelpDialog { help = false }
    val dragFn: ((Float, Float) -> Unit)? = selOv?.let { o ->
        { dx: Float, dy: Float -> vm.updateOverlay(o.id) { it.copy(x = (it.x + dx).coerceIn(0f, 1f), y = (it.y + dy).coerceIn(0f, 1f)) } }
    }

    Column(Modifier.fillMaxSize().background(EdBg).statusBarsPadding().navigationBarsPadding()) {
        // top bar
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            IconButton(onClick = { help = true }) { Icon(Icons.Default.HelpOutline, "Help", tint = Color.White) }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { vm.playback.pause(); vm.showExport = true }) {
                Text("Export", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
        // preview
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp), contentAlignment = Alignment.Center) {
            FitPreview(p, { vm.playback.positionMs }, Modifier.fillMaxSize(), onDrag = dragFn)
        }
        // undo · redo · play · full screen
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.undo() }, enabled = vm.undoCount > 0) { Icon(Icons.AutoMirrored.Filled.Undo, "Undo", tint = if (vm.undoCount > 0) Color.White else Color(0xFF5A5A5A)) }
            IconButton(onClick = { vm.redo() }, enabled = vm.redoCount > 0) { Icon(Icons.AutoMirrored.Filled.Redo, "Redo", tint = if (vm.redoCount > 0) Color.White else Color(0xFF5A5A5A)) }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); vm.playback.toggle() }, modifier = Modifier.size(56.dp)) {
                Icon(if (vm.playback.playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play / Pause", tint = Color.White, modifier = Modifier.size(42.dp))
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { vm.zoomDp = (vm.zoomDp / 1.4f).coerceAtLeast(12f) }) { Icon(Icons.Default.ZoomOut, "Zoom out", tint = Color.White) }
            IconButton(onClick = { vm.zoomDp = (vm.zoomDp * 1.4f).coerceAtMost(500f) }) { Icon(Icons.Default.ZoomIn, "Zoom in", tint = Color.White) }
            IconButton(onClick = { full = true }) { Icon(Icons.Default.Fullscreen, "Full screen", tint = Color.White) }
        }
        // tools
        ToolRow(vm, p, onTemplate = { picker = 2 }, onPicture = { pickPicture.launch(arrayOf("image/jpeg", "image/png", "image/webp")) })
        // timeline
        TimelineBlock(vm, p, onAdd = { picker = 1 })
    }
    SheetHost(vm, p)
}

@Composable
private fun Tool(icon: ImageVector, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    Column(
        Modifier.width(78.dp).clickable { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() }.padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp, color = EdMuted, maxLines = 1)
    }
}

@Composable
private fun ToolRow(vm: MainViewModel, p: Project, onTemplate: () -> Unit, onPicture: () -> Unit) {
    val card = if (vm.sel.startsWith("card:")) p.cards.find { it.id == vm.sel.removePrefix("card:") } else null
    val ov = if (vm.sel.startsWith("ov:")) p.overlays.find { it.id == vm.sel.removePrefix("ov:") } else null
    var confirm by remember { mutableStateOf(false) }
    if (confirm && card != null) ConfirmDialog("Delete this card?", { confirm = false }) { vm.deleteCard(card.id) }
    LazyRow(Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 6.dp)) {
        if (card != null) {
            item { Tool(Icons.Default.Check, "Done", Color(0xFFFFC107)) { vm.sel = "" } }
            item { Tool(Icons.Default.Edit, "Edit") { vm.cardTab = 0; vm.editingCard = card.id } }
            item { Tool(Icons.Default.Dashboard, "Template") { onTemplate() } }
            item { Tool(Icons.Default.Mic, "Voice") { vm.cardTab = 5; vm.editingCard = card.id } }
            item { Tool(Icons.Default.Image, "Pictures") { vm.cardTab = 1; vm.editingCard = card.id } }
            item { Tool(Icons.Default.Animation, "Motion") { vm.cardTab = 3; vm.editingCard = card.id } }
            item { Tool(Icons.Default.Timer, "Time") { vm.sheet = "timing" } }
            item { Tool(Icons.Default.ContentCut, "Split") { vm.splitCard(card.id, vm.playback.positionMs) } }
            item { Tool(Icons.Default.ContentCopy, "Copy") { vm.duplicateCard(card.id) } }
            item { Tool(Icons.Default.Delete, "Delete", Color(0xFFFF8A80)) { confirm = true } }
        } else if (ov != null) {
            item { Tool(Icons.Default.Check, "Done", Color(0xFFFFC107)) { vm.sel = "" } }
            item { Tool(Icons.Default.Edit, "Edit") { vm.sheet = "overlay" } }
            item { Tool(Icons.Default.ContentCopy, "Copy") { vm.duplicateOverlay(ov.id) } }
            item { Tool(Icons.Default.Delete, "Delete", Color(0xFFFF8A80)) { vm.deleteOverlay(ov.id) } }
        } else {
            item { Tool(Icons.Default.AspectRatio, "Canvas") { vm.sheet = "style" } }
            item { Tool(Icons.Default.MusicNote, "Audio") { vm.sheet = "voice" } }
            item { Tool(Icons.Default.EmojiEmotions, "Sticker") { vm.sheet = "sticker" } }
            item { Tool(Icons.Default.TextFields, "Text") { vm.addOverlay(0, "Your text"); vm.sheet = "overlay" } }
            item { Tool(Icons.Default.Image, "Picture") { onPicture() } }
            item { Tool(Icons.Default.AutoAwesome, "Script") { vm.sheet = "aiscript" } }
            item { Tool(Icons.Default.Timer, "Timing") { vm.sheet = "timing" } }
        }
    }
}

@Composable
private fun HelpDialog(onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose, title = { Text("How to edit") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "• Drag the timeline to move the play-head (white line).\n" +
                        "• Tap a card to select it. Drag its white edges to trim it. Drag the selected card sideways to change its place in the order.\n" +
                        "• Text, Sticker and Picture add layers above the video. Tap a layer to select it: drag it on the timeline to move it in time, drag its edges to trim, drag it on the preview to move it on screen.\n" +
                        "• + adds a card (pick a design from the pictures).\n" +
                        "• Audio: voice-over for the whole video. Each card also has its own Voice (select a card → Voice).\n" +
                        "• Script: paste a script and cards are made for you."
                )
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("OK") } }
    )
}

@Composable
private fun FullScreenPreview(vm: MainViewModel, p: Project, onClose: () -> Unit) {
    Dialog(onDismissRequest = { vm.playback.pause(); onClose() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Box(Modifier.fillMaxSize()) {
                FitPreview(p, { vm.playback.positionMs }, Modifier.fillMaxSize().clickable { vm.playback.toggle() })
                Row(Modifier.align(Alignment.BottomCenter).padding(20.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    IconButton(onClick = { vm.playback.toggle() }) { Icon(if (vm.playback.playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(40.dp)) }
                    IconButton(onClick = { vm.playback.pause(); onClose() }) { Icon(Icons.Default.FullscreenExit, "Close", tint = Color.White, modifier = Modifier.size(36.dp)) }
                }
            }
        }
    }
}

/** Progress and result of the AI jobs. Dialogs sit above everything, so the user always sees what is happening. */
@Composable
private fun AiDialogs(vm: MainViewModel) {
    if (vm.aiBusy || vm.ttsBusy) {
        AlertDialog(
            onDismissRequest = {}, confirmButton = {},
            title = { Text("Please wait…") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(vm.aiStatus.ifBlank { "Working…" })
                    Text("This can take up to a minute. Keep the app open.", style = MaterialTheme.typography.bodySmall)
                }
            }
        )
    }
    val r = vm.aiResult
    if (r != null && !vm.aiBusy && !vm.ttsBusy) {
        AlertDialog(
            onDismissRequest = { vm.aiResult = null },
            title = { Text(if (r.startsWith("✅")) "Done" else "Problem") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(r) } },
            confirmButton = { TextButton(onClick = { vm.aiResult = null }) { Text("OK") } }
        )
    }
}

@Composable
private fun rememberCardThumbs(p: Project): Map<String, ImageBitmap> {
    val ctx = LocalContext.current
    val map = remember { mutableStateMapOf<String, ImageBitmap>() }
    val keys = remember { HashMap<String, Int>() }
    val sig = p.cards.map { it.id to it.copy(startMs = 0, endMs = 5000).hashCode() } + listOf("land" to p.settings.landscape.hashCode())
    LaunchedEffect(sig) {
        withContext(Dispatchers.Default) {
            for (c in p.cards) {
                val h = c.copy(startMs = 0, endMs = 5000).hashCode() * 31 + p.settings.landscape.hashCode()
                if (keys[c.id] != h) {
                    val bmp = runCatching { Thumbs.render(ctx, p, c, 240) }.getOrNull() ?: continue
                    keys[c.id] = h
                    withContext(Dispatchers.Main) { map[c.id] = bmp.asImageBitmap() }
                }
            }
        }
    }
    return map
}

// =====================================================================================
//  Timeline: overlay lanes · cards (main track) · voice · ruler. "+" on the left, big time under it.
// =====================================================================================
private const val LANE_DP = 30f
private const val CARD_DP = 64f
private const val VOICE_DP = 36f
private const val RULER_DP = 26f
private const val GAP_DP = 4f

/** Overlays that overlap in time are placed on separate lanes. */
private fun overlayLanes(list: List<Overlay>): Pair<Map<String, Int>, Int> {
    val ends = ArrayList<Long>()
    val m = HashMap<String, Int>()
    for (o in list.sortedBy { it.startMs }) {
        var lane = ends.indexOfFirst { it <= o.startMs }
        if (lane < 0) { ends.add(o.endMs); lane = ends.size - 1 } else ends[lane] = o.endMs
        m[o.id] = lane
    }
    return m to ends.size
}

@Composable
private fun TimelineBlock(vm: MainViewModel, p: Project, onAdd: () -> Unit) {
    val lanes = remember(p.overlays) { overlayLanes(p.overlays) }.second
    val lanesDp = lanes * (LANE_DP + GAP_DP)
    val totalDp = lanesDp + CARD_DP + GAP_DP + VOICE_DP + GAP_DP + RULER_DP
    val pb = vm.playback
    val total = Timing.totalMs(p)
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(totalDp.dp)) {
            TimelineCanvas(vm, p, Modifier.fillMaxSize())
            // "+" button sits on the left, aligned with the main (card) track, like InShot
            Column(Modifier.padding(start = 10.dp, top = lanesDp.dp).width(70.dp).height(CARD_DP.dp), verticalArrangement = Arrangement.Center) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(16.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFFFF5A7A), Color(0xFFE91E4A))))
                        .clickable { onAdd() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.AddCircle, "Add card", tint = Color.White, modifier = Modifier.size(30.dp)) }
            }
        }
        Box(Modifier.fillMaxWidth().height(30.dp)) {
            Text(Timing.fmt(pb.positionMs), Modifier.align(Alignment.Center), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(Timing.fmt(total), Modifier.align(Alignment.CenterEnd).padding(end = 16.dp), color = EdMuted, fontSize = 14.sp)
        }
    }
}

@Composable
private fun TimelineCanvas(vm: MainViewModel, p: Project, modifier: Modifier = Modifier) {
    val pb = vm.playback
    val density = LocalDensity.current.density
    val total = Timing.totalMs(p)
    val s = p.settings
    val thumbs = rememberCardThumbs(p)
    val wf = vm.waveform
    val pNow by rememberUpdatedState(p)
    val laneInfo = remember(p.overlays) { overlayLanes(p.overlays) }
    val lanesNow by rememberUpdatedState(laneInfo.first)
    val laneCount = laneInfo.second

    val laneH = LANE_DP * density
    val cardH = CARD_DP * density
    val voiceH = VOICE_DP * density
    val rulerH = RULER_DP * density
    val gap = GAP_DP * density
    val yCard = laneCount * (laneH + gap)
    val yVoice = yCard + cardH + gap
    val yRuler = yVoice + voiceH + gap
    val textPaint = remember(density) {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f * density; color = android.graphics.Color.WHITE }
    }
    val hues = remember { listOf(Color(0xFFB3213B), Color(0xFF9A7B0A), Color(0xFF2756B5), Color(0xFF1E8F5B), Color(0xFF7B3FA0), Color(0xFFB45A2E)) }

    Canvas(
        modifier.background(Color(0xFF1B1B1B))
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { o ->
                        val w = size.width.toFloat()
                        val ppm = vm.zoomDp * density / 1000f
                        val ms = pb.positionMs + (o.x - w / 2f) / ppm
                        when {
                            o.y >= yRuler -> pb.seek(ms.toLong())
                            o.y >= yVoice -> vm.sheet = "voice"
                            o.y >= yCard -> {
                                val c = pNow.cards.lastOrNull { ms >= it.startMs && ms <= it.endMs }
                                vm.sel = if (c != null) "card:" + c.id else ""
                            }
                            else -> {
                                val lane = (o.y / (laneH + gap)).toInt()
                                val ov = pNow.overlays.lastOrNull { (lanesNow[it.id] ?: 0) == lane && ms >= it.startMs && ms <= it.endMs }
                                vm.sel = if (ov != null) "ov:" + ov.id else ""
                            }
                        }
                    },
                    onDoubleTap = { o ->
                        val w = size.width.toFloat()
                        val ppm = vm.zoomDp * density / 1000f
                        val ms = pb.positionMs + (o.x - w / 2f) / ppm
                        if (o.y >= yCard && o.y < yCard + cardH) {
                            val c = pNow.cards.lastOrNull { ms >= it.startMs && ms <= it.endMs }
                            if (c != null) { vm.sel = "card:" + c.id; vm.cardTab = 0; vm.editingCard = c.id }
                        } else if (o.y < yCard) {
                            val lane = (o.y / (laneH + gap)).toInt()
                            val ov = pNow.overlays.lastOrNull { (lanesNow[it.id] ?: 0) == lane && ms >= it.startMs && ms <= it.endMs }
                            if (ov != null) { vm.sel = "ov:" + ov.id; vm.sheet = "overlay" }
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                // 0 scrub · 1/2 trim card · 3 move (re-order) card · 4/5 trim overlay · 6 move overlay in time
                var mode = 0
                var tIdx = -1
                var tid = ""
                var acc = 0f
                val finish: () -> Unit = {
                    if (mode == 3) {
                        val id = vm.dragCard
                        val c = if (id != null) pNow.cards.find { it.id == id } else null
                        if (id != null && c != null) {
                            val ppm = vm.zoomDp * density / 1000f
                            val center = (c.startMs + c.endMs) / 2f + vm.dragShiftPx / ppm
                            val idx = pNow.cards.filter { it.id != id }.count { (it.startMs + it.endMs) / 2f < center }
                            vm.moveCardTo(id, idx)
                        }
                        vm.dragCard = null; vm.dragShiftPx = 0f
                    }
                    mode = 0
                }
                detectDragGestures(
                    onDragStart = { o ->
                        val w = size.width.toFloat()
                        val ppm = vm.zoomDp * density / 1000f
                        mode = 0; acc = 0f; vm.dragShiftPx = 0f
                        val hit = 30f * density
                        val selNow = vm.sel
                        if (selNow.startsWith("card:") && o.y >= yCard && o.y < yCard + cardH) {
                            val i = pNow.cards.indexOfFirst { it.id == selNow.removePrefix("card:") }
                            if (i >= 0) {
                                val c = pNow.cards[i]
                                val xl = w / 2f + (c.startMs - pb.positionMs) * ppm
                                val xr = w / 2f + (c.endMs - pb.positionMs) * ppm
                                when {
                                    abs(o.x - xl) < hit && abs(o.x - xl) <= abs(o.x - xr) -> { mode = 1; tIdx = i }
                                    abs(o.x - xr) < hit -> { mode = 2; tIdx = i }
                                    o.x >= xl && o.x <= xr -> { mode = 3; vm.dragCard = c.id }
                                }
                            }
                        } else if (selNow.startsWith("ov:")) {
                            val oid = selNow.removePrefix("ov:")
                            val ov = pNow.overlays.find { it.id == oid }
                            val ly = (lanesNow[oid] ?: 0) * (laneH + gap)
                            if (ov != null && o.y >= ly && o.y < ly + laneH) {
                                val xl = w / 2f + (ov.startMs - pb.positionMs) * ppm
                                val xr = w / 2f + (ov.endMs - pb.positionMs) * ppm
                                tid = oid
                                when {
                                    abs(o.x - xl) < hit && abs(o.x - xl) <= abs(o.x - xr) -> mode = 4
                                    abs(o.x - xr) < hit -> mode = 5
                                    o.x >= xl && o.x <= xr -> mode = 6
                                }
                            }
                        }
                        if (mode == 0) pb.pause()
                    },
                    onDragEnd = { finish() },
                    onDragCancel = { finish() }
                ) { change, drag ->
                    change.consume()
                    val w = size.width.toFloat()
                    val ppm = vm.zoomDp * density / 1000f
                    val ms = (pb.positionMs + (change.position.x - w / 2f) / ppm).toLong().coerceAtLeast(0L)
                    when (mode) {
                        0 -> {
                            acc += -drag.x / ppm
                            val whole = acc.toLong()
                            acc -= whole
                            if (whole != 0L) pb.seek(pb.positionMs + whole)
                        }
                        1 -> vm.setEdge(tIdx, false, ms)
                        2 -> vm.setEdge(tIdx, true, ms)
                        3 -> vm.dragShiftPx += drag.x
                        4 -> vm.trimOverlay(tid, false, ms)
                        5 -> vm.trimOverlay(tid, true, ms)
                        else -> {
                            acc += drag.x / ppm
                            val whole = acc.toLong()
                            if (whole != 0L) { acc -= whole; vm.moveOverlay(tid, whole) }
                        }
                    }
                }
            }
    ) {
        val w = size.width
        val ppm = vm.zoomDp * density / 1000f
        val cx = w / 2f
        val pos = pb.positionMs
        val sel = vm.sel
        fun xOf(ms: Long): Float = cx + (ms - pos) * ppm
        fun label(t: String, x: Float, y: Float, color: Int = android.graphics.Color.WHITE) {
            textPaint.color = color
            drawIntoCanvas { it.nativeCanvas.drawText(t, x, y, textPaint) }
        }
        val corner = CornerRadius(8f * density)

        // overlay lanes
        p.overlays.forEach { o ->
            val lane = lanesNow[o.id] ?: 0
            val ly = lane * (laneH + gap)
            val x0 = xOf(o.startMs)
            val x1 = xOf(o.endMs)
            if (x1 < -40f || x0 > w + 40f) return@forEach
            val ow = (x1 - x0).coerceAtLeast(4f)
            val col = when (o.type) { 0 -> Color(0xFF6E4FD6); 1 -> Color(0xFFE0A100); else -> Color(0xFF1F9AA8) }
            drawRoundRect(col, Offset(x0, ly), Size(ow, laneH), corner)
            clipRect(x0, ly, x0 + ow, ly + laneH) {
                label(when (o.type) { 0 -> "T  " + o.text.replace('\n', ' ').take(24); 1 -> o.text; else -> "▣ picture" }, x0 + 6f * density, ly + laneH / 2f + 4f * density)
            }
            val selected = sel == "ov:" + o.id
            if (selected) {
                drawRoundRect(Color.White, Offset(x0, ly), Size(ow, laneH), corner, style = Stroke(2.5f * density))
                val hw = 8f * density
                drawRoundRect(Color.White, Offset(x0 - 1f, ly), Size(hw, laneH), CornerRadius(4f * density))
                drawRoundRect(Color.White, Offset(x1 - hw + 1f, ly), Size(hw, laneH), CornerRadius(4f * density))
            }
        }

        // main track: cards
        drawRect(Color(0xFF262626), Offset(0f, yCard), Size(w, cardH))
        fun drawClip(i: Int, c: NCard, dx: Float, ghost: Boolean) {
            val x0 = xOf(c.startMs) + dx
            val x1 = xOf(c.endMs) + dx
            if (x1 < -40f || x0 > w + 40f) return
            val cw = (x1 - x0).coerceAtLeast(3f)
            drawRoundRect(hues[i % hues.size].copy(alpha = if (ghost) 0.85f else 1f), Offset(x0, yCard), Size(cw, cardH), corner)
            val bmp = thumbs[c.id]
            if (bmp != null) {
                val tileW = (cardH * bmp.width / bmp.height).coerceAtLeast(8f)
                clipRect(x0, yCard, x0 + cw, yCard + cardH) {
                    var tx = x0
                    while (tx < x0 + cw) {
                        if (tx + tileW >= 0f && tx <= w) drawImage(image = bmp, dstOffset = IntOffset(tx.toInt(), yCard.toInt()), dstSize = IntSize(tileW.toInt(), cardH.toInt()), alpha = if (ghost) 0.85f else 1f)
                        tx += tileW
                    }
                    drawRect(Color(0xAA000000), Offset(x0, yCard), Size(cw, 16f * density))
                    label("${i + 1}  " + c.headline.replace('\n', ' ').take(24), x0 + 4f * density, yCard + 12f * density)
                }
            }
            val selected = sel == "card:" + c.id
            drawRoundRect(if (selected) Color.White else Color(0x55FFFFFF), Offset(x0, yCard), Size(cw, cardH), corner, style = Stroke(if (selected) 3f * density else 1f))
            if (selected && !ghost) {
                val hw = 10f * density
                drawRoundRect(Color.White, Offset(x0 - 1f, yCard), Size(hw, cardH), CornerRadius(4f * density))
                drawRoundRect(Color.White, Offset(x1 - hw + 1f, yCard), Size(hw, cardH), CornerRadius(4f * density))
                drawLine(Color(0xFF333333), Offset(x0 + hw / 2f, yCard + cardH * 0.3f), Offset(x0 + hw / 2f, yCard + cardH * 0.7f), 2f)
                drawLine(Color(0xFF333333), Offset(x1 - hw / 2f + 1f, yCard + cardH * 0.3f), Offset(x1 - hw / 2f + 1f, yCard + cardH * 0.7f), 2f)
            }
        }
        val dragId = vm.dragCard
        p.cards.forEachIndexed { i, c -> if (c.id != dragId) drawClip(i, c, 0f, false) }
        if (dragId != null) {
            val i = p.cards.indexOfFirst { it.id == dragId }
            if (i >= 0) drawClip(i, p.cards[i], vm.dragShiftPx, true)
        }
        if (p.cards.isEmpty()) label("Tap + to add your first card", cx + 12f * density, yCard + cardH / 2f + 4f * density, 0xFFB4B4B4.toInt())

        // voice track: whole-video voice-over + the voice of single cards
        drawRect(Color(0xFF262626), Offset(0f, yVoice), Size(w, voiceH))
        if (s.audioPath != null) {
            val ax0 = xOf(0L)
            val ax1 = xOf(s.audioDurMs)
            drawRoundRect(Color(0xFF14636B), Offset(ax0, yVoice), Size((ax1 - ax0).coerceAtLeast(3f), voiceH), corner)
            if (wf != null && wf.isNotEmpty()) {
                val bw = (ax1 - ax0) / wf.size
                for (i in wf.indices) {
                    val x = ax0 + (i + 0.5f) * bw
                    if (x < -2f || x > w + 2f) continue
                    val hh = wf[i] * voiceH * 0.4f + 1f
                    drawLine(Color(0xDDFFFFFF), Offset(x, yVoice + voiceH / 2f - hh), Offset(x, yVoice + voiceH / 2f + hh), maxOf(1f, bw * 0.8f))
                }
            }
        }
        p.cards.forEach { c ->
            if (c.voicePath != null && c.voiceDurMs > 0) {
                val x0 = xOf(c.startMs)
                val x1 = xOf(c.startMs + c.voiceDurMs)
                drawRoundRect(Color(0xFF2E9E8F), Offset(x0, yVoice + 3f * density), Size((x1 - x0).coerceAtLeast(3f), voiceH - 6f * density), corner)
                clipRect(x0, yVoice, x1, yVoice + voiceH) { label("🎙", x0 + 4f * density, yVoice + voiceH / 2f + 4f * density) }
            }
        }
        if (s.audioPath == null && p.cards.none { it.voicePath != null }) label("🎙 Tap here to add voice", 12f * density + 70f * density, yVoice + voiceH / 2f + 4f * density, 0xFFB4B4B4.toInt())

        // ruler with a dot every second and a label every few seconds (under the tracks, like InShot)
        val secPx = vm.zoomDp * density
        val stepMs = when { secPx >= 110f -> 1000L; secPx >= 55f -> 2000L; secPx >= 22f -> 5000L; else -> 10000L }
        val leftMs = pos - cx / ppm
        var t = (floor(leftMs / stepMs).toLong() * stepMs).coerceAtLeast(0L)
        val rightMs = pos + cx / ppm
        while (t <= rightMs && t <= total + stepMs) {
            val x = xOf(t)
            drawCircle(Color(0xFF8A8A8A), 2.5f * density, Offset(x, yRuler + 5f * density))
            label("${"%02d".format(t / 60000)}:${"%02d".format((t / 1000) % 60)}", x - 14f * density, yRuler + 20f * density, 0xFF9A9A9A.toInt())
            t += stepMs
        }

        // end marker + play-head
        val ex1 = xOf(total)
        drawLine(Color(0x99FFC107), Offset(ex1, 0f), Offset(ex1, yVoice + voiceH), 2f)
        drawLine(Color.White, Offset(cx, 0f), Offset(cx, yRuler), 3f * density)
    }
}

// =====================================================================================
//  Bottom sheets
// =====================================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SheetHost(vm: MainViewModel, p: Project) {
    val kind = vm.sheet
    if (kind.isEmpty()) return
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val card = if (vm.sel.startsWith("card:")) p.cards.find { it.id == vm.sel.removePrefix("card:") } else null
    val ov = if (vm.sel.startsWith("ov:")) p.overlays.find { it.id == vm.sel.removePrefix("ov:") } else null
    ModalBottomSheet(onDismissRequest = { vm.sheet = "" }, sheetState = state, containerColor = Color(0xFF2B2B2B)) {
        Column(
            Modifier.padding(horizontal = 16.dp).padding(bottom = 28.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (kind) {
                "voice" -> { Text("Audio · voice-over for the whole video", style = MaterialTheme.typography.titleMedium, color = GoldC); AudioPanel(vm, p) }
                "aiscript" -> { Text("Script → cards + voice-over", style = MaterialTheme.typography.titleMedium, color = GoldC); AiScriptPanel(vm, p) }
                "sticker" -> {
                    Text("Stickers", style = MaterialTheme.typography.titleMedium, color = GoldC)
                    Opt.stickers.chunked(8).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            row.forEach { e -> Text(e, fontSize = 30.sp, modifier = Modifier.clickable { vm.addOverlay(1, e); vm.sheet = "overlay" }.padding(6.dp)) }
                        }
                    }
                }
                "overlay" -> if (ov != null) {
                    Text("Edit " + Opt.overlayTypes[ov.type].lowercase(), style = MaterialTheme.typography.titleMedium, color = GoldC)
                    OverlayPanel(vm, ov)
                }
                "style" -> {
                    var t by remember { mutableStateOf(0) }
                    Text("Canvas & style", style = MaterialTheme.typography.titleMedium, color = GoldC)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Ticker", "Logo", "Format").forEachIndexed { i, n -> FilterChip(t == i, { t = i }, { Text(n) }) }
                    }
                    when (t) {
                        0 -> TickerPanel(vm, p)
                        1 -> BrandPanel(vm, p)
                        else -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(p.settings.landscape, { vm.updateSettings { it.copy(landscape = true) } }, { Text("16:9 landscape") })
                            FilterChip(!p.settings.landscape, { vm.updateSettings { it.copy(landscape = false) } }, { Text("9:16 portrait") })
                        }
                    }
                }
                "timing" -> {
                    if (card != null) {
                        Text("Card time", style = MaterialTheme.typography.titleMedium, color = GoldC)
                        TimingPanel(vm, p, card)
                    } else {
                        Text("Timing", style = MaterialTheme.typography.titleMedium, color = GoldC)
                        TimelineOptsPanel(vm, p)
                    }
                }
            }
            Button(onClick = { vm.sheet = "" }, modifier = Modifier.fillMaxWidth()) { Text("Done") }
        }
    }
}

@Composable
private fun OverlayPanel(vm: MainViewModel, o: Overlay) {
    val id = o.id
    when (o.type) {
        0 -> {
            RtlField("Text", o.text, { v -> vm.updateOverlay(id) { it.copy(text = v) } }, minLines = 2)
            ColorRow("Text colour", o.color) { v -> vm.updateOverlay(id) { it.copy(color = v) } }
            val plates = listOf(0, 0xCC0A1A3F.toInt(), 0xCCD90429.toInt(), 0xCCFFC107.toInt(), 0xCC000000.toInt(), 0xCCFFFFFF.toInt())
            DropdownField("Plate behind the text", listOf("None", "Navy", "Red", "Gold", "Black", "White"), plates.indexOf(o.bg).coerceAtLeast(0), { i -> vm.updateOverlay(id) { it.copy(bg = plates[i]) } })
        }
        1 -> Opt.stickers.chunked(8).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { e -> Text(e, fontSize = 26.sp, modifier = Modifier.clickable { vm.updateOverlay(id) { it.copy(text = e) } }.padding(4.dp)) }
            }
        }
        else -> Text("Picture layer. Move it on the preview, change the size below.", style = MaterialTheme.typography.bodySmall)
    }
    SliderRow("Size", o.size, 0.3f..3f, "${(o.size * 100).toInt()}%") { v -> vm.updateOverlay(id) { it.copy(size = v) } }
    SliderRow("Rotation", o.rot, -180f..180f, "${o.rot.toInt()}°") { v -> vm.updateOverlay(id) { it.copy(rot = v) } }
    SliderRow("Position left ↔ right", o.x, 0f..1f, "${(o.x * 100).toInt()}%") { v -> vm.updateOverlay(id) { it.copy(x = v) } }
    SliderRow("Position up ↕ down", o.y, 0f..1f, "${(o.y * 100).toInt()}%") { v -> vm.updateOverlay(id) { it.copy(y = v) } }
    Text("Time on the video", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TimeField("Start", o.startMs, { v -> vm.updateOverlay(id) { it.copy(startMs = v.coerceIn(0L, it.endMs - 300)) } }, Modifier.weight(1f))
        TimeField("End", o.endMs, { v -> vm.updateOverlay(id) { it.copy(endMs = maxOf(v, it.startMs + 300)) } }, Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { vm.trimOverlay(id, false, vm.playback.positionMs) }, modifier = Modifier.weight(1f)) { Text("Start = play-head", fontSize = 12.sp) }
        OutlinedButton(onClick = { vm.trimOverlay(id, true, vm.playback.positionMs) }, modifier = Modifier.weight(1f)) { Text("End = play-head", fontSize = 12.sp) }
    }
    DropdownField("Enter animation", Opt.textAnims, o.anim, { v -> vm.updateOverlay(id) { it.copy(anim = v) } })
    DropdownField("Exit animation", listOf("None") + Opt.textAnims, o.exit, { v -> vm.updateOverlay(id) { it.copy(exit = v) } })
}

@Composable
private fun AiScriptPanel(vm: MainViewModel, p: Project) {
    val st by vm.settings.collectAsState()
    val clip = LocalClipboardManager.current
    var maxCards by remember { mutableStateOf(0f) }
    var tplMode by remember { mutableStateOf(0) }
    var single by remember { mutableStateOf(13) }
    var replace by remember { mutableStateOf(true) }
    var withVoice by remember { mutableStateOf(true) }
    var withTicker by remember { mutableStateOf(true) }
    var spread by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    Text("1. Paste the full news script.  2. Cards are made on your phone (offline, instantly).  3. The voice-over is optional (Google key).  4. You set each card's time with the play-head.", style = MaterialTheme.typography.bodySmall)
    RtlField("News script (Urdu / English)", vm.aiScript, { vm.aiScript = it }, minLines = 8)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = {
            val t = clip.getText()?.text
            if (t.isNullOrBlank()) vm.message = "Clipboard is empty" else vm.aiScript = t
        }) { Icon(Icons.Default.ContentPaste, null, Modifier.size(18.dp)); Text("  Paste script") }
        if (vm.aiScript.isNotBlank()) OutlinedButton(onClick = { vm.aiScript = "" }) { Text("Clear") }
    }
    SliderRow("Number of cards", maxCards, 0f..12f, if (maxCards.toInt() == 0) "Auto" else "${maxCards.toInt()}") { maxCards = it }
    DropdownField("Templates", listOf("Best for each part (auto)", "TV news style (new 10)", "Classic designs", "One template for all"), tplMode, { tplMode = it })
    if (tplMode == 3) DropdownField("Template", Opt.templates, single, { single = it })
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(replace, { replace = it }); Text("Replace the cards I already have", Modifier.weight(1f).padding(start = 12.dp)) }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(withVoice, { withVoice = it }); Text("Also create the voice-over", Modifier.weight(1f).padding(start = 12.dp)) }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(withTicker, { withTicker = it }); Text("Make the ticker text from the headlines", Modifier.weight(1f).padding(start = 12.dp)) }
    if (withVoice) {
        if (st.geminiKey.isBlank() || showKey) GeminiKeyFields(vm)
        else Row(verticalAlignment = Alignment.CenterVertically) {
            Text("✓ Google key saved (voice model: ${GeminiTts.label(st.geminiModel)})", Modifier.weight(1f), color = Color(0xFF69F0AE))
            TextButton(onClick = { showKey = true }) { Text("Change") }
        }
        PopupField("Speaking style (optional)", vm.ttsStyle, { vm.ttsStyle = it }, placeholder = "e.g. Read like a calm Urdu news anchor")
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(spread, { spread = it }); Text("Spread the cards evenly over the voice-over (starting point)", Modifier.weight(1f).padding(start = 12.dp)) }
    }
    val tplArg = when (tplMode) { 0 -> -1; 1 -> -2; 2 -> -3; else -> single }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Button(onClick = { vm.generateFromScript(maxCards.toInt(), tplArg, replace, withVoice, withTicker, spread) }, enabled = !vm.aiBusy) {
            Text(if (vm.aiBusy) "Working…" else "✨ Create cards")
        }
        if (vm.aiBusy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
    }
    if (vm.aiStatus.isNotBlank()) Text(vm.aiStatus, color = Color(0xFFFFC107))
    Text(
        "Cards are made offline from your script: each card gets a headline and a short description, the ticker is made from the headlines. " +
            "Only the optional voice-over is sent to Google (with your own key). Add pictures to each card and set the card times to match the voice-over.",
        style = MaterialTheme.typography.bodySmall
    )
}

@Composable
fun TimingPanel(vm: MainViewModel, p: Project, c: NCard) {
    val id = c.id
    val dur = (c.endMs - c.startMs).coerceAtLeast(1L)
    val idx = p.cards.indexOfFirst { it.id == id }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Card ${idx + 1}", style = MaterialTheme.typography.labelLarge, color = Color(0xFFFFC107))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TimeField("Start", c.startMs, { v -> vm.setTiming(id, v, null) }, Modifier.weight(1f))
            TimeField("End", c.endMs, { v -> vm.setTiming(id, null, v) }, Modifier.weight(1f))
        }
        TimeField("Duration", dur, { v -> vm.setDuration(id, v) }, Modifier.fillMaxWidth())
        Text("Type a value and press Done (keyboard) or tap another field. Examples: 5   12.5   1:05   0:01:05.250", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.setTiming(id, vm.playback.positionMs, null) }, modifier = Modifier.weight(1f)) { Text("Start = play-head", fontSize = 12.sp) }
            OutlinedButton(onClick = { vm.setTiming(id, null, vm.playback.positionMs) }, modifier = Modifier.weight(1f)) { Text("End = play-head", fontSize = 12.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = { vm.nudge(id, -500, 0) }) { Text("Start −0.5s") }
            TextButton(onClick = { vm.nudge(id, 500, 0) }) { Text("Start +0.5s") }
            TextButton(onClick = { vm.nudge(id, 0, -500) }) { Text("End −0.5s") }
            TextButton(onClick = { vm.nudge(id, 0, 500) }) { Text("End +0.5s") }
        }
        if (idx > 0) OutlinedButton(onClick = { vm.startAfterPrevious(id) }, modifier = Modifier.fillMaxWidth()) { Text("Start right after previous card") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.moveCard(id, -1) }, enabled = idx > 0, modifier = Modifier.weight(1f)) { Text("◀ Move earlier") }
            OutlinedButton(onClick = { vm.moveCard(id, 1) }, enabled = idx < p.cards.size - 1, modifier = Modifier.weight(1f)) { Text("Move later ▶") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(p.settings.ripple, { v -> vm.updateSettings { it.copy(ripple = v) } })
            Text("  Move the following cards when I change the end time", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
        }
        Timing.validate(p.cards, p.settings.audioDurMs, p.settings.allowOverlap).filter { it.index == idx }.forEach {
            Text("⚠ ${it.text}", color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun AnimPanel(vm: MainViewModel, c: NCard) {
    val id = c.id
    DropdownField("Text animation", Opt.textAnims, c.textAnim, { v -> vm.updateCard(id) { it.copy(textAnim = v) } })
    DropdownField("Image animation", Opt.imageAnims, c.imageAnim, { v -> vm.updateCard(id) { it.copy(imageAnim = v) } })
    DropdownField("Exit animation (before card ends)", listOf("None") + Opt.textAnims, c.exitAnim, { v -> vm.updateCard(id) { it.copy(exitAnim = v) } })
    DropdownField("Looping effect", Opt.idleFx, c.idleFx, { v -> vm.updateCard(id) { it.copy(idleFx = v) } })
    DropdownField("Transition into this card", Opt.transitions, c.transition, { v -> vm.updateCard(id) { it.copy(transition = v) } })
    SliderRow("Transition length", c.transMs.toFloat(), 150f..2500f, "${c.transMs} ms") { v -> vm.updateCard(id) { it.copy(transMs = v.toInt()) } }
    SliderRow("Animation duration", c.animMs.toFloat(), 150f..2500f, "${c.animMs} ms") { v -> vm.updateCard(id) { it.copy(animMs = v.toInt()) } }
    SliderRow("Animation speed", c.animSpeed, 0.25f..3f, "x${"%.2f".format(c.animSpeed)}") { v -> vm.updateCard(id) { it.copy(animSpeed = v) } }
}

@Composable
private fun TickerPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(s.tickerStyle == 1, { vm.updateSettings { it.copy(tickerStyle = 1) } }, { Text("TV strip") })
        FilterChip(s.tickerStyle == 0, { vm.updateSettings { it.copy(tickerStyle = 0) } }, { Text("Label box") })
    }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(s.tickerOn, { v -> vm.updateSettings { it.copy(tickerOn = v) } }); Text("  Show ticker strip") }
    RtlField("Ticker text (Urdu / English)", s.tickerText, { v -> vm.updateSettings { it.copy(tickerText = v) } }, minLines = 2)
    RtlField("Label", s.tickerLabel, { v -> vm.updateSettings { it.copy(tickerLabel = v) } })
    SliderRow("Scrolling speed", s.tickerSpeed, 30f..400f, "${s.tickerSpeed.toInt()} px/s") { v -> vm.updateSettings { it.copy(tickerSpeed = v) } }
    SliderRow("Font size", s.tickerSize, 0.6f..1.6f, "${(s.tickerSize * 100).toInt()}%") { v -> vm.updateSettings { it.copy(tickerSize = v) } }
    ColorRow("Ticker text colour", s.tickerColor) { v -> vm.updateSettings { it.copy(tickerColor = v) } }
    ColorRow("Ticker background", s.tickerBg) { v -> vm.updateSettings { it.copy(tickerBg = v) } }
}

@Composable
private fun BrandPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importLogo(u) }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(s.showLogo, { v -> vm.updateSettings { it.copy(showLogo = v) } }); Text("  Show logo on every card") }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { pickLogo.launch(arrayOf("image/png", "image/webp")) }) { Text("Upload PNG logo") }
        if (s.logoPath != null) OutlinedButton(onClick = { vm.updateSettings { it.copy(logoPath = null) } }) { Text("Use default") }
    }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(s.showChannelName, { v -> vm.updateSettings { it.copy(showChannelName = v) } }); Text("  Show channel name") }
    RtlField("Channel name", s.channelName, { v -> vm.updateSettings { it.copy(channelName = v) } })
    SliderRow("Logo size", s.logoSize, 0.06f..0.4f, "${(s.logoSize * 100).toInt()}%") { v -> vm.updateSettings { it.copy(logoSize = v) } }
    SliderRow("Logo opacity", s.logoOpacity, 0.1f..1f, "${(s.logoOpacity * 100).toInt()}%") { v -> vm.updateSettings { it.copy(logoOpacity = v) } }
    Text("Logo position for all cards:")
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(Opt.logoPositions.indices.toList()) { i ->
            FilterChip(selected = false, onClick = { vm.mutate { pr -> pr.copy(cards = pr.cards.map { it.copy(logoPos = i) }) } }, label = { Text(Opt.logoPositions[i]) })
        }
    }
}

@Composable
private fun AudioPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importAudio(u) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { pick.launch(arrayOf("audio/*")) }) { Text(if (s.audioPath == null) "Import audio" else "Replace audio") }
        if (s.audioPath != null) OutlinedButton(onClick = { vm.removeAudio() }) { Text("Remove") }
    }
    if (s.audioPath != null) {
        Text("Length: ${Timing.fmt(s.audioDurMs)}", style = MaterialTheme.typography.bodySmall)
        SliderRow("Volume", s.volume, 0f..2f, "${(s.volume * 100).toInt()}%") { vm.setVolume(it) }
    } else Text("MP3, WAV, M4A or AAC. Without audio the video ends at the last card.", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(6.dp))
    AiVoiceSection(vm)
}

/** Google AI Studio key (paste), voice model (pick from a list) and voice. Used in the Voice sheet and in Settings. */
@Composable
fun GeminiKeyFields(vm: MainViewModel) {
    val st by vm.settings.collectAsState()
    val clip = LocalClipboardManager.current
    PopupField(
        "Google AI Studio API key", st.geminiKey, { v -> vm.updateAppSettings { s -> s.copy(geminiKey = v.trim()) } },
        password = true, hint = "Create a free key at aistudio.google.com/apikey and paste it here."
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = {
            val t = clip.getText()?.text?.trim()
            if (t.isNullOrBlank()) vm.message = "Clipboard is empty" else vm.updateAppSettings { s -> s.copy(geminiKey = t) }
        }) { Icon(Icons.Default.ContentPaste, null, Modifier.size(18.dp)); Text("  Paste key") }
        if (st.geminiKey.isNotBlank()) TextButton(onClick = { vm.updateAppSettings { s -> s.copy(geminiKey = "", geminiModels = "") } }) { Text("Remove key") }
    }
    Text("The key stays on this phone and is used only for the voice-over.", style = MaterialTheme.typography.bodySmall)
    val ids = vm.modelList()
    DropdownField("Voice model", ids.map { GeminiTts.label(it) }, ids.indexOf(st.geminiModel).coerceAtLeast(0), { i -> vm.updateAppSettings { s -> s.copy(geminiModel = ids[i]) } })
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { vm.loadModels() }, enabled = !vm.modelsBusy && st.geminiKey.isNotBlank()) {
            Icon(Icons.Default.Refresh, null, Modifier.size(18.dp)); Text(if (vm.modelsBusy) "  Loading…" else "  Load models for my key")
        }
        if (vm.modelsBusy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
    }
    Text("This also checks that your key works. Pick a model from the list; nothing has to be typed.", style = MaterialTheme.typography.bodySmall)
    DropdownField("Voice", GeminiTts.voices, GeminiTts.voices.indexOf(st.geminiVoice).coerceAtLeast(0), { i -> vm.updateAppSettings { s -> s.copy(geminiVoice = GeminiTts.voices[i]) } })
}

@Composable
private fun AiVoiceSection(vm: MainViewModel) {
    Text("🤖 Create a voice-over with AI (online, optional)", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
    GeminiKeyFields(vm)
    PopupField("Speaking style (optional)", vm.ttsStyle, { vm.ttsStyle = it }, placeholder = "e.g. Read like a calm Urdu news anchor")
    RtlField("Voice-over script (Urdu / English)", vm.ttsScript, { vm.ttsScript = it }, minLines = 5)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { vm.scriptFromCards() }) { Text("Fill from cards") }
        Button(onClick = { vm.generateVoice() }, enabled = !vm.ttsBusy) { Text(if (vm.ttsBusy) "Generating…" else "Generate voice-over") }
        if (vm.ttsBusy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
    }
    Text(
        "The script is sent to Google with your own key; the result is saved as the project's voice-over (replacing the current one). " +
            "Urdu (ur-PK) is a preview language in Gemini TTS, so listen to the result. Everything else in the app stays offline.",
        style = MaterialTheme.typography.bodySmall
    )
}

@Composable
private fun TimelineOptsPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    val total = Timing.totalMs(p)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(s.allowOverlap, { v -> vm.updateSettings { it.copy(allowOverlap = v) } })
        Text("  Allow overlapping cards (transitions)", Modifier.weight(1f))
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(s.ripple, { v -> vm.updateSettings { it.copy(ripple = v) } })
        Text("  Move following cards when I change a card's end time", Modifier.weight(1f))
    }
    OutlinedButton(onClick = { vm.distribute() }, modifier = Modifier.fillMaxWidth()) {
        Text("Distribute cards evenly over ${Timing.fmt(if (s.audioDurMs > 0) s.audioDurMs else p.cards.size * 5000L)}")
    }
    DropdownField("Video ends at", listOf("End of voice-over", "End of last card", "Custom time"), s.endMode, { v -> vm.updateSettings { it.copy(endMode = v) } })
    if (s.endMode == 2) TimeField("Custom end", if (s.customEndMs > 0) s.customEndMs else total, { v -> vm.updateSettings { it.copy(customEndMs = v) } })
    Timing.validate(p.cards, s.audioDurMs, s.allowOverlap).forEach { Text("⚠ ${it.text}", color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall) }
    Text("All cards", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
    p.cards.forEachIndexed { i, c ->
        Card(colors = CardDefaults.cardColors(containerColor = NavyC)) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Card ${i + 1}: ${c.headline.take(40)}", maxLines = 1)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TimeField("Start", c.startMs, { v -> vm.setTiming(c.id, v, null) }, Modifier.weight(1f))
                    TimeField("End", c.endMs, { v -> vm.setTiming(c.id, null, v) }, Modifier.weight(1f))
                }
                TimeField("Duration", c.endMs - c.startMs, { v -> vm.setDuration(c.id, v) }, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun PathThumb(path: String, modifier: Modifier = Modifier) {
    val bmp by produceState<ImageBitmap?>(null, path) { value = withContext(Dispatchers.Default) { Bmp.load(path, 300)?.asImageBitmap() } }
    Box(modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF1B2A55)), contentAlignment = Alignment.Center) {
        bmp?.let { androidx.compose.foundation.Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable
private fun PicturesPanel(vm: MainViewModel, c: NCard) {
    val id = c.id
    val pickMany = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list -> if (list.isNotEmpty()) vm.importPictures(id, list) }
    var extraSlot by remember { mutableStateOf(0) }
    val pickExtra = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importExtraImage(id, extraSlot, u) }
    val pics = c.pictures()
    val slots = Opt.extraSlots(c.template)
    Text("Pictures in this card: ${pics.size}  (no limit)", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
    Button(onClick = { pickMany.launch(arrayOf("image/jpeg", "image/png", "image/webp")) }) {
        Icon(Icons.Default.AddCircle, null); Text("  Add pictures (select many)")
    }
    if (pics.isNotEmpty()) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(pics) { i, path ->
                Box(Modifier.size(120.dp, 86.dp)) {
                    PathThumb(path, Modifier.fillMaxSize())
                    if (i == 0) Text("MAIN", fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomStart).background(Color(0xAA000000)).padding(horizontal = 4.dp))
                    else TextButton(onClick = { vm.makePictureFirst(id, i) }, modifier = Modifier.align(Alignment.BottomStart)) { Text("Make main", fontSize = 10.sp) }
                    IconButton(onClick = { vm.removePicture(id, i) }, modifier = Modifier.align(Alignment.TopEnd).size(30.dp)) {
                        Icon(Icons.Default.Close, "Remove", tint = Color.White, modifier = Modifier.background(Color(0x99000000), CircleShape))
                    }
                }
            }
        }
        if (pics.size > 1) {
            Text("The card's time is shared equally between the pictures; they change one after another.", style = MaterialTheme.typography.bodySmall)
            DropdownField("Change between pictures", Opt.slideFx, c.slideFx, { v -> vm.updateCard(id) { it.copy(slideFx = v) } })
        }
        SliderRow("Main picture zoom / crop", c.imgScale, 1f..3f, "x${"%.2f".format(c.imgScale)}") { v -> vm.updateCard(id) { it.copy(imgScale = v) } }
        SliderRow("Position left ↔ right", c.imgX, -1f..1f, "%.2f".format(c.imgX)) { v -> vm.updateCard(id) { it.copy(imgX = v) } }
        SliderRow("Position up ↕ down", c.imgY, -1f..1f, "%.2f".format(c.imgY)) { v -> vm.updateCard(id) { it.copy(imgY = v) } }
    }
    if (slots > 0) {
        Text("Small match pictures used by this template", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
        for (slot in 0 until slots) {
            val has = c.extraImages.getOrNull(slot)?.isNotBlank() == true
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { extraSlot = slot; pickExtra.launch(arrayOf("image/jpeg", "image/png", "image/webp")) }) { Text(if (has) "Replace picture ${slot + 2}" else "Add picture ${slot + 2}") }
                if (has) OutlinedButton(onClick = { vm.removeExtraImage(id, slot) }) { Text("Remove") }
            }
        }
    }
}

// =====================================================================================
//  Card editor: preview on top, six simple tabs underneath
// =====================================================================================
@Composable
fun CardEditor(vm: MainViewModel, p: Project, id: String) {
    val c = p.cards.find { it.id == id } ?: run { vm.editingCard = null; return }
    val dur = (c.endMs - c.startMs).coerceAtLeast(1L)
    var t by remember { mutableStateOf(dur.toFloat()) }
    var anim by remember { mutableStateOf(false) }
    LaunchedEffect(anim, c.id) {
        if (anim) {
            var last = withFrameNanos { it }
            t = 0f
            while (anim) {
                val now = withFrameNanos { it }
                t += (now - last) / 1_000_000f; last = now
                if (t > dur) { t = dur.toFloat(); anim = false }
            }
        }
    }
    val solo = remember(p, c) { p.copy(cards = listOf(c.copy(startMs = 0, endMs = dur)), overlays = emptyList()) }
    val tpl = c.template
    val tab = vm.cardTab
    ScreenScaffold("Edit card", { vm.editingCard = null }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Box(Modifier.fillMaxWidth().height(210.dp).background(Color(0xFF02060F)).padding(4.dp)) {
                FitPreview(solo, { t.toLong() }, Modifier.fillMaxSize())
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { anim = true }) { Icon(Icons.Default.PlayArrow, "Play animation", tint = Color(0xFFFFC107)) }
                Slider(value = t, onValueChange = { anim = false; t = it }, valueRange = 0f..dur.toFloat(), modifier = Modifier.weight(1f))
            }
            LazyRow(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(listOf("Text", "Pictures", "Look", "Motion", "Time", "Voice")) { i, n -> FilterChip(tab == i, { vm.cardTab = i }, { Text(n) }) }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (tab) {
                    0 -> {
                        DropdownField("Template", Opt.templates, tpl, { v -> vm.updateCard(id) { it.copy(template = v) } })
                        RtlField("Headline (Urdu / English)", c.headline, { v -> vm.updateCard(id) { it.copy(headline = v) } }, minLines = 2)
                        if (tpl !in listOf(2, 5, 9, 11)) RtlField(if (tpl == 22) "Kicker (small label above the bar)" else "Description", c.description, { v -> vm.updateCard(id) { it.copy(description = v) } }, minLines = 2)
                        if (tpl in listOf(2, 5, 9, 11, 16, 17)) {
                            RtlField("Team 1", c.team1, { v -> vm.updateCard(id) { it.copy(team1 = v) } })
                            RtlField("Team 2", c.team2, { v -> vm.updateCard(id) { it.copy(team2 = v) } })
                        }
                        if (tpl in listOf(2, 5, 9, 17)) {
                            RtlField("Score (e.g. 182/4)", c.score, { v -> vm.updateCard(id) { it.copy(score = v) } })
                            RtlField("Overs", c.overs, { v -> vm.updateCard(id) { it.copy(overs = v) } })
                            RtlField("Wickets", c.wickets, { v -> vm.updateCard(id) { it.copy(wickets = v) } })
                        }
                        if (tpl in listOf(2, 5, 9)) RtlField("Match status", c.status, { v -> vm.updateCard(id) { it.copy(status = v) } })
                        if (tpl == 6 || tpl == 11) {
                            RtlField("Player name", c.playerName, { v -> vm.updateCard(id) { it.copy(playerName = v) } })
                            RtlField("Statistics (one per line, e.g. Runs: 85)", c.stats, { v -> vm.updateCard(id) { it.copy(stats = v) } }, minLines = 4)
                        }
                        SliderRow("Text size", c.textScale, 0.5f..1.6f, "${(c.textScale * 100).toInt()}%") { v -> vm.updateCard(id) { it.copy(textScale = v) } }
                        RtlField("Ticker text for this card (empty = project ticker)", c.tickerText, { v -> vm.updateCard(id) { it.copy(tickerText = v) } }, minLines = 2)
                    }
                    1 -> PicturesPanel(vm, c)
                    2 -> {
                        ColorRow("Text colour", c.textColor) { v -> vm.updateCard(id) { it.copy(textColor = v) } }
                        ColorRow("Background / tint colour", c.bgColor) { v -> vm.updateCard(id) { it.copy(bgColor = v) } }
                        DropdownField("Logo position", Opt.logoPositions, c.logoPos, { v -> vm.updateCard(id) { it.copy(logoPos = v) } })
                    }
                    3 -> AnimPanel(vm, c)
                    4 -> TimingPanel(vm, p, c)
                    else -> CardVoicePanel(vm, c)
                }
            }
        }
    }
}

/** Script and voice for THIS card: paste a script here to make cards from it, or give the card its own voice. */
@Composable
private fun CardVoicePanel(vm: MainViewModel, c: NCard) {
    val st by vm.settings.collectAsState()
    val clip = LocalClipboardManager.current
    var sameDesign by remember { mutableStateOf(true) }
    var replace by remember { mutableStateOf(false) }
    var fit by remember { mutableStateOf(true) }
    var vtext by remember(c.id) { mutableStateOf("") }
    Text("Script for this card", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
    Text("Paste a script and cards are made from it (offline, instantly) right at this card.", style = MaterialTheme.typography.bodySmall)
    RtlField("Script (paste here)", vm.cardScript, { vm.cardScript = it }, minLines = 6)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = {
            val t = clip.getText()?.text
            if (t.isNullOrBlank()) vm.message = "Clipboard is empty" else vm.cardScript = t
        }) { Icon(Icons.Default.ContentPaste, null, Modifier.size(18.dp)); Text("  Paste script") }
        if (vm.cardScript.isNotBlank()) OutlinedButton(onClick = { vm.cardScript = "" }) { Text("Clear") }
    }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(sameDesign, { sameDesign = it }); Text("Use this card's design for the new cards", Modifier.weight(1f).padding(start = 12.dp)) }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(replace, { replace = it }); Text("Replace this card (otherwise the new cards go after it)", Modifier.weight(1f).padding(start = 12.dp)) }
    Button(onClick = { vm.cardsFromScript(c.id, vm.cardScript, sameDesign, replace) }, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.AutoAwesome, null, Modifier.size(18.dp)); Text("  Make cards from this script")
    }
    HorizontalDivider()
    Text("Voice for this card", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
    if (st.geminiKey.isBlank()) {
        Text("Paste your Google AI Studio key to create voices (the key is used only for voices).", style = MaterialTheme.typography.bodySmall)
        GeminiKeyFields(vm)
    }
    RtlField("Text to read (empty = this card's headline + description)", vtext, { vtext = it }, minLines = 3)
    PopupField("Speaking style (optional)", vm.ttsStyle, { vm.ttsStyle = it }, placeholder = "e.g. Read like a calm Urdu news anchor")
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(fit, { fit = it }); Text("Make the card as long as the voice", Modifier.weight(1f).padding(start = 12.dp)) }
    Button(
        onClick = { vm.generateCardVoice(c.id, vtext.ifBlank { listOf(c.headline, c.description).filter { it.isNotBlank() }.joinToString("۔ ") }, fit) },
        enabled = !vm.ttsBusy && !vm.aiBusy, modifier = Modifier.fillMaxWidth()
    ) { Icon(Icons.Default.Mic, null, Modifier.size(18.dp)); Text("  Generate voice for this card") }
    if (c.voicePath != null) Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Voice added (${Timing.fmt(c.voiceDurMs)})", Modifier.weight(1f), color = Color(0xFF69F0AE))
        TextButton(onClick = { vm.removeCardVoice(c.id) }) { Text("Remove voice") }
    }
}

// =====================================================================================
//  Export screen
// =====================================================================================
@Composable
private fun ExportScreen(vm: MainViewModel, p: Project) {
    ScreenScaffold("Export video", { vm.showExport = false }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) { ExportTab(vm, p) }
    }
}

@Composable
fun ExportTab(vm: MainViewModel, p: Project) {
    val ctx = LocalContext.current
    val st by vm.settings.collectAsState()
    val state by ExportState.state.collectAsState()
    var res by remember(st.resolution) { mutableStateOf(st.resolution) }
    var fps by remember(st.fps) { mutableStateOf(st.fps) }
    var quality by remember { mutableStateOf(1) }
    var aq by remember { mutableStateOf(1) }
    var soft by remember { mutableStateOf(false) }
    var name by remember(p.id) { mutableStateOf("ZCH_" + p.name.replace(Regex("[^\\p{L}\\p{N}]+"), "_")) }
    val land = p.settings.landscape
    val total = Timing.totalMs(p)
    val longSide = if (res == 720) 1280 else 1920
    val w = if (land) longSide else res
    val h = if (land) res else longSide
    val baseBr = if (res == 720) intArrayOf(2_500_000, 4_000_000, 6_000_000) else intArrayOf(5_000_000, 8_000_000, 12_000_000)
    val vbr = (baseBr[quality] * fps / 30.0).toInt()
    val abr = intArrayOf(96_000, 128_000, 192_000)[aq]
    val legacyPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val needLegacy = android.os.Build.VERSION.SDK_INT < 29
    val running = state is ExportUi.Running
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Export settings", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFC107))
        Text("Resolution")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(720, 1080).forEach { r -> FilterChip(res == r, { res = r }, { Text("${r}p") }) } }
        Text("Aspect ratio")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(land, { vm.updateSettings { it.copy(landscape = true) } }, { Text("16:9") })
            FilterChip(!land, { vm.updateSettings { it.copy(landscape = false) } }, { Text("9:16") })
        }
        Text("Frame rate")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(24, 25, 30).forEach { f -> FilterChip(fps == f, { fps = f }, { Text("$f fps") }) } }
        DropdownField("Video quality", listOf("Low (small file)", "Medium", "High"), quality, { quality = it })
        DropdownField("Audio quality", listOf("96 kbps", "128 kbps", "192 kbps"), aq, { aq = it })
        PopupField("Output file name", name, { name = it })
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(soft, { soft = it })
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text("Compatibility mode (slower)")
                Text("Rendering normally uses the phone's GPU (fast). Turn this on only if the exported video is black or garbled.", style = MaterialTheme.typography.bodySmall)
            }
        }
        val mb = (((vbr + abr) / 8.0) * total / 1000.0 / 1_000_000)
        Text("Output: ${w}×${h}, $fps fps, about ${"%.1f".format(mb)} MB, ${Timing.fmt(total)} long")
        if (total > 10 * 60_000L) Text("⚠ Long project: export may take a long time and a lot of storage.", color = Color(0xFFFFC107))
        if (res == 1080) Text("⚠ 1080p needs more time/memory on older phones. Use 720p if the export fails.", color = Color(0xFFFFC107), style = MaterialTheme.typography.bodySmall)
        if (p.cards.isEmpty()) Text("Add at least one card first.", color = Color(0xFFFF8A80))

        when (val s = state) {
            is ExportUi.Running -> {
                LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                Text("${(s.progress * 100).toInt()}%  ${s.msg}")
                Button(onClick = { vm.cancelExport() }) { Text("Cancel export") }
            }
            is ExportUi.Done -> {
                Text("✅ Export finished: Movies/ZCH NewsCard Studio", color = Color(0xFF69F0AE))
                Text("Find it in Recent Exports to play, share or delete.", style = MaterialTheme.typography.bodySmall)
            }
            is ExportUi.Failed -> Text("❌ Export failed: ${s.msg}", color = Color(0xFFFF8A80))
            ExportUi.Cancelled -> Text("Export cancelled.")
            ExportUi.Idle -> {}
        }
        if (p.exportStatus == "interrupted") Text("The previous export was interrupted. Start again to retry.", color = Color(0xFFFFC107))
        Button(enabled = !running && p.cards.isNotEmpty(), modifier = Modifier.fillMaxWidth(), onClick = {
            if (android.os.Build.VERSION.SDK_INT >= 33) notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            val ok = !needLegacy || androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (ok) vm.startExport(w, h, fps, vbr, abr, name, land, p.settings.endMode, p.settings.customEndMs, soft)
            else {
                legacyPerm.launch(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE))
                vm.message = "Allow storage access, then press Export again"
            }
        }) { Text("Export MP4") }
        if (p.exports.isNotEmpty()) TextButton(onClick = { vm.go(Screen.Exports) }) { Text("Open Recent Exports") }
    }
}
