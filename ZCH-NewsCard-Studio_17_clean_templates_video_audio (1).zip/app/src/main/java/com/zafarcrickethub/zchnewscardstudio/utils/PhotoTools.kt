package com.zafarcrickethub.zchnewscardstudio.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import com.zafarcrickethub.zchnewscardstudio.graphics.Bmp
import jp.co.cyberagent.android.gpuimage.GPUImage
import jp.co.cyberagent.android.gpuimage.filter.GPUImageBrightnessFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageColorMatrixFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageContrastFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageFilterGroup
import jp.co.cyberagent.android.gpuimage.filter.GPUImageGammaFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageGrayscaleFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageSaturationFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageSepiaToneFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageVignetteFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Picture tools for the news cards:
 *  - filters: GPUImage (OpenGL ES shaders on the GPU)
 *  - remove background: ML Kit selfie segmentation (on-device, the model is bundled with the app, no internet)
 * Both write a NEW file next to the source picture and return its path; the original file is never touched.
 */
object PhotoTools {
    /** Index 0 = "Original" (handled by the caller: it means "go back to the picture before the filter"). */
    val filterNames = listOf("Original", "Vivid", "Warm", "Cool", "Black & white", "Sepia", "Drama", "Bright", "Soft fade")

    private fun matrix(vararg v: Float): GPUImageFilter = GPUImageColorMatrixFilter(1.0f, floatArrayOf(*v))

    private fun filterFor(index: Int): GPUImageFilter? = when (index) {
        1 -> GPUImageFilterGroup(listOf<GPUImageFilter>(GPUImageSaturationFilter(1.4f), GPUImageContrastFilter(1.12f)))
        2 -> matrix(1.10f, 0f, 0f, 0f, 0f, 1.0f, 0f, 0f, 0f, 0f, 0.86f, 0f, 0f, 0f, 0f, 1f)
        3 -> matrix(0.88f, 0f, 0f, 0f, 0f, 1.0f, 0f, 0f, 0f, 0f, 1.12f, 0f, 0f, 0f, 0f, 1f)
        4 -> GPUImageFilterGroup(listOf<GPUImageFilter>(GPUImageGrayscaleFilter(), GPUImageContrastFilter(1.15f)))
        5 -> GPUImageSepiaToneFilter()
        6 -> GPUImageFilterGroup(listOf<GPUImageFilter>(GPUImageContrastFilter(1.3f), GPUImageSaturationFilter(0.85f), GPUImageVignetteFilter()))
        7 -> GPUImageFilterGroup(listOf<GPUImageFilter>(GPUImageBrightnessFilter(0.08f), GPUImageGammaFilter(1.15f)))
        8 -> GPUImageFilterGroup(listOf<GPUImageFilter>(GPUImageContrastFilter(0.88f), GPUImageSaturationFilter(0.9f), GPUImageBrightnessFilter(0.04f)))
        else -> null
    }

    private fun outFile(src: String, tag: String, png: Boolean): File =
        File(File(src).parentFile, "img_${System.currentTimeMillis()}_$tag.${if (png) "png" else "jpg"}")

    private fun save(bmp: Bitmap, file: File, png: Boolean) {
        FileOutputStream(file).use { o ->
            bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 92, o)
        }
    }

    /** Applies filter `index` (1..) to the picture and returns the path of the new picture, or null if it failed. */
    suspend fun applyFilter(ctx: Context, srcPath: String, index: Int): String? = withContext(Dispatchers.Default) {
        val filter = filterFor(index) ?: return@withContext null
        val src = Bmp.load(srcPath, 2048) ?: return@withContext null
        try {
            val gpu = GPUImage(ctx.applicationContext)
            gpu.setImage(src)
            gpu.setFilter(filter)
            var result: Bitmap = gpu.getBitmapWithFilterApplied() ?: return@withContext null
            val keepAlpha = src.hasAlpha()
            if (keepAlpha) {
                // shaders do not always keep transparency (cut-out pictures): copy the original alpha back
                val copy = result.copy(Bitmap.Config.ARGB_8888, true) ?: return@withContext null
                val p = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
                Canvas(copy).drawBitmap(src, 0f, 0f, p)
                result = copy
            }
            val out = outFile(srcPath, "f$index", keepAlpha)
            save(result, out, keepAlpha)
            out.path
        } catch (t: Throwable) {
            null
        }
    }

    /** Cuts the person out of the picture (transparent PNG). Returns null when no person is found. */
    suspend fun removeBackground(srcPath: String): String? = withContext(Dispatchers.Default) {
        val src = Bmp.load(srcPath, 1280) ?: return@withContext null
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .build()
        val segmenter = Segmentation.getClient(options)
        try {
            val mask = segmenter.process(InputImage.fromBitmap(src, 0)).await()
            val mw = mask.width
            val mh = mask.height
            val buf = mask.buffer
            buf.rewind()
            val conf = FloatArray(mw * mh)
            for (i in conf.indices) conf[i] = buf.getFloat()

            val w = src.width
            val h = src.height
            val px = IntArray(w * h)
            src.getPixels(px, 0, w, 0, 0, w, h)
            var solid = 0
            for (y in 0 until h) {
                val my = (y * mh / h).coerceIn(0, mh - 1)
                for (x in 0 until w) {
                    val mx = (x * mw / w).coerceIn(0, mw - 1)
                    val c = conf[my * mw + mx]
                    val a = ((c - 0.45f) / 0.25f).coerceIn(0f, 1f)     // soft edge between 45% and 70% confidence
                    if (a > 0.5f) solid++
                    val i = y * w + x
                    px[i] = (px[i] and 0x00FFFFFF) or ((a * 255f).toInt() shl 24)
                }
            }
            if (solid < w * h * 0.015f) return@withContext null          // nobody found
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            out.setPixels(px, 0, w, 0, 0, w, h)
            val file = outFile(srcPath, "cutout", true)
            save(out, file, true)
            file.path
        } finally {
            segmenter.close()
        }
    }
}
