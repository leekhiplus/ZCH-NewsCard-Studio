package com.zafarcrickethub.zchnewscardstudio.renderer

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import com.zafarcrickethub.zchnewscardstudio.data.Pal
import com.zafarcrickethub.zchnewscardstudio.graphics.Bmp
import com.zafarcrickethub.zchnewscardstudio.graphics.TextKit
import kotlin.math.max

data class ThumbSpec(
    val bgMode: Int = 0,          // 0 navy, 1 red, 2 gold, 3 image
    val bgPath: String? = null,
    val playerPath: String? = null,
    val urdu: String = "پاکستان نے سیریز جیت لی",
    val english: String = "PAKISTAN WIN THE SERIES",
    val color: Int = Pal.White,
    val urduScale: Float = 1f,
    val engScale: Float = 1f,
    val showLogo: Boolean = true,
    val logoPath: String? = null,
    val channelName: String = "ZAFAR CRICKET HUB"
)

object ThumbRenderer {
    const val W = 1280
    const val H = 720
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    private fun cover(cv: Canvas, path: String?, dest: RectF, rad: Float): Boolean {
        val b = Bmp.load(path, 1600) ?: return false
        cv.save()
        cv.clipPath(Path().apply { addRoundRect(dest, rad, rad, Path.Direction.CW) })
        val sc = max(dest.width() / b.width, dest.height() / b.height)
        val m = Matrix()
        m.setScale(sc, sc)
        m.postTranslate(dest.centerX() - b.width * sc / 2, dest.centerY() - b.height * sc / 2)
        cv.drawBitmap(b, m, bmpPaint)
        cv.restore()
        return true
    }

    fun draw(ctx: Context, cv: Canvas, w: Int, h: Int, t: ThumbSpec) {
        val save = cv.save()
        cv.scale(w / W.toFloat(), h / H.toFloat())
        val full = RectF(0f, 0f, W.toFloat(), H.toFloat())
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val (c1, c2) = when (t.bgMode) {
            1 -> Pal.Red to Pal.DarkRed
            2 -> Pal.Gold to 0xFF8A6D00.toInt()
            else -> Pal.Navy to Pal.DeepNavy
        }
        p.shader = LinearGradient(0f, 0f, W.toFloat(), H.toFloat(), c1, c2, Shader.TileMode.CLAMP)
        cv.drawRect(full, p); p.shader = null
        if (t.bgMode == 3 && cover(cv, t.bgPath, full, 0f)) {
            p.color = 0x88000000.toInt(); cv.drawRect(full, p)
        }
        val hasPlayer = t.playerPath != null
        if (hasPlayer) {
            val r = RectF(30f, 30f, 560f, 690f)
            if (cover(cv, t.playerPath, r, 24f)) {
                p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = Pal.Gold
                cv.drawRoundRect(r, 24f, 24f, p)
            }
        }
        val tr = if (hasPlayer) RectF(590f, 50f, 1250f, 470f) else RectF(60f, 90f, 1220f, 470f)
        TextKit.draw(ctx, cv, t.urdu, tr, 130f, t.color, true, true, 1, t.urduScale)
        val bar = RectF(tr.left, 500f, tr.right, 520f)
        p.reset(); p.color = Pal.Red; cv.drawRect(RectF(bar.left, 490f, bar.right, 500f), p)
        TextKit.draw(ctx, cv, t.english, RectF(tr.left, 510f, tr.right, 680f), 80f, if (t.bgMode == 2) Pal.DeepNavy else Pal.Gold, true, true, 1, t.engScale, latin = true)
        if (t.showLogo) {
            val lb = Bmp.load(t.logoPath, 600)
            if (lb != null) {
                val lw = 200f; val lh = lw * lb.height / lb.width
                cv.drawBitmap(lb, null, RectF(W - 30f - lw, 20f, W - 30f, 20f + lh), bmpPaint)
            } else {
                val r = RectF(W - 330f, 18f, W - 24f, 80f)
                p.reset(); p.isAntiAlias = true; p.color = 0xE60A1A3F.toInt(); cv.drawRoundRect(r, 31f, 31f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = Pal.Gold; cv.drawRoundRect(r, 31f, 31f, p)
                TextKit.draw(ctx, cv, t.channelName, RectF(r.left + 20f, r.top + 8f, r.right - 20f, r.bottom - 8f), 36f, Pal.White, latin = true, shadow = false)
            }
        }
        cv.restoreToCount(save)
    }
}
