-keep class kotlinx.serialization.** { *; }
-keep class com.arthenica.** { *; }
-keep class com.yalantis.ucrop.** { *; }
-keep class be.tarsos.dsp.** { *; }
-keep class com.airbnb.lottie.** { *; }
# native (JNI) method names must survive renaming
-keep class com.zafarcrickethub.zchnewscardstudio.audio.OboeRecorder { *; }
-dontwarn com.yalantis.ucrop.**
-dontwarn okhttp3.**
-dontwarn okio.**

# Libraries added for this app's own filters / segmentation / playback / compression. Kept whole (reflection, native
# bindings or JSON model files inside them) so enabling R8 below cannot break them; the app's OWN code is NOT listed
# here, so it still gets shrunk and its names obfuscated like we want.
-keep class jp.co.cyberagent.android.gpuimage.** { *; }
-dontwarn jp.co.cyberagent.android.gpuimage.**
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.internal.mlkit_vision_segmentation_selfie.** { *; }
-dontwarn com.google.mlkit.**
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keeps crash stack traces readable for support, without keeping class/method names (those are still obfuscated).
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
