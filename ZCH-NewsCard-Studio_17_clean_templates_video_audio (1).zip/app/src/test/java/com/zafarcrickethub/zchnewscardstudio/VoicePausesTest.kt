package com.zafarcrickethub.zchnewscardstudio

import com.zafarcrickethub.zchnewscardstudio.audio.VoicePauses
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VoicePausesTest {
    private fun p(a: Long, b: Long) = VoicePauses.Pause(a, b)

    @Test fun oneCutForEveryLongEnoughPause() {
        val pauses = listOf(p(3000, 3500), p(7000, 7600), p(11000, 11200))
        // all three pauses are long enough -> 3 cuts -> 4 spoken parts
        assertEquals(3, VoicePauses.cuts(pauses, 150, 15000).size)
        // only the two longest (500 ms and 600 ms) count when the minimum is 400 ms
        assertEquals(2, VoicePauses.cuts(pauses, 400, 15000).size)
        // nothing counts when the minimum is longer than every pause
        assertTrue(VoicePauses.cuts(pauses, 2000, 15000).isEmpty())
    }

    @Test fun cutsAreSortedAndInsideThePauses() {
        val pauses = listOf(p(7000, 7600), p(3000, 3500))      // given out of order
        val cuts = VoicePauses.cuts(pauses, 300, 15000)
        assertEquals(2, cuts.size)
        assertTrue(cuts[0] < cuts[1])
        assertTrue(cuts[0] in 3000..3500)
        assertTrue(cuts[1] in 7000..7600)
    }

    @Test fun cutIsMiddleOfShortPauseAndJustBeforeSpeechForLongPause() {
        assertEquals(3200L, VoicePauses.cutPoint(p(3000, 3400)))      // middle
        assertEquals(3750L, VoicePauses.cutPoint(p(3000, 4000)))      // 250 ms before the next sentence
    }

    @Test fun tooShortPartsAreNotCreated() {
        // a second pause only 400 ms after the first would make a 400 ms card: skipped
        val pauses = listOf(p(3000, 3400), p(3800, 4200), p(9000, 9400))
        val cuts = VoicePauses.cuts(pauses, 300, 15000)
        assertEquals(2, cuts.size)
        // a pause right before the end of the audio is skipped as well
        val tail = VoicePauses.cuts(listOf(p(3000, 3400), p(14500, 14900)), 300, 15000)
        assertEquals(1, tail.size)
    }
}
