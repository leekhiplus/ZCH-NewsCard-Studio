package com.zafarcrickethub.zchnewscardstudio.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.zafarcrickethub.zchnewscardstudio.data.Opt
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.data.Samples

@Composable
private fun RowScope.Tile(title: String, sub: String, icon: ImageVector, color: Color, onClick: () -> Unit) {
    Card(
        onClick = onClick, modifier = Modifier.weight(1f).height(112.dp),
        colors = CardDefaults.cardColors(containerColor = color)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = Color.White)
            Column { Text(title, style = MaterialTheme.typography.titleSmall); Text(sub, style = MaterialTheme.typography.bodySmall, color = Color(0xFFDDE3F5)) }
        }
    }
}

@Composable
fun NewProjectDialog(initialTemplate: Int, onDismiss: () -> Unit, onCreate: (String, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var t by remember { mutableStateOf(initialTemplate) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss, title = { Text("New project") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Project name") }, singleLine = true)
                DropdownField("First card", Opt.templates, t, { t = it })
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(name, t) }) { Text("Create") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ProjectItem(vm: MainViewModel, p: Project, extra: @Composable () -> Unit = {}) {
    Card(onClick = { vm.open(p.id) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            val c = p.cards.firstOrNull()
            if (c != null) CardThumb(p, c, Modifier.width(130.dp), 320)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(p.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text(dateText(p.createdAt), style = MaterialTheme.typography.bodySmall)
                Text("${p.cards.size} cards • ${statusText(p.exportStatus)}", style = MaterialTheme.typography.bodySmall, color = Color(0xFFFFC107))
            }
            extra()
        }
    }
}

@Composable
fun DashboardScreen(vm: MainViewModel) {
    val projects by vm.projects.collectAsState()
    val settings by vm.settings.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    if (showNew) NewProjectDialog(0, { showNew = false }) { n, t -> showNew = false; vm.createProject(n, t) }
    ScreenScaffold("ZCH NewsCard Studio", null) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("Zafar Cricket Hub", style = MaterialTheme.typography.headlineSmall, color = Color(0xFFFFC107))
                Text("Offline Urdu news graphics & video creator", style = MaterialTheme.typography.bodyMedium)
            }
            val last = projects.find { it.id == settings.lastProject }
            if (last != null) item {
                Card(onClick = { vm.open(last.id) }, colors = CardDefaults.cardColors(containerColor = Color(0xFF7A0016))) {
                    Row(Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayArrow, null); Column(Modifier.padding(start = 10.dp)) {
                            Text("Continue editing", style = MaterialTheme.typography.labelMedium); Text(last.name, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
            item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile("Create New Project", "Start a news video", Icons.Default.AddCircle, Color(0xFFD90429)) { showNew = true }
                Tile("My Projects", "${projects.size} saved", Icons.Default.FolderOpen, Color(0xFF1B3270)) { vm.go(Screen.Projects) }
            } }
            item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile("News Templates", "13 built-in designs", Icons.Default.Slideshow, Color(0xFF1B3270)) { vm.go(Screen.Templates) }
                Tile("Recent Exports", "Play • share • delete", Icons.Default.MovieCreation, Color(0xFF1B3270)) { vm.go(Screen.Exports) }
            } }
            item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile("Thumbnail Maker", "1280×720 JPG / PNG", Icons.Default.Image, Color(0xFF8A6D00)) { vm.go(Screen.Thumbnail) }
                Tile("Settings", "Defaults & branding", Icons.Default.Settings, Color(0xFF1B3270)) { vm.go(Screen.Settings) }
            } }
            item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile("Help & About", "How it works", Icons.Default.Info, Color(0xFF1B3270)) { vm.go(Screen.Help) }
                Row(Modifier.weight(1f)) {}
            } }
            if (projects.isNotEmpty()) {
                item { Text("Recent projects", style = MaterialTheme.typography.titleMedium) }
                items(projects.take(4), key = { it.id }) { ProjectItem(vm, it) }
            }
        }
    }
}

@Composable
fun ProjectsScreen(vm: MainViewModel) {
    val projects by vm.projects.collectAsState()
    var rename by remember { mutableStateOf<Project?>(null) }
    var del by remember { mutableStateOf<Project?>(null) }
    var showNew by remember { mutableStateOf(false) }
    rename?.let { p -> TextInputDialog("Rename project", p.name, { rename = null }) { vm.rename(p.id, it); rename = null } }
    del?.let { p -> ConfirmDialog("Delete \"${p.name}\" and all of its files?", { del = null }) { vm.delete(p.id) } }
    if (showNew) NewProjectDialog(0, { showNew = false }) { n, t -> showNew = false; vm.createProject(n, t) }
    ScreenScaffold("My Projects", { vm.back() }, actions = {
        IconButton(onClick = { showNew = true }) { Icon(Icons.Default.AddCircle, "New") }
    }) { pad ->
        if (projects.isEmpty()) {
            Column(Modifier.padding(pad).fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("No projects yet. Tap + to create your first news video.")
            }
        } else LazyColumn(Modifier.padding(pad).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(projects, key = { it.id }) { p ->
                ProjectItem(vm, p) {
                    Column {
                        Row {
                            IconButton(onClick = { rename = p }) { Icon(Icons.Default.Edit, "Rename") }
                            IconButton(onClick = { vm.duplicate(p.id) }) { Icon(Icons.Default.ContentCopy, "Duplicate") }
                        }
                        IconButton(onClick = { del = p }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            }
        }
    }
}

@Composable
fun TemplatesScreen(vm: MainViewModel) {
    var pick by remember { mutableStateOf(-1) }
    if (pick >= 0) NewProjectDialog(pick, { pick = -1 }) { n, t -> pick = -1; vm.createProject(n, t) }
    val demo = Project(cards = emptyList())
    ScreenScaffold("News Templates", { vm.back() }) { pad ->
        LazyVerticalGrid(GridCells.Adaptive(170.dp), Modifier.padding(pad).padding(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(Opt.templates.indices.toList()) { i ->
                Card(onClick = { pick = i }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(8.dp)) {
                        CardThumb(demo, remember(i) { Samples.card(i) }, Modifier.fillMaxWidth(), 420)
                        Text(Opt.templates[i], Modifier.padding(top = 6.dp), style = MaterialTheme.typography.labelLarge, maxLines = 2)
                        Text("Tap to start a project", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun ExportsScreen(vm: MainViewModel) {
    val projects by vm.projects.collectAsState()
    val ctx = LocalContext.current
    val all = projects.flatMap { p -> p.exports.map { p to it } }.sortedByDescending { it.second.time }
    ScreenScaffold("Recent Exports", { vm.back() }) { pad ->
        if (all.isEmpty()) {
            Column(Modifier.padding(pad).fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) { Text("No exported videos yet.") }
        } else LazyColumn(Modifier.padding(pad).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(all, key = { it.second.uri }) { (p, rec) ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(rec.name, style = MaterialTheme.typography.titleMedium)
                        Text("${p.name} • ${rec.info}", style = MaterialTheme.typography.bodySmall)
                        Text(dateText(rec.time), style = MaterialTheme.typography.bodySmall, color = Color(0xFFFFC107))
                        Row {
                            TextButton(onClick = {
                                try { ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(rec.uri), "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                                catch (e: Exception) { vm.message = "No video player found" }
                            }) { IconText(Icons.Default.PlayArrow, "Play") }
                            TextButton(onClick = {
                                val i = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, Uri.parse(rec.uri)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                ctx.startActivity(Intent.createChooser(i, "Share video"))
                            }) { IconText(Icons.Default.Share, "Share") }
                            TextButton(onClick = { vm.deleteExport(p.id, rec) }) { IconText(Icons.Default.Delete, "Delete") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val st by vm.settings.collectAsState()
    var channel by remember(st.channelName) { mutableStateOf(st.channelName) }
    var ticker by remember(st.ticker) { mutableStateOf(st.ticker) }
    ScreenScaffold("Settings", { vm.back() }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Defaults for new projects & exports", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFC107))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Portrait 9:16 by default", Modifier.weight(1f))
                Switch(checked = !st.landscape, onCheckedChange = { v -> vm.updateAppSettings { it.copy(landscape = !v) } })
            }
            Text("Default resolution")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(720, 1080).forEach { r -> FilterChip(selected = st.resolution == r, onClick = { vm.updateAppSettings { it.copy(resolution = r) } }, label = { Text("${r}p") }) }
            }
            Text("Default frame rate")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(24, 25, 30).forEach { f -> FilterChip(selected = st.fps == f, onClick = { vm.updateAppSettings { it.copy(fps = f) } }, label = { Text("$f fps") }) }
            }
            OutlinedTextField(value = channel, onValueChange = { channel = it; vm.updateAppSettings { s -> s.copy(channelName = it) } }, label = { Text("Channel name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            RtlField("Default ticker text", ticker, { ticker = it; vm.updateAppSettings { s -> s.copy(ticker = it) } }, minLines = 2)
            Text("Settings are stored on this device (DataStore). The app never needs the internet.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun HelpScreen(vm: MainViewModel) {
    ScreenScaffold("Help & About", { vm.back() }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("ZCH NewsCard Studio", style = MaterialTheme.typography.headlineSmall, color = Color(0xFFFFC107))
            Text("Zafar Cricket Hub • version 1.0.0")
            Text("How to make a video", style = MaterialTheme.typography.titleMedium)
            Text("1. Create a project and pick the first template.\n2. Open the Timeline tab and import your voice-over (MP3, WAV, M4A, AAC).\n3. Editor layout (like CapCut / InShot): preview on top, multi-track timeline in the middle, tools at the bottom. Drag the timeline to scrub; the white line in the centre is the play-head.\n4. Tap a card clip to select it: drag its white edge handles to trim, or use Timing to type exact start / end / duration. Split cuts a card at the play-head. Double-tap a clip to edit its text, pictures and animations.\n5. Voice, Ticker and Logo tracks are below the cards: tap them to edit.\n6. Add card → 13 templates, including 5 match templates with a BREAKING NEWS banner on top, pictures, and the ticker strip at the bottom.\n7. Export (top right): 720p/1080p, 16:9 or 9:16, FPS, quality → MP4 in Movies/ZCH NewsCard Studio.")
            Text("Good to know", style = MaterialTheme.typography.titleMedium)
            Text("• Card timing is manual (or evenly distributed). The app does not understand speech.\n• Everything is processed locally. No internet, accounts or ads.\n• Image \"crop\" is done by zooming and moving the image inside the card frame.\n• Flags are simplified built-in drawings.\n• Very high resolutions (1080p) need more storage and time on older phones.")
        }
    }
}
