package com.zafarcrickethub.zchnewscardstudio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zafarcrickethub.zchnewscardstudio.audio.Playback
import com.zafarcrickethub.zchnewscardstudio.data.Opt
import com.zafarcrickethub.zchnewscardstudio.data.Project
import com.zafarcrickethub.zchnewscardstudio.data.Samples
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportState
import com.zafarcrickethub.zchnewscardstudio.renderer.ExportUi
import com.zafarcrickethub.zchnewscardstudio.renderer.Thumbs
import com.zafarcrickethub.zchnewscardstudio.utils.Timing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.floor
import com.zafarcrickethub.zchnewscardstudio.data.Card as NCard

@Composable
fun PlaybackLoop(pb: Playback) {
    LaunchedEffect(pb.playing) {
        if (pb.playing) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                pb.tick((now - last) / 1_000_000L)
                last = now
            }
        }
    }
}

// =====================================================================================
//  Editor screen: preview (top) – transport – multi-track timeline – tool bar (bottom)
// =====================================================================================
@Composable
fun EditorScreen(vm: MainViewModel) {
    val p = vm.current ?: run { vm.go(Screen.Projects); return }
    PlaybackLoop(vm.playback)
    if (vm.showExport) { ExportScreen(vm, p); return }
    val ec = vm.editingCard
    if (ec != null) { CardEditor(vm, p, ec); return }
    if (vm.fullPreview) { FullPreview(vm, p); return }
    var rename by remember { mutableStateOf(false) }
    if (rename) TextInputDialog("Rename project", p.name, { rename = false }) { vm.rename(p.id, it); rename = false }

    Column(Modifier.fillMaxSize().background(NavyDark)) {
        Row(Modifier.fillMaxWidth().background(NavyC).padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            Column(Modifier.weight(1f).clickable { rename = true }) {
                Text(p.name, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                Text("${if (p.settings.landscape) "16:9" else "9:16"} • ${p.cards.size} cards • ${Timing.fmt(Timing.totalMs(p))}", style = MaterialTheme.typography.labelSmall, color = Color(0xFFB8C4E6))
            }
            Button(
                onClick = { vm.playback.pause(); vm.showExport = true },
                colors = ButtonDefaults.buttonColors(containerColor = RedC),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)
            ) { Text("Export") }
        }
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF02060F)).padding(6.dp)) {
            FitPreview(p, { vm.playback.positionMs }, Modifier.fillMaxSize())
        }
        TransportBar(vm, p)
        TimelineView(vm, p, Modifier.fillMaxWidth())
        EditorToolbar(vm, p)
    }
    SheetHost(vm, p)
}

@Composable
private fun TransportBar(vm: MainViewModel, p: Project) {
    val pb = vm.playback
    val total = Timing.totalMs(p)
    Row(Modifier.fillMaxWidth().background(NavyC).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("${Timing.fmt(pb.positionMs)} / ${Timing.fmt(total)}", style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(104.dp))
        IconButton(onClick = { vm.undo() }, enabled = vm.undoCount > 0) { Icon(Icons.Default.Undo, "Undo", tint = if (vm.undoCount > 0) Color.White else Color.Gray) }
        IconButton(onClick = { vm.redo() }, enabled = vm.redoCount > 0) { Icon(Icons.Default.Redo, "Redo", tint = if (vm.redoCount > 0) Color.White else Color.Gray) }
        Spacer(Modifier.weight(1f))
        Button(
            onClick = { pb.toggle() }, shape = CircleShape, contentPadding = PaddingValues(0.dp),
            colors = ButtonDefaults.buttonColors(containerColor = RedC), modifier = Modifier.size(44.dp)
        ) { Icon(if (pb.playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play / Pause") }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = { vm.zoomDp = (vm.zoomDp / 1.4f).coerceAtLeast(12f) }) { Icon(Icons.Default.ZoomOut, "Zoom out", tint = Color.White) }
        IconButton(onClick = { vm.zoomDp = (vm.zoomDp * 1.4f).coerceAtMost(500f) }) { Icon(Icons.Default.ZoomIn, "Zoom in", tint = Color.White) }
        IconButton(onClick = { vm.fullPreview = true }) { Icon(Icons.Default.Fullscreen, "Full preview", tint = Color.White) }
    }
}

@Composable
private fun FullPreview(vm: MainViewModel, p: Project) {
    val pb = vm.playback
    val total = Timing.totalMs(p)
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { pb.pause(); vm.fullPreview = false }) { Icon(Icons.Default.FullscreenExit, "Exit", tint = Color.White) }
            Text("Preview", color = Color.White)
        }
        FitPreview(p, { pb.positionMs }, Modifier.weight(1f).fillMaxWidth())
        Slider(
            value = pb.positionMs.toFloat(), onValueChange = { pb.seek(it.toLong()) },
            valueRange = 0f..total.toFloat().coerceAtLeast(1f), modifier = Modifier.padding(horizontal = 12.dp)
        )
        Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { val pr = p.cards.lastOrNull { it.startMs < pb.positionMs - 500 }; pb.seek(pr?.startMs ?: 0L) }) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White) }
            Button(onClick = { pb.toggle() }, colors = ButtonDefaults.buttonColors(containerColor = RedC)) {
                Icon(if (pb.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null); Text(if (pb.playing) " Pause" else " Play")
            }
            IconButton(onClick = { val nx = p.cards.firstOrNull { it.startMs > pb.positionMs + 10 }; if (nx != null) pb.seek(nx.startMs) }) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
            Text("  ${Timing.fmt(pb.positionMs)} / ${Timing.fmt(total)}", color = Color.White)
        }
    }
}

// =====================================================================================
//  Bottom tool bar (changes with the selected clip, like CapCut)
// =====================================================================================
@Composable
private fun ToolButton(icon: ImageVector, label: String, enabled: Boolean = true, tint: Color = Color.White, onClick: () -> Unit) {
    Column(
        Modifier.width(66.dp).clickable(enabled = enabled, onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = if (enabled) tint else Color.Gray, modifier = Modifier.size(24.dp))
        Text(label, fontSize = 10.sp, maxLines = 1, color = if (enabled) Color(0xFFDDE3F5) else Color.Gray)
    }
}

@Composable
private fun EditorToolbar(vm: MainViewModel, p: Project) {
    val sel = vm.sel
    val card = if (sel.startsWith("card:")) p.cards.find { it.id == sel.removePrefix("card:") } else null
    val idx = if (card != null) p.cards.indexOf(card) else -1
    var confirmDelete by remember { mutableStateOf(false) }
    if (confirmDelete && card != null) ConfirmDialog("Delete this card?", { confirmDelete = false }) { vm.deleteCard(card.id) }
    LazyRow(
        Modifier.fillMaxWidth().background(Color(0xFF0B1226)),
        contentPadding = PaddingValues(horizontal = 6.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        if (card != null) {
            item { ToolButton(Icons.Default.Check, "Done", tint = Color(0xFFFFC107)) { vm.sel = "" } }
            item { ToolButton(Icons.Default.Edit, "Edit") { vm.editingCard = card.id } }
            item { ToolButton(Icons.Default.Dashboard, "Template") { vm.sheet = "template" } }
            item { ToolButton(Icons.Default.Timer, "Timing") { vm.sheet = "timing" } }
            item { ToolButton(Icons.Default.Animation, "Animation") { vm.sheet = "anim" } }
            item { ToolButton(Icons.Default.ContentCut, "Split") { vm.splitCard(card.id, vm.playback.positionMs) } }
            item { ToolButton(Icons.Default.ContentCopy, "Duplicate") { vm.duplicateCard(card.id) } }
            item { ToolButton(Icons.Default.ChevronLeft, "Move left", enabled = idx > 0) { vm.moveCard(card.id, -1) } }
            item { ToolButton(Icons.Default.ChevronRight, "Move right", enabled = idx < p.cards.size - 1) { vm.moveCard(card.id, 1) } }
            item { ToolButton(Icons.Default.Delete, "Delete", tint = Color(0xFFFF8A80)) { confirmDelete = true } }
        } else if (sel == "audio") {
            item { ToolButton(Icons.Default.Check, "Done", tint = Color(0xFFFFC107)) { vm.sel = "" } }
            item { ToolButton(Icons.Default.VolumeUp, "Volume") { vm.sheet = "audio" } }
            item { ToolButton(Icons.Default.Mic, "Replace") { vm.sheet = "audio" } }
            item { ToolButton(Icons.Default.Delete, "Remove", tint = Color(0xFFFF8A80)) { vm.removeAudio(); vm.sel = "" } }
        } else if (sel == "ticker") {
            item { ToolButton(Icons.Default.Check, "Done", tint = Color(0xFFFFC107)) { vm.sel = "" } }
            item { ToolButton(Icons.Default.Edit, "Edit ticker") { vm.sheet = "ticker" } }
            item { ToolButton(Icons.Default.Subtitles, if (p.settings.tickerOn) "Hide" else "Show") { vm.updateSettings { it.copy(tickerOn = !it.tickerOn) } } }
        } else if (sel == "logo") {
            item { ToolButton(Icons.Default.Check, "Done", tint = Color(0xFFFFC107)) { vm.sel = "" } }
            item { ToolButton(Icons.Default.Edit, "Edit logo") { vm.sheet = "brand" } }
            item { ToolButton(Icons.Default.Star, if (p.settings.showLogo) "Hide" else "Show") { vm.updateSettings { it.copy(showLogo = !it.showLogo) } } }
        } else {
            item { ToolButton(Icons.Default.AddCircle, "Add card", tint = Color(0xFFFFC107)) { vm.sheet = "addcard" } }
            item { ToolButton(Icons.Default.Mic, "Voice-over") { vm.sheet = "audio" } }
            item { ToolButton(Icons.Default.Subtitles, "Ticker") { vm.sheet = "ticker" } }
            item { ToolButton(Icons.Default.Star, "Logo") { vm.sheet = "brand" } }
            item { ToolButton(Icons.Default.Timer, "Timing") { vm.sheet = "opts" } }
            item { ToolButton(Icons.Default.AspectRatio, "Format") { vm.sheet = "format" } }
            item { ToolButton(Icons.Default.Image, "Thumbnail") { vm.playback.pause(); vm.go(Screen.Thumbnail) } }
            item { ToolButton(Icons.Default.Fullscreen, "Preview") { vm.fullPreview = true } }
        }
    }
}

// =====================================================================================
//  Multi-track timeline (ruler, cards with thumbnails, voice-over waveform, ticker, logo)
// =====================================================================================
@Composable
private fun rememberCardThumbs(p: Project): Map<String, ImageBitmap> {
    val ctx = LocalContext.current
    val map = remember { mutableStateMapOf<String, ImageBitmap>() }
    val keys = remember { HashMap<String, Int>() }
    val sig = p.cards.map { it.id to it.copy(startMs = 0, endMs = 5000).hashCode() } + listOf("land" to p.settings.landscape.hashCode())
    LaunchedEffect(sig) {
        withContext(Dispatchers.Default) {
            for (c in p.cards) {
                val h = c.copy(startMs = 0, endMs = 5000).hashCode() * 31 + p.settings.landscape.hashCode()
                if (keys[c.id] != h) {
                    val bmp = runCatching { Thumbs.render(ctx, p, c, 240) }.getOrNull() ?: continue
                    keys[c.id] = h
                    withContext(Dispatchers.Main) { map[c.id] = bmp.asImageBitmap() }
                }
            }
        }
    }
    return map
}

@Composable
private fun TimelineView(vm: MainViewModel, p: Project, modifier: Modifier = Modifier) {
    val pb = vm.playback
    val density = LocalDensity.current.density
    val total = Timing.totalMs(p)
    val s = p.settings
    val thumbs = rememberCardThumbs(p)
    val wf = vm.waveform
    val pNow by rememberUpdatedState(p)

    val rulerH = 24f * density
    val cardH = 60f * density
    val audioH = 42f * density
    val tickH = 30f * density
    val logoH = 30f * density
    val gap = 4f * density
    val yCard = rulerH + gap
    val yAudio = yCard + cardH + gap
    val yTick = yAudio + audioH + gap
    val yLogo = yTick + tickH + gap
    val textPaint = remember(density) {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f * density; color = android.graphics.Color.WHITE }
    }
    val hues = remember { listOf(Color(0xFFB3213B), Color(0xFF9A7B0A), Color(0xFF2756B5), Color(0xFF1E8F5B), Color(0xFF7B3FA0), Color(0xFFB45A2E)) }

    fun selIdx(): Int {
        val sl = vm.sel
        return if (sl.startsWith("card:")) pNow.cards.indexOfFirst { it.id == sl.removePrefix("card:") } else -1
    }

    Canvas(
        modifier.height(((yLogo + logoH + gap) / density).dp).background(Color(0xFF0B1226))
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { o ->
                        val w = size.width.toFloat()
                        val ppm = vm.zoomDp * density / 1000f
                        val ms = pb.positionMs + (o.x - w / 2f) / ppm
                        val cards = pNow.cards
                        when {
                            o.y < yCard -> pb.seek(ms.toLong())
                            o.y < yAudio -> {
                                val c = cards.lastOrNull { ms >= it.startMs && ms <= it.endMs }
                                vm.sel = if (c != null) "card:" + c.id else ""
                                val last = cards.maxOfOrNull { it.endMs } ?: 0L
                                val plusX = w / 2f + (last - pb.positionMs) * ppm
                                if (c == null && o.x >= plusX && o.x <= plusX + 52f * density) vm.sheet = "addcard"
                            }
                            o.y < yTick -> { if (pNow.settings.audioPath != null) vm.sel = "audio" else vm.sheet = "audio" }
                            o.y < yLogo -> vm.sel = "ticker"
                            else -> vm.sel = "logo"
                        }
                    },
                    onDoubleTap = { o ->
                        val w = size.width.toFloat()
                        val ppm = vm.zoomDp * density / 1000f
                        val ms = pb.positionMs + (o.x - w / 2f) / ppm
                        val c = pNow.cards.lastOrNull { ms >= it.startMs && ms <= it.endMs }
                        if (c != null && o.y >= yCard && o.y < yAudio) { vm.sel = "card:" + c.id; vm.editingCard = c.id }
                    }
                )
            }
            .pointerInput(Unit) {
                var mode = 0      // 0 = scrub, 1 = trim left edge, 2 = trim right edge
                var idx = -1
                var acc = 0f
                detectDragGestures(
                    onDragStart = { o ->
                        val w = size.width.toFloat()
                        val ppm = vm.zoomDp * density / 1000f
                        mode = 0; acc = 0f
                        val i = selIdx()
                        if (i >= 0 && o.y >= yCard && o.y < yAudio) {
                            val c = pNow.cards[i]
                            val xl = w / 2f + (c.startMs - pb.positionMs) * ppm
                            val xr = w / 2f + (c.endMs - pb.positionMs) * ppm
                            val hit = 30f * density
                            if (abs(o.x - xl) < hit && abs(o.x - xl) <= abs(o.x - xr)) { mode = 1; idx = i }
                            else if (abs(o.x - xr) < hit) { mode = 2; idx = i }
                        }
                        if (mode == 0) pb.pause()
                    },
                    onDragEnd = { mode = 0 },
                    onDragCancel = { mode = 0 }
                ) { change, drag ->
                    change.consume()
                    val w = size.width.toFloat()
                    val ppm = vm.zoomDp * density / 1000f
                    if (mode == 0) {
                        acc += -drag.x / ppm
                        val whole = acc.toLong()
                        acc -= whole
                        if (whole != 0L) pb.seek(pb.positionMs + whole)
                    } else {
                        val ms = pb.positionMs + (change.position.x - w / 2f) / ppm
                        vm.setEdge(idx, mode == 2, ms.toLong().coerceAtLeast(0L))
                    }
                }
            }
    ) {
        val w = size.width
        val ppm = vm.zoomDp * density / 1000f
        val cx = w / 2f
        val pos = pb.positionMs
        val sel = vm.sel
        fun xOf(ms: Long): Float = cx + (ms - pos) * ppm
        fun label(t: String, x: Float, y: Float, color: Int = android.graphics.Color.WHITE) {
            textPaint.color = color
            drawIntoCanvas { it.nativeCanvas.drawText(t, x, y, textPaint) }
        }
        val corner = CornerRadius(8f * density)

        // ---- ruler
        drawRect(Color(0xFF111B36), Offset.Zero, Size(w, rulerH))
        val secPx = vm.zoomDp * density
        val stepMs = when { secPx >= 110f -> 1000L; secPx >= 55f -> 2000L; secPx >= 22f -> 5000L; else -> 10000L }
        val leftMs = pos - cx / ppm
        var t = (floor(leftMs / stepMs).toLong() * stepMs).coerceAtLeast(0L)
        val rightMs = pos + cx / ppm
        while (t <= rightMs && t <= total + stepMs) {
            val x = xOf(t)
            drawLine(Color(0xFF6C7BA8), Offset(x, rulerH - 8f * density), Offset(x, rulerH), 2f)
            label("${t / 60000}:${"%02d".format((t / 1000) % 60)}", x + 3f * density, rulerH - 10f * density, 0xFFB8C4E6.toInt())
            t += stepMs
        }

        // ---- card clips with thumbnails
        drawRect(Color(0xFF0E1731), Offset(0f, yCard), Size(w, cardH))
        p.cards.forEachIndexed { i, c ->
            val x0 = xOf(c.startMs)
            val x1 = xOf(c.endMs)
            if (x1 < -40f || x0 > w + 40f) return@forEachIndexed
            val cw = (x1 - x0).coerceAtLeast(3f)
            drawRoundRect(hues[i % hues.size], Offset(x0, yCard), Size(cw, cardH), corner)
            val bmp = thumbs[c.id]
            if (bmp != null) {
                val tileW = (cardH * bmp.width / bmp.height).coerceAtLeast(8f)
                clipRect(x0, yCard, x0 + cw, yCard + cardH) {
                    var tx = x0
                    while (tx < x0 + cw) {
                        if (tx + tileW >= 0f && tx <= w) {
                            drawImage(image = bmp, dstOffset = IntOffset(tx.toInt(), yCard.toInt()), dstSize = IntSize(tileW.toInt(), cardH.toInt()))
                        }
                        tx += tileW
                    }
                    drawRect(Color(0xAA000000), Offset(x0, yCard), Size(cw, 15f * density))
                    label("${i + 1}  " + c.headline.replace('\n', ' ').take(24), x0 + 4f * density, yCard + 11f * density)
                }
            }
            val selected = sel == "card:" + c.id
            drawRoundRect(if (selected) Color.White else Color(0x66FFFFFF), Offset(x0, yCard), Size(cw, cardH), corner, style = Stroke(if (selected) 3f * density else 1f))
            if (selected) {
                val hw = 9f * density
                drawRoundRect(Color.White, Offset(x0 - 1f, yCard), Size(hw, cardH), CornerRadius(4f * density))
                drawRoundRect(Color.White, Offset(x1 - hw + 1f, yCard), Size(hw, cardH), CornerRadius(4f * density))
                drawLine(Color(0xFF333333), Offset(x0 + hw / 2f, yCard + cardH * 0.3f), Offset(x0 + hw / 2f, yCard + cardH * 0.7f), 2f)
                drawLine(Color(0xFF333333), Offset(x1 - hw / 2f + 1f, yCard + cardH * 0.3f), Offset(x1 - hw / 2f + 1f, yCard + cardH * 0.7f), 2f)
            }
        }
        // "+" button after the last card
        val lastEnd = p.cards.maxOfOrNull { it.endMs } ?: 0L
        val px = xOf(lastEnd) + 10f * density
        drawCircle(Color(0xFFFFC107), 16f * density, Offset(px + 16f * density, yCard + cardH / 2f))
        drawLine(Color.Black, Offset(px + 8f * density, yCard + cardH / 2f), Offset(px + 24f * density, yCard + cardH / 2f), 3f * density)
        drawLine(Color.Black, Offset(px + 16f * density, yCard + cardH / 2f - 8f * density), Offset(px + 16f * density, yCard + cardH / 2f + 8f * density), 3f * density)

        // ---- voice-over track
        val aSel = sel == "audio"
        if (s.audioPath != null) {
            val ax0 = xOf(0L)
            val ax1 = xOf(s.audioDurMs)
            drawRoundRect(Color(0xFF14636B), Offset(ax0, yAudio), Size((ax1 - ax0).coerceAtLeast(3f), audioH), corner)
            if (wf != null && wf.isNotEmpty()) {
                val bw = (ax1 - ax0) / wf.size
                for (i in wf.indices) {
                    val x = ax0 + (i + 0.5f) * bw
                    if (x < -2f || x > w + 2f) continue
                    val hh = wf[i] * audioH * 0.4f + 1f
                    drawLine(Color(0xDDFFFFFF), Offset(x, yAudio + audioH / 2f - hh), Offset(x, yAudio + audioH / 2f + hh), maxOf(1f, bw * 0.8f))
                }
            }
            clipRect(ax0, yAudio, ax1, yAudio + audioH) { label("🎙 Voice-over", maxOf(ax0, 0f) + 6f * density, yAudio + 12f * density) }
            if (aSel) drawRoundRect(Color.White, Offset(ax0, yAudio), Size((ax1 - ax0).coerceAtLeast(3f), audioH), corner, style = Stroke(3f * density))
        } else {
            drawRoundRect(Color(0xFF1A2646), Offset(8f * density, yAudio), Size(w - 16f * density, audioH), corner)
            label("＋ Tap to add voice-over", 18f * density, yAudio + audioH / 2f + 4f * density, 0xFFB8C4E6.toInt())
        }

        // ---- ticker + logo tracks
        val ex0 = xOf(0L)
        val ex1 = xOf(total)
        drawRoundRect(if (s.tickerOn) Color(0xFF8E1A2B) else Color(0xFF2A3354), Offset(ex0, yTick), Size((ex1 - ex0).coerceAtLeast(3f), tickH), corner)
        clipRect(ex0, yTick, ex1, yTick + tickH) {
            label(if (s.tickerOn) "📰 Ticker: " + s.tickerText.take(40) else "Ticker (hidden)", maxOf(ex0, 0f) + 6f * density, yTick + tickH / 2f + 4f * density)
        }
        if (sel == "ticker") drawRoundRect(Color.White, Offset(ex0, yTick), Size((ex1 - ex0).coerceAtLeast(3f), tickH), corner, style = Stroke(3f * density))
        drawRoundRect(if (s.showLogo) Color(0xFF7A6208) else Color(0xFF2A3354), Offset(ex0, yLogo), Size((ex1 - ex0).coerceAtLeast(3f), logoH), corner)
        clipRect(ex0, yLogo, ex1, yLogo + logoH) {
            label(if (s.showLogo) "★ Logo: " + s.channelName else "Logo (hidden)", maxOf(ex0, 0f) + 6f * density, yLogo + logoH / 2f + 4f * density)
        }
        if (sel == "logo") drawRoundRect(Color.White, Offset(ex0, yLogo), Size((ex1 - ex0).coerceAtLeast(3f), logoH), corner, style = Stroke(3f * density))

        // ---- end marker + play-head
        drawLine(Color(0x99FFC107), Offset(ex1, yCard), Offset(ex1, size.height), 2f)
        drawLine(Color.White, Offset(cx, 0f), Offset(cx, size.height), 2.5f * density)
        drawPath(Path().apply { moveTo(cx - 7f * density, 0f); lineTo(cx + 7f * density, 0f); lineTo(cx, 9f * density); close() }, Color.White)
    }
}

// =====================================================================================
//  Bottom sheets
// =====================================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SheetHost(vm: MainViewModel, p: Project) {
    val kind = vm.sheet
    if (kind.isEmpty()) return
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val card = if (vm.sel.startsWith("card:")) p.cards.find { it.id == vm.sel.removePrefix("card:") } else null
    ModalBottomSheet(onDismissRequest = { vm.sheet = "" }, sheetState = state, containerColor = SurfaceC) {
        Column(
            Modifier.padding(horizontal = 16.dp).padding(bottom = 28.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (kind) {
                "addcard" -> {
                    Text("Add a news card", style = MaterialTheme.typography.titleMedium, color = GoldC)
                    TemplateGrid(p) { t -> vm.addCard(t); vm.sheet = "" }
                }
                "template" -> if (card != null) {
                    Text("Change template", style = MaterialTheme.typography.titleMedium, color = GoldC)
                    TemplateGrid(p) { t -> vm.updateCard(card.id) { it.copy(template = t) }; vm.sheet = "" }
                }
                "timing" -> if (card != null) {
                    Text("Card timing (manual)", style = MaterialTheme.typography.titleMedium, color = GoldC)
                    TimingPanel(vm, p, card)
                }
                "anim" -> if (card != null) {
                    Text("Animation & transition", style = MaterialTheme.typography.titleMedium, color = GoldC)
                    AnimPanel(vm, card)
                }
                "ticker" -> { Text("News ticker", style = MaterialTheme.typography.titleMedium, color = GoldC); TickerPanel(vm, p) }
                "brand" -> { Text("Channel logo & branding", style = MaterialTheme.typography.titleMedium, color = GoldC); BrandPanel(vm, p) }
                "audio" -> { Text("Voice-over", style = MaterialTheme.typography.titleMedium, color = GoldC); AudioPanel(vm, p) }
                "opts" -> { Text("Timeline & timing", style = MaterialTheme.typography.titleMedium, color = GoldC); TimelineOptsPanel(vm, p) }
                "format" -> {
                    Text("Video format", style = MaterialTheme.typography.titleMedium, color = GoldC)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(p.settings.landscape, { vm.updateSettings { it.copy(landscape = true) } }, { Text("16:9 landscape") })
                        FilterChip(!p.settings.landscape, { vm.updateSettings { it.copy(landscape = false) } }, { Text("9:16 portrait") })
                    }
                }
            }
            Button(onClick = { vm.sheet = "" }, modifier = Modifier.fillMaxWidth()) { Text("Done") }
        }
    }
}

@Composable
private fun TemplateGrid(p: Project, onPick: (Int) -> Unit) {
    Opt.templates.indices.toList().chunked(2).forEach { rowIdx ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            rowIdx.forEach { i ->
                val sample = remember(i) { Samples.card(i) }
                Card(onClick = { onPick(i) }, modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = NavyC)) {
                    Column(Modifier.padding(6.dp)) {
                        CardThumb(p, sample, Modifier.fillMaxWidth(), 360)
                        Text(Opt.templates[i], style = MaterialTheme.typography.labelMedium, maxLines = 2, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
            if (rowIdx.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
fun TimingPanel(vm: MainViewModel, p: Project, c: NCard) {
    val id = c.id
    val dur = (c.endMs - c.startMs).coerceAtLeast(1L)
    val idx = p.cards.indexOfFirst { it.id == id }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Card ${idx + 1}", style = MaterialTheme.typography.labelLarge, color = Color(0xFFFFC107))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TimeField("Start", c.startMs, { v -> vm.setTiming(id, v, null) }, Modifier.weight(1f))
            TimeField("End", c.endMs, { v -> vm.setTiming(id, null, v) }, Modifier.weight(1f))
        }
        TimeField("Duration", dur, { v -> vm.setDuration(id, v) }, Modifier.fillMaxWidth())
        Text("Type a value and press Done (keyboard) or tap another field. Examples: 5   12.5   1:05   0:01:05.250", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.setTiming(id, vm.playback.positionMs, null) }, modifier = Modifier.weight(1f)) { Text("Start = play-head", fontSize = 12.sp) }
            OutlinedButton(onClick = { vm.setTiming(id, null, vm.playback.positionMs) }, modifier = Modifier.weight(1f)) { Text("End = play-head", fontSize = 12.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = { vm.nudge(id, -500, 0) }) { Text("Start −0.5s") }
            TextButton(onClick = { vm.nudge(id, 500, 0) }) { Text("Start +0.5s") }
            TextButton(onClick = { vm.nudge(id, 0, -500) }) { Text("End −0.5s") }
            TextButton(onClick = { vm.nudge(id, 0, 500) }) { Text("End +0.5s") }
        }
        if (idx > 0) OutlinedButton(onClick = { vm.startAfterPrevious(id) }, modifier = Modifier.fillMaxWidth()) { Text("Start right after previous card") }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(p.settings.ripple, { v -> vm.updateSettings { it.copy(ripple = v) } })
            Text("  Move the following cards when I change the end time", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
        }
        Timing.validate(p.cards, p.settings.audioDurMs, p.settings.allowOverlap).filter { it.index == idx }.forEach {
            Text("⚠ ${it.text}", color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun AnimPanel(vm: MainViewModel, c: NCard) {
    val id = c.id
    DropdownField("Text animation", Opt.textAnims, c.textAnim, { v -> vm.updateCard(id) { it.copy(textAnim = v) } })
    DropdownField("Image animation", Opt.imageAnims, c.imageAnim, { v -> vm.updateCard(id) { it.copy(imageAnim = v) } })
    DropdownField("Transition into this card", Opt.transitions, c.transition, { v -> vm.updateCard(id) { it.copy(transition = v) } })
    SliderRow("Animation duration", c.animMs.toFloat(), 150f..2500f, "${c.animMs} ms") { v -> vm.updateCard(id) { it.copy(animMs = v.toInt()) } }
    SliderRow("Animation speed", c.animSpeed, 0.25f..3f, "x${"%.2f".format(c.animSpeed)}") { v -> vm.updateCard(id) { it.copy(animSpeed = v) } }
}

@Composable
private fun TickerPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(s.tickerOn, { v -> vm.updateSettings { it.copy(tickerOn = v) } }); Text("  Show ticker strip") }
    RtlField("Ticker text (Urdu / English)", s.tickerText, { v -> vm.updateSettings { it.copy(tickerText = v) } }, minLines = 2)
    RtlField("Label", s.tickerLabel, { v -> vm.updateSettings { it.copy(tickerLabel = v) } })
    SliderRow("Scrolling speed", s.tickerSpeed, 30f..400f, "${s.tickerSpeed.toInt()} px/s") { v -> vm.updateSettings { it.copy(tickerSpeed = v) } }
    SliderRow("Font size", s.tickerSize, 0.6f..1.6f, "${(s.tickerSize * 100).toInt()}%") { v -> vm.updateSettings { it.copy(tickerSize = v) } }
    ColorRow("Ticker text colour", s.tickerColor) { v -> vm.updateSettings { it.copy(tickerColor = v) } }
    ColorRow("Ticker background", s.tickerBg) { v -> vm.updateSettings { it.copy(tickerBg = v) } }
}

@Composable
private fun BrandPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importLogo(u) }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(s.showLogo, { v -> vm.updateSettings { it.copy(showLogo = v) } }); Text("  Show logo on every card") }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { pickLogo.launch(arrayOf("image/png", "image/webp")) }) { Text("Upload PNG logo") }
        if (s.logoPath != null) OutlinedButton(onClick = { vm.updateSettings { it.copy(logoPath = null) } }) { Text("Use default") }
    }
    Row(verticalAlignment = Alignment.CenterVertically) { Switch(s.showChannelName, { v -> vm.updateSettings { it.copy(showChannelName = v) } }); Text("  Show channel name") }
    RtlField("Channel name", s.channelName, { v -> vm.updateSettings { it.copy(channelName = v) } })
    SliderRow("Logo size", s.logoSize, 0.06f..0.4f, "${(s.logoSize * 100).toInt()}%") { v -> vm.updateSettings { it.copy(logoSize = v) } }
    SliderRow("Logo opacity", s.logoOpacity, 0.1f..1f, "${(s.logoOpacity * 100).toInt()}%") { v -> vm.updateSettings { it.copy(logoOpacity = v) } }
    Text("Logo position for all cards:")
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(Opt.logoPositions.indices.toList()) { i ->
            FilterChip(selected = false, onClick = { vm.mutate { pr -> pr.copy(cards = pr.cards.map { it.copy(logoPos = i) }) } }, label = { Text(Opt.logoPositions[i]) })
        }
    }
}

@Composable
private fun AudioPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importAudio(u) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { pick.launch(arrayOf("audio/*")) }) { Text(if (s.audioPath == null) "Import audio" else "Replace audio") }
        if (s.audioPath != null) OutlinedButton(onClick = { vm.removeAudio() }) { Text("Remove") }
    }
    if (s.audioPath != null) {
        Text("Length: ${Timing.fmt(s.audioDurMs)}", style = MaterialTheme.typography.bodySmall)
        SliderRow("Volume", s.volume, 0f..2f, "${(s.volume * 100).toInt()}%") { vm.setVolume(it) }
    } else Text("MP3, WAV, M4A or AAC. Without audio the video ends at the last card.", style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun TimelineOptsPanel(vm: MainViewModel, p: Project) {
    val s = p.settings
    val total = Timing.totalMs(p)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(s.allowOverlap, { v -> vm.updateSettings { it.copy(allowOverlap = v) } })
        Text("  Allow overlapping cards (transitions)", Modifier.weight(1f))
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(s.ripple, { v -> vm.updateSettings { it.copy(ripple = v) } })
        Text("  Move following cards when I change a card's end time", Modifier.weight(1f))
    }
    OutlinedButton(onClick = { vm.distribute() }, modifier = Modifier.fillMaxWidth()) {
        Text("Distribute cards evenly over ${Timing.fmt(if (s.audioDurMs > 0) s.audioDurMs else p.cards.size * 5000L)}")
    }
    DropdownField("Video ends at", listOf("End of voice-over", "End of last card", "Custom time"), s.endMode, { v -> vm.updateSettings { it.copy(endMode = v) } })
    if (s.endMode == 2) TimeField("Custom end", if (s.customEndMs > 0) s.customEndMs else total, { v -> vm.updateSettings { it.copy(customEndMs = v) } })
    Timing.validate(p.cards, s.audioDurMs, s.allowOverlap).forEach { Text("⚠ ${it.text}", color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall) }
    Text("All cards", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
    p.cards.forEachIndexed { i, c ->
        Card(colors = CardDefaults.cardColors(containerColor = NavyC)) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Card ${i + 1}: ${c.headline.take(40)}", maxLines = 1)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TimeField("Start", c.startMs, { v -> vm.setTiming(c.id, v, null) }, Modifier.weight(1f))
                    TimeField("End", c.endMs, { v -> vm.setTiming(c.id, null, v) }, Modifier.weight(1f))
                }
                TimeField("Duration", c.endMs - c.startMs, { v -> vm.setDuration(c.id, v) }, Modifier.fillMaxWidth())
            }
        }
    }
}

// =====================================================================================
//  Full card editor
// =====================================================================================
@Composable
fun CardEditor(vm: MainViewModel, p: Project, id: String) {
    val c = p.cards.find { it.id == id } ?: run { vm.editingCard = null; return }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importCardImage(id, u) }
    var extraSlot by remember { mutableStateOf(0) }
    val pickExtra = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importExtraImage(id, extraSlot, u) }
    val dur = (c.endMs - c.startMs).coerceAtLeast(1L)
    var t by remember { mutableStateOf(dur.toFloat()) }
    var anim by remember { mutableStateOf(false) }
    LaunchedEffect(anim, c.id) {
        if (anim) {
            var last = withFrameNanos { it }
            t = 0f
            while (anim) {
                val now = withFrameNanos { it }
                t += (now - last) / 1_000_000f; last = now
                if (t > dur) { t = dur.toFloat(); anim = false }
            }
        }
    }
    val solo = remember(p, c) { p.copy(cards = listOf(c.copy(startMs = 0, endMs = dur))) }
    val tpl = c.template
    val slots = Opt.extraSlots(tpl)
    ScreenScaffold("Edit card", { vm.editingCard = null }) { pad ->
        Column(Modifier.padding(pad).padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            FramePreview(solo, { t.toLong() })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { anim = true }) { Icon(Icons.Default.PlayArrow, null); Text(" Play animation") }
                Text("  ${Timing.fmt(t.toLong())}")
            }
            Slider(value = t, onValueChange = { anim = false; t = it }, valueRange = 0f..dur.toFloat())

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(12.dp)) {
                    Text("⏱ Timing (manual)", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
                    TimingPanel(vm, p, c)
                }
            }

            DropdownField("Template", Opt.templates, tpl, { v -> vm.updateCard(id) { it.copy(template = v) } })
            RtlField("Headline (Urdu / English)", c.headline, { v -> vm.updateCard(id) { it.copy(headline = v) } }, minLines = 2)
            if (tpl != 2 && tpl != 5 && tpl != 9 && tpl != 11) RtlField("Description", c.description, { v -> vm.updateCard(id) { it.copy(description = v) } }, minLines = 2)
            if (tpl == 2 || tpl == 5 || tpl == 9 || tpl == 11) {
                RtlField("Team 1", c.team1, { v -> vm.updateCard(id) { it.copy(team1 = v) } })
                RtlField("Team 2", c.team2, { v -> vm.updateCard(id) { it.copy(team2 = v) } })
            }
            if (tpl == 2 || tpl == 5 || tpl == 9) {
                RtlField("Score (e.g. 182/4)", c.score, { v -> vm.updateCard(id) { it.copy(score = v) } })
                RtlField("Overs", c.overs, { v -> vm.updateCard(id) { it.copy(overs = v) } })
                RtlField("Wickets", c.wickets, { v -> vm.updateCard(id) { it.copy(wickets = v) } })
                RtlField("Match status", c.status, { v -> vm.updateCard(id) { it.copy(status = v) } })
            }
            if (tpl == 6 || tpl == 11) {
                RtlField("Player name", c.playerName, { v -> vm.updateCard(id) { it.copy(playerName = v) } })
                RtlField("Statistics (one per line, e.g. Runs: 85)", c.stats, { v -> vm.updateCard(id) { it.copy(stats = v) } }, minLines = 4)
            }
            SliderRow("Text size", c.textScale, 0.5f..1.6f, "${(c.textScale * 100).toInt()}%") { v -> vm.updateCard(id) { it.copy(textScale = v) } }
            ColorRow("Text colour", c.textColor) { v -> vm.updateCard(id) { it.copy(textColor = v) } }
            ColorRow("Background colour", c.bgColor) { v -> vm.updateCard(id) { it.copy(bgColor = v) } }

            Text("Main picture", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { pick.launch(arrayOf("image/jpeg", "image/png", "image/webp")) }) { Text(if (c.imagePath == null) "Add image" else "Replace image") }
                if (c.imagePath != null) OutlinedButton(onClick = { vm.updateCard(id) { it.copy(imagePath = null) } }) { Text("Remove") }
            }
            if (c.imagePath != null) {
                SliderRow("Zoom / crop", c.imgScale, 1f..3f, "x${"%.2f".format(c.imgScale)}") { v -> vm.updateCard(id) { it.copy(imgScale = v) } }
                SliderRow("Position left ↔ right", c.imgX, -1f..1f, "%.2f".format(c.imgX)) { v -> vm.updateCard(id) { it.copy(imgX = v) } }
                SliderRow("Position up ↕ down", c.imgY, -1f..1f, "%.2f".format(c.imgY)) { v -> vm.updateCard(id) { it.copy(imgY = v) } }
            }
            if (slots > 0) {
                Text("Match pictures (this template shows $slots more)", style = MaterialTheme.typography.titleSmall, color = Color(0xFFFFC107))
                for (slot in 0 until slots) {
                    val has = c.extraImages.getOrNull(slot)?.isNotBlank() == true
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { extraSlot = slot; pickExtra.launch(arrayOf("image/jpeg", "image/png", "image/webp")) }) {
                            Text(if (has) "Replace picture ${slot + 2}" else "Add picture ${slot + 2}")
                        }
                        if (has) OutlinedButton(onClick = { vm.removeExtraImage(id, slot) }) { Text("Remove") }
                    }
                }
            }
            DropdownField("Image animation", Opt.imageAnims, c.imageAnim, { v -> vm.updateCard(id) { it.copy(imageAnim = v) } })
            DropdownField("Text animation", Opt.textAnims, c.textAnim, { v -> vm.updateCard(id) { it.copy(textAnim = v) } })
            DropdownField("Transition into this card", Opt.transitions, c.transition, { v -> vm.updateCard(id) { it.copy(transition = v) } })
            SliderRow("Animation duration", c.animMs.toFloat(), 150f..2500f, "${c.animMs} ms") { v -> vm.updateCard(id) { it.copy(animMs = v.toInt()) } }
            SliderRow("Animation speed", c.animSpeed, 0.25f..3f, "x${"%.2f".format(c.animSpeed)}") { v -> vm.updateCard(id) { it.copy(animSpeed = v) } }
            DropdownField("Logo position", Opt.logoPositions, c.logoPos, { v -> vm.updateCard(id) { it.copy(logoPos = v) } })
            RtlField("Ticker text for this card (empty = project ticker)", c.tickerText, { v -> vm.updateCard(id) { it.copy(tickerText = v) } }, minLines = 2)
        }
    }
}

// =====================================================================================
//  Export screen
// =====================================================================================
@Composable
private fun ExportScreen(vm: MainViewModel, p: Project) {
    ScreenScaffold("Export video", { vm.showExport = false }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) { ExportTab(vm, p) }
    }
}

@Composable
fun ExportTab(vm: MainViewModel, p: Project) {
    val ctx = LocalContext.current
    val st by vm.settings.collectAsState()
    val state by ExportState.state.collectAsState()
    var res by remember(st.resolution) { mutableStateOf(st.resolution) }
    var fps by remember(st.fps) { mutableStateOf(st.fps) }
    var quality by remember { mutableStateOf(1) }
    var aq by remember { mutableStateOf(1) }
    var name by remember(p.id) { mutableStateOf("ZCH_" + p.name.replace(Regex("[^\\p{L}\\p{N}]+"), "_")) }
    val land = p.settings.landscape
    val total = Timing.totalMs(p)
    val longSide = if (res == 720) 1280 else 1920
    val w = if (land) longSide else res
    val h = if (land) res else longSide
    val baseBr = if (res == 720) intArrayOf(2_500_000, 4_000_000, 6_000_000) else intArrayOf(5_000_000, 8_000_000, 12_000_000)
    val vbr = (baseBr[quality] * fps / 30.0).toInt()
    val abr = intArrayOf(96_000, 128_000, 192_000)[aq]
    val legacyPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val needLegacy = android.os.Build.VERSION.SDK_INT < 29
    val running = state is ExportUi.Running
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Export settings", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFC107))
        Text("Resolution")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(720, 1080).forEach { r -> FilterChip(res == r, { res = r }, { Text("${r}p") }) } }
        Text("Aspect ratio")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(land, { vm.updateSettings { it.copy(landscape = true) } }, { Text("16:9") })
            FilterChip(!land, { vm.updateSettings { it.copy(landscape = false) } }, { Text("9:16") })
        }
        Text("Frame rate")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(24, 25, 30).forEach { f -> FilterChip(fps == f, { fps = f }, { Text("$f fps") }) } }
        DropdownField("Video quality", listOf("Low (small file)", "Medium", "High"), quality, { quality = it })
        DropdownField("Audio quality", listOf("96 kbps", "128 kbps", "192 kbps"), aq, { aq = it })
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Output file name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        val mb = (((vbr + abr) / 8.0) * total / 1000.0 / 1_000_000)
        Text("Output: ${w}×${h}, $fps fps, about ${"%.1f".format(mb)} MB, ${Timing.fmt(total)} long")
        if (total > 10 * 60_000L) Text("⚠ Long project: export may take a long time and a lot of storage.", color = Color(0xFFFFC107))
        if (res == 1080) Text("⚠ 1080p needs more time/memory on older phones. Use 720p if the export fails.", color = Color(0xFFFFC107), style = MaterialTheme.typography.bodySmall)
        if (p.cards.isEmpty()) Text("Add at least one card first.", color = Color(0xFFFF8A80))

        when (val s = state) {
            is ExportUi.Running -> {
                LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                Text("${(s.progress * 100).toInt()}%  ${s.msg}")
                Button(onClick = { vm.cancelExport() }) { Text("Cancel export") }
            }
            is ExportUi.Done -> {
                Text("✅ Export finished: Movies/ZCH NewsCard Studio", color = Color(0xFF69F0AE))
                Text("Find it in Recent Exports to play, share or delete.", style = MaterialTheme.typography.bodySmall)
            }
            is ExportUi.Failed -> Text("❌ Export failed: ${s.msg}", color = Color(0xFFFF8A80))
            ExportUi.Cancelled -> Text("Export cancelled.")
            ExportUi.Idle -> {}
        }
        if (p.exportStatus == "interrupted") Text("The previous export was interrupted. Start again to retry.", color = Color(0xFFFFC107))
        Button(enabled = !running && p.cards.isNotEmpty(), modifier = Modifier.fillMaxWidth(), onClick = {
            if (android.os.Build.VERSION.SDK_INT >= 33) notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            val ok = !needLegacy || androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (ok) vm.startExport(w, h, fps, vbr, abr, name, land, p.settings.endMode, p.settings.customEndMs)
            else {
                legacyPerm.launch(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE))
                vm.message = "Allow storage access, then press Export again"
            }
        }) { Text("Export MP4") }
        if (p.exports.isNotEmpty()) TextButton(onClick = { vm.go(Screen.Exports) }) { Text("Open Recent Exports") }
    }
}
